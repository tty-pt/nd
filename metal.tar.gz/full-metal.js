

window.env = {};

window.env.strout = function strout(memory, p, l) {
        var buf = new Uint8Array(memory.buffer, p, l);
        var s = "";
        var i;

        for (i = 0; i < l && buf[i]; i++)
                s += String.fromCharCode(buf[i]);

        return s;
};

function bcpy(bufd, bufo, d, o, len) {
        try {
                (new Uint8Array(bufd, d, len))
                        .set(new Uint8Array(bufo, o, len));

                return len;
        } catch (e) {
                console.error(e);
                return -1;
        }
}

function bmemcpy(memd, memo, d, o, len) {
        return bcpy(memd.buffer, memo.buffer, d, o, len);
}

var progs = { 0: 'kern' }

window.env.umem = function umem(pid, d, o, len) {
        return bmemcpy(memory, progs[pid].memory, d, o, len);
};

window.env.kmem = function kmem(pid, d, o, len) {
        return bmemcpy(progs[pid].memory, memory, d, o, len);
};



window.env.js_emem = function js_emem(ofs, p, p_len) {
        return bcpy(memory.buffer, shbuf, p, ofs, p_len);
}

window.env.evt_count = function evt_count(ms) {
        return 0;
};

window.env.js_run = function js_run(ptr, len) {
        var buf = new Uint8Array(memory.buffer, ptr, len);
        var path = _jsnstr(buf, len);

        run(path);
};

window.env.flush = function flush(p, l) {};
window.env.js_shutdown = function js_shutdown(e) {};
window.env.tty_read = function tty_read() {};


window.env.strin = function strin(mem, ptr, str, maxlen) {
        var wm = new Uint8Array(mem.buffer);
        var
 enc = new TextEncoder();
        var bbuf = enc.encode(str);
        var i;

        for (i = 0; i < bbuf.length; i++)
                wm[ptr + i] = bbuf[i];
        wm[ptr + i] = enc.encode("\0")[0];
};
(function() {
const kmem = window["env"].kmem;
const umem = window["env"].umem;
const flush = window["env"].flush;
const js_shutdown = window["env"].js_shutdown;
const js_emem = window["env"].js_emem;
const evt_count = window["env"].evt_count;
const tty_read = window["env"].tty_read;
const js_run = window["env"].js_run;
function asmFunc(global, env, buffer) {
 var HEAP8 = new global.Int8Array(buffer);
 var HEAP16 = new global.Int16Array(buffer);
 var HEAP32 = new global.Int32Array(buffer);
 var HEAPU8 = new global.Uint8Array(buffer);
 var HEAPU16 = new global.Uint16Array(buffer);
 var HEAPU32 = new global.Uint32Array(buffer);
 var HEAPF32 = new global.Float32Array(buffer);
 var HEAPF64 = new global.Float64Array(buffer);
 var Math_imul = global.Math.imul;
 var Math_fround = global.Math.fround;
 var Math_abs = global.Math.abs;
 var Math_clz32 = global.Math.clz32;
 var Math_min = global.Math.min;
 var Math_max = global.Math.max;
 var Math_floor = global.Math.floor;
 var Math_ceil = global.Math.ceil;
 var Math_sqrt = global.Math.sqrt;
 var abort = env.abort;
 var nan = global.NaN;
 var infinity = global.Infinity;
 var kmem = env.kmem;
 var umem = env.umem;
 var flush = env.flush;
 var js_shutdown = env.js_shutdown;
 var js_emem = env.js_emem;
 var evt_count = env.evt_count;
 var tty_read = env.tty_read;
 var js_run = env.js_run;
 var global$0 = 208032;
 var global$1 = 208032;
 var global$2 = 142492;
 var i64toi32_i32$HIGH_BITS = 0;
 function do_early_param($0, $1, $2, $3) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  $3 = $3 | 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  $2 = 83020;
  while (1) {
   label$2 : {
    if ($2 >>> 0 < 83024) {
     label$4 : {
      if (HEAP32[$2 + 8 >> 2]) {
       if (parameq($0, HEAP32[$2 >> 2])) {
        break label$4
       }
      }
      if (strcmp($0, 20204)) {
       break label$2
      }
      if (strcmp(HEAP32[$2 >> 2], 20212)) {
       break label$2
      }
     }
     if (!FUNCTION_TABLE[HEAP32[$2 + 4 >> 2]]($1)) {
      break label$2
     }
     HEAP32[$3 >> 2] = $0;
     printk(20221, $3);
     break label$2;
    }
    global$0 = $3 + 16 | 0;
    return 0;
   }
   $2 = $2 + 12 | 0;
   continue;
  };
 }
 function parse_early_param() {
  if (HEAPU8[140044]) {
   return
  }
  strlcpy();
  parse_args(20013, 140048, 0, 0, 0, 2);
  HEAP8[140044] = 1;
 }
 function start_kernel() {
  var $0 = 0, $1 = 0;
  $1 = global$0 - 48 | 0;
  global$0 = $1;
  HEAP32[HEAP32[257] + 24 >> 2] = 1470918301;
  HEAP8[65540] = 1;
  HEAP8[65556] = 0;
  boot_cpu_init();
  HEAP32[$1 + 32 >> 2] = 19936;
  printk(20027, $1 + 32 | 0);
  HEAP32[$1 + 44 >> 2] = 140560;
  parse_early_param();
  setup_processor();
  setup_arch_memory();
  $0 = HEAP32[$1 + 44 >> 2];
  add_device_randomness($0, strlen($0));
  memset(16136, 0, 4);
  printk(20032, 0);
  HEAP8[8492] = 1;
  build_all_zonelists();
  __cpuhp_setup_state_cpuslocked();
  HEAP32[$1 + 16 >> 2] = 140560;
  printk(20109, $1 + 16 | 0);
  parse_early_param();
  $0 = parse_args(20136, 0, 83012, -1, -1, 3);
  if (!(!$0 | $0 >>> 0 > 4294963200)) {
   parse_args(20151, $0, 0, -1, -1, 4)
  }
  HEAP8[65552] = 1;
  setup_log_buf();
  mem_init();
  HEAP32[20654] = 3;
  HEAP32[20653] = 15616;
  vmalloc_init();
  sched_init();
  if (HEAPU8[65556]) {
   HEAP8[65556] = 0
  }
  open_softirq(9, 20);
  init_timers();
  hrtimers_prepare_cpu();
  open_softirq(8, 13);
  HEAP32[1124] = 4492;
  HEAP32[1122] = 4484;
  HEAP32[16410] = 7;
  HEAP32[16404] = 8;
  timekeeping_init();
  HEAP32[2989] = 22;
  HEAP32[2987] = 0;
  HEAP8[79296] = 1;
  __printk_safe_flush(11948);
  HEAP8[65556] = 1;
  HEAP8[65540] = 0;
  HEAP32[20654] = 4;
  $0 = HEAP32[16386];
  if (!$0) {
   $0 = HEAP32[35268];
   if ($0) {
    FUNCTION_TABLE[$0]()
   }
   HEAP32[19830] = HEAP32[19830] + 1;
   global$0 = $1 + 48 | 0;
   return;
  }
  HEAP32[$1 >> 2] = $0;
  HEAP32[$1 + 4 >> 2] = HEAP32[16387];
  panic(20169, $1);
  abort();
 }
 function unknown_bootoption($0, $1, $2, $3) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  $3 = $3 | 0;
  var $4 = 0, $5 = 0, $6 = 0;
  $5 = global$0 - 16 | 0;
  global$0 = $5;
  repair_env_string($0, $1);
  $2 = 83020;
  label$1 : {
   label$2 : {
    label$3 : {
     while (1) {
      $3 = strlen(HEAP32[$2 >> 2]);
      label$5 : {
       if (!parameqn($0, HEAP32[$2 >> 2], $3)) {
        break label$5
       }
       if (HEAP32[$2 + 8 >> 2]) {
        $3 = HEAPU8[$0 + $3 | 0];
        if ($3 ? ($3 | 0) != 61 : 0) {
         break label$5
        }
        $6 = 1;
        break label$5;
       }
       $4 = HEAP32[$2 + 4 >> 2];
       if (!$4) {
        break label$3
       }
       if (FUNCTION_TABLE[$4]($0 + $3 | 0)) {
        break label$1
       }
      }
      $2 = $2 + 12 | 0;
      if ($2 >>> 0 < 83024) {
       continue
      }
      break;
     };
     if ($6) {
      break label$1
     }
     if (strchr($0)) {
      if (!$1) {
       break label$1
      }
      if (strchr($0) >>> 0 < $1 >>> 0) {
       break label$1
      }
     }
     if (HEAP32[16386]) {
      break label$1
     }
     if (!$1) {
      break label$2
     }
     $6 = $1 - $0 | 0;
     $2 = 8;
     $1 = 3520;
     while (1) {
      $3 = $1;
      $4 = HEAP32[$1 >> 2];
      if ($4) {
       if (!$2) {
        HEAP32[16387] = $0;
        HEAP32[16386] = 20252;
       }
       $1 = $3 + 4 | 0;
       $2 = $2 + -1 | 0;
       if (strncmp($0, $4, $6)) {
        continue
       }
      }
      break;
     };
     HEAP32[$3 >> 2] = $0;
     break label$1;
    }
    HEAP32[$5 >> 2] = HEAP32[$2 >> 2];
    printk(20312, $5);
    break label$1;
   }
   $1 = 8;
   $2 = 3568;
   while (1) {
    if (HEAP32[$2 >> 2]) {
     if (!$1) {
      HEAP32[16387] = $0;
      HEAP32[16386] = 20199;
     }
     $2 = $2 + 4 | 0;
     $1 = $1 + -1 | 0;
     continue;
    }
    break;
   };
   HEAP32[$2 >> 2] = $0;
  }
  global$0 = $5 + 16 | 0;
  return 0;
 }
 function set_init_arg($0, $1, $2, $3) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  $3 = $3 | 0;
  if (HEAP32[16386]) {
   return 0
  }
  repair_env_string($0, $1);
  $1 = 0;
  label$2 : {
   label$3 : {
    while (1) {
     if (!HEAP32[$1 + 3568 >> 2]) {
      break label$3
     }
     $1 = $1 + 4 | 0;
     if (($1 | 0) != 36) {
      continue
     }
     break;
    };
    HEAP32[16386] = 20199;
    $1 = 65548;
    break label$2;
   }
   $1 = $1 + 3568 | 0;
  }
  HEAP32[$1 >> 2] = $0;
  return 0;
 }
 function repair_env_string($0, $1) {
  var $2 = 0;
  $2 = global$0 - 16 | 0;
  global$0 = $2;
  label$1 : {
   label$2 : {
    if (!$1) {
     break label$2
    }
    if (($1 | 0) != ((strlen($0) + $0 | 0) + 1 | 0)) {
     if (((strlen($0) + $0 | 0) + 2 | 0) != ($1 | 0)) {
      break label$1
     }
     HEAP8[$1 + -2 | 0] = 61;
     memmove($1 + -1 | 0, $1, strlen($1) + 1 | 0);
     break label$2;
    }
    HEAP8[$1 + -1 | 0] = 61;
   }
   global$0 = $2 + 16 | 0;
   return;
  }
  HEAP32[$2 + 8 >> 2] = 20294;
  HEAP32[$2 + 4 >> 2] = 261;
  HEAP32[$2 >> 2] = 20287;
  printk(20256, $2);
  abort();
 }
 function irq_work_queue($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  $2 = HEAP32[$0 >> 2];
  $3 = $2 & 1;
  $1 = $2 & -2;
  label$1 : {
   while (1) {
    if (($1 | 0) == ($2 | 0)) {
     break label$1
    }
    $1 = $2;
    if (!$3) {
     continue
    }
    break;
   };
   return;
  }
  HEAP32[$0 >> 2] = $2 | 3;
  $1 = $0 + 4 | 0;
  label$3 : {
   if (!(HEAPU8[$0 | 0] & 4)) {
    llist_add_batch($1, $1, 3612);
    break label$3;
   }
   llist_add_batch($1, $1, 3608);
  }
 }
 function kallsyms_expand_symbol($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $3 = $0;
  $4 = HEAPU8[$0 | 0];
  $2 = 128;
  label$2 : while (1) {
   label$1 : {
    if (!$4) {
     break label$1
    }
    $4 = $4 + -1 | 0;
    $3 = $3 + 1 | 0;
    $0 = HEAPU16[HEAPU8[$3 | 0] << 1 >> 1];
    while (1) {
     $5 = HEAPU8[$0 | 0];
     if (!$5) {
      continue label$2
     }
     label$4 : {
      if ($6) {
       if ($2 >>> 0 < 2) {
        break label$1
       }
       HEAP8[$1 | 0] = $5;
       $2 = $2 + -1 | 0;
       $1 = $1 + 1 | 0;
       break label$4;
      }
      $6 = 1;
     }
     $0 = $0 + 1 | 0;
     continue;
    };
   }
   break;
  };
  if ($2) {
   HEAP8[$1 | 0] = 0
  }
 }
 function get_symbol_pos() {
  var $0 = 0;
  $0 = global$0 - 16 | 0;
  global$0 = $0;
  HEAP32[$0 + 8 >> 2] = 20437;
  HEAP32[$0 + 4 >> 2] = 206;
  HEAP32[$0 >> 2] = 20426;
  printk(20395, $0);
  abort();
 }
 function kallsyms_lookup($0, $1, $2) {
  HEAP8[$2 | 0] = 0;
  HEAP8[$2 + 127 | 0] = 0;
  if ($0 >>> 0 < 82988 | $0 >>> 0 > 82992 ? !($0 >>> 0 >= 82984 ? $0 >>> 0 <= 19428 : 0) : 0) {
   $2 = 0
  } else {
   kallsyms_expand_symbol(get_symbol_offset(get_symbol_pos()), $2);
   if ($1) {
    HEAP32[$1 >> 2] = 0
   }
  }
  return $2;
 }
 function get_symbol_offset($0) {
  var $1 = 0;
  $1 = $0 & 255;
  $0 = HEAP32[($0 >>> 6 & 67108860) >> 2];
  while (1) {
   if ($1) {
    $1 = $1 + -1 | 0;
    $0 = (HEAPU8[$0 | 0] + $0 | 0) + 1 | 0;
    continue;
   }
   break;
  };
  return $0;
 }
 function __sprint_symbol($0, $1, $2, $3) {
  var $4 = 0, $5 = 0;
  $4 = global$0 + -64 | 0;
  global$0 = $4;
  $5 = kallsyms_lookup($1 + $2 | 0, $4 + 60 | 0, $0);
  label$1 : {
   if ($5) {
    if (($0 | 0) != ($5 | 0)) {
     strcpy($0, $5)
    }
    $1 = strlen($0);
    $2 = HEAP32[$4 + 56 >> 2] - $2 | 0;
    HEAP32[$4 + 56 >> 2] = $2;
    if ($3) {
     HEAP32[$4 + 36 >> 2] = HEAP32[$4 + 52 >> 2];
     HEAP32[$4 + 32 >> 2] = $2;
     $1 = sprintf($0 + $1 | 0, 20458, $4 + 32 | 0) + $1 | 0;
    }
    $2 = HEAP32[$4 + 60 >> 2];
    if (!$2) {
     break label$1
    }
    HEAP32[$4 + 16 >> 2] = $2;
    sprintf($0 + $1 | 0, 20469, $4 + 16 | 0);
    break label$1;
   }
   HEAP32[$4 >> 2] = $1;
   sprintf($0, 20452, $4);
  }
  global$0 = $4 - -64 | 0;
 }
 function __put_cred($0) {
  var $1 = 0, $2 = 0;
  $1 = global$0 - 48 | 0;
  global$0 = $1;
  label$1 : {
   label$2 : {
    if (!HEAP32[$0 >> 2]) {
     $2 = HEAP32[2];
     if (HEAP32[$2 + 696 >> 2] == ($0 | 0)) {
      break label$2
     }
     if (HEAP32[$2 + 692 >> 2] == ($0 | 0)) {
      break label$1
     }
     call_rcu($0 + 92 | 0, 5);
     global$0 = $1 + 48 | 0;
     return;
    }
    HEAP32[$1 + 40 >> 2] = 20513;
    HEAP32[$1 + 36 >> 2] = 141;
    HEAP32[$1 + 32 >> 2] = 20506;
    printk(20475, $1 + 32 | 0);
    abort();
   }
   HEAP32[$1 + 8 >> 2] = 20513;
   HEAP32[$1 + 4 >> 2] = 147;
   HEAP32[$1 >> 2] = 20506;
   printk(20475, $1);
   abort();
  }
  HEAP32[$1 + 24 >> 2] = 20513;
  HEAP32[$1 + 20 >> 2] = 148;
  HEAP32[$1 + 16 >> 2] = 20506;
  printk(20475, $1 + 16 | 0);
  abort();
 }
 function put_cred_rcu($0) {
  $0 = $0 | 0;
  var $1 = 0, $2 = 0;
  $1 = global$0 - 16 | 0;
  global$0 = $1;
  $0 = $0 + -92 | 0;
  if (!HEAP32[$0 >> 2]) {
   $2 = HEAP32[$0 + 88 >> 2];
   if ($2) {
    HEAP32[$2 >> 2] = HEAP32[$2 >> 2] + -1
   }
   free_uid(HEAP32[$0 + 80 >> 2]);
   kmem_cache_free(HEAP32[16390], $0);
   global$0 = $1 + 16 | 0;
   return;
  }
  HEAP32[$1 + 4 >> 2] = HEAP32[$0 >> 2];
  HEAP32[$1 >> 2] = $0;
  panic(20524, $1);
  abort();
 }
 function exit_creds($0) {
  var $1 = 0, $2 = 0;
  $1 = HEAP32[$0 + 692 >> 2];
  HEAP32[$0 + 692 >> 2] = 0;
  $2 = HEAP32[$1 >> 2] + -1 | 0;
  HEAP32[$1 >> 2] = $2;
  if (!$2) {
   __put_cred($1)
  }
  $1 = HEAP32[$0 + 696 >> 2];
  HEAP32[$0 + 696 >> 2] = 0;
  $0 = HEAP32[$1 >> 2] + -1 | 0;
  HEAP32[$1 >> 2] = $0;
  if ($0) {
   return
  }
  __put_cred($1);
 }
 function notifier_call_chain($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0;
  $3 = -1;
  $0 = HEAP32[$0 >> 2];
  while (1) {
   if (!(!$0 | !$3)) {
    $4 = HEAP32[$0 + 4 >> 2];
    $5 = FUNCTION_TABLE[HEAP32[$0 >> 2]]($0, $1, $2) | 0;
    $3 = $3 + -1 | 0;
    $0 = $4;
    if (!($5 & 32768)) {
     continue
    }
   }
   break;
  };
 }
 function atomic_notifier_call_chain($0, $1, $2) {
  notifier_call_chain($0, $1, $2);
 }
 function sys_ni_syscall() {
  return -38;
 }
 function kthread_data($0) {
  return HEAP32[HEAP32[$0 + 604 >> 2] + 8 >> 2];
 }
 function kthread_probe_data($0) {
  var $1 = 0;
  $1 = global$0 - 16 | 0;
  global$0 = $1;
  $0 = HEAP32[$0 + 604 >> 2];
  HEAP32[$1 + 12 >> 2] = 0;
  __probe_kernel_read($1 + 12 | 0, $0 + 8 | 0, 4);
  global$0 = $1 + 16 | 0;
  return HEAP32[$1 + 12 >> 2];
 }
 function parameqn($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $6 = 1;
  label$1 : {
   while (1) {
    if ($3 >>> 0 >= $2 >>> 0) {
     break label$1
    }
    $4 = $1 + $3 | 0;
    $5 = $0 + $3 | 0;
    $3 = $3 + 1 | 0;
    $5 = HEAPU8[$5 | 0];
    $4 = HEAPU8[$4 | 0];
    if (((($5 | 0) == 45 ? 95 : $5) | 0) == ((($4 | 0) == 45 ? 95 : $4) | 0)) {
     continue
    }
    break;
   };
   $6 = 0;
  }
  return $6;
 }
 function parameq($0, $1) {
  return parameqn($0, $1, strlen($0) + 1 | 0);
 }
 function parse_args($0, $1, $2, $3, $4, $5) {
  var $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0;
  $6 = global$0 + -64 | 0;
  global$0 = $6;
  $10 = skip_spaces($1);
  label$1 : {
   while (1) {
    if (!HEAPU8[$10 | 0]) {
     break label$1
    }
    $10 = next_arg($10, $6 + 60 | 0, $6 + 56 | 0);
    label$3 : {
     $9 = HEAP32[$6 + 56 >> 2];
     if (!$9) {
      if (!strcmp(HEAP32[$6 + 60 >> 2], 20568)) {
       break label$3
      }
      $9 = HEAP32[$6 + 56 >> 2];
     }
     $8 = 0;
     $11 = HEAP32[$6 + 60 >> 2];
     $1 = $2;
     label$5 : {
      label$6 : {
       label$7 : {
        label$8 : {
         label$9 : {
          label$10 : {
           label$11 : {
            label$12 : {
             while (1) {
              if ($8 >>> 0 >= 0) {
               break label$12
              }
              if (!parameq($11, HEAP32[$1 >> 2])) {
               $1 = $1 + 20 | 0;
               $8 = $8 + 1 | 0;
               continue;
              }
              break;
             };
             $8 = HEAP8[$1 + 14 | 0];
             if (($8 | 0) < ($3 | 0) | ($8 | 0) > ($4 | 0)) {
              continue
             }
             if (HEAP8[HEAP32[$1 + 8 >> 2]] & 1 ? 0 : !$9) {
              break label$6
             }
             if (HEAP8[$1 + 15 | 0] & 1) {
              break label$11
             }
             break label$10;
            }
            if (!$5) {
             break label$8
            }
            $1 = FUNCTION_TABLE[$5]($11, $9, $0, 0) | 0;
            if (!$1) {
             continue
            }
            break label$9;
           }
           HEAP32[$6 + 48 >> 2] = HEAP32[$1 >> 2];
           printk(20682, $6 + 48 | 0);
           add_taint(6, 0);
          }
          $1 = FUNCTION_TABLE[HEAP32[HEAP32[$1 + 8 >> 2] + 4 >> 2]]($9, $1) | 0;
          if (!$1) {
           continue
          }
         }
         if (($1 | 0) == -28) {
          break label$7
         }
         if (($1 | 0) != -2) {
          break label$5
         }
        }
        HEAP32[$6 + 20 >> 2] = HEAP32[$6 + 60 >> 2];
        HEAP32[$6 + 16 >> 2] = $0;
        printk(20571, $6 + 16 | 0);
        $7 = -2;
        continue;
       }
       HEAP32[$6 + 40 >> 2] = HEAP32[$6 + 60 >> 2];
       HEAP32[$6 + 32 >> 2] = $0;
       $1 = HEAP32[$6 + 56 >> 2];
       HEAP32[$6 + 36 >> 2] = $1 ? $1 : 20642;
       printk(20601, $6 + 32 | 0);
       $7 = -28;
       continue;
      }
      $1 = -22;
     }
     HEAP32[$6 + 8 >> 2] = HEAP32[$6 + 60 >> 2];
     HEAP32[$6 >> 2] = $0;
     $7 = HEAP32[$6 + 56 >> 2];
     HEAP32[$6 + 4 >> 2] = $7 ? $7 : 20642;
     printk(20643, $6);
     $7 = $1;
     continue;
    }
    break;
   };
   $7 = $7 ? $7 : $10;
  }
  global$0 = $6 - -64 | 0;
  return $7;
 }
 function wq_worker_waking_up($0) {
  $0 = kthread_data($0);
  if (HEAPU16[$0 + 48 >> 1] & 456) {
   return
  }
  $0 = HEAP32[$0 + 32 >> 2];
  HEAP32[$0 + 380 >> 2] = HEAP32[$0 + 380 >> 2] + 1;
 }
 function wq_worker_sleeping($0) {
  var $1 = 0;
  label$1 : {
   $0 = kthread_data($0);
   if (HEAPU16[$0 + 48 >> 1] & 456) {
    break label$1
   }
   $0 = HEAP32[$0 + 32 >> 2];
   if (HEAP32[$0 >> 2]) {
    break label$1
   }
   $1 = HEAP32[$0 + 380 >> 2] + -1 | 0;
   HEAP32[$0 + 380 >> 2] = $1;
   if (HEAP32[$0 + 20 >> 2] == ($0 + 20 | 0) | $1) {
    break label$1
   }
   $1 = HEAP32[$0 + 36 >> 2];
   if (!$1 | ($1 | 0) == ($0 + 36 | 0)) {
    break label$1
   }
   return HEAP32[$1 + 28 >> 2];
  }
  return 0;
 }
 function queue_work_on($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  $5 = HEAP32[16394];
  HEAP32[16394] = 0;
  $4 = HEAP32[$2 >> 2];
  HEAP32[$3 + 12 >> 2] = $4;
  label$1 : {
   if (HEAP32[$3 + 12 >> 2] & 1) {
    break label$1
   }
   HEAP32[$2 >> 2] = $4 | 1;
   if ($4 & 1) {
    break label$1
   }
   __queue_work($0, $1, $2);
  }
  HEAP32[16394] = $5;
  global$0 = $3 + 16 | 0;
 }
 function __queue_work($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  label$1 : {
   if (HEAP8[$1 + 130 | 0] & 1) {
    if (HEAP32[1] & 2031872) {
     break label$1
    }
    $3 = HEAP32[2];
    if (!(HEAPU8[$3 + 12 | 0] & 32)) {
     break label$1
    }
    $3 = kthread_data($3);
    if (!$3 | HEAP32[HEAP32[$3 + 16 >> 2] + 4 >> 2] != ($1 | 0)) {
     break label$1
    }
   }
   $4 = $1 + 128 | 0;
   $6 = $1 + 132 | 0;
   $7 = $1 + 136 | 0;
   $5 = ($0 | 0) != 1;
   $0 = 0;
   label$3 : {
    if (!$5) {
     break label$3
    }
    $0 = 1;
   }
   while (1) {
    label$5 : {
     label$7 : {
      label$8 : {
       label$9 : {
        label$10 : {
         label$11 : {
          label$12 : {
           if (!$0) {
            if (HEAPU8[65564] == 1) {
             break label$12
            }
            $0 = 1;
            continue;
           }
           if (HEAPU8[$4 | 0] & 2) {
            $3 = HEAP32[$7 >> 2]
           } else {
            $3 = HEAP32[$6 >> 2]
           }
           $0 = get_work_pool($2);
           label$17 : {
            if (!(!$0 | ($0 | 0) == HEAP32[$3 >> 2])) {
             $0 = find_worker_executing_work($0, $2);
             if ($0) {
              $0 = HEAP32[$0 + 16 >> 2];
              if (HEAP32[$0 + 4 >> 2] == ($1 | 0)) {
               break label$17
              }
             }
            }
            $0 = $3;
           }
           if (HEAP32[$0 + 16 >> 2] | !(HEAPU8[$4 | 0] & 2)) {
            break label$11
           }
           if (!$5) {
            break label$10
           }
           break label$9;
          }
          if (HEAPU8[65580]) {
           break label$8
          }
          printk(20788, 0);
          HEAP8[65580] = 1;
          break label$7;
         }
         label$21 : {
          if (HEAP32[$2 + 4 >> 2] == ($2 + 4 | 0)) {
           $1 = ((HEAP32[$0 + 8 >> 2] << 2) + $0 | 0) + 20 | 0;
           HEAP32[$1 >> 2] = HEAP32[$1 >> 2] + 1;
           $3 = HEAP32[$0 + 8 >> 2] << 4;
           $1 = HEAP32[$0 + 80 >> 2];
           if (($1 | 0) >= HEAP32[$0 + 84 >> 2]) {
            break label$21
           }
           HEAP32[$0 + 80 >> 2] = $1 + 1;
           $1 = HEAP32[$0 >> 2];
           $4 = $1 + 20 | 0;
           if (($4 | 0) != HEAP32[$1 + 20 >> 2]) {
            break label$5
           }
           HEAP32[$1 + 16 >> 2] = HEAP32[20749];
           break label$5;
          }
          return;
         }
         $4 = $0 + 88 | 0;
         $3 = $3 | 2;
         break label$5;
        }
        $0 = 0;
        continue;
       }
       $0 = 1;
       continue;
      }
      $0 = 1;
      continue;
     }
     $0 = 1;
     continue;
    }
    break;
   };
   insert_work($0, $2, $4, $3);
  }
 }
 function get_work_pool($0) {
  $0 = HEAP32[$0 >> 2];
  if (!($0 & 4)) {
   $0 = $0 >>> 5 | 0;
   if (($0 | 0) != 134217727) {
    $0 = __radix_tree_lookup($0 - HEAP32[974] | 0)
   } else {
    $0 = 0
   }
   return $0;
  }
  return HEAP32[($0 & -256) >> 2];
 }
 function find_worker_executing_work($0, $1) {
  var $2 = 0;
  $0 = ((Math_imul($1, 1640531527) >>> 24 & 252) + $0 | 0) + 84 | 0;
  $2 = $1 + 12 | 0;
  while (1) {
   $0 = HEAP32[$0 >> 2];
   if ($0) {
    if (HEAP32[$0 + 8 >> 2] != ($1 | 0) | HEAP32[$0 + 12 >> 2] != HEAP32[$2 >> 2]) {
     continue
    }
   }
   break;
  };
  return $0;
 }
 function insert_work($0, $1, $2, $3) {
  var $4 = 0;
  HEAP32[$1 >> 2] = $0 | $3 | 5;
  $3 = HEAP32[$2 + 4 >> 2];
  $4 = $1 + 4 | 0;
  HEAP32[$2 + 4 >> 2] = $4;
  HEAP32[$3 >> 2] = $4;
  HEAP32[$1 + 4 >> 2] = $2;
  HEAP32[$1 + 8 >> 2] = $3;
  HEAP32[$0 + 16 >> 2] = HEAP32[$0 + 16 >> 2] + 1;
  $0 = HEAP32[$0 >> 2];
  if (HEAP32[$0 + 380 >> 2]) {
   return
  }
  $1 = HEAP32[$0 + 36 >> 2];
  if (!(!$1 | ($0 + 36 | 0) == ($1 | 0))) {
   wake_up_process(HEAP32[$1 + 28 >> 2])
  }
 }
 function mod_delayed_work_on($0, $1) {
  var $2 = 0, $3 = 0;
  $2 = global$0 - 16 | 0;
  global$0 = $2;
  while (1) {
   $3 = try_to_grab_pending($1, $2 + 12 | 0);
   if (($3 | 0) == -11) {
    continue
   }
   break;
  };
  if (($3 | 0) >= 0) {
   __queue_work(1, $0, $1);
   HEAP32[16394] = HEAP32[$2 + 12 >> 2];
  }
  global$0 = $2 + 16 | 0;
 }
 function try_to_grab_pending($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  $4 = global$0 - 16 | 0;
  global$0 = $4;
  $3 = HEAP32[16394];
  HEAP32[16394] = 0;
  HEAP32[$1 >> 2] = $3;
  $2 = 1;
  label$1 : {
   if (del_timer($0 + 16 | 0)) {
    break label$1
   }
   $3 = HEAP32[$0 >> 2];
   HEAP32[$4 + 12 >> 2] = $3;
   if (!(HEAP32[$4 + 12 >> 2] & 1)) {
    HEAP32[$0 >> 2] = $3 | 1;
    $2 = 0;
    if (!($3 & 1)) {
     break label$1
    }
   }
   label$4 : {
    $5 = get_work_pool($0);
    if ($5) {
     label$6 : {
      $3 = HEAP32[$0 >> 2];
      if (!($3 & 4)) {
       break label$6
      }
      $6 = $3 & -256;
      if (!$6) {
       break label$6
      }
      if (($5 | 0) == HEAP32[$6 >> 2]) {
       break label$4
      }
     }
    }
    HEAP32[16394] = HEAP32[$1 >> 2];
    $2 = (HEAP32[$0 >> 2] & 20) == 16 ? -2 : -11;
    break label$1;
   }
   if ($3 & 2) {
    pwq_activate_delayed_work($0);
    $3 = HEAP32[$0 >> 2];
   }
   $1 = $0 + 8 | 0;
   $2 = HEAP32[$1 >> 2];
   $7 = HEAP32[$0 + 4 >> 2];
   HEAP32[$2 >> 2] = $7;
   HEAP32[$7 + 4 >> 2] = $2;
   $2 = $0 + 4 | 0;
   HEAP32[$0 + 4 >> 2] = $2;
   HEAP32[$1 >> 2] = $2;
   pwq_dec_nr_in_flight($6, $3 >>> 4 & 15);
   HEAP32[$0 >> 2] = HEAP32[$5 + 8 >> 2] << 5 | 1;
   $2 = 1;
  }
  $0 = $2;
  global$0 = $4 + 16 | 0;
  return $0;
 }
 function pwq_activate_delayed_work($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  $1 = HEAP32[$0 >> 2];
  $1 = $1 << 29 >> 31 & $1 & -256;
  $2 = HEAP32[$1 >> 2];
  $3 = $2 + 20 | 0;
  if (($3 | 0) == HEAP32[$2 + 20 >> 2]) {
   HEAP32[$2 + 16 >> 2] = HEAP32[20749]
  }
  move_linked_works($0, $3);
  HEAP32[$0 >> 2] = HEAP32[$0 >> 2] & -3;
  HEAP32[$1 + 80 >> 2] = HEAP32[$1 + 80 >> 2] + 1;
 }
 function pwq_dec_nr_in_flight($0, $1) {
  var $2 = 0, $3 = 0;
  label$1 : {
   if (($1 | 0) == 15) {
    break label$1
   }
   $2 = (($1 << 2) + $0 | 0) + 20 | 0;
   HEAP32[$2 >> 2] = HEAP32[$2 >> 2] + -1;
   $3 = HEAP32[$0 + 80 >> 2];
   HEAP32[$0 + 80 >> 2] = $3 + -1;
   if (!(HEAP32[$0 + 88 >> 2] == ($0 + 88 | 0) | ($3 | 0) > HEAP32[$0 + 84 >> 2])) {
    pwq_activate_delayed_work(HEAP32[$0 + 88 >> 2] + -4 | 0)
   }
   if (HEAP32[$2 >> 2] | HEAP32[$0 + 12 >> 2] != ($1 | 0)) {
    break label$1
   }
   HEAP32[$0 + 12 >> 2] = -1;
   $1 = HEAP32[$0 + 4 >> 2];
   $2 = HEAP32[$1 + 36 >> 2] + -1 | 0;
   HEAP32[$1 + 36 >> 2] = $2;
   if ($2) {
    break label$1
   }
   complete(HEAP32[$1 + 40 >> 2] + 12 | 0);
  }
  put_pwq($0);
 }
 function check_flush_dependency($0) {
  label$1 : {
   if (HEAPU8[$0 + 128 | 0] & 8 | HEAP32[1] & 2031872) {
    break label$1
   }
   $0 = HEAP32[2];
   if (!(HEAPU8[$0 + 12 | 0] & 32)) {
    break label$1
   }
   kthread_data($0);
  }
 }
 function __flush_work() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0;
  $0 = global$0 - 32 | 0;
  global$0 = $0;
  label$1 : {
   if (!HEAPU8[65565]) {
    break label$1
   }
   HEAP32[16394] = 0;
   label$2 : {
    label$3 : {
     label$4 : {
      $1 = get_work_pool(16888);
      if ($1) {
       $2 = HEAP32[4222];
       $2 = $2 << 29 >> 31 & $2 & -256;
       if (!$2) {
        break label$4
       }
       if (($1 | 0) == HEAP32[$2 >> 2]) {
        break label$3
       }
       break label$2;
      }
      HEAP32[16394] = 1;
      break label$1;
     }
     $3 = find_worker_executing_work($1, 16888);
     if (!$3) {
      break label$2
     }
     $2 = HEAP32[$3 + 16 >> 2];
    }
    check_flush_dependency(HEAP32[$2 + 4 >> 2]);
    $1 = $0 | 4;
    HEAP32[$0 + 8 >> 2] = $1;
    HEAP32[$0 + 12 >> 2] = 6;
    HEAP32[$0 + 4 >> 2] = $1;
    HEAP32[$0 >> 2] = -31;
    HEAP32[$0 + 16 >> 2] = 0;
    __init_waitqueue_head($0 + 20 | 0);
    HEAP32[$0 + 28 >> 2] = HEAP32[2];
    label$6 : {
     if ($3) {
      $3 = HEAP32[$3 + 20 >> 2];
      $1 = 240;
      break label$6;
     }
     $1 = HEAP32[4222];
     HEAP32[4222] = $1 | 8;
     $3 = HEAP32[4223];
     $1 = $1 & 8 | 240;
    }
    insert_work($2, $0, $3, $1);
    HEAP32[16394] = 1;
    wait_for_common($0 + 16 | 0);
    break label$1;
   }
   HEAP32[16394] = 1;
  }
  global$0 = $0 + 32 | 0;
 }
 function wq_barrier_func($0) {
  $0 = $0 | 0;
  complete($0 + 16 | 0);
 }
 function put_pwq($0) {
  var $1 = 0;
  $1 = HEAP32[$0 + 16 >> 2] + -1 | 0;
  HEAP32[$0 + 16 >> 2] = $1;
  if (!(!(HEAPU8[HEAP32[$0 + 4 >> 2] + 128 | 0] & 2) | $1)) {
   queue_work_on(1, HEAP32[16393], $0 + 112 | 0)
  }
 }
 function print_worker_info($0) {
  var $1 = 0, $2 = 0;
  $1 = global$0 - 112 | 0;
  global$0 = $1;
  HEAP32[$1 + 108 >> 2] = 0;
  $2 = $1 + 96 | 0;
  HEAP32[$2 >> 2] = 0;
  HEAP32[$2 + 4 >> 2] = 0;
  HEAP32[$1 + 88 >> 2] = 0;
  HEAP32[$1 + 92 >> 2] = 0;
  HEAP32[$1 + 80 >> 2] = 0;
  HEAP32[$1 + 84 >> 2] = 0;
  $2 = $1 - -64 | 0;
  HEAP32[$2 >> 2] = 0;
  HEAP32[$2 + 4 >> 2] = 0;
  HEAP32[$1 + 56 >> 2] = 0;
  HEAP32[$1 + 60 >> 2] = 0;
  HEAP32[$1 + 48 >> 2] = 0;
  HEAP32[$1 + 52 >> 2] = 0;
  HEAP32[$1 + 44 >> 2] = 0;
  HEAP32[$1 + 40 >> 2] = 0;
  label$1 : {
   if (!(HEAPU8[$0 + 12 | 0] & 32)) {
    break label$1
   }
   $0 = kthread_probe_data($0);
   __probe_kernel_read($1 + 108 | 0, $0 + 12 | 0, 4);
   __probe_kernel_read($1 + 44 | 0, $0 + 16 | 0, 4);
   __probe_kernel_read($1 + 40 | 0, HEAP32[$1 + 44 >> 2] + 4 | 0, 4);
   __probe_kernel_read($1 + 80 | 0, HEAP32[$1 + 40 >> 2] + 88 | 0, 23);
   __probe_kernel_read($1 + 48 | 0, $0 + 56 | 0, 23);
   $0 = HEAP32[$1 + 108 >> 2];
   if (HEAPU8[$1 + 48 | 0] | HEAPU8[$1 + 80 | 0] ? 0 : !$0) {
    break label$1
   }
   HEAP32[$1 + 24 >> 2] = $0;
   HEAP32[$1 + 16 >> 2] = 32649;
   HEAP32[$1 + 20 >> 2] = $1 + 80;
   printk(20756, $1 + 16 | 0);
   if (strcmp($1 + 80 | 0, $1 + 48 | 0)) {
    HEAP32[$1 >> 2] = $1 + 48;
    printk(20776, $1);
   }
   printk(20784, 0);
  }
  global$0 = $1 + 112 | 0;
 }
 function move_linked_works($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $4 = $0 + 4 | 0;
  while (1) {
   $3 = HEAP32[$0 + 4 >> 2];
   $5 = $0 + 8 | 0;
   $2 = HEAP32[$5 >> 2];
   HEAP32[$3 + 4 >> 2] = $2;
   HEAP32[$2 >> 2] = $3;
   $2 = $1 + 4 | 0;
   $3 = HEAP32[$2 >> 2];
   $6 = $2;
   $2 = $0 + 4 | 0;
   HEAP32[$6 >> 2] = $2;
   HEAP32[$3 >> 2] = $2;
   $4 = HEAP32[$4 >> 2];
   HEAP32[$0 + 4 >> 2] = $1;
   HEAP32[$5 >> 2] = $3;
   $3 = $4 + -4 | 0;
   if (HEAPU8[$0 | 0] & 8) {
    $0 = $3;
    continue;
   }
   break;
  };
 }
 function signal_wake_up_state($0, $1) {
  var $2 = 0;
  $2 = HEAP32[$0 + 4 >> 2];
  HEAP32[$2 >> 2] = HEAP32[$2 >> 2] | 4;
  try_to_wake_up($0, $1 | 1, 0);
 }
 function task_clear_jobctl_trapping($0) {
  var $1 = 0;
  $1 = HEAP32[$0 + 428 >> 2];
  if (!($1 & 2097152)) {
   return
  }
  $0 = $0 + 428 | 0;
  HEAP32[$0 >> 2] = $1 & -2097153;
  __wake_up_bit((Math_imul($0 << 5 | 21, 1640531527) >>> 21 & 2040) + 13568 | 0, $0);
 }
 function task_clear_jobctl_pending($0) {
  var $1 = 0, $2 = 0;
  $1 = global$0 - 16 | 0;
  global$0 = $1;
  $2 = HEAP32[$0 + 428 >> 2] & -2031617;
  HEAP32[$0 + 428 >> 2] = $2;
  if (!($2 & 1703936)) {
   task_clear_jobctl_trapping($0)
  }
  global$0 = $1 + 16 | 0;
 }
 function __send_signal($0) {
  var $1 = 0;
  label$1 : {
   if (!prepare_signal($0)) {
    break label$1
   }
   $1 = HEAP32[$0 + 732 >> 2] + 32 | 0;
   if (HEAP32[$1 + 8 >> 2] & 256) {
    break label$1
   }
   HEAP32[$1 + 8 >> 2] = HEAP32[$1 + 8 >> 2] | 256;
   complete_signal($0);
  }
 }
 function do_send_sig_info($0) {
  var $1 = 0;
  $1 = global$0 - 16 | 0;
  global$0 = $1;
  if (__lock_task_sighand($0, $1 + 12 | 0)) {
   __send_signal($0);
   HEAP32[16398] = HEAP32[$1 + 12 >> 2];
  }
  global$0 = $1 + 16 | 0;
 }
 function __lock_task_sighand($0, $1) {
  var $2 = 0, $3 = 0;
  $0 = $0 + 736 | 0;
  while (1) {
   label$1 : {
    $2 = HEAP32[$0 >> 2];
    if (!$2) {
     break label$1
    }
    $3 = HEAP32[16398];
    HEAP32[16398] = 0;
    HEAP32[$1 >> 2] = $3;
    if (HEAP32[$0 >> 2] == ($2 | 0)) {
     break label$1
    }
    HEAP32[16398] = HEAP32[$1 >> 2];
    continue;
   }
   break;
  };
  return $2;
 }
 function prepare_signal($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  $2 = global$0 - 16 | 0;
  global$0 = $2;
  $3 = HEAP32[$0 + 732 >> 2];
  $1 = HEAP32[$3 + 64 >> 2];
  label$1 : {
   if ($1 & 12) {
    if (!($1 & 4)) {
     $1 = 1;
     break label$1;
    }
   }
   if (!(HEAP32[$0 + 740 >> 2] & 256 | HEAP32[$0 + 744 >> 2] & 256)) {
    $1 = 0;
    if (HEAP32[$0 + 500 >> 2] == 1 ? 256 : 0) {
     break label$1
    }
    $0 = HEAP32[HEAP32[$0 + 736 >> 2] + 100 >> 2];
    if (($0 | 0) == 1 ? $0 | !(HEAP32[$3 + 64 >> 2] & 64) : 0) {
     break label$1
    }
    $1 = 1;
    if ($0) {
     break label$1
    }
    break label$1;
   }
   $1 = 1;
  }
  global$0 = $2 + 16 | 0;
  return $1;
 }
 function complete_signal($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  $2 = HEAP32[$0 + 732 >> 2];
  label$1 : {
   label$4 : {
    if (!(HEAP32[$0 + 740 >> 2] & 256 | HEAPU8[$0 + 12 | 0] & 4)) {
     $1 = $0;
     break label$4;
    }
    if (HEAP32[$0 + 584 >> 2] == ($0 + 584 | 0)) {
     break label$1
    }
    $3 = HEAP32[$2 + 28 >> 2];
    $1 = $3;
    while (1) {
     if (HEAP32[$1 + 740 >> 2] & 256 | HEAPU8[$1 + 12 | 0] & 4) {
      $1 = HEAP32[$1 + 584 >> 2] + -584 | 0;
      if (($1 | 0) != ($3 | 0)) {
       continue
      }
      break label$1;
     }
     break;
    };
    HEAP32[$2 + 28 >> 2] = $1;
   }
   if (!(HEAP32[$1 + 744 >> 2] & 256 | (HEAP32[HEAP32[$0 + 736 >> 2] + 100 >> 2] | HEAPU8[$2 + 64 | 0] & 4))) {
    HEAP32[$2 + 48 >> 2] = 9;
    HEAP32[$2 + 60 >> 2] = 0;
    HEAP32[$2 + 64 >> 2] = 4;
    $1 = $0;
    while (1) {
     task_clear_jobctl_pending($1);
     $2 = $1 + 760 | 0;
     HEAP32[$2 >> 2] = HEAP32[$2 >> 2] | 256;
     signal_wake_up_state($1, 256);
     $1 = HEAP32[$1 + 584 >> 2] + -584 | 0;
     if (($1 | 0) != ($0 | 0)) {
      continue
     }
     break;
    };
    break label$1;
   }
   signal_wake_up_state($1, 256);
  }
 }
 function do_no_restart_syscall($0) {
  $0 = $0 | 0;
  return -4;
 }
 function free_uid($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0;
  $2 = global$0 - 16 | 0;
  global$0 = $2;
  label$1 : {
   if (!$0) {
    break label$1
   }
   if (!refcount_dec_and_lock_irqsave($0, $2 + 12 | 0)) {
    break label$1
   }
   $4 = HEAP32[$2 + 12 >> 2];
   $1 = HEAP32[$0 + 28 >> 2];
   if ($1) {
    $3 = HEAP32[$0 + 24 >> 2];
    HEAP32[$1 >> 2] = $3;
    if ($3) {
     HEAP32[$3 + 4 >> 2] = $1
    }
    $1 = $0 + 24 | 0;
    HEAP32[$1 >> 2] = 0;
    HEAP32[$1 + 4 >> 2] = 0;
   }
   HEAP32[16400] = $4;
   kmem_cache_free(HEAP32[16399], $0);
  }
  global$0 = $2 + 16 | 0;
 }
 function raise_softirq() {
  var $0 = 0, $1 = 0;
  HEAP32[1088] = HEAP32[1088] | 512;
  $1 = HEAPU8[65656];
  HEAP8[65656] = 0;
  if (!(HEAP32[1] & 2096896)) {
   $0 = HEAP32[1120];
   if (!(!$0 | !HEAP32[$0 >> 2])) {
    wake_up_process($0)
   }
  }
  HEAP8[65656] = $1 & 1;
 }
 function open_softirq($0, $1) {
  HEAP32[($0 << 2) + 65616 >> 2] = $1;
 }
 function tasklet_action($0) {
  $0 = $0 | 0;
  tasklet_action_common(4484, 6);
 }
 function tasklet_hi_action($0) {
  $0 = $0 | 0;
  tasklet_action_common(4492, 0);
 }
 function tasklet_action_common($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  $2 = HEAP32[$0 >> 2];
  HEAP32[$0 >> 2] = 0;
  HEAP8[65656] = 1;
  HEAP32[$0 + 4 >> 2] = $0;
  $5 = 1 << $1;
  label$1 : {
   while (1) {
    if ($2) {
     $1 = HEAP32[$2 >> 2];
     if (HEAP32[$2 + 8 >> 2]) {
      HEAP32[$2 >> 2] = 0;
      $4 = $0 + 4 | 0;
      HEAP32[HEAP32[$4 >> 2] >> 2] = $2;
      HEAP32[$4 >> 2] = $2;
      HEAP32[1088] = HEAP32[1088] | $5;
      HEAP8[65656] = 1;
      $2 = $1;
      continue;
     }
     $4 = HEAP32[$2 + 4 >> 2];
     HEAP32[$3 + 12 >> 2] = $4;
     if (!(HEAP32[$3 + 12 >> 2] & 1)) {
      break label$1
     }
     HEAP32[$2 + 4 >> 2] = $4 & -2;
     if (!($4 & 1)) {
      break label$1
     }
     FUNCTION_TABLE[HEAP32[$2 + 12 >> 2]](HEAP32[$2 + 16 >> 2]);
     $2 = $1;
     continue;
    }
    break;
   };
   global$0 = $3 + 16 | 0;
   return;
  }
  HEAP32[$3 + 8 >> 2] = 21085;
  HEAP32[$3 + 4 >> 2] = 522;
  HEAP32[$3 >> 2] = 21075;
  printk(21037, $3);
  abort();
 }
 function __cpuhp_setup_state_cpuslocked() {
  __inlined_func$mutex_lock : {
   if (HEAP32[1125]) {
    __mutex_lock();
    break __inlined_func$mutex_lock;
   }
   HEAP32[1125] = HEAP32[2];
  }
  cpuhp_store_callbacks();
  mutex_unlock(4500);
 }
 function cpuhp_store_callbacks() {
  if (HEAP32[1273]) {
   return -16
  }
  HEAP32[1275] = 93;
  HEAP32[1274] = 0;
  HEAP8[5109] = 0;
  HEAP32[1273] = 27742;
  HEAP32[1276] = 0;
  return 0;
 }
 function boot_cpu_init() {
  HEAP32[16417] = HEAP32[16417] | 1;
  HEAP32[16418] = HEAP32[16418] | 1;
  HEAP32[16415] = HEAP32[16415] | 1;
  HEAP32[16416] = HEAP32[16416] | 1;
 }
 function panic($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0;
  $2 = global$0 - 48 | 0;
  global$0 = $2;
  HEAP8[66772] = 0;
  $3 = HEAPU8[66720];
  label$1 : {
   $4 = HEAP32[2125];
   if (($4 | 0) == -1) {
    HEAP8[66772] = 0;
    HEAP32[2125] = 0;
    break label$1;
   }
   HEAP8[66772] = 0;
   if (!$4) {
    break label$1
   }
   while (1) continue;
  }
  if (HEAP32[2968]) {
   HEAP32[2968] = 15
  }
  bust_spinlocks(1);
  HEAP32[$2 + 44 >> 2] = $1;
  $0 = vscnprintf(65696, 1024, $0, $1);
  if (!(!$0 | HEAPU8[$0 + 65695 | 0] != 10)) {
   HEAP8[$0 + 65695 | 0] = 0
  }
  HEAP32[$2 + 32 >> 2] = 65696;
  printk(21176, $2 + 32 | 0);
  label$5 : {
   if (!$3) {
    __printk_safe_flush(11948);
    break label$5;
   }
   if (!HEAPU8[65680]) {
    HEAP8[65680] = 1
   }
  }
  $3 = 0;
  atomic_notifier_call_chain(65676, 0, 65696);
  __printk_safe_flush(11948);
  kmsg_dump(1);
  bust_spinlocks(0);
  debug_locks_off();
  console_trylock();
  HEAP8[68984] = 0;
  console_unlock();
  if (!HEAP32[16681]) {
   HEAP32[16681] = 9
  }
  $1 = HEAP32[2124];
  label$8 : {
   label$9 : {
    if (($1 | 0) >= 1) {
     HEAP32[$2 + 16 >> 2] = $1;
     printk(21210, $2 + 16 | 0);
     $0 = 0;
     $1 = 0;
     while (1) {
      $4 = HEAP32[2124];
      if (($1 | 0) < (Math_imul($4, 1e3) | 0)) {
       if (($1 | 0) >= ($0 | 0)) {
        $3 = $3 ^ 1;
        $1 = (FUNCTION_TABLE[HEAP32[16681]]($3) | 0) + $1 | 0;
        $0 = $1 + 200 | 0;
       }
       $1 = $1 + 100 | 0;
       continue;
      }
      break;
     };
     if (!$4) {
      break label$8
     }
     break label$9;
    }
    $0 = 0;
    if (!$1) {
     break label$8
    }
   }
   kmsg_dump(3);
   machine_restart();
  }
  HEAP32[$2 >> 2] = 65696;
  printk(21239, $2);
  HEAP8[66772] = 1;
  $1 = 0;
  while (1) {
   if (($1 | 0) >= ($0 | 0)) {
    $3 = $3 ^ 1;
    $1 = (FUNCTION_TABLE[HEAP32[16681]]($3) | 0) + $1 | 0;
    $0 = $1 + 200 | 0;
   }
   $1 = $1 + 100 | 0;
   continue;
  };
 }
 function no_blink($0) {
  $0 = $0 | 0;
  return 0;
 }
 function print_tainted() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0;
  label$1 : {
   if (HEAP32[16691]) {
    $2 = sprintf(66736, 21350, 0);
    $3 = $2 + 66736 | 0;
    $1 = 21296;
    while (1) {
     if (!(($0 | 0) == 18)) {
      HEAP8[$0 + $3 | 0] = HEAPU8[!(HEAP32[($0 >>> 3 & 28) + 66764 >> 2] & 1 << $0) + $1 | 0];
      $1 = $1 + 3 | 0;
      $0 = $0 + 1 | 0;
      continue;
     }
     break;
    };
    HEAP8[($0 + $2 | 0) + 66736 | 0] = 0;
    break label$1;
   }
   snprintf(66736, 28, 21360, 0);
  }
  return 66736;
 }
 function add_taint($0, $1) {
  label$1 : {
   if (($1 | 0) != 1) {
    break label$1
   }
   $1 = HEAP32[4943];
   HEAP32[4943] = 0;
   if (!$1) {
    break label$1
   }
   printk(21372, 0);
  }
  $1 = ($0 >>> 3 & 536870908) + 66764 | 0;
  HEAP32[$1 >> 2] = HEAP32[$1 >> 2] | 1 << ($0 & 31);
 }
 function arch_release_task_struct($0) {
 }
 function free_task($0) {
  if (HEAP32[$0 >> 2] == 128) {
   account_kernel_stack($0);
   __free_pages(HEAP32[20650] + Math_imul(HEAPU16[$0 + 6 >> 1], 36) | 0, 0);
   HEAP32[$0 + 4 >> 2] = 0;
  }
  if (HEAPU8[$0 + 14 | 0] & 32) {
   kfree(HEAP32[$0 + 604 >> 2])
  }
  kmem_cache_free(HEAP32[16695], $0);
 }
 function account_kernel_stack($0) {
  HEAP32[20669] = HEAP32[20669] + -64;
  $0 = Math_imul(HEAP32[HEAP32[20650] + Math_imul(HEAPU16[$0 + 6 >> 1], 36) >> 2] >>> 31 | 0, 516) + 141680 | 0;
  HEAP32[$0 >> 2] = HEAP32[$0 >> 2] + -64;
 }
 function __mmdrop($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0;
  $1 = global$0 - 48 | 0;
  global$0 = $1;
  if (($0 | 0) != 15736) {
   free_pages(HEAP32[$0 + 36 >> 2], 0);
   HEAP32[$0 + 360 >> 2] = 0;
   $2 = $0 + 340 | 0;
   while (1) {
    label$3 : {
     if (($3 | 0) != 4) {
      $4 = HEAP32[$2 >> 2];
      if (!$4) {
       break label$3
      }
      HEAP32[$1 + 40 >> 2] = $4;
      HEAP32[$1 + 36 >> 2] = $3;
      HEAP32[$1 + 32 >> 2] = $0;
      printk(21467, $1 + 32 | 0);
      break label$3;
     }
     if (HEAP32[$0 + 48 >> 2]) {
      HEAP32[$1 + 16 >> 2] = HEAP32[$0 + 48 >> 2];
      printk(21518, $1 + 16 | 0);
     }
     kmem_cache_free(HEAP32[16694], $0);
     global$0 = $1 + 48 | 0;
     return;
    }
    $2 = $2 + 4 | 0;
    $3 = $3 + 1 | 0;
    continue;
   };
  }
  HEAP32[$1 + 8 >> 2] = 21458;
  HEAP32[$1 + 4 >> 2] = 668;
  HEAP32[$1 >> 2] = 21451;
  printk(21420, $1);
  abort();
 }
 function __put_task_struct($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  exit_creds($0);
  $3 = HEAP32[$0 + 732 >> 2];
  $1 = HEAP32[$3 >> 2] + -1 | 0;
  HEAP32[$3 >> 2] = $1;
  if (!$1) {
   $1 = HEAP32[$3 + 368 >> 2];
   label$2 : {
    if (!$1) {
     break label$2
    }
    $2 = HEAP32[$1 + 44 >> 2] + -1 | 0;
    HEAP32[$1 + 44 >> 2] = $2;
    if ($2) {
     break label$2
    }
    HEAP32[$1 + 384 >> 2] = -32;
    HEAP32[$1 + 396 >> 2] = 10;
    $2 = $1 + 388 | 0;
    HEAP32[$1 + 392 >> 2] = $2;
    HEAP32[$2 >> 2] = $2;
    queue_work_on(1, HEAP32[16393], $1 + 384 | 0);
   }
   kmem_cache_free(HEAP32[16696], $3);
  }
  free_task($0);
 }
 function mmdrop_async_fn($0) {
  $0 = $0 | 0;
  __mmdrop($0 + -384 | 0);
 }
 function ns_to_timespec64($0, $1, $2) {
  var $3 = 0, $4 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  label$1 : {
   if ($1 | $2) {
    $1 = div_s64_rem($1, $2, 1e9, $3 + 12 | 0);
    $2 = i64toi32_i32$HIGH_BITS;
    $4 = HEAP32[$3 + 12 >> 2];
    if (($4 | 0) > -1) {
     break label$1
    }
    $4 = $4 + 1e9 | 0;
    HEAP32[$3 + 12 >> 2] = $4;
    $2 = $2 + -1 | 0;
    $1 = $1 + -1 | 0;
    if ($1 >>> 0 < 4294967295) {
     $2 = $2 + 1 | 0
    }
    break label$1;
   }
   $1 = 0;
   $2 = 0;
  }
  HEAP32[$0 + 8 >> 2] = $4;
  HEAP32[$0 >> 2] = $1;
  HEAP32[$0 + 4 >> 2] = $2;
  global$0 = $3 + 16 | 0;
 }
 function set_normalized_timespec64($0, $1, $2, $3, $4) {
  var $5 = 0;
  $5 = global$0 - 16 | 0;
  HEAP32[$5 + 8 >> 2] = $3;
  HEAP32[$5 + 12 >> 2] = $4;
  while (1) {
   if (!(($4 | 0) < 0 ? 1 : ($4 | 0) <= 0 ? ($3 >>> 0 > 999999999 ? 0 : 1) : 0)) {
    $4 = $4 + -1 | 0;
    $3 = $3 + -1e9 | 0;
    if ($3 >>> 0 < 3294967296) {
     $4 = $4 + 1 | 0
    }
    HEAP32[$5 + 8 >> 2] = $3;
    HEAP32[$5 + 12 >> 2] = $4;
    $1 = $1 + 1 | 0;
    if ($1 >>> 0 < 1) {
     $2 = $2 + 1 | 0
    }
    continue;
   }
   break;
  };
  while (1) {
   if (!(($4 | 0) > -1 ? 1 : ($4 | 0) >= -1 ? ($3 >>> 0 <= 4294967295 ? 0 : 1) : 0)) {
    $3 = $3 + 1e9 | 0;
    if ($3 >>> 0 < 1e9) {
     $4 = $4 + 1 | 0
    }
    HEAP32[$5 + 8 >> 2] = $3;
    HEAP32[$5 + 12 >> 2] = $4;
    $2 = $2 + -1 | 0;
    $1 = $1 + -1 | 0;
    if ($1 >>> 0 < 4294967295) {
     $2 = $2 + 1 | 0
    }
    continue;
   }
   break;
  };
  HEAP32[$0 + 8 >> 2] = $3;
  HEAP32[$0 >> 2] = $1;
  HEAP32[$0 + 4 >> 2] = $2;
 }
 function lock_timer_base($0, $1) {
  var $2 = 0, $3 = 0;
  $0 = $0 + 16 | 0;
  while (1) {
   $2 = HEAP32[$0 >> 2];
   if ($2 & 262144) {
    continue
   }
   $3 = HEAP32[16697];
   HEAP32[16697] = 0;
   HEAP32[$1 >> 2] = $3;
   if (($2 | 0) != HEAP32[$0 >> 2]) {
    HEAP32[16697] = HEAP32[$1 >> 2];
    continue;
   }
   break;
  };
 }

 function calc_wheel_index($0, $1) {
  var $2 = 0;
  $2 = $0 - $1 | 0;
  if ($2 >>> 0 <= 62) {
   return $0 + 1 & 63
  }
  if ($2 >>> 0 <= 503) {
   return $0 + 8 >>> 3 & 63 | 64
  }
  if ($2 >>> 0 <= 4031) {
   return $0 - -64 >>> 6 & 63 | 128
  }
  if ($2 >>> 0 <= 32255) {
   return $0 + 512 >>> 9 & 63 | 192
  }
  if ($2 >>> 0 <= 258047) {
   return $0 + 4096 >>> 12 & 63 | 256
  }
  if ($2 >>> 0 <= 2064383) {
   return $0 + 32768 >>> 15 & 63 | 320
  }
  if ($2 >>> 0 <= 16515071) {
   return $0 + 262144 >>> 18 & 63 | 384
  }
  if ($2 >>> 0 <= 132120575) {
   return $0 + 2097152 >>> 21 & 63 | 448
  }
  if (($2 | 0) > -1) {
   return $0 >>> 0 > 1056964607 ? 575 : $0 + 16777216 >>> 24 & 63 | 512
  }
  return $1 & 63;
 }

 function detach_if_pending($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, wasm2js_i32$0 = 0, wasm2js_i32$1 = 0;
  label$1 : {
   label$2 : {
    $3 = HEAP32[$0 + 4 >> 2];
    if ($3) {
     $4 = HEAP32[$0 >> 2];
     if (!$4) {
      break label$2
     }
     HEAP32[$4 + 4 >> 2] = $3;
     break label$1;
    }
    return 0;
   }
   $2 = HEAP32[$0 + 16 >> 2];
   $5 = $2 >>> 22 | 0;
   if ((($5 << 2) + 8668 | 0) != ($3 | 0)) {
    break label$1
   }
   $2 = ($2 >>> 25 & 124) + 8596 | 0;
   $6 = HEAP32[$2 >> 2];
   (wasm2js_i32$0 = $2, wasm2js_i32$1 = __wasm_rotl_i32(-2, $5) & $6), HEAP32[wasm2js_i32$0 >> 2] = wasm2js_i32$1;
  }
  HEAP32[$3 >> 2] = $4;
  if ($1) {
   HEAP32[$0 + 4 >> 2] = 0
  }
  HEAP32[$0 >> 2] = 512;
  return 1;
 }

 function enqueue_timer($0, $1) {
  var $2 = 0, $3 = 0;
  $2 = ($1 << 2) + 8668 | 0;
  $3 = HEAP32[$2 >> 2];
  HEAP32[$0 >> 2] = $3;
  if ($3) {
   HEAP32[$3 + 4 >> 2] = $0
  }
  HEAP32[$2 >> 2] = $0;
  HEAP32[$0 + 4 >> 2] = $2;
  HEAP32[$0 + 16 >> 2] = HEAP32[$0 + 16 >> 2] & 4194303 | $1 << 22;
  $0 = (($1 | 0) / 32 << 2) + 8596 | 0;
  HEAP32[$0 >> 2] = HEAP32[$0 >> 2] | 1 << ($1 & 31);
 }

 function internal_add_timer($0) {
  enqueue_timer($0, calc_wheel_index(HEAP32[$0 + 8 >> 2], HEAP32[2145]));
 }

 function del_timer($0) {
  var $1 = 0;
  $1 = global$0 - 16 | 0;
  global$0 = $1;
  label$1 : {
   if (HEAP32[$0 + 4 >> 2]) {
    lock_timer_base($0, $1 + 12 | 0);
    $0 = detach_if_pending($0, 1);
    HEAP32[16697] = HEAP32[$1 + 12 >> 2];
    break label$1;
   }
   $0 = 0;
  }
  global$0 = $1 + 16 | 0;
  return $0;
 }

 function schedule_timeout($0) {
  var $1 = 0, $2 = 0;
  $1 = global$0 - 48 | 0;
  global$0 = $1;
  $2 = 2147483647;
  label$1 : {
   label$2 : {
    label$3 : {
     if (($0 | 0) == 2147483647) {
      schedule();
      break label$3;
     }
     if (($0 | 0) <= -1) {
      break label$2
     }
     HEAP32[$1 + 32 >> 2] = 0;
     HEAP32[$1 + 28 >> 2] = 11;
     HEAP32[$1 + 20 >> 2] = 0;
     HEAP32[$1 + 36 >> 2] = HEAP32[2];
     $2 = HEAP32[20749];
     lock_timer_base($1 + 16 | 0, $1 + 44 | 0);
     detach_if_pending($1 + 16 | 0, 0);
     $0 = $0 + $2 | 0;
     HEAP32[$1 + 24 >> 2] = $0;
     internal_add_timer($1 + 16 | 0);
     HEAP32[16697] = HEAP32[$1 + 44 >> 2];
     schedule();
     del_timer($1 + 16 | 0);
     $2 = $0 - HEAP32[20749] | 0;
     $0 = 0;
     if (($2 | 0) < 1) {
      break label$1
     }
    }
    $0 = $2;
    break label$1;
   }
   HEAP32[$1 >> 2] = $0;
   printk(21631, $1);
   dump_stack();
   HEAP32[HEAP32[2] >> 2] = 0;
   $0 = 0;
  }
  global$0 = $1 + 48 | 0;
  return $0;
 }

 function process_timeout($0) {
  $0 = $0 | 0;
  wake_up_process(HEAP32[$0 + 20 >> 2]);
 }

 function schedule_timeout_uninterruptible($0) {
  HEAP32[HEAP32[2] >> 2] = 2;
  return schedule_timeout($0);
 }

 function init_timers() {
  var $0 = 0, $1 = 0, $2 = 0;
  $0 = HEAP32[2145];
  $1 = HEAP32[2147];
  $2 = 1;
  while (1) {
   if ($2) {
    $1 = 0;
    $0 = HEAP32[20749];
    $2 = 0;
    continue;
   }
   break;
  };
  HEAP32[2145] = $0;
  HEAP32[2147] = $1;
  open_softirq(1, 12);
 }

 function run_timer_softirq($0) {
  $0 = $0 | 0;
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, wasm2js_i32$0 = 0, wasm2js_i32$1 = 0;
  $7 = global$0 - 48 | 0;
  global$0 = $7;
  if ((HEAP32[20749] - HEAP32[2145] | 0) >= 0) {
   HEAP32[16697] = 0;
   HEAP8[8593] = 0;
   label$3 : while (1) {
    $2 = HEAP32[2145];
    if ((HEAP32[20749] - $2 | 0) >= 0) {
     $3 = 0;
     $1 = $7;
     $5 = 0;
     $0 = 0;
     while (1) {
      label$4 : {
       if ($5 >>> 0 > 8) {
        break label$4
       }
       $6 = $2 & 63 | $3;
       $8 = (($6 | 0) / 32 << 2) + 8596 | 0;
       $4 = HEAP32[$8 >> 2];
       (wasm2js_i32$0 = $8, wasm2js_i32$1 = __wasm_rotl_i32(-2, $2) & $4), HEAP32[wasm2js_i32$0 >> 2] = wasm2js_i32$1;
       if ($4 & 1 << ($2 & 31)) {
        $6 = ($6 << 2) + 8668 | 0;
        $4 = HEAP32[$6 >> 2];
        HEAP32[$1 >> 2] = $4;
        if ($4) {
         HEAP32[$4 + 4 >> 2] = $1
        }
        $1 = $1 + 4 | 0;
        HEAP32[$6 >> 2] = 0;
        $0 = $0 + 1 | 0;
       }
       if ($2 & 7) {
        break label$4
       }
       $3 = $3 - -64 | 0;
       $5 = $5 + 1 | 0;
       $2 = $2 >>> 3 | 0;
       continue;
      }
      break;
     };
     HEAP32[2145] = HEAP32[2145] + 1;
     while (1) {
      if (!$0) {
       continue label$3
      }
      $0 = $0 + -1 | 0;
      $5 = ($0 << 2) + $7 | 0;
      while (1) {
       $1 = HEAP32[$5 >> 2];
       if ($1) {
        HEAP32[2144] = $1;
        $3 = HEAP32[$1 + 4 >> 2];
        $2 = HEAP32[$1 >> 2];
        HEAP32[$3 >> 2] = $2;
        if ($2) {
         HEAP32[$2 + 4 >> 2] = $3
        }
        HEAP32[$1 >> 2] = 512;
        HEAP32[$1 + 4 >> 2] = 0;
        $2 = HEAP32[$1 + 12 >> 2];
        if (!(HEAPU8[$1 + 18 | 0] & 32)) {
         HEAP32[16697] = 1;
         $3 = HEAP32[1];
         FUNCTION_TABLE[$2]($1);
         if (HEAP32[1] != ($3 | 0)) {
          HEAP32[1] = $3
         }
         HEAP32[16697] = 0;
         continue;
        }
        $3 = HEAP32[1];
        FUNCTION_TABLE[$2]($1);
        if (HEAP32[1] != ($3 | 0)) {
         HEAP32[1] = $3
        }
        continue;
       }
       break;
      };
      continue;
     };
    }
    break;
   };
   HEAP32[16697] = 1;
   HEAP32[2144] = 0;
  }
  global$0 = $7 + 48 | 0;
 }

 function ktime_get_real() {
  return ktime_get_with_offset(0) | 0;
 }

 function ktime_get_boottime() {
  return ktime_get_with_offset(1) | 0;
 }

 function ktime_get_clocktai() {
  return ktime_get_with_offset(2) | 0;
 }

 function __ktime_divns($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0;
  $4 = global$0 - 16 | 0;
  global$0 = $4;
  $8 = $1;
  $6 = $1 >> 31;
  $1 = $1 + $6 | 0;
  $9 = $0;
  $5 = $8 >> 31;
  $0 = $5 + $0 | 0;
  if ($0 >>> 0 < $5 >>> 0) {
   $1 = $1 + 1 | 0
  }
  $7 = $0 ^ $5;
  $0 = $1 ^ $6;
  $6 = $0;
  HEAP32[$4 + 8 >> 2] = $7;
  HEAP32[$4 + 12 >> 2] = $0;
  $5 = 0;
  $0 = 0;
  while (1) {
   if (!(($3 | 0) == 1 & $2 >>> 0 < 0 | $3 >>> 0 < 1)) {
    $1 = $5 + 1 | 0;
    if ($1 >>> 0 < 1) {
     $0 = $0 + 1 | 0
    }
    $5 = $1;
    $2 = ($3 & 1) << 31 | $2 >>> 1;
    $3 = $3 >> 1;
    continue;
   }
   break;
  };
  $0 = $6;
  $6 = $7;
  $3 = $5 & 31;
  $7 = $4;
  if (32 <= ($5 & 63) >>> 0) {
   $1 = 0;
   $0 = $0 >>> $3 | 0;
  } else {
   $1 = $0 >>> $3 | 0;
   $0 = ((1 << $3) - 1 & $0) << 32 - $3 | $6 >>> $3;
  }
  HEAP32[$7 + 8 >> 2] = $0;
  HEAP32[$4 + 12 >> 2] = $1;
  label$3 : {
   if (!(!$1 & $0 >>> 0 > 4294967295 | $1 >>> 0 > 0)) {
    $2 = ($0 >>> 0) / ($2 >>> 0) | 0;
    HEAP32[$4 + 8 >> 2] = $2;
    HEAP32[$4 + 12 >> 2] = 0;
    $3 = 0;
    break label$3;
   }
   __div64_32($4 + 8 | 0, $2);
   $2 = HEAP32[$4 + 8 >> 2];
   $3 = HEAP32[$4 + 12 >> 2];
  }
  global$0 = $4 + 16 | 0;
  $0 = ($8 | 0) < 0 ? 1 : ($8 | 0) <= 0 ? ($9 >>> 0 >= 0 ? 0 : 1) : 0;
  $1 = $0 ? 0 - $2 | 0 : $2;
  i64toi32_i32$HIGH_BITS = $0 ? 0 - ($3 + (0 < $2 >>> 0) | 0) | 0 : $3;
  return $1;
 }

 function hrtimer_forward($0, $1, $2, $3, $4) {
  var $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0;
  $13 = global$0 - 16 | 0;
  global$0 = $13;
  $5 = HEAP32[$0 + 20 >> 2];
  $9 = $1;
  $8 = HEAP32[$0 + 16 >> 2];
  $6 = $8;
  $1 = $2 - ($5 + ($1 >>> 0 < $6 >>> 0) | 0) | 0;
  $7 = $9 - $6 | 0;
  label$1 : {
   if (HEAP8[$0 + 40 | 0] & 1 | (($1 | 0) < 0 ? 1 : ($1 | 0) <= 0 ? ($7 >>> 0 >= 0 ? 0 : 1) : 0)) {
    break label$1
   }
   $6 = $3;
   $11 = $3 >>> 0 <= 4e6 ? 0 : 1;
   $3 = $4;
   $10 = ($3 | 0) > 0 ? 1 : ($3 | 0) >= 0 ? $11 : 0;
   $4 = $10 ? $6 : 4e6;
   $6 = $10 ? $3 : 0;
   $3 = $6;
   label$2 : {
    if (!(($1 | 0) > ($3 | 0) ? 1 : ($1 | 0) >= ($3 | 0) ? ($7 >>> 0 < $4 >>> 0 ? 0 : 1) : 0)) {
     $7 = HEAP32[$0 + 24 >> 2];
     $1 = HEAP32[$0 + 28 >> 2];
     $10 = 0;
     $3 = 1;
     break label$2;
    }
    $11 = __ktime_divns($7, $1, $4, $6);
    $1 = $0 + 16 | 0;
    $5 = $1;
    $8 = HEAP32[$1 >> 2];
    $3 = HEAP32[$1 + 4 >> 2];
    $10 = i64toi32_i32$HIGH_BITS;
    $1 = __wasm_i64_mul($11, $10, $4, $6);
    $7 = i64toi32_i32$HIGH_BITS;
    $3 = $7 + $3 | 0;
    $8 = $1 + $8 | 0;
    if ($8 >>> 0 < $1 >>> 0) {
     $3 = $3 + 1 | 0
    }
    HEAP32[$5 >> 2] = $8;
    $12 = $5;
    $5 = $3;
    HEAP32[$12 + 4 >> 2] = $3;
    $3 = $7 + HEAP32[$0 + 28 >> 2] | 0;
    $7 = $1 + HEAP32[$0 + 24 >> 2] | 0;
    if ($7 >>> 0 < $1 >>> 0) {
     $3 = $3 + 1 | 0
    }
    HEAP32[$0 + 24 >> 2] = $7;
    $1 = $3;
    HEAP32[$0 + 28 >> 2] = $1;
    if (($5 | 0) > ($2 | 0) ? 1 : ($5 | 0) >= ($2 | 0) ? ($8 >>> 0 <= $9 >>> 0 ? 0 : 1) : 0) {
     break label$1
    }
    $2 = ($5 | 0) < ($2 | 0) ? 1 : ($5 | 0) <= ($2 | 0) ? ($8 >>> 0 > $9 >>> 0 ? 0 : 1) : 0;
    $3 = $2 + $11 | 0;
    if ($3 >>> 0 < $2 >>> 0) {
     $10 = $10 + 1 | 0
    }
   }
   $11 = $3;
   $2 = $0;
   $12 = $0;
   $3 = $1 + $6 | 0;
   $0 = $4;
   $4 = $0 + $7 | 0;
   if ($4 >>> 0 < $0 >>> 0) {
    $3 = $3 + 1 | 0
   }
   $1 = ($3 | 0) < ($1 | 0) ? 1 : ($3 | 0) <= ($1 | 0) ? ($4 >>> 0 >= $7 >>> 0 ? 0 : 1) : 0;
   $9 = ($3 | 0) < 0 ? 1 : ($3 | 0) <= 0 ? ($4 >>> 0 >= 0 ? 0 : 1) : 0;
   $7 = $9 ? -1 : $1 ? -1 : $4;
   $4 = ($3 | 0) < ($6 | 0) ? 1 : ($3 | 0) <= ($6 | 0) ? ($4 >>> 0 >= $0 >>> 0 ? 0 : 1) : 0;
   HEAP32[$12 + 24 >> 2] = $4 ? -1 : $7;
   HEAP32[$2 + 28 >> 2] = $4 ? 2147483647 : $9 ? 2147483647 : $1 ? 2147483647 : $3;
   $3 = $2 + 16 | 0;
   $9 = $3;
   $1 = $5 + $6 | 0;
   $2 = $0 + $8 | 0;
   if ($2 >>> 0 < $0 >>> 0) {
    $1 = $1 + 1 | 0
   }
   $4 = ($1 | 0) < ($5 | 0) ? 1 : ($1 | 0) <= ($5 | 0) ? ($2 >>> 0 >= $8 >>> 0 ? 0 : 1) : 0;
   $5 = ($1 | 0) < 0 ? 1 : ($1 | 0) <= 0 ? ($2 >>> 0 >= 0 ? 0 : 1) : 0;
   $0 = ($1 | 0) < ($6 | 0) ? 1 : ($1 | 0) <= ($6 | 0) ? ($2 >>> 0 >= $0 >>> 0 ? 0 : 1) : 0;
   HEAP32[$9 >> 2] = $0 ? -1 : $5 ? -1 : $4 ? -1 : $2;
   HEAP32[$3 + 4 >> 2] = $0 ? 2147483647 : $5 ? 2147483647 : $4 ? 2147483647 : $1;
  }
  global$0 = $13 + 16 | 0;
  i64toi32_i32$HIGH_BITS = $10;
  return $11;
 }

 function hrtimer_start_range_ns($0, $1, $2, $3, $4, $5) {
  var $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0;
  $11 = HEAP32[16698];
  HEAP32[16698] = 0;
  $8 = HEAP32[$0 + 36 >> 2];
  $6 = HEAPU8[$0 + 40 | 0];
  if ($6 & 1) {
   __remove_hrtimer($0, $8, $6, HEAP32[$8 >> 2] == 11008)
  }
  if ($5 & 1) {
   $9 = FUNCTION_TABLE[HEAP32[$8 + 28 >> 2]]() | 0;
   $7 = i64toi32_i32$HIGH_BITS;
   $5 = $2 + $7 | 0;
   $6 = $1 + $9 | 0;
   if ($6 >>> 0 < $1 >>> 0) {
    $5 = $5 + 1 | 0
   }
   $2 = ($5 | 0) < ($2 | 0) ? 1 : ($5 | 0) <= ($2 | 0) ? ($6 >>> 0 >= $1 >>> 0 ? 0 : 1) : 0;
   $10 = ($5 | 0) < 0 ? 1 : ($5 | 0) <= 0 ? ($6 >>> 0 >= 0 ? 0 : 1) : 0;
   $1 = $10 ? -1 : $2 ? -1 : $6;
   $6 = ($5 | 0) < ($7 | 0) ? 1 : ($5 | 0) <= ($7 | 0) ? ($6 >>> 0 >= $9 >>> 0 ? 0 : 1) : 0;
   $1 = $6 ? -1 : $1;
   $2 = $6 ? 2147483647 : $10 ? 2147483647 : $2 ? 2147483647 : $5;
  }
  HEAP32[$0 + 24 >> 2] = $1;
  HEAP32[$0 + 28 >> 2] = $2;
  $7 = $0;
  $5 = $2 + $4 | 0;
  $6 = $1 + $3 | 0;
  if ($6 >>> 0 < $3 >>> 0) {
   $5 = $5 + 1 | 0
  }
  $1 = ($5 | 0) < ($2 | 0) ? 1 : ($5 | 0) <= ($2 | 0) ? ($6 >>> 0 >= $1 >>> 0 ? 0 : 1) : 0;
  $2 = ($5 | 0) < 0 ? 1 : ($5 | 0) <= 0 ? ($6 >>> 0 >= 0 ? 0 : 1) : 0;
  $3 = ($5 | 0) < ($4 | 0) ? 1 : ($5 | 0) <= ($4 | 0) ? ($6 >>> 0 >= $3 >>> 0 ? 0 : 1) : 0;
  HEAP32[$7 + 16 >> 2] = $3 ? -1 : $2 ? -1 : $1 ? -1 : $6;
  HEAP32[$0 + 20 >> 2] = $3 ? 2147483647 : $2 ? 2147483647 : $1 ? 2147483647 : $5;
  if (enqueue_hrtimer($0, $8)) {
   hrtimer_reprogram($0)
  }
  HEAP32[16698] = $11;
 }

 function __remove_hrtimer($0, $1, $2, $3) {
  var $4 = 0, wasm2js_i32$0 = 0, wasm2js_i32$1 = 0;
  $4 = HEAPU8[$0 + 40 | 0];
  HEAP8[$0 + 40 | 0] = $2;
  label$1 : {
   if (!($4 & 1)) {
    break label$1
   }
   $2 = HEAP32[$1 >> 2];
   if (!timerqueue_del($1 + 20 | 0, $0)) {
    (wasm2js_i32$0 = $2, wasm2js_i32$1 = HEAP32[$2 + 4 >> 2] & __wasm_rotl_i32(-2, HEAP32[$1 + 4 >> 2])), HEAP32[wasm2js_i32$0 + 4 >> 2] = wasm2js_i32$1
   }
   if (!$3 | HEAP32[$2 + 24 >> 2] != ($0 | 0)) {
    break label$1
   }
   $0 = __hrtimer_get_next_event($2, 255);
   $1 = i64toi32_i32$HIGH_BITS;
   $3 = HEAP32[$2 + 24 >> 2];
   label$3 : {
    if (!$3 | !HEAPU8[$3 + 42 | 0]) {
     break label$3
    }
    if (!(HEAPU8[$2 + 12 | 0] & 8)) {
     HEAP32[$2 + 32 >> 2] = $0;
     HEAP32[$2 + 36 >> 2] = $1;
     break label$3;
    }
    $0 = __hrtimer_get_next_event($2, 15);
    $1 = i64toi32_i32$HIGH_BITS;
   }
   if (($0 | 0) == HEAP32[$2 + 16 >> 2] & HEAP32[$2 + 20 >> 2] == ($1 | 0)) {
    break label$1
   }
   $2 = $2 + 16 | 0;
   HEAP32[$2 >> 2] = $0;
   HEAP32[$2 + 4 >> 2] = $1;
  }
 }

 function enqueue_hrtimer($0, $1) {
  var $2 = 0;
  HEAP8[$0 + 40 | 0] = 1;
  $2 = HEAP32[$1 >> 2];
  HEAP32[$2 + 4 >> 2] = HEAP32[$2 + 4 >> 2] | 1 << HEAP32[$1 + 4 >> 2];
  return timerqueue_add($1 + 20 | 0, $0);
 }

 function hrtimer_reprogram($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0;
  $2 = HEAP32[$0 + 16 >> 2];
  $3 = HEAP32[$0 + 36 >> 2];
  $1 = $3;
  $4 = HEAP32[$1 + 32 >> 2];
  $1 = HEAP32[$0 + 20 >> 2] - (($2 >>> 0 < $4 >>> 0) + HEAP32[$1 + 36 >> 2] | 0) | 0;
  $2 = $2 - $4 | 0;
  $4 = $2;
  $2 = ($1 | 0) > 0 ? 1 : ($1 | 0) >= 0 ? ($2 >>> 0 <= 0 ? 0 : 1) : 0;
  $4 = $2 ? $4 : 0;
  $2 = $2 ? $1 : 0;
  $1 = HEAP32[$3 >> 2];
  label$1 : {
   label$2 : {
    if (HEAPU8[$0 + 42 | 0]) {
     if (HEAPU8[$1 + 12 | 0] & 8) {
      break label$1
     }
     $3 = HEAP32[$1 + 36 >> 2];
     if (($2 | 0) > ($3 | 0) ? 1 : ($2 | 0) >= ($3 | 0) ? ($4 >>> 0 < HEAPU32[$1 + 32 >> 2] ? 0 : 1) : 0) {
      break label$1
     }
     HEAP32[$1 + 40 >> 2] = $0;
     $3 = $1 + 32 | 0;
     HEAP32[$3 >> 2] = $4;
     HEAP32[$3 + 4 >> 2] = $2;
     $3 = HEAP32[$1 + 20 >> 2];
     if (($2 | 0) > ($3 | 0) ? 1 : ($2 | 0) >= ($3 | 0) ? ($4 >>> 0 < HEAPU32[$1 + 16 >> 2] ? 0 : 1) : 0) {
      break label$1
     }
     if (($1 | 0) == 11008) {
      break label$2
     }
     break label$1;
    }
    if (($1 | 0) != 11008) {
     break label$1
    }
   }
   if (HEAPU8[11020] & 2) {
    break label$1
   }
   $1 = HEAP32[2757];
   if (($2 | 0) > ($1 | 0) ? 1 : ($2 | 0) >= ($1 | 0) ? ($4 >>> 0 < HEAPU32[2756] ? 0 : 1) : 0) {
    break label$1
   }
   HEAP32[2756] = $4;
   HEAP32[2757] = $2;
   HEAP32[2758] = $0;
  }
 }

 function hrtimer_try_to_cancel($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  if (hrtimer_active($0)) {
   $3 = HEAP32[16698];
   HEAP32[16698] = 0;
   $1 = HEAP32[$0 + 36 >> 2];
   label$2 : {
    if (($0 | 0) != HEAP32[HEAP32[$0 + 36 >> 2] + 16 >> 2]) {
     $2 = 0;
     if (!(HEAP8[$0 + 40 | 0] & 1)) {
      break label$2
     }
     __remove_hrtimer($0, $1, 0, HEAP32[$1 >> 2] == 11008);
     $2 = 1;
     break label$2;
    }
    $2 = -1;
   }
   $1 = $2;
   HEAP32[16698] = $3;
  }
  return $1;
 }

 function hrtimer_active($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $3 = $0 + 36 | 0;
  $6 = $0 + 40 | 0;
  label$1 : {
   while (1) {
    $1 = HEAP32[$3 >> 2];
    while (1) {
     $4 = $1 + 12 | 0;
     $5 = HEAP32[$4 >> 2];
     if ($5 & 1) {
      continue
     }
     break;
    };
    $2 = 1;
    if (HEAPU8[$6 | 0] | HEAP32[$1 + 16 >> 2] == ($0 | 0)) {
     break label$1
    }
    if (HEAP32[$4 >> 2] != ($5 | 0) | HEAP32[$3 >> 2] != ($1 | 0)) {
     continue
    }
    break;
   };
   $2 = 0;
  }
  return $2;
 }

 function hrtimer_init($0) {
  var $1 = 0;
  memset($0, 0, 48);
  $1 = HEAP32[5425];
  HEAP8[$0 + 42 | 0] = 0;
  HEAP32[$0 + 36 >> 2] = Math_imul($1, 40) + 11056;
  HEAP32[$0 >> 2] = $0;
 }

 function __hrtimer_run_queues($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0;
  $6 = global$0 - 16 | 0;
  global$0 = $6;
  HEAP32[$6 + 12 >> 2] = HEAP32[2753] & 240;
  label$2 : while (1) {
   $5 = __next_base(11008, $6 + 12 | 0);
   if ($5) {
    $7 = HEAP32[$5 + 36 >> 2] + $1 | 0;
    $8 = $0 + HEAP32[$5 + 32 >> 2] | 0;
    if ($8 >>> 0 < $0 >>> 0) {
     $7 = $7 + 1 | 0
    }
    while (1) {
     $4 = HEAP32[$5 + 24 >> 2];
     if (!$4) {
      continue label$2
     }
     $3 = HEAP32[$4 + 28 >> 2];
     if (($7 | 0) < ($3 | 0) ? 1 : ($7 | 0) <= ($3 | 0) ? ($8 >>> 0 >= HEAPU32[$4 + 24 >> 2] ? 0 : 1) : 0) {
      continue label$2
     }
     $9 = $5 + 16 | 0;
     HEAP32[$9 >> 2] = $4;
     $3 = $5 + 12 | 0;
     HEAP32[$3 >> 2] = HEAP32[$3 >> 2] + 1;
     HEAP32[$3 >> 2] = HEAP32[$3 >> 2] + 1;
     __remove_hrtimer($4, $5, 0, 0);
     HEAP32[16698] = $2;
     $10 = FUNCTION_TABLE[HEAP32[$4 + 32 >> 2]]($4) | 0;
     HEAP32[16698] = 0;
     if (!(!$10 | HEAP8[$4 + 40 | 0] & 1)) {
      enqueue_hrtimer($4, $5)
     }
     HEAP32[$3 >> 2] = HEAP32[$3 >> 2] + 1;
     HEAP32[$9 >> 2] = 0;
     HEAP32[$3 >> 2] = HEAP32[$3 >> 2] + 1;
     continue;
    };
   }
   break;
  };
  global$0 = $6 + 16 | 0;
 }

 function __next_base($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, wasm2js_i32$0 = 0, wasm2js_i32$1 = 0;
  $3 = HEAP32[$1 >> 2];
  if ($3) {
   $4 = $3 & 65535;
   $2 = $4 ? $3 : $3 >>> 16 | 0;
   $5 = $2 & 255;
   $2 = $5 ? $2 : $2 >>> 8 | 0;
   $6 = $2 & 15;
   $2 = $6 ? $2 : $2 >>> 4 | 0;
   $7 = $2 & 3;
   $8 = $1;
   $1 = !$4 << 4;
   $1 = $5 ? $1 : $1 | 8;
   $1 = $6 ? $1 : $1 | 4;
   $1 = ((($7 ? $2 : $2 >>> 2 | 0) ^ -1) & 1) + ($7 ? $1 : $1 | 2) | 0;
   (wasm2js_i32$0 = $8, wasm2js_i32$1 = __wasm_rotl_i32(-2, $1) & $3), HEAP32[wasm2js_i32$0 >> 2] = wasm2js_i32$1;
   return (Math_imul($1, 40) + $0 | 0) + 48 | 0;
  }
  return 0;
 }

 function hrtimers_prepare_cpu() {
  var $0 = 0, $1 = 0;
  $0 = -320;
  while (1) {
   if ($0) {
    $1 = $0 + 11396 | 0;
    HEAP32[$1 >> 2] = 0;
    HEAP32[$1 + 4 >> 2] = 0;
    HEAP32[$0 + 11376 >> 2] = 11008;
    $0 = $0 + 40 | 0;
    continue;
   }
   break;
  };
  HEAP32[2752] = 0;
  HEAP32[2760] = -1;
  HEAP32[2761] = 2147483647;
  HEAP32[2756] = -1;
  HEAP32[2757] = 2147483647;
  HEAP8[11020] = HEAPU8[11020] & 250;
  HEAP32[2753] = 0;
  HEAP32[2762] = 0;
  HEAP32[2758] = 0;
 }

 function hrtimer_run_softirq($0) {
  $0 = $0 | 0;
  var $1 = 0, $2 = 0;
  $0 = HEAP32[16698];
  HEAP32[16698] = 0;
  $2 = ktime_get_update_offsets_now();
  $1 = HEAP32[2783];
  HEAP32[2822] = HEAP32[2782];
  HEAP32[2823] = $1;
  $1 = HEAP32[2793];
  HEAP32[2832] = HEAP32[2792];
  HEAP32[2833] = $1;
  $1 = HEAP32[2803];
  HEAP32[2842] = HEAP32[2802];
  HEAP32[2843] = $1;
  __hrtimer_run_queues($2, i64toi32_i32$HIGH_BITS, $0);
  HEAP8[11020] = HEAPU8[11020] & 247;
  if (!((__hrtimer_get_next_event(11008, 240) | 0) == -1 & (i64toi32_i32$HIGH_BITS | 0) == 2147483647)) {
   hrtimer_reprogram(HEAP32[2762])
  }
  HEAP32[16698] = $0;
 }

 function __hrtimer_get_next_event($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0;
  $2 = -1;
  $3 = 2147483647;
  if (!(!($1 & 240) | HEAPU8[$0 + 12 | 0] & 8)) {
   HEAP32[$0 + 40 >> 2] = 0;
   $2 = __hrtimer_next_event_base($0, HEAP32[$0 + 4 >> 2] & 240, -1, 2147483647);
   $4 = HEAP32[$0 + 40 >> 2];
   $3 = i64toi32_i32$HIGH_BITS;
  }
  if ($1 & 15) {
   HEAP32[$0 + 24 >> 2] = $4;
   $2 = __hrtimer_next_event_base($0, HEAP32[$0 + 4 >> 2] & 15, $2, $3);
   $3 = i64toi32_i32$HIGH_BITS;
  }
  i64toi32_i32$HIGH_BITS = $3;
  return $2;
 }

 function __hrtimer_next_event_base($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0;
  $6 = global$0 - 16 | 0;
  global$0 = $6;
  HEAP32[$6 + 12 >> 2] = $1;
  $9 = $0 + 40 | 0;
  while (1) {
   $4 = __next_base($0, $6 + 12 | 0);
   if ($4) {
    $5 = HEAP32[$4 + 24 >> 2];
    if (!$5) {
     $5 = 0;
     if (!$5) {
      continue
     }
    }
    $7 = HEAP32[$5 + 16 >> 2];
    $8 = HEAP32[$4 + 32 >> 2];
    $1 = $7 - $8 | 0;
    $4 = HEAP32[$5 + 20 >> 2] - (HEAP32[$4 + 36 >> 2] + ($7 >>> 0 < $8 >>> 0) | 0) | 0;
    if (($4 | 0) > ($3 | 0) ? 1 : ($4 | 0) >= ($3 | 0) ? ($1 >>> 0 < $2 >>> 0 ? 0 : 1) : 0) {
     continue
    }
    if (HEAPU8[$5 + 42 | 0]) {
     HEAP32[$9 >> 2] = $5
    } else {
     HEAP32[$0 + 24 >> 2] = $5
    }
    $2 = $1;
    $3 = $4;
    continue;
   }
   break;
  };
  global$0 = $6 + 16 | 0;
  $0 = ($3 | 0) > 0 ? 1 : ($3 | 0) >= 0 ? ($2 >>> 0 <= 0 ? 0 : 1) : 0;
  $1 = $0 ? $2 : 0;
  i64toi32_i32$HIGH_BITS = $0 ? $3 : 0;
  return $1;
 }

 function ktime_get() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0;
  while (1) {
   $4 = HEAP32[16704];
   if ($4 & 1) {
    continue
   }
   $5 = HEAP32[16716];
   $6 = HEAP32[16717];
   $0 = HEAP32[16706];
   $0 = FUNCTION_TABLE[HEAP32[$0 >> 2]]($0) | 0;
   $7 = i64toi32_i32$HIGH_BITS;
   $2 = HEAP32[16713];
   $1 = HEAP32[16714];
   $8 = HEAP32[16715];
   $9 = HEAP32[16712];
   $10 = HEAP32[16708];
   $11 = HEAP32[16709];
   $3 = HEAP32[16710];
   $12 = HEAP32[16711];
   if (HEAP32[16704] != ($4 | 0)) {
    continue
   }
   break;
  };
  $3 = __wasm_i64_mul($10 & $0 - $3, $11 & $7 - ($12 + ($0 >>> 0 < $3 >>> 0) | 0), $9, 0) + $1 | 0;
  $0 = $8 + i64toi32_i32$HIGH_BITS | 0;
  $0 = $3 >>> 0 < $1 >>> 0 ? $0 + 1 | 0 : $0;
  $1 = $2 & 31;
  if (32 <= ($2 & 63) >>> 0) {
   $2 = 0;
   $1 = $0 >>> $1 | 0;
  } else {
   $2 = $0 >>> $1 | 0;
   $1 = ((1 << $1) - 1 & $0) << 32 - $1 | $3 >>> $1;
  }
  $1 = $1 + $5 | 0;
  $0 = $2 + $6 | 0;
  $0 = $1 >>> 0 < $5 >>> 0 ? $0 + 1 | 0 : $0;
  i64toi32_i32$HIGH_BITS = $0;
  return $1 | 0;
 }

 function ktime_get_with_offset($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0, $15 = 0;
  $0 = HEAP32[($0 << 2) + 21760 >> 2];
  while (1) {
   $3 = HEAP32[16704];
   if ($3 & 1) {
    continue
   }
   $7 = HEAP32[$0 >> 2];
   $8 = HEAP32[$0 + 4 >> 2];
   $5 = HEAP32[16716];
   $9 = HEAP32[16717];
   $1 = HEAP32[16706];
   $1 = FUNCTION_TABLE[HEAP32[$1 >> 2]]($1) | 0;
   $10 = i64toi32_i32$HIGH_BITS;
   $4 = HEAP32[16713];
   $2 = HEAP32[16714];
   $11 = HEAP32[16715];
   $12 = HEAP32[16712];
   $13 = HEAP32[16708];
   $14 = HEAP32[16709];
   $6 = HEAP32[16710];
   $15 = HEAP32[16711];
   if (($3 | 0) != HEAP32[16704]) {
    continue
   }
   break;
  };
  $0 = $8 + $9 | 0;
  $3 = $5 + $7 | 0;
  if ($3 >>> 0 < $5 >>> 0) {
   $0 = $0 + 1 | 0
  }
  $5 = $0;
  $1 = __wasm_i64_mul($13 & $1 - $6, $14 & $10 - ($15 + ($1 >>> 0 < $6 >>> 0) | 0), $12, 0) + $2 | 0;
  $0 = $11 + i64toi32_i32$HIGH_BITS | 0;
  $0 = $1 >>> 0 < $2 >>> 0 ? $0 + 1 | 0 : $0;
  $2 = $1;
  $1 = $4 & 31;
  if (32 <= ($4 & 63) >>> 0) {
   $4 = 0;
   $2 = $0 >>> $1 | 0;
  } else {
   $4 = $0 >>> $1 | 0;
   $2 = ((1 << $1) - 1 & $0) << 32 - $1 | $2 >>> $1;
  }
  $1 = $2 + $3 | 0;
  $0 = $5 + $4 | 0;
  i64toi32_i32$HIGH_BITS = $1 >>> 0 < $2 >>> 0 ? $0 + 1 | 0 : $0;
  return $1;
 }

 function tk_set_wall_to_mono($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  $1 = HEAP32[16738];
  $4 = 0 - $1 | 0;
  $2 = 0 - (HEAP32[16739] + (0 < $1 >>> 0) | 0) | 0;
  $1 = 0 - HEAP32[16740] | 0;
  set_normalized_timespec64($3, $4, $2, $1, $1 >> 31);
  $2 = $0 + 8 | 0;
  $1 = $2;
  $5 = HEAP32[$1 + 4 >> 2];
  HEAP32[16740] = HEAP32[$1 >> 2];
  HEAP32[16741] = $5;
  $1 = HEAP32[$0 + 4 >> 2];
  $0 = HEAP32[$0 >> 2];
  HEAP32[16738] = $0;
  HEAP32[16739] = $1;
  $4 = 0 - $0 | 0;
  $1 = 0 - ((0 < $0 >>> 0) + $1 | 0) | 0;
  $0 = 0 - HEAP32[$2 >> 2] | 0;
  set_normalized_timespec64($3, $4, $1, $0, $0 >> 31);
  $0 = HEAP32[$3 + 4 >> 2];
  $1 = $0;
  $2 = HEAP32[$3 >> 2];
  $5 = __wasm_i64_mul($2, $0, 1e9, 0);
  $0 = i64toi32_i32$HIGH_BITS;
  $4 = HEAP32[$3 + 8 >> 2];
  $5 = $5 + $4 | 0;
  if ($5 >>> 0 < $4 >>> 0) {
   $0 = $0 + 1 | 0
  }
  $2 = ($1 | 0) > 2 ? 1 : ($1 | 0) >= 2 ? ($2 >>> 0 <= 633437443 ? 0 : 1) : 0;
  $1 = $2 ? -1 : $5;
  $0 = $2 ? 2147483647 : $0;
  $2 = $0;
  HEAP32[16742] = $1;
  HEAP32[16743] = $0;
  $0 = HEAP32[16748];
  $0 = __wasm_i64_mul($0, $0 >> 31, 1e9, 0) + $1 | 0;
  HEAP32[16746] = $0;
  $2 = $2 + i64toi32_i32$HIGH_BITS | 0;
  HEAP32[16747] = $0 >>> 0 < $1 >>> 0 ? $2 + 1 | 0 : $2;
  global$0 = $3 + 16 | 0;
 }

 function timekeeping_update() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0, $4 = 0, wasm2js_i32$0 = 0, wasm2js_i32$1 = 0;
  $0 = ntp_get_next_leap();
  $2 = i64toi32_i32$HIGH_BITS;
  $1 = $2;
  HEAP32[16752] = $0;
  HEAP32[16753] = $1;
  if (!(($0 | 0) == -1 & ($1 | 0) == 2147483647)) {
   $2 = HEAP32[16742];
   $1 = $1 - (HEAP32[16743] + ($0 >>> 0 < $2 >>> 0) | 0) | 0;
   HEAP32[16752] = $0 - $2;
   HEAP32[16753] = $1;
  }
  (wasm2js_i32$0 = 66920, wasm2js_i32$1 = __wasm_i64_mul(HEAP32[16754], HEAP32[16755], 1e9, 0)), HEAP32[wasm2js_i32$0 >> 2] = wasm2js_i32$1;
  HEAP32[16731] = i64toi32_i32$HIGH_BITS;
  $0 = HEAP32[16739] + HEAP32[16735] | 0;
  $1 = HEAP32[16734];
  $2 = $1 + HEAP32[16738] | 0;
  if ($2 >>> 0 < $1 >>> 0) {
   $0 = $0 + 1 | 0
  }
  $1 = __wasm_i64_mul($2, $0, 1e9, 0);
  $0 = i64toi32_i32$HIGH_BITS;
  $4 = HEAP32[16740];
  $3 = $4;
  $1 = $1 + $3 | 0;
  if ($1 >>> 0 < $3 >>> 0) {
   $0 = $0 + 1 | 0
  }
  HEAP32[16716] = $1;
  HEAP32[16717] = $0;
  $1 = HEAP32[16715];
  $3 = HEAP32[16713];
  $0 = $3 & 31;
  HEAP32[16736] = $2 + ($4 + (32 <= ($3 & 63) >>> 0 ? $1 >>> $0 | 0 : ((1 << $0) - 1 & $1) << 32 - $0 | HEAP32[16714] >>> $0) >>> 0 > 999999999);
  atomic_notifier_call_chain(67088, 1, 66824);
  $0 = HEAP32[16743] + HEAP32[16717] | 0;
  $2 = HEAP32[16716];
  $1 = $2 + HEAP32[16742] | 0;
  if ($1 >>> 0 < $2 >>> 0) {
   $0 = $0 + 1 | 0
  }
  HEAP32[16718] = $1;
  HEAP32[16719] = $0;
  update_fast_timekeeper(66824, 11392);
  update_fast_timekeeper(66880, 11520);
  HEAP32[16749] = HEAP32[16749] + 1;
  memcpy(67104, 66824, 264);
 }

 function update_fast_timekeeper($0, $1) {
  var $2 = 0;
  HEAP32[$1 >> 2] = HEAP32[$1 >> 2] + 1;
  $2 = $1 + 8 | 0;
  memcpy($2, $0, 56);
  HEAP32[$1 >> 2] = HEAP32[$1 >> 2] + 1;
  memcpy($1 - -64 | 0, $2, 56);
 }

 function tk_setup_internals($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0;
  $6 = global$0 - 16 | 0;
  global$0 = $6;
  $4 = HEAP32[16706];
  HEAP32[16706] = $0;
  $5 = HEAP32[$0 + 12 >> 2];
  HEAP32[16708] = HEAP32[$0 + 8 >> 2];
  HEAP32[16709] = $5;
  HEAP8[67e3] = HEAPU8[67e3] + 1;
  $5 = HEAP32[16706];
  $1 = FUNCTION_TABLE[HEAP32[$5 >> 2]]($5) | 0;
  HEAP32[16720] = $0;
  HEAP32[16710] = $1;
  $5 = i64toi32_i32$HIGH_BITS;
  HEAP32[16711] = $5;
  HEAP32[16724] = $1;
  HEAP32[16725] = $5;
  $5 = HEAP32[$0 + 12 >> 2];
  HEAP32[16722] = HEAP32[$0 + 8 >> 2];
  HEAP32[16723] = $5;
  $5 = HEAP32[$0 + 20 >> 2];
  $1 = $5 & 31;
  if (32 <= ($5 & 63) >>> 0) {
   $5 = 4e6 << $1;
   $7 = 0;
  } else {
   $5 = (1 << $1) - 1 & 4e6 >>> 32 - $1;
   $7 = 4e6 << $1;
  }
  $8 = $5;
  $3 = HEAP32[$0 + 16 >> 2];
  $2 = $3 >>> 1 | 0;
  $1 = $2 + $7 | 0;
  if ($1 >>> 0 < $2 >>> 0) {
   $8 = $8 + 1 | 0
  }
  $2 = $1;
  HEAP32[$6 + 8 >> 2] = $1;
  HEAP32[$6 + 12 >> 2] = $8;
  label$1 : {
   if (!(!$8 & $1 >>> 0 > 4294967295 | $8 >>> 0 > 0)) {
    $2 = ($2 >>> 0) / ($3 >>> 0) | 0;
    HEAP32[$6 + 8 >> 2] = $2;
    HEAP32[$6 + 12 >> 2] = 0;
    $1 = 0;
    break label$1;
   }
   __div64_32($6 + 8 | 0, $3);
   $2 = HEAP32[$6 + 8 >> 2];
   $1 = HEAP32[$6 + 12 >> 2];
  }
  if (!(($2 | 0) != 0 | ($1 | 0) != 0)) {
   $2 = 1;
   HEAP32[$6 + 8 >> 2] = 1;
   HEAP32[$6 + 12 >> 2] = 0;
   $1 = 0;
  }
  HEAP32[16756] = $2;
  HEAP32[16757] = $1;
  $8 = HEAP32[$0 + 16 >> 2];
  $1 = __wasm_i64_mul($2, $1, $8, 0);
  $3 = i64toi32_i32$HIGH_BITS;
  HEAP32[16762] = $1;
  HEAP32[16763] = $3;
  HEAP32[16758] = $1;
  HEAP32[16759] = $3;
  HEAP32[16760] = $7 - $1;
  HEAP32[16761] = $5 - ($3 + ($7 >>> 0 < $1 >>> 0) | 0);
  $9 = HEAP32[$0 + 20 >> 2];
  if ($4) {
   $0 = $9 - HEAP32[$4 + 20 >> 2] | 0;
   label$5 : {
    if (($0 | 0) > -1) {
     $2 = HEAP32[16715];
     $3 = HEAP32[16714];
     $1 = $0;
     $4 = $1 & 31;
     if (32 <= ($1 & 63) >>> 0) {
      $1 = $3 << $4;
      $2 = 0;
     } else {
      $1 = (1 << $4) - 1 & $3 >>> 32 - $4 | $2 << $4;
      $2 = $3 << $4;
     }
     HEAP32[16714] = $2;
     HEAP32[16715] = $1;
     $1 = HEAP32[16729];
     $2 = HEAP32[16728];
     $3 = $0 & 31;
     if (32 <= ($0 & 63) >>> 0) {
      $1 = $2 << $3;
      $0 = 0;
     } else {
      $1 = (1 << $3) - 1 & $2 >>> 32 - $3 | $1 << $3;
      $0 = $2 << $3;
     }
     break label$5;
    }
    $3 = HEAP32[16715];
    $2 = HEAP32[16714];
    $0 = 0 - $0 | 0;
    $1 = $0;
    $4 = $1 & 31;
    if (32 <= ($1 & 63) >>> 0) {
     $1 = 0;
     $2 = $3 >>> $4 | 0;
    } else {
     $1 = $3 >>> $4 | 0;
     $2 = ((1 << $4) - 1 & $3) << 32 - $4 | $2 >>> $4;
    }
    HEAP32[16714] = $2;
    HEAP32[16715] = $1;
    $3 = HEAP32[16729];
    $2 = HEAP32[16728];
    $4 = $0 & 31;
    if (32 <= ($0 & 63) >>> 0) {
     $1 = 0;
     $0 = $3 >>> $4 | 0;
    } else {
     $1 = $3 >>> $4 | 0;
     $0 = ((1 << $4) - 1 & $3) << 32 - $4 | $2 >>> $4;
    }
   }
   HEAP32[16728] = $0;
   HEAP32[16729] = $1;
  }
  HEAP32[16766] = 0;
  HEAP32[16767] = 0;
  HEAP32[16727] = $9;
  HEAP32[16713] = $9;
  HEAP32[16769] = 0;
  HEAP32[16770] = 0;
  HEAP32[16726] = $8;
  HEAP32[16712] = $8;
  $0 = 32 - $9 | 0;
  HEAP32[16768] = $0;
  $1 = $7;
  $7 = $0 & 31;
  if (32 <= ($0 & 63) >>> 0) {
   $0 = $1 << $7;
   $1 = 0;
  } else {
   $0 = (1 << $7) - 1 & $1 >>> 32 - $7 | $5 << $7;
   $1 = $1 << $7;
  }
  HEAP32[16764] = $1;
  HEAP32[16765] = $0;
  global$0 = $6 + 16 | 0;
 }

 function read_persistent_clock64($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0;
  $1 = global$0 - 32 | 0;
  global$0 = $1;
  $2 = $1 + 16 | 0;
  HEAP32[$2 >> 2] = 0;
  HEAP32[$2 + 4 >> 2] = 0;
  $3 = $1 + 32 | 0;
  $4 = HEAP32[$3 + 4 >> 2];
  $2 = $1 + 8 | 0;
  HEAP32[$2 >> 2] = HEAP32[$3 >> 2];
  HEAP32[$2 + 4 >> 2] = $4;
  $3 = HEAP32[$1 + 20 >> 2];
  $4 = HEAP32[$1 + 16 >> 2];
  HEAP32[$1 + 24 >> 2] = $4;
  HEAP32[$1 + 28 >> 2] = $3;
  HEAP32[$1 >> 2] = $4;
  HEAP32[$1 + 4 >> 2] = $3;
  $3 = HEAP32[$2 + 4 >> 2];
  $4 = $0 + 8 | 0;
  HEAP32[$4 >> 2] = HEAP32[$2 >> 2];
  HEAP32[$4 + 4 >> 2] = $3;
  $2 = HEAP32[$1 + 4 >> 2];
  HEAP32[$0 >> 2] = HEAP32[$1 >> 2];
  HEAP32[$0 + 4 >> 2] = $2;
  global$0 = $1 + 32 | 0;
 }

 function read_persistent_wall_and_boot_offset($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0;
  $2 = global$0 - 16 | 0;
  global$0 = $2;
  read_persistent_clock64($0);
  ns_to_timespec64($2, sched_clock(), i64toi32_i32$HIGH_BITS);
  $3 = $2 + 8 | 0;
  $4 = HEAP32[$3 + 4 >> 2];
  $0 = $1 + 8 | 0;
  HEAP32[$0 >> 2] = HEAP32[$3 >> 2];
  HEAP32[$0 + 4 >> 2] = $4;
  $0 = HEAP32[$2 + 4 >> 2];
  HEAP32[$1 >> 2] = HEAP32[$2 >> 2];
  HEAP32[$1 + 4 >> 2] = $0;
  global$0 = $2 + 16 | 0;
 }

 function timekeeping_init() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $1 = global$0 - 80 | 0;
  global$0 = $1;
  read_persistent_wall_and_boot_offset($1 - -64 | 0, $1 + 48 | 0);
  label$1 : {
   label$2 : {
    $4 = HEAP32[$1 + 64 >> 2];
    $0 = HEAP32[$1 + 68 >> 2];
    $2 = HEAP32[$1 + 72 >> 2];
    if ((($0 | 0) < 0 ? 1 : ($0 | 0) <= 0 ? ($4 >>> 0 >= 0 ? 0 : 1) : 0) | (($0 | 0) == 2 & $4 >>> 0 > 633437443 | $0 >>> 0 > 2) | $2 >>> 0 > 999999999) {
     break label$2
    }
    $3 = __wasm_i64_mul($4, $0, 1e9, 0) + $2 | 0;
    $6 = $3 >>> 0 >= 1 ? 0 : 1;
    $5 = i64toi32_i32$HIGH_BITS + ($2 >> 31) | 0;
    $3 = $3 >>> 0 < $2 >>> 0 ? $5 + 1 | 0 : $5;
    if (($3 | 0) < 0 ? 1 : ($3 | 0) <= 0 ? $6 : 0) {
     break label$2
    }
    HEAP8[67092] = 1;
    break label$1;
   }
   if ((__wasm_i64_mul($4, $0, 1e9, 0) | 0) == (0 - $2 | 0) & (i64toi32_i32$HIGH_BITS | 0) == (0 - (($2 >> 31) + (0 < $2 >>> 0) | 0) | 0)) {
    break label$1
   }
   $2 = 0;
   printk(21772, 0);
   HEAP32[$1 + 72 >> 2] = 0;
   $4 = 0;
   $0 = 0;
   HEAP32[$1 + 64 >> 2] = 0;
   HEAP32[$1 + 68 >> 2] = 0;
  }
  $3 = HEAP32[$1 + 48 >> 2];
  $5 = HEAP32[$1 + 52 >> 2];
  label$3 : {
   if (!(($0 | 0) < ($5 | 0) ? 1 : ($0 | 0) <= ($5 | 0) ? ($4 >>> 0 >= $3 >>> 0 ? 0 : 1) : 0)) {
    $6 = HEAP32[$1 + 56 >> 2];
    if (($2 | 0) >= ($6 | 0) | (($0 | 0) > ($5 | 0) ? 1 : ($0 | 0) >= ($5 | 0) ? ($4 >>> 0 <= $3 >>> 0 ? 0 : 1) : 0)) {
     break label$3
    }
   }
   $6 = 0;
   HEAP32[$1 + 56 >> 2] = 0;
   $3 = 0;
   $5 = 0;
   HEAP32[$1 + 48 >> 2] = 0;
   HEAP32[$1 + 52 >> 2] = 0;
  }
  $5 = $5 - (($3 >>> 0 < $4 >>> 0) + $0 | 0) | 0;
  $0 = $6 - $2 | 0;
  set_normalized_timespec64($1 + 16 | 0, $3 - $4 | 0, $5, $0, $0 >> 31);
  $2 = $1 + 24 | 0;
  $4 = HEAP32[$2 + 4 >> 2];
  $0 = $1 + 40 | 0;
  HEAP32[$0 >> 2] = HEAP32[$2 >> 2];
  HEAP32[$0 + 4 >> 2] = $4;
  $2 = HEAP32[$1 + 20 >> 2];
  HEAP32[$1 + 32 >> 2] = HEAP32[$1 + 16 >> 2];
  HEAP32[$1 + 36 >> 2] = $2;
  HEAP32[16704] = HEAP32[16704] + 1;
  ntp_clear();
  $2 = HEAP32[2956];
  if ($2) {
   FUNCTION_TABLE[$2](11760) | 0
  }
  tk_setup_internals(11760);
  HEAP32[16754] = 0;
  HEAP32[16755] = 0;
  $2 = HEAP32[$1 + 68 >> 2];
  HEAP32[16734] = HEAP32[$1 + 64 >> 2];
  HEAP32[16735] = $2;
  $2 = HEAP32[$0 + 4 >> 2];
  $4 = $1 + 8 | 0;
  HEAP32[$4 >> 2] = HEAP32[$0 >> 2];
  HEAP32[$4 + 4 >> 2] = $2;
  $0 = HEAP32[$1 + 72 >> 2];
  $2 = $0;
  $4 = $0 >> 31;
  $3 = HEAP32[16713];
  $0 = $3 & 31;
  if (32 <= ($3 & 63) >>> 0) {
   $3 = $2 << $0;
   $0 = 0;
  } else {
   $3 = (1 << $0) - 1 & $2 >>> 32 - $0 | $4 << $0;
   $0 = $2 << $0;
  }
  HEAP32[16714] = $0;
  HEAP32[16715] = $3;
  $0 = HEAP32[$1 + 36 >> 2];
  HEAP32[$1 >> 2] = HEAP32[$1 + 32 >> 2];
  HEAP32[$1 + 4 >> 2] = $0;
  tk_set_wall_to_mono($1);
  timekeeping_update();
  HEAP32[16704] = HEAP32[16704] + 1;
  global$0 = $1 + 80 | 0;
 }

 function ktime_get_update_offsets_now() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  while (1) {
   $4 = HEAP32[16704];
   if ($4 & 1) {
    continue
   }
   $3 = HEAP32[16716];
   $6 = HEAP32[16717];
   $1 = HEAP32[16706];
   $1 = FUNCTION_TABLE[HEAP32[$1 >> 2]]($1) | 0;
   $2 = HEAP32[16710];
   $2 = __wasm_i64_mul($1 - $2 & HEAP32[16708], HEAP32[16709] & i64toi32_i32$HIGH_BITS - (HEAP32[16711] + ($1 >>> 0 < $2 >>> 0) | 0), HEAP32[16712], 0);
   $1 = i64toi32_i32$HIGH_BITS + HEAP32[16715] | 0;
   $0 = HEAP32[16714];
   $5 = $2 + $0 | 0;
   if ($5 >>> 0 < $0 >>> 0) {
    $0 = $1 + 1 | 0
   } else {
    $0 = $1
   }
   $2 = $0;
   $1 = HEAP32[16713];
   $0 = $1 & 31;
   if (32 <= ($1 & 63) >>> 0) {
    $1 = 0;
    $0 = $2 >>> $0 | 0;
   } else {
    $1 = $2 >>> $0 | 0;
    $0 = ((1 << $0) - 1 & $2) << 32 - $0 | $5 >>> $0;
   }
   $2 = $3 + $0 | 0;
   $1 = $1 + $6 | 0;
   $1 = $2 >>> 0 < $0 >>> 0 ? $1 + 1 | 0 : $1;
   $0 = HEAP32[16749];
   if (($0 | 0) != HEAP32[2754]) {
    $3 = HEAP32[16743];
    HEAP32[2782] = HEAP32[16742];
    HEAP32[2783] = $3;
    $3 = HEAP32[16745];
    HEAP32[2792] = HEAP32[16744];
    HEAP32[2793] = $3;
    HEAP32[2754] = $0;
    $0 = HEAP32[16747];
    HEAP32[2802] = HEAP32[16746];
    HEAP32[2803] = $0;
   }
   $0 = HEAP32[16753];
   if (!(($1 | 0) < ($0 | 0) ? 1 : ($1 | 0) <= ($0 | 0) ? ($2 >>> 0 >= HEAPU32[16752] ? 0 : 1) : 0)) {
    $0 = HEAP32[16743] + -1 | 0;
    $3 = HEAP32[16742] + -1e9 | 0;
    if ($3 >>> 0 < 3294967296) {
     $0 = $0 + 1 | 0
    }
    HEAP32[2782] = $3;
    HEAP32[2783] = $0;
   }
   if (HEAP32[16704] != ($4 | 0)) {
    continue
   }
   break;
  };
  i64toi32_i32$HIGH_BITS = $1;
  return $2;
 }

 function dummy_clock_read($0) {
  $0 = $0 | 0;
  i64toi32_i32$HIGH_BITS = HEAP32[16775];
  return HEAP32[16774];
 }

 function ntp_clear() {
  var $0 = 0;
  HEAP32[2936] = 16e6;
  HEAP32[2937] = 16e6;
  HEAP32[2935] = HEAP32[2935] | 64;
  HEAP32[16842] = 0;
  ntp_update_frequency();
  HEAP32[16848] = 0;
  HEAP32[16849] = 0;
  HEAP32[2938] = -1;
  HEAP32[2939] = 2147483647;
  $0 = HEAP32[16845];
  HEAP32[16846] = HEAP32[16844];
  HEAP32[16847] = $0;
 }

 function ntp_update_frequency() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $1 = HEAP32[16853] + HEAP32[16857] | 0;
  $3 = HEAP32[16856];
  $0 = $3 + HEAP32[16852] | 0;
  if ($0 >>> 0 < $3 >>> 0) {
   $1 = $1 + 1 | 0
  }
  $3 = 0;
  $4 = $3 + $0 | 0;
  $2 = Math_imul(HEAP32[2934], 1024e3) + $1 | 0;
  $2 = $4 >>> 0 < 0 ? $2 + 1 | 0 : $2;
  $3 = $2;
  $6 = __wasm_i64_mul($4, 0, -1924145349, 0);
  $0 = i64toi32_i32$HIGH_BITS;
  $5 = $0;
  $0 = $0 + -2095944041 | 0;
  $1 = $6 + -1924145349 | 0;
  if ($1 >>> 0 < 2370821947) {
   $0 = $0 + 1 | 0
  }
  $2 = $1;
  $1 = $0;
  $0 = ($5 | 0) == ($0 | 0) & $2 >>> 0 < $6 >>> 0 | $0 >>> 0 < $5 >>> 0;
  $2 = $1;
  $6 = $3;
  $3 = 0;
  $1 = __wasm_i64_mul($6, $3, -1924145349, 0);
  $5 = $2 + $1 | 0;
  $0 = i64toi32_i32$HIGH_BITS + $0 | 0;
  $0 = $5 >>> 0 < $1 >>> 0 ? $0 + 1 | 0 : $0;
  $1 = __wasm_i64_mul($4, 0, -2095944041, 0);
  $2 = $5 + $1 | 0;
  $4 = $0;
  $0 = $0 + i64toi32_i32$HIGH_BITS | 0;
  $0 = $2 >>> 0 < $1 >>> 0 ? $0 + 1 | 0 : $0;
  $1 = $0;
  $0 = ($4 | 0) == ($0 | 0) & $2 >>> 0 < $5 >>> 0 | $0 >>> 0 < $4 >>> 0;
  $3 = $1;
  $1 = __wasm_i64_mul($6, 0, -2095944041, 0);
  $3 = $3 + $1 | 0;
  $2 = i64toi32_i32$HIGH_BITS + $0 | 0;
  $2 = $3 >>> 0 < $1 >>> 0 ? $2 + 1 | 0 : $2;
  $1 = $3;
  $0 = $2;
  HEAP32[16854] = $0 >>> 7;
  $3 = HEAP32[16844];
  $5 = HEAP32[16845];
  $1 = ($0 & 127) << 25 | $1 >>> 7;
  HEAP32[16844] = $1;
  $2 = $0 >>> 7 | 0;
  HEAP32[16845] = $2;
  $4 = HEAP32[16846];
  $0 = $3;
  $3 = $1 + ($4 - $0 | 0) | 0;
  $0 = $2 + (HEAP32[16847] - ($5 + ($4 >>> 0 < $0 >>> 0) | 0) | 0) | 0;
  HEAP32[16846] = $3;
  HEAP32[16847] = $3 >>> 0 < $1 >>> 0 ? $0 + 1 | 0 : $0;
 }

 function ntp_get_next_leap() {
  var $0 = 0, $1 = 0, $2 = 0;
  $1 = -1;
  if (!(HEAPU8[11740] & 16) | HEAP32[16850] != 1) {
   $0 = 2147483647
  } else {
   $0 = HEAP32[2938];
   $1 = HEAP32[2939];
   $2 = __wasm_i64_mul($0, $1, 1e9, 0);
   $0 = ($1 | 0) > 2 ? 1 : ($1 | 0) >= 2 ? ($0 >>> 0 <= 633437443 ? 0 : 1) : 0;
   $1 = $0 ? -1 : $2;
   $0 = $0 ? 2147483647 : i64toi32_i32$HIGH_BITS;
  }
  i64toi32_i32$HIGH_BITS = $0;
  return $1;
 }

 function jiffies_read($0) {
  $0 = $0 | 0;
  i64toi32_i32$HIGH_BITS = 0;
  return HEAP32[20749];
 }

 function call_rcu($0, $1) {
  HEAP32[$0 >> 2] = 0;
  HEAP32[$0 + 4 >> 2] = $1;
  HEAP32[HEAP32[2966] >> 2] = $0;
  HEAP32[2966] = $0;
  if (!(HEAPU8[HEAP32[2] + 12 | 0] & 2)) {
   return
  }
  $0 = HEAP32[19828];
  HEAP32[19828] = 0;
  resched_curr(12208);
  HEAP32[19828] = $0;
 }

 function rcu_process_callbacks($0) {
  $0 = $0 | 0;
  var $1 = 0, $2 = 0;
  label$1 : {
   $1 = HEAP32[2965];
   if (($1 | 0) == 11856) {
    break label$1
   }
   $0 = HEAP32[2964];
   HEAP32[2964] = HEAP32[$1 >> 2];
   HEAP32[$1 >> 2] = 0;
   if (HEAP32[2966] == HEAP32[2965]) {
    HEAP32[2966] = 11856
   }
   HEAP32[2965] = 11856;
   while (1) {
    if (!$0) {
     break label$1
    }
    HEAP32[1] = HEAP32[1] + 512;
    $1 = HEAP32[$0 >> 2];
    $2 = HEAP32[$0 + 4 >> 2];
    if ($2 >>> 0 <= 4095) {
     kfree($0 - $2 | 0);
     $0 = $1;
     continue;
    } else {
     HEAP32[$0 + 4 >> 2] = 0;
     FUNCTION_TABLE[$2]($0);
     $0 = $1;
     continue;
    }
   };
  }
 }

 function msg_print_ext_header($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0;
  $8 = global$0 - 32 | 0;
  global$0 = $8;
  $12 = HEAPU8[$0 + 14 | 0];
  $3 = HEAP32[$0 >> 2];
  $6 = HEAP32[$0 + 4 >> 2];
  $9 = HEAPU8[$0 + 15 | 0];
  HEAP32[$8 + 24 >> 2] = $9 & 8 ? 99 : 45;
  $4 = __wasm_i64_mul($3, 0, -1924145349, 0);
  $0 = i64toi32_i32$HIGH_BITS;
  $7 = $0;
  $0 = $0 + -2095944041 | 0;
  $10 = $4 + -1924145349 | 0;
  if ($10 >>> 0 < 2370821947) {
   $0 = $0 + 1 | 0
  }
  $11 = __wasm_i64_mul($6, 0, -1924145349, 0);
  $5 = $11 + $0 | 0;
  $0 = i64toi32_i32$HIGH_BITS + (($0 | 0) == ($7 | 0) & $10 >>> 0 < $4 >>> 0 | $0 >>> 0 < $7 >>> 0) | 0;
  $4 = __wasm_i64_mul($3, 0, -2095944041, 0);
  $3 = $4 + $5 | 0;
  $0 = $5 >>> 0 < $11 >>> 0 ? $0 + 1 | 0 : $0;
  $7 = $0 + i64toi32_i32$HIGH_BITS | 0;
  $4 = $3 >>> 0 < $4 >>> 0 ? $7 + 1 | 0 : $7;
  $3 = ($4 | 0) == ($0 | 0) & $3 >>> 0 < $5 >>> 0 | $4 >>> 0 < $0 >>> 0;
  $5 = __wasm_i64_mul($6, 0, -2095944041, 0);
  $0 = $5 + $4 | 0;
  $6 = $8 + 16 | 0;
  $3 = i64toi32_i32$HIGH_BITS + $3 | 0;
  $3 = $0 >>> 0 < $5 >>> 0 ? $3 + 1 | 0 : $3;
  HEAP32[$6 >> 2] = ($3 & 511) << 23 | $0 >>> 9;
  HEAP32[$6 + 4 >> 2] = $3 >>> 9;
  $0 = $8;
  HEAP32[$0 + 8 >> 2] = $1;
  HEAP32[$0 + 12 >> 2] = $2;
  HEAP32[$0 >> 2] = $12 << 3 | $9 >>> 5;
  $1 = scnprintf(68992, 8192, 22024, $0);
  global$0 = $0 + 32 | 0;
  return $1;
 }

 function msg_print_ext_body($0, $1, $2, $3, $4, $5) {
  var $6 = 0, $7 = 0, $8 = 0;
  $7 = global$0 - 32 | 0;
  global$0 = $7;
  $6 = $0 + $1 | 0;
  $1 = $0;
  while (1) {
   if ($5) {
    $8 = HEAPU8[$4 | 0];
    label$3 : {
     if (!(($8 | 0) == 92 | ($8 + -32 & 255) >>> 0 >= 95)) {
      if ($6 >>> 0 <= $1 >>> 0) {
       break label$3
      }
      HEAP8[$1 | 0] = $8;
      $1 = $1 + 1 | 0;
      break label$3;
     }
     HEAP32[$7 + 16 >> 2] = $8;
     $1 = scnprintf($1, $6 - $1 | 0, 22041, $7 + 16 | 0) + $1 | 0;
    }
    $4 = $4 + 1 | 0;
    $5 = $5 + -1 | 0;
    continue;
   }
   break;
  };
  if ($6 >>> 0 > $1 >>> 0) {
   HEAP8[$1 | 0] = 10;
   $1 = $1 + 1 | 0;
  }
  label$6 : {
   if (!$3) {
    break label$6
   }
   $4 = 1;
   while (1) {
    if ($3) {
     $5 = HEAPU8[$2 | 0];
     if (!(!($4 & 1) | $6 >>> 0 <= $1 >>> 0)) {
      HEAP8[$1 | 0] = 32;
      $1 = $1 + 1 | 0;
     }
     label$10 : {
      label$11 : {
       if ($5) {
        if (($5 | 0) == 92 | ($5 + -32 & 255) >>> 0 >= 95) {
         break label$11
        }
        $4 = 0;
        if ($6 >>> 0 <= $1 >>> 0) {
         break label$10
        }
        HEAP8[$1 | 0] = $5;
        $1 = $1 + 1 | 0;
        break label$10;
       }
       $4 = 1;
       if ($6 >>> 0 <= $1 >>> 0) {
        break label$10
       }
       HEAP8[$1 | 0] = 10;
       $1 = $1 + 1 | 0;
       break label$10;
      }
      HEAP32[$7 >> 2] = $5;
      $1 = scnprintf($1, $6 - $1 | 0, 22041, $7) + $1 | 0;
      $4 = 0;
     }
     $2 = $2 + 1 | 0;
     $3 = $3 + -1 | 0;
     continue;
    }
    break;
   };
   if ($6 >>> 0 <= $1 >>> 0) {
    break label$6
   }
   HEAP8[$1 | 0] = 10;
   $1 = $1 + 1 | 0;
  }
  global$0 = $7 + 32 | 0;
  return $1 - $0 | 0;
 }

 function printk($0, $1) {
  var $2 = 0;
  $2 = global$0 - 16 | 0;
  global$0 = $2;
  HEAP32[$2 + 12 >> 2] = $1;
  vprintk_func($0, $1);
  global$0 = $2 + 16 | 0;
 }

 function setup_log_buf() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0;
  $0 = global$0 - 48 | 0;
  global$0 = $0;
  label$1 : {
   if (HEAP32[2974] != 67432) {
    break label$1
   }
   $1 = HEAP32[35290];
   if (!$1) {
    break label$1
   }
   label$2 : {
    $1 = memblock_alloc_try_nid_nopanic($1, 8, -1);
    if (!$1) {
     break label$2
    }
    $2 = HEAPU8[78268];
    HEAP8[78268] = 0;
    __printk_safe_enter();
    HEAP32[2974] = $1;
    HEAP32[2975] = HEAP32[35290];
    HEAP32[35290] = 0;
    $3 = HEAP32[16986];
    memcpy($1, 67432, 512);
    __printk_safe_exit();
    HEAP8[78268] = $2 & 1;
    HEAP32[$0 + 32 >> 2] = HEAP32[2975];
    printk(21869, $0 + 32 | 0);
    $1 = 512 - $3 | 0;
    HEAP32[$0 + 16 >> 2] = $1;
    HEAP32[$0 + 20 >> 2] = Math_imul($1, 100) >>> 9;
    printk(21901, $0 + 16 | 0);
    break label$1;
   }
   HEAP32[$0 >> 2] = HEAP32[35290];
   printk(21822, $0);
  }
  global$0 = $0 + 48 | 0;
 }

 function msg_print_text($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0;
  $4 = $0 + 16 | 0;
  $7 = HEAPU16[$0 + 10 >> 1];
  while (1) {
   $5 = memchr($4, $7);
   label$2 : {
    if ($5) {
     $8 = $5 + 1 | 0;
     $7 = ($4 + $7 | 0) - $8 | 0;
     $5 = $5 - $4 | 0;
     break label$2;
    }
    $8 = 0;
    $5 = $7;
   }
   $9 = $5 + print_prefix($0, $1, 0) | 0;
   label$4 : {
    label$5 : {
     if ($2) {
      if ($9 + 1 >>> 0 >= $3 - $6 >>> 0) {
       break label$4
      }
      $6 = print_prefix($0, $1, $2 + $6 | 0) + $6 | 0;
      memcpy($6 + $2 | 0, $4, $5);
      $4 = $6 + $5 | 0;
      HEAP8[$4 + $2 | 0] = 10;
      break label$5;
     }
     $4 = $6 + $9 | 0;
    }
    $6 = $4 + 1 | 0;
    $4 = $8;
    if ($4) {
     continue
    }
   }
   break;
  };
  return $6;
 }

 function print_prefix($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0;
  $6 = global$0 - 48 | 0;
  global$0 = $6;
  $3 = 0;
  label$1 : {
   if (!$1) {
    break label$1
   }
   $1 = HEAPU8[$0 + 14 | 0] << 3 | HEAPU8[$0 + 15 | 0] >>> 5;
   if ($2) {
    HEAP32[$6 + 32 >> 2] = $1;
    $3 = sprintf($2, 21976, $6 + 32 | 0);
    break label$1;
   }
   $3 = 6;
   if ($1 >>> 0 > 999) {
    break label$1
   }
   $3 = 5;
   if ($1 >>> 0 > 99) {
    break label$1
   }
   $3 = $1 >>> 0 > 9 ? 4 : 3;
  }
  $7 = $3;
  label$3 : {
   if (!HEAPU8[67949]) {
    break label$3
   }
   $4 = HEAP32[$0 + 4 >> 2];
   $8 = HEAP32[$0 >> 2];
   $3 = $8;
   $0 = __wasm_i64_mul($3, 0, 917808535, 0) + 917808535 | 0;
   $5 = i64toi32_i32$HIGH_BITS + -1989124287 | 0;
   $1 = $0 >>> 0 < 917808535 ? $5 + 1 | 0 : $5;
   $9 = $4;
   $4 = 0;
   $0 = __wasm_i64_mul($9, $4, 917808535, 0);
   $4 = $1 + $0 | 0;
   $5 = i64toi32_i32$HIGH_BITS;
   $1 = __wasm_i64_mul($3, 0, -1989124287, 0);
   $3 = $4 + $1 | 0;
   $5 = $4 >>> 0 < $0 >>> 0 ? $5 + 1 | 0 : $5;
   $0 = $5 + i64toi32_i32$HIGH_BITS | 0;
   $0 = $3 >>> 0 < $1 >>> 0 ? $0 + 1 | 0 : $0;
   $1 = $0;
   $0 = ($5 | 0) == ($0 | 0) & $3 >>> 0 < $4 >>> 0 | $0 >>> 0 < $5 >>> 0;
   $4 = $1;
   $1 = __wasm_i64_mul($9, 0, -1989124287, 0);
   $4 = $4 + $1 | 0;
   $5 = i64toi32_i32$HIGH_BITS + $0 | 0;
   $0 = $4;
   $1 = (($0 >>> 0 < $1 >>> 0 ? $5 + 1 | 0 : $5) & 536870911) << 3 | $0 >>> 29;
   $0 = $2 ? $2 + $7 | 0 : 0;
   if ($0) {
    HEAP32[$6 + 16 >> 2] = $1;
    HEAP32[$6 + 20 >> 2] = ($8 + Math_imul($1, -1e9) >>> 0) / 1e3;
    $4 = sprintf($0, 21996, $6 + 16 | 0);
    break label$3;
   }
   HEAP32[$6 >> 2] = $1;
   $4 = snprintf(0, 0, 21981, $6);
  }
  global$0 = $6 + 48 | 0;
  return $4 + $7 | 0;
 }

 function vprintk_store($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $4 = 67984;
  $1 = vscnprintf(67984, 992, $1, $2);
  label$2 : {
   if ($1) {
    $3 = $1 + -1 | 0;
    $2 = $1;
    $1 = HEAPU8[$1 + 67983 | 0] == 10;
    $2 = $1 ? $3 : $2;
    $1 = $1 << 1;
    break label$2;
   }
   $2 = 0;
   $1 = 0;
  }
  while (1) {
   label$1 : {
    if (HEAPU8[$4 | 0] != 1) {
     break label$1
    }
    $3 = HEAP8[$4 + 1 | 0];
    if (!$3) {
     break label$1
    }
    $5 = 4;
    $6 = $3 + -48 | 0;
    label$5 : {
     if ($6 >>> 0 < 8) {
      $0 = ($0 | 0) == -1 ? $6 : $0;
      break label$5;
     }
     if (($3 | 0) == 99) {
      $5 = 8;
      break label$5;
     }
     if (($3 | 0) != 100) {
      break label$1
     }
    }
    $4 = $4 + 2 | 0;
    $2 = $2 + -2 | 0;
    $1 = $1 | $5;
    continue;
   }
   break;
  };
  $0 = ($0 | 0) == -1 ? HEAP32[2969] : $0;
  label$8 : {
   label$9 : {
    label$10 : {
     label$11 : {
      if (HEAP32[19816]) {
       $3 = $1 & 8;
       if (!(!$3 | HEAP32[19817] != HEAP32[2])) {
        if (cont_add($0, $1, $4, $2)) {
         break label$9
        }
       }
       cont_flush();
       if (!$2) {
        break label$11
       }
       break label$10;
      }
      $3 = $1 & 8;
      if ($2) {
       break label$10
      }
     }
     if (!$3) {
      break label$10
     }
     return;
    }
    if ($1 & 2) {
     break label$8
    }
    if (!cont_add($0, $1, $4, $2)) {
     break label$8
    }
   }
   return;
  }
  log_store(0, $0, $1, 0, 0, $4, $2 & 65535);
 }

 function cont_add($0, $1, $2, $3) {
  var $4 = 0, $5 = 0;
  $4 = HEAP32[19816];
  label$1 : {
   if ($4 + $3 >>> 0 < 993) {
    if (!$4) {
     HEAP8[79280] = $0;
     HEAP8[79281] = 0;
     HEAP32[19817] = HEAP32[2];
     $0 = sched_clock();
     HEAP32[19821] = $1;
     HEAP32[19818] = $0;
     HEAP32[19819] = i64toi32_i32$HIGH_BITS;
     $4 = HEAP32[19816];
    }
    memcpy($4 + 78272 | 0, $2, $3);
    HEAP32[19816] = HEAP32[19816] + $3;
    $5 = 1;
    if (!($1 & 2)) {
     break label$1
    }
    HEAP32[19821] = HEAP32[19821] | 2;
   }
   cont_flush();
  }
  return $5;
 }

 function cont_flush() {
  var $0 = 0;
  $0 = HEAP32[19816];
  if ($0) {
   log_store(HEAPU8[79281], HEAPU8[79280], HEAP32[19821], HEAP32[19818], HEAP32[19819], 78272, $0 & 65535);
   HEAP32[19816] = 0;
  }
 }

 function log_store($0, $1, $2, $3, $4, $5, $6) {
  var $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0;
  $9 = -16 - $6 & 7;
  $8 = ($6 + $9 | 0) + 16 | 0;
  if (log_make_free_space($8)) {
   $7 = HEAP32[2975] >>> 2 | 0;
   $6 = $7 >>> 0 < $6 >>> 0 ? $7 : $6;
   $12 = strlen(22010);
   $7 = $6 + $12 | 0;
   $9 = 0 - $7 & 7;
   $8 = ($9 + ($7 & 65535) | 0) + 16 | 0;
   if (log_make_free_space($8)) {
    return
   }
  }
  $7 = HEAP32[16986];
  label$3 : {
   if (($7 + $8 | 0) + 16 >>> 0 > HEAPU32[2975]) {
    memset($7 + HEAP32[2974] | 0, 0, 16);
    HEAP32[16986] = 0;
    $7 = 0;
    break label$3;
   }
  }
  $7 = $7 + HEAP32[2974] | 0;
  $10 = $7 + 16 | 0;
  $11 = $6 & 65535;
  memcpy($10, $5, $11);
  HEAP16[$7 + 10 >> 1] = $6;
  $6 = $12 & 65535;
  if ($6) {
   memcpy($10 + $11 | 0, 22010, $6);
   $13 = $7 + 10 | 0;
   $6 = $12 + HEAPU16[$13 >> 1] | 0;
   HEAP16[$13 >> 1] = $6;
   $6 = $6 & 65535;
  } else {
   $6 = $11
  }
  memcpy($6 + $10 | 0, 0, 0);
  HEAP8[$7 + 15 | 0] = $2 & 31 | $1 << 5;
  HEAP8[$7 + 14 | 0] = $0;
  HEAP16[$7 + 12 >> 1] = 0;
  if (!(($3 | 0) != 0 | ($4 | 0) != 0)) {
   $3 = sched_clock();
   $4 = i64toi32_i32$HIGH_BITS;
  }
  HEAP32[$7 >> 2] = $3;
  HEAP32[$7 + 4 >> 2] = $4;
  memset(HEAPU16[$7 + 10 >> 1] + $10 | 0, 0, $9);
  HEAP16[$7 + 8 >> 1] = $8;
  HEAP32[16986] = HEAP32[16986] + ($8 & 65535);
  $0 = HEAP32[16989];
  $1 = HEAP32[16988] + 1 | 0;
  if ($1 >>> 0 < 1) {
   $0 = $0 + 1 | 0
  }
  HEAP32[16988] = $1;
  HEAP32[16989] = $0;
  write(1, $5, $11);
  write(1, 22022, 1);
 }

 function vprintk_emit($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $3 = HEAPU8[78268];
  HEAP8[78268] = 0;
  __printk_safe_enter();
  $4 = HEAP32[16988];
  $5 = HEAP32[16989];
  $6 = ($0 | 0) == -2;
  vprintk_store($6 ? -1 : $0, $1, $2);
  $0 = HEAP32[16988];
  $1 = HEAP32[16989];
  __printk_safe_exit();
  HEAP8[78268] = $3 & 1;
  if (!(($0 | 0) == ($4 | 0) & ($1 | 0) == ($5 | 0) | $6)) {
   label$2 : {
    label$3 : {
     if (console_trylock()) {
      break label$3
     }
     $2 = HEAPU8[78268];
     HEAP8[78268] = 0;
     __printk_safe_enter();
     $3 = HEAP32[19822];
     if (!(HEAPU8[79292] | !$3 | ($3 | 0) == HEAP32[2])) {
      HEAP8[79292] = 1;
      while (1) {
       if (HEAPU8[79292]) {
        continue
       }
       break;
      };
      __printk_safe_exit();
      HEAP8[78268] = $2 & 1;
      break label$3;
     }
     __printk_safe_exit();
     HEAP8[78268] = $2 & 1;
     break label$2;
    }
    console_unlock();
   }
  }
  if (!(($0 | 0) == ($4 | 0) & ($1 | 0) == ($5 | 0))) {
   wake_up_klogd()
  }
 }

 function console_trylock() {
  if (__down_trylock_console_sem()) {
   return 0
  }
  if (HEAPU8[68976]) {
   __up_console_sem();
   return 0;
  }
  HEAP8[68980] = 1;
  HEAP8[68984] = 0;
  return 1;
 }

 function console_unlock() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0;
  $6 = global$0 - 16 | 0;
  global$0 = $6;
  label$1 : {
   if (HEAPU8[68976]) {
    __up_console_sem();
    break label$1;
   }
   $10 = HEAPU8[68984] ^ 1;
   while (1) {
    HEAP8[68984] = 0;
    while (1) {
     $4 = 0;
     $9 = HEAPU8[78268];
     HEAP8[78268] = 0;
     __printk_safe_enter();
     $3 = HEAP32[16991];
     $1 = HEAP32[19553];
     $0 = HEAP32[16990];
     $2 = HEAP32[19552];
     if (!(($3 | 0) == ($1 | 0) & $0 >>> 0 <= $2 >>> 0 | $3 >>> 0 < $1 >>> 0)) {
      HEAP32[$6 >> 2] = $0 - $2;
      HEAP32[$6 + 4 >> 2] = $3 - ($1 + ($0 >>> 0 < $2 >>> 0) | 0);
      $4 = sprintf(77184, 21940, $6);
      $0 = HEAP32[16991];
      $1 = $0;
      $2 = HEAP32[16990];
      HEAP32[19552] = $2;
      HEAP32[19553] = $0;
      HEAP32[19554] = HEAP32[16992];
     }
     $8 = HEAPU8[67948];
     $11 = HEAP32[2968];
     $3 = HEAP32[2974];
     $12 = HEAP32[16988];
     $13 = HEAP32[16989];
     label$6 : {
      while (1) {
       if (($2 | 0) == ($12 | 0) & ($1 | 0) == ($13 | 0)) {
        break label$6
       }
       $7 = HEAP32[19554];
       $0 = $7 + $3 | 0;
       $5 = HEAPU16[$0 + 8 >> 1];
       $0 = $5 ? $0 : $3;
       if (!($8 | ($11 | 0) > (HEAPU8[$0 + 15 | 0] >>> 5 | 0))) {
        if ($5) {
         $0 = $5 + $7 | 0
        } else {
         $0 = HEAPU16[$3 + 8 >> 1]
        }
        HEAP32[19554] = $0;
        $2 = $2 + 1 | 0;
        if ($2 >>> 0 < 1) {
         $1 = $1 + 1 | 0
        }
        HEAP32[19552] = $2;
        HEAP32[19553] = $1;
        continue;
       }
       break;
      };
      label$11 : {
       if (!HEAP32[19555]) {
        break label$11
       }
       $3 = HEAP32[19557];
       if (($3 | 0) == ($1 | 0) & $2 >>> 0 < HEAPU32[19556] | $1 >>> 0 < $3 >>> 0) {
        break label$11
       }
       HEAP32[19555] = 0;
      }
      $2 = 0;
      $3 = msg_print_text($0, HEAPU8[78232], $4 + 77184 | 0, 1024 - $4 | 0);
      if (HEAP32[19559]) {
       $1 = msg_print_ext_header($0, HEAP32[19552], HEAP32[19553]);
       $5 = $1;
       $8 = $1 + 68992 | 0;
       $7 = 8192 - $1 | 0;
       $1 = $0 + 16 | 0;
       $2 = HEAPU16[$0 + 10 >> 1];
       $2 = $5 + msg_print_ext_body($8, $7, $1 + $2 | 0, HEAPU16[$0 + 12 >> 1], $1, $2) | 0;
      }
      $1 = HEAP32[2974] + 8 | 0;
      $0 = HEAP32[19554];
      $5 = HEAPU16[$1 + $0 >> 1];
      label$13 : {
       if ($5) {
        $1 = $0 + $5 | 0;
        break label$13;
       }
       $1 = HEAPU16[$1 >> 1];
      }
      HEAP32[19554] = $1;
      $1 = HEAP32[19553];
      $0 = HEAP32[19552] + 1 | 0;
      if ($0 >>> 0 < 1) {
       $1 = $1 + 1 | 0
      }
      HEAP32[19552] = $0;
      HEAP32[19553] = $1;
      HEAP32[19822] = HEAP32[2];
      label$15 : {
       $0 = HEAP32[19561];
       if (!$0) {
        break label$15
       }
       $4 = $3 + $4 | 0;
       while (1) {
        if (!$0) {
         break label$15
        }
        $1 = HEAP32[19555];
        label$17 : {
         if (($0 | 0) != ($1 | 0) ? $1 : 0) {
          break label$17
         }
         $3 = HEAP16[$0 + 40 >> 1];
         if (!($3 & 4)) {
          break label$17
         }
         $1 = HEAP32[$0 + 16 >> 2];
         if (!$1) {
          break label$17
         }
         if (!($3 & 64)) {
          FUNCTION_TABLE[$1]($0, 77184, $4);
          break label$17;
         }
         FUNCTION_TABLE[$1]($0, 68992, $2);
        }
        $0 = HEAP32[$0 + 52 >> 2];
        continue;
       };
      }
      $0 = 0;
      HEAP32[19822] = 0;
      if (HEAPU8[79292]) {
       HEAP8[79292] = 0;
       $0 = 1;
      }
      __printk_safe_exit();
      HEAP8[78268] = $9 & 1;
      if (!(($0 | $10) & 1)) {
       _cond_resched();
       $0 = 0;
      }
      if (!$0) {
       continue
      }
      break label$1;
     }
     break;
    };
    HEAP8[68980] = 0;
    __up_console_sem();
    $1 = HEAP32[16988];
    $2 = HEAP32[16989];
    $0 = HEAP32[19552];
    $4 = HEAP32[19553];
    __printk_safe_exit();
    HEAP8[78268] = $9 & 1;
    if (($0 | 0) == ($1 | 0) & ($2 | 0) == ($4 | 0)) {
     break label$1
    }
    if (console_trylock()) {
     continue
    }
    break;
   };
  }
  global$0 = $6 + 16 | 0;
 }

 function wake_up_klogd() {
  if (HEAP32[2972] != 11888) {
   HEAP32[2979] = HEAP32[2979] | 1;
   irq_work_queue(11920);
  }
 }

 function __up_console_sem() {
  var $0 = 0;
  $0 = HEAPU8[78268];
  HEAP8[78268] = 0;
  __printk_safe_enter();
  up();
  __printk_safe_exit();
  HEAP8[78268] = $0 & 1;
 }

 function __down_trylock_console_sem() {
  var $0 = 0, $1 = 0;
  $0 = HEAPU8[78268];
  HEAP8[78268] = 0;
  __printk_safe_enter();
  $1 = down_trylock();
  __printk_safe_exit();
  HEAP8[78268] = $0 & 1;
  return ($1 | 0) != 0;
 }

 function console_unblank() {
  var $0 = 0, $1 = 0;
  label$1 : {
   if (HEAP32[19560]) {
    if (!__down_trylock_console_sem()) {
     break label$1
    }
    return;
   }
   down();
   if (!HEAPU8[68976]) {
    HEAP8[68984] = 1;
    HEAP8[68980] = 1;
   }
  }
  HEAP8[68980] = 1;
  HEAP8[68984] = 0;
  $0 = 78244;
  while (1) {
   $0 = HEAP32[$0 >> 2];
   if ($0) {
    label$5 : {
     if (!(HEAPU8[$0 + 40 | 0] & 4)) {
      break label$5
     }
     $1 = HEAP32[$0 + 28 >> 2];
     if (!$1) {
      break label$5
     }
     FUNCTION_TABLE[$1]();
    }
    $0 = $0 + 52 | 0;
    continue;
   }
   break;
  };
  console_unlock();
 }

 function defer_console_output() {
  HEAP32[2979] = HEAP32[2979] | 2;
  irq_work_queue(11920);
 }

 function printk_deferred($0, $1) {
  var $2 = 0;
  $2 = global$0 - 16 | 0;
  global$0 = $2;
  HEAP32[$2 + 12 >> 2] = $1;
  vprintk_emit(-2, $0, $1);
  defer_console_output();
  global$0 = $2 + 16 | 0;
 }

 function kmsg_dump($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  label$1 : {
   if (HEAPU8[78248] ? 0 : $0 >>> 0 >= 3) {
    break label$1
   }
   $1 = 11932;
   while (1) {
    $1 = HEAP32[$1 >> 2];
    if (($1 | 0) == 11932) {
     break label$1
    }
    $2 = HEAP32[$1 + 12 >> 2];
    if ($2 >>> 0 < $0 >>> 0 ? $2 : 0) {
     continue
    }
    HEAP8[$1 + 16 | 0] = 1;
    $2 = HEAPU8[78268];
    HEAP8[78268] = 0;
    __printk_safe_enter();
    $3 = HEAP32[19565];
    HEAP32[$1 + 32 >> 2] = HEAP32[19564];
    HEAP32[$1 + 36 >> 2] = $3;
    HEAP32[$1 + 20 >> 2] = HEAP32[19566];
    $3 = HEAP32[16989];
    HEAP32[$1 + 40 >> 2] = HEAP32[16988];
    HEAP32[$1 + 44 >> 2] = $3;
    HEAP32[$1 + 24 >> 2] = HEAP32[16986];
    __printk_safe_exit();
    HEAP8[78268] = $2 & 1;
    FUNCTION_TABLE[HEAP32[$1 + 8 >> 2]]($1, $0);
    HEAP8[$1 + 16 | 0] = 0;
    continue;
   };
  }
 }

 function log_make_free_space($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  $5 = HEAP32[16988];
  $4 = HEAP32[16989];
  $3 = HEAP32[16990];
  $2 = HEAP32[16991];
  while (1) {
   label$1 : {
    if (($2 | 0) == ($4 | 0) & $3 >>> 0 >= $5 >>> 0 | $2 >>> 0 > $4 >>> 0) {
     break label$1
    }
    if (logbuf_has_space($0, 0)) {
     break label$1
    }
    $6 = HEAP32[2974] + 8 | 0;
    $7 = HEAP32[16992];
    $1 = HEAPU16[$6 + $7 >> 1];
    label$3 : {
     if ($1) {
      $1 = $1 + $7 | 0;
      break label$3;
     }
     $1 = HEAPU16[$6 >> 1];
    }
    HEAP32[16992] = $1;
    $1 = $3 + 1 | 0;
    if ($1 >>> 0 < 1) {
     $2 = $2 + 1 | 0
    }
    $3 = $1;
    HEAP32[16990] = $1;
    HEAP32[16991] = $2;
    continue;
   }
   break;
  };
  $1 = HEAP32[19565];
  if (!(($2 | 0) == ($1 | 0) & HEAPU32[19564] >= $3 >>> 0 | $1 >>> 0 > $2 >>> 0)) {
   HEAP32[19564] = $3;
   HEAP32[19565] = $2;
   HEAP32[19566] = HEAP32[16992];
  }
  return logbuf_has_space($0, ($3 | 0) == ($5 | 0) & ($2 | 0) == ($4 | 0)) ? 0 : -12;
 }

 function logbuf_has_space($0, $1) {
  var $2 = 0, $3 = 0;
  $2 = HEAP32[16992];
  $3 = HEAP32[16986];
  label$1 : {
   if (!($1 | $2 >>> 0 < $3 >>> 0)) {
    $1 = $2 - $3 | 0;
    break label$1;
   }
   $1 = HEAP32[2975] - $3 | 0;
   $1 = $1 >>> 0 > $2 >>> 0 ? $1 : $2;
  }
  return $1 >>> 0 >= $0 + 16 >>> 0;
 }

 function wake_up_klogd_work_func($0) {
  $0 = $0 | 0;
  $0 = HEAP32[2979];
  HEAP32[2979] = 0;
  label$1 : {
   if (!($0 & 2)) {
    break label$1
   }
   if (!console_trylock()) {
    break label$1
   }
   console_unlock();
  }
  if ($0 & 1) {
   __wake_up(11888, 1, 0)
  }
 }

 function __printk_safe_flush($0) {
  $0 = $0 | 0;
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0;
  $1 = global$0 - 96 | 0;
  global$0 = $1;
  $9 = $0 + 12 | 0;
  $5 = $0 + -8 | 0;
  $0 = 0;
  label$1 : {
   label$3 : while (1) {
    $6 = HEAP32[$5 >> 2];
    if (!($6 >>> 0 > 236 | ($0 | 0) != 0 & $6 >>> 0 <= $0 >>> 0)) {
     if (!$6) {
      break label$1
     }
     $8 = $6 + $9 | 0;
     $3 = $0 + $9 | 0;
     label$4 : while (1) {
      $2 = $3;
      while (1) {
       $7 = 1;
       $0 = $3;
       label$6 : while (1) {
        $3 = $0 + 1 | 0;
        label$7 : {
         while (1) {
          label$9 : {
           if ($0 >>> 0 < $8 >>> 0) {
            $4 = HEAPU8[$0 | 0];
            if (($4 | 0) != 10) {
             label$12 : {
              if (($4 | 0) != 1 | $3 >>> 0 >= $8 >>> 0) {
               break label$12
              }
              $4 = HEAP8[$3 | 0];
              if (!$4) {
               break label$12
              }
              $10 = $4 + -48 >>> 0 < 8;
              if ($10 | $4 + -99 >>> 0 <= 1) {
               break label$9
              }
             }
             $0 = $3;
             $7 = 0;
             continue label$6;
            }
            HEAP32[$1 + 36 >> 2] = $2;
            HEAP32[$1 + 32 >> 2] = (1 - $2 | 0) + $0;
            printk_deferred(22083, $1 + 32 | 0);
            $3 = $0 + 1 | 0;
            continue label$4;
           }
           if (!($7 | $2 >>> 0 >= $8 >>> 0)) {
            HEAP32[$1 + 84 >> 2] = $2;
            HEAP32[$1 + 80 >> 2] = $8 - $2;
            printk_deferred(22083, $1 + 80 | 0);
            $0 = strlen(22088);
            HEAP32[$1 + 68 >> 2] = 22088;
            HEAP32[$1 + 64 >> 2] = $0;
            printk_deferred(22083, $1 - -64 | 0);
           }
           $0 = $6;
           if (($0 | 0) != HEAP32[$5 >> 2]) {
            continue label$3
           }
           HEAP32[$5 >> 2] = 0;
           break label$1;
          }
          if (!$7) {
           break label$7
          }
          if (!$10) {
           $7 = 1;
           if ($4 + -99 >>> 0 > 1) {
            continue
           }
          }
          break;
         };
         $0 = $0 + 2 | 0;
         $7 = 1;
         continue;
        }
        break;
       };
       HEAP32[$1 + 52 >> 2] = $2;
       HEAP32[$1 + 48 >> 2] = $0 - $2;
       printk_deferred(22083, $1 + 48 | 0);
       $2 = $0;
       continue;
      };
     };
    }
    break;
   };
   $0 = strlen(22048);
   HEAP32[$1 + 20 >> 2] = 22048;
   HEAP32[$1 + 16 >> 2] = $0;
   printk_deferred(22083, $1 + 16 | 0);
  }
  $0 = HEAP32[$5 + 4 >> 2];
  HEAP32[$5 + 4 >> 2] = 0;
  if ($0) {
   HEAP32[$1 >> 2] = $0;
   printk_deferred(22092, $1);
  }
  global$0 = $1 + 96 | 0;
 }

 function __printk_safe_enter() {
  HEAP32[3049] = HEAP32[3049] + 1;
 }

 function __printk_safe_exit() {
  HEAP32[3049] = HEAP32[3049] + -1;
 }

 function vprintk_func($0, $1) {
  var $2 = 0, $3 = 0;
  $2 = global$0 - 16 | 0;
  global$0 = $2;
  label$1 : {
   label$3 : {
    label$4 : {
     label$5 : {
      if (!(HEAP32[3049] & 1073741824)) {
       if (HEAP32[3049] < 0) {
        break label$1
       }
       if (!(HEAP32[3049] & 1073741823)) {
        break label$5
       }
       HEAP32[$2 + 12 >> 2] = $1;
       while (1) {
        $1 = HEAP32[2985];
        if ($1 >>> 0 >= 235) {
         break label$4
        }
        label$8 : {
         if ($1) {
          break label$8
         }
        }
        $3 = HEAP32[$2 + 12 >> 2];
        HEAP32[$2 + 8 >> 2] = $3;
        $3 = vscnprintf($1 + 11960 | 0, 236 - $1 | 0, $0, $3);
        if (!$3) {
         break label$1
        }
        if (($1 | 0) != HEAP32[2985]) {
         continue
        }
        break;
       };
       HEAP32[2985] = $1 + $3;
       break label$3;
      }
      vprintk_store(-1, $0, $1);
      defer_console_output();
      break label$1;
     }
     vprintk_emit(-1, $0, $1);
     break label$1;
    }
    HEAP32[2986] = HEAP32[2986] + 1;
   }
   if (HEAPU8[79296]) {
    irq_work_queue(11948)
   }
  }
  global$0 = $2 + 16 | 0;
 }

 function __mutex_lock() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0, $4 = 0;
  $2 = global$0 - 32 | 0;
  global$0 = $2;
  $1 = HEAP32[2];
  label$1 : {
   label$3 : {
    label$4 : {
     label$6 : {
      label$7 : {
       label$9 : {
        label$10 : {
         label$11 : {
          label$12 : {
           label$14 : {
            label$15 : {
             $0 = HEAP32[1125];
             $3 = $0 & -8;
             if ($3) {
              if ($0 & 4 ? ($1 | 0) == ($3 | 0) : 0) {
               break label$10
              }
              $0 = HEAP32[2];
              $1 = HEAP32[1125];
              $3 = $1 & -8;
              if (!$3) {
               break label$15
              }
              if ($1 & 4 ? ($0 | 0) == ($3 | 0) : 0) {
               break label$9
              }
              HEAP32[$2 + 16 >> 2] = 4504;
              $1 = HEAP32[1127];
              HEAP32[$2 + 20 >> 2] = $1;
              HEAP32[1127] = $2 + 16;
              HEAP32[$1 >> 2] = $2 + 16;
              if (HEAP32[1126] == ($2 + 16 | 0)) {
               HEAP32[1125] = HEAP32[1125] | 1
              }
              HEAP32[$2 + 24 >> 2] = $0;
              HEAP32[$2 + 12 >> 2] = 2;
              HEAP32[HEAP32[2] >> 2] = 2;
              $0 = 0;
              while (1) {
               label$20 : {
                $1 = HEAP32[2];
                $3 = HEAP32[1125];
                $4 = $3 & -8;
                if (!$4) {
                 break label$20
                }
                if ($3 & 4 ? ($1 | 0) == ($4 | 0) : 0) {
                 break label$12
                }
                schedule();
                label$24 : {
                 if (!($0 & 1)) {
                  $0 = 0;
                  if (HEAP32[1126] != ($2 + 16 | 0)) {
                   break label$24
                  }
                  HEAP32[1125] = HEAP32[1125] | 2;
                 }
                 $0 = 1;
                }
                HEAP32[$2 + 12 >> 2] = 2;
                HEAP32[HEAP32[2] >> 2] = 2;
                $1 = HEAP32[2];
                $3 = HEAP32[1125];
                $4 = $3 & -8;
                if (!$4) {
                 break label$14
                }
                if (!($3 & 4 ? ($1 | 0) == ($4 | 0) : 0)) {
                 continue
                }
                break label$11;
               }
               break;
              };
              $0 = 7;
              break label$4;
             }
             $0 = $0 & 7;
             break label$6;
            }
            $4 = $1 & 7;
            break label$7;
           }
           $0 = 7;
           break label$4;
          }
          $0 = 3;
          break label$4;
         }
         $0 = 3;
         break label$4;
        }
        $0 = $0 & 3;
        break label$6;
       }
       $4 = $1 & 3;
      }
      $0 = $4 & 5 | $0;
      break label$3;
     }
     HEAP32[1125] = $1 | $0 & 5;
     break label$1;
    }
    HEAP32[1125] = $1 | $0 & $3 & 5;
    HEAP32[HEAP32[2] >> 2] = 0;
    $0 = HEAP32[$2 + 20 >> 2];
    $1 = HEAP32[$2 + 16 >> 2];
    HEAP32[$0 >> 2] = $1;
    HEAP32[$1 + 4 >> 2] = $0;
    if (HEAP32[1126] != 4504) {
     break label$1
    }
    $0 = HEAP32[1125] & -8;
   }
   HEAP32[1125] = $0;
  }
  global$0 = $2 + 32 | 0;
 }

 function mutex_unlock($0) {
  if (HEAP32[$0 >> 2] == HEAP32[2]) {
   HEAP32[$0 >> 2] = 0;
   return;
  }
  __mutex_unlock_slowpath($0);
 }

 function __mutex_unlock_slowpath($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  $2 = global$0 - 16 | 0;
  global$0 = $2;
  HEAP32[$2 + 8 >> 2] = 1;
  $1 = HEAP32[$0 >> 2];
  HEAP32[$2 + 12 >> 2] = $2 + 8;
  $3 = $1 & 2;
  label$1 : {
   if (!$3) {
    HEAP32[$0 >> 2] = $1 & 7;
    if (!($1 & 1)) {
     break label$1
    }
   }
   $1 = HEAP32[$0 + 4 >> 2];
   label$4 : {
    if (($1 | 0) != ($0 + 4 | 0)) {
     $1 = HEAP32[$1 + 8 >> 2];
     wake_q_add($2 + 8 | 0, $1);
     break label$4;
    }
    $1 = 0;
   }
   if ($3) {
    $3 = $0;
    $0 = HEAP32[$0 >> 2] & 1 | $1;
    HEAP32[$3 >> 2] = $1 ? $0 | 4 : $0;
   }
   wake_up_q($2 + 8 | 0);
  }
  global$0 = $2 + 16 | 0;
 }

 function mutex_trylock($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0;
  $3 = $0;
  $1 = HEAP32[2];
  $4 = $1;
  label$1 : {
   label$2 : {
    $0 = HEAP32[$0 >> 2];
    $2 = $0 & -8;
    if ($2) {
     if ($0 & 4 ? ($1 | 0) == ($2 | 0) : 0) {
      break label$2
     }
     return 0;
    }
    $0 = $0 & 7;
    break label$1;
   }
   $0 = $0 & 3;
  }
  HEAP32[$3 >> 2] = $4 | $0 & 5;
  return 1;
 }

 function down() {
  var $0 = 0, $1 = 0;
  $1 = HEAPU8[79300];
  HEAP8[79300] = 0;
  $0 = HEAP32[2976];
  label$1 : {
   if ($0) {
    HEAP32[2976] = $0 + -1;
    break label$1;
   }
   __down();
  }
  HEAP8[79300] = $1 & 1;
 }

 function __down() {
  var $0 = 0, $1 = 0, $2 = 0;
  $0 = global$0 - 16 | 0;
  global$0 = $0;
  HEAP32[$0 >> 2] = 11908;
  $1 = HEAP32[2978];
  HEAP32[$0 + 4 >> 2] = $1;
  HEAP32[2978] = $0;
  HEAP32[$1 >> 2] = $0;
  HEAP8[$0 + 12 | 0] = 0;
  HEAP32[$0 + 8 >> 2] = HEAP32[2];
  $1 = 2147483647;
  $2 = $0 + 12 | 0;
  label$1 : {
   while (1) {
    if (($1 | 0) >= 1) {
     HEAP32[HEAP32[2] >> 2] = 2;
     HEAP8[79300] = 1;
     $1 = schedule_timeout($1);
     HEAP8[79300] = 0;
     if (!HEAPU8[$2 | 0]) {
      continue
     }
     break label$1;
    }
    break;
   };
   $1 = HEAP32[$0 >> 2];
   $2 = HEAP32[$0 + 4 >> 2];
   HEAP32[$1 + 4 >> 2] = $2;
   HEAP32[$2 >> 2] = $1;
   HEAP32[$0 >> 2] = 256;
   HEAP32[$0 + 4 >> 2] = 512;
  }
  global$0 = $0 + 16 | 0;
 }

 function down_trylock() {
  var $0 = 0, $1 = 0;
  $1 = HEAPU8[79300];
  HEAP8[79300] = 0;
  $0 = HEAP32[2976] + -1 | 0;
  if (($0 | 0) >= 0) {
   HEAP32[2976] = $0
  }
  HEAP8[79300] = $1 & 1;
  return $0 >>> 31 | 0;
 }

 function up() {
  var $0 = 0;
  $0 = HEAPU8[79300];
  HEAP8[79300] = 0;
  label$1 : {
   if (HEAP32[2977] == 11908) {
    HEAP32[2976] = HEAP32[2976] + 1;
    break label$1;
   }
   __up();
  }
  HEAP8[79300] = $0 & 1;
 }

 function __up() {
  var $0 = 0, $1 = 0, $2 = 0;
  $0 = HEAP32[2977];
  $1 = HEAP32[$0 >> 2];
  $2 = HEAP32[$0 + 4 >> 2];
  HEAP32[$1 + 4 >> 2] = $2;
  HEAP8[$0 + 12 | 0] = 1;
  HEAP32[$2 >> 2] = $1;
  HEAP32[$0 >> 2] = 256;
  HEAP32[$0 + 4 >> 2] = 512;
  wake_up_process(HEAP32[$0 + 8 >> 2]);
 }

 function rwsem_is_locked($0) {
  return HEAP32[$0 >> 2] != 0;
 }

 function __down_read_common($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  $1 = global$0 - 32 | 0;
  global$0 = $1;
  $2 = HEAP32[$0 >> 2];
  label$2 : {
   if (!(HEAP32[$0 + 4 >> 2] == ($0 + 4 | 0) ? ($2 | 0) >= 0 : 0)) {
    HEAP32[$1 + 28 >> 2] = 1;
    $2 = HEAP32[2];
    HEAP32[$2 + 8 >> 2] = HEAP32[$2 + 8 >> 2] + 1;
    HEAP32[$1 + 24 >> 2] = $2;
    HEAP32[$1 + 16 >> 2] = $0 + 4;
    $3 = $0 + 8 | 0;
    $0 = HEAP32[$3 >> 2];
    HEAP32[$3 >> 2] = $1 + 16;
    HEAP32[$1 + 20 >> 2] = $0;
    HEAP32[$0 >> 2] = $1 + 16;
    while (1) {
     if ($2) {
      HEAP32[$1 + 12 >> 2] = 2;
      HEAP32[HEAP32[2] >> 2] = 2;
      schedule();
      $2 = HEAP32[$1 + 24 >> 2];
      continue;
     }
     break;
    };
    break label$2;
   }
   HEAP32[$0 >> 2] = $2 + 1;
  }
  global$0 = $1 + 32 | 0;
 }

 function __down_read_trylock($0) {
  var $1 = 0;
  $1 = HEAP32[$0 >> 2];
  if (HEAP32[$0 + 4 >> 2] != ($0 + 4 | 0) | ($1 | 0) < 0) {
   $0 = 0
  } else {
   HEAP32[$0 >> 2] = $1 + 1;
   $0 = 1;
  }
  return $0;
 }

 function __down_write_common($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  $1 = global$0 - 32 | 0;
  global$0 = $1;
  HEAP32[$1 + 16 >> 2] = $0 + 4;
  $3 = $0 + 8 | 0;
  $2 = HEAP32[$3 >> 2];
  HEAP32[$3 >> 2] = $1 + 16;
  HEAP32[$1 + 20 >> 2] = $2;
  HEAP32[$2 >> 2] = $1 + 16;
  HEAP32[$1 + 28 >> 2] = 0;
  HEAP32[$1 + 24 >> 2] = HEAP32[2];
  while (1) {
   if (HEAP32[$0 >> 2]) {
    HEAP32[$1 + 12 >> 2] = 2;
    HEAP32[HEAP32[2] >> 2] = 2;
    schedule();
    continue;
   }
   break;
  };
  HEAP32[$0 >> 2] = -1;
  $0 = HEAP32[$1 + 16 >> 2];
  $2 = HEAP32[$1 + 20 >> 2];
  HEAP32[$0 + 4 >> 2] = $2;
  HEAP32[$2 >> 2] = $0;
  HEAP32[$1 + 16 >> 2] = 256;
  HEAP32[$1 + 20 >> 2] = 512;
  global$0 = $1 + 32 | 0;
 }

 function __up_read($0) {
  var $1 = 0;
  $1 = HEAP32[$0 >> 2] + -1 | 0;
  HEAP32[$0 >> 2] = $1;
  label$1 : {
   if ($1) {
    break label$1
   }
   $1 = $0 + 4 | 0;
   $0 = HEAP32[$0 + 4 >> 2];
   if (($1 | 0) == ($0 | 0)) {
    break label$1
   }
   wake_up_process(HEAP32[$0 + 8 >> 2]);
  }
 }

 function __up_write($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0;
  HEAP32[$0 >> 2] = 0;
  $4 = $0 + 4 | 0;
  $1 = HEAP32[$0 + 4 >> 2];
  label$1 : {
   if (($4 | 0) == ($1 | 0)) {
    break label$1
   }
   if (HEAP32[$1 + 12 >> 2]) {
    $2 = 1;
    while (1) {
     $5 = $2;
     $3 = HEAP32[$1 >> 2];
     $2 = HEAP32[$1 + 4 >> 2];
     HEAP32[$3 + 4 >> 2] = $2;
     HEAP32[$2 >> 2] = $3;
     HEAP32[$1 >> 2] = 256;
     HEAP32[$1 + 4 >> 2] = 512;
     $2 = HEAP32[$1 + 8 >> 2];
     HEAP32[$1 + 8 >> 2] = 0;
     wake_up_process($2);
     $1 = HEAP32[$2 + 8 >> 2] + -1 | 0;
     HEAP32[$2 + 8 >> 2] = $1;
     if (!$1) {
      __put_task_struct($2)
     }
     if (($3 | 0) != ($4 | 0)) {
      $2 = $5 + 1 | 0;
      $1 = $3;
      if (HEAP32[$1 + 12 >> 2]) {
       continue
      }
     }
     break;
    };
    HEAP32[$0 >> 2] = HEAP32[$0 >> 2] + $5;
    break label$1;
   }
   wake_up_process(HEAP32[$1 + 8 >> 2]);
  }
 }

 function __task_rq_lock($0) {
  $0 = $0 + 20 | 0;
  label$1 : {
   while (1) {
    if (HEAP32[$0 >> 2] != 2) {
     break label$1
    }
    if (HEAP32[$0 >> 2] != 2) {
     continue
    }
    break;
   };
   while (1) continue;
  }
 }

 function task_rq_lock($0, $1) {
  var $2 = 0;
  $0 = $0 + 20 | 0;
  label$1 : {
   while (1) {
    $2 = HEAP32[19828];
    HEAP32[19828] = 0;
    HEAP32[$1 >> 2] = $2;
    if (HEAP32[$0 >> 2] != 2) {
     break label$1
    }
    HEAP32[19828] = HEAP32[$1 >> 2];
    if (HEAP32[$0 >> 2] != 2) {
     continue
    }
    break;
   };
   while (1) continue;
  }
  return 12208;
 }

 function update_rq_clock($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0;
  label$1 : {
   if (HEAPU8[$0 + 1056 | 0] & 2) {
    break label$1
   }
   __inlined_func$sched_clock_cpu : {
    if (HEAP32[19830] < 1) {
     i64toi32_i32$HIGH_BITS = 0;
     $1 = 0;
     break __inlined_func$sched_clock_cpu;
    }
    $1 = sched_clock();
   }
   $4 = i64toi32_i32$HIGH_BITS;
   $2 = HEAP32[$0 + 1064 >> 2];
   $3 = $4 - (HEAP32[$0 + 1068 >> 2] + ($1 >>> 0 < $2 >>> 0) | 0) | 0;
   $2 = $1 - $2 | 0;
   if (($3 | 0) < 0 ? 1 : ($3 | 0) <= 0 ? ($2 >>> 0 >= 0 ? 0 : 1) : 0) {
    break label$1
   }
   $5 = $0 + 1064 | 0;
   HEAP32[$5 >> 2] = $1;
   HEAP32[$5 + 4 >> 2] = $4;
   $1 = $3 + HEAP32[$0 + 1076 >> 2] | 0;
   $3 = $2 + HEAP32[$0 + 1072 >> 2] | 0;
   if ($3 >>> 0 < $2 >>> 0) {
    $1 = $1 + 1 | 0
   }
   HEAP32[$0 + 1072 >> 2] = $3;
   HEAP32[$0 + 1076 >> 2] = $1;
  }
 }

 function wake_q_add($0, $1) {
  var $2 = 0, $3 = 0;
  $3 = HEAP32[19828];
  HEAP32[19828] = 0;
  if (HEAP32[$1 + 792 >> 2]) {
   HEAP32[19828] = $3;
   return;
  }
  $2 = $1 + 792 | 0;
  HEAP32[HEAP32[$0 + 4 >> 2] >> 2] = $2;
  HEAP32[19828] = $3;
  HEAP32[$2 >> 2] = 1;
  HEAP32[$1 + 8 >> 2] = HEAP32[$1 + 8 >> 2] + 1;
  HEAP32[$0 + 4 >> 2] = $2;
 }

 function wake_up_q($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0;
  $1 = global$0 - 16 | 0;
  global$0 = $1;
  $0 = HEAP32[$0 >> 2];
  label$1 : {
   while (1) {
    if (($0 | 0) != 1) {
     $2 = $0 + -792 | 0;
     if (!$2) {
      break label$1
     }
     $4 = HEAP32[$0 >> 2];
     HEAP32[$0 >> 2] = 0;
     wake_up_process($2);
     $0 = $0 + -784 | 0;
     $3 = HEAP32[$0 >> 2] + -1 | 0;
     HEAP32[$0 >> 2] = $3;
     $0 = $4;
     if ($3) {
      continue
     }
     __put_task_struct($2);
     continue;
    }
    break;
   };
   global$0 = $1 + 16 | 0;
   return;
  }
  HEAP32[$1 + 8 >> 2] = 22151;
  HEAP32[$1 + 4 >> 2] = 431;
  HEAP32[$1 >> 2] = 22144;
  printk(22113, $1);
  abort();
 }

 function wake_up_process($0) {
  try_to_wake_up($0, 3, 0);
 }

 function try_to_wake_up($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  $5 = HEAP32[19828];
  HEAP32[19828] = 0;
  label$1 : {
   if (!(HEAP32[$0 >> 2] & $1)) {
    break label$1
   }
   if (HEAP32[$0 + 20 >> 2]) {
    __task_rq_lock($0);
    $4 = 1;
    if (HEAP32[$0 + 20 >> 2] == 1) {
     update_rq_clock(12208);
     ttwu_do_wakeup($0, $2);
     break label$1;
    }
   }
   if (HEAPU8[$0 + 440 | 0] & 2) {
    HEAP32[3322] = HEAP32[3322] + -1
   }
   update_rq_clock(12208);
   activate_task($0);
   $4 = 1;
   HEAP32[$0 + 20 >> 2] = 1;
   if (HEAPU8[$0 + 12 | 0] & 32) {
    wq_worker_waking_up($0)
   }
   ttwu_do_wakeup($0, $2);
  }
  HEAP32[19828] = $5;
  global$0 = $3 + 16 | 0;
  return $4;
 }

 function resched_curr($0) {
  var $1 = 0;
  $0 = HEAP32[HEAP32[$0 + 1036 >> 2] + 4 >> 2];
  $1 = HEAP32[$0 >> 2];
  if (!($1 & 8)) {
   HEAP32[$0 >> 2] = $1 | 8
  }
 }

 function activate_task($0) {
  if (!(HEAP32[$0 >> 2] & 1024 | (!(HEAP32[$0 >> 2] & 2) | HEAP8[$0 + 14 | 0] & 1))) {
   HEAP32[3310] = HEAP32[3310] + -1
  }
  FUNCTION_TABLE[HEAP32[HEAP32[$0 + 40 >> 2] + 4 >> 2]](12208, $0, 9);
 }

 function deactivate_task($0) {
  if (!(HEAP32[$0 >> 2] & 1024 | (!(HEAP32[$0 >> 2] & 2) | HEAP8[$0 + 14 | 0] & 1))) {
   HEAP32[3310] = HEAP32[3310] + 1
  }
  FUNCTION_TABLE[HEAP32[HEAP32[$0 + 40 >> 2] + 8 >> 2]](12208, $0, 9);
 }

 function check_preempt_curr($0, $1, $2) {
  var $3 = 0, $4 = 0;
  $3 = HEAP32[$1 + 40 >> 2];
  $4 = HEAP32[HEAP32[$0 + 1036 >> 2] + 40 >> 2];
  label$1 : {
   if (($3 | 0) != ($4 | 0)) {
    $1 = 23072;
    while (1) {
     if (!$1 | ($1 | 0) == ($4 | 0)) {
      break label$1
     }
     if (($1 | 0) != ($3 | 0)) {
      $1 = HEAP32[$1 >> 2];
      continue;
     }
     break;
    };
    resched_curr($0);
    break label$1;
   }
   FUNCTION_TABLE[HEAP32[$3 + 20 >> 2]]($0, $1, $2);
  }
  $1 = HEAP32[$0 + 1036 >> 2];
  if (!(HEAP32[$1 + 20 >> 2] != 1 | !(HEAP32[HEAP32[$1 + 4 >> 2] >> 2] & 8))) {
   HEAP32[$0 + 1056 >> 2] = HEAP32[$0 + 1056 >> 2] | 1
  }
 }

 function ttwu_do_wakeup($0, $1) {
  check_preempt_curr(12208, $0, $1);
  HEAP32[$0 >> 2] = 0;
 }

 function __sched_fork($0) {
  var $1 = 0, $2 = 0;
  HEAP32[$0 + 20 >> 2] = 0;
  $1 = $0 + 120 | 0;
  HEAP32[$1 >> 2] = 0;
  HEAP32[$1 + 4 >> 2] = 0;
  $1 = $0 + 112 | 0;
  HEAP32[$1 >> 2] = 0;
  HEAP32[$1 + 4 >> 2] = 0;
  $1 = $0 + 96 | 0;
  HEAP32[$1 >> 2] = 0;
  HEAP32[$1 + 4 >> 2] = 0;
  $1 = $0 + 88 | 0;
  HEAP32[$1 >> 2] = 0;
  HEAP32[$1 + 4 >> 2] = 0;
  HEAP32[$0 + 80 >> 2] = 0;
  $1 = $0 + 104 | 0;
  HEAP32[$1 >> 2] = 0;
  HEAP32[$1 + 4 >> 2] = 0;
  $1 = $0 + 160 | 0;
  HEAP32[$0 + 160 >> 2] = $1;
  $2 = $0 + 72 | 0;
  HEAP32[$0 + 76 >> 2] = $2;
  HEAP32[$2 >> 2] = $2;
  hrtimer_init($1 + 80 | 0);
  HEAP32[$1 + 112 >> 2] = 61;
  hrtimer_init($1 + 128 | 0);
  HEAP32[$1 + 160 >> 2] = 62;
  __dl_clear_params($0);
  HEAP32[$0 + 136 >> 2] = 0;
  $1 = $0 + 128 | 0;
  HEAP32[$0 + 132 >> 2] = $1;
  HEAP32[$0 + 128 >> 2] = $1;
  HEAP32[$0 + 148 >> 2] = 0;
  HEAP32[$0 + 144 >> 2] = HEAP32[3361];
 }

 function set_load_weight() {
  var $0 = 0, $1 = 0;
  if (HEAP32[340] == 5) {
   HEAP32[270] = 3;
   HEAP32[268] = 3;
   HEAP32[269] = 1431655765;
   return;
  }
  $0 = HEAP32[263] + -100 << 2;
  $1 = HEAP32[$0 + 22176 >> 2];
  HEAP32[270] = $1;
  HEAP32[269] = HEAP32[$0 + 22336 >> 2];
  HEAP32[268] = $1;
 }

 function to_ratio($0, $1, $2, $3) {
  label$1 : {
   if (!(($2 | 0) == -1 & ($3 | 0) == -1)) {
    if (!($0 | $1)) {
     break label$1
    }
    $3 = $3 << 20 | $2 >>> 12;
    return div64_u64($2 << 20, $3, $0, $1);
   }
   return 1048576;
  }
  return 0;
 }

 function finish_task_switch($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  $1 = HEAP32[3315];
  if (HEAP32[1]) {
   HEAP32[1] = 0
  }
  $3 = HEAP32[$0 >> 2];
  HEAP32[19828] = 1;
  HEAP32[3315] = 0;
  label$2 : {
   if (!$1) {
    break label$2
   }
   $2 = HEAP32[$1 + 44 >> 2] + -1 | 0;
   HEAP32[$1 + 44 >> 2] = $2;
   if ($2) {
    break label$2
   }
   __mmdrop($1);
  }
  label$3 : {
   if (($3 | 0) != 128) {
    break label$3
   }
   $1 = HEAP32[HEAP32[$0 + 40 >> 2] + 44 >> 2];
   if ($1) {
    FUNCTION_TABLE[$1]($0)
   }
   $1 = HEAP32[$0 + 8 >> 2] + -1 | 0;
   HEAP32[$0 + 8 >> 2] = $1;
   if ($1) {
    break label$3
   }
   __put_task_struct($0);
  }
 }

 function __schedule($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0;
  $3 = global$0 - 32 | 0;
  global$0 = $3;
  $1 = HEAP32[3311];
  if (HEAP32[1]) {
   __schedule_bug($1);
   HEAP32[1] = 0;
  }
  HEAP32[19828] = 0;
  $2 = HEAP32[2966];
  if (($2 | 0) != HEAP32[2965]) {
   HEAP32[2965] = $2;
   raise_softirq();
  }
  HEAP32[3316] = HEAP32[3316] << 1;
  update_rq_clock(12208);
  $4 = $1 + 660 | 0;
  if (!(!HEAP32[$1 >> 2] | $0)) {
   $0 = HEAP32[$1 >> 2];
   label$3 : {
    if (!($0 & 1 | HEAP8[$1 + 761 | 0] & 1 ? !(!($0 & 257) | !(HEAP32[HEAP32[$1 + 4 >> 2] >> 2] & 4)) : 0)) {
     deactivate_task($1);
     HEAP32[$1 + 20 >> 2] = 0;
     if (HEAPU8[$1 + 440 | 0] & 2) {
      HEAP32[3322] = HEAP32[3322] + 1
     }
     if (!(HEAPU8[$1 + 12 | 0] & 32)) {
      break label$3
     }
     $0 = wq_worker_sleeping($1);
     if (!$0 | ($0 | 0) == HEAP32[2]) {
      break label$3
     }
     if (HEAP32[$0 >> 2] & 3) {
      label$8 : {
       if (HEAP32[$0 + 20 >> 2] == 1) {
        break label$8
       }
       if (HEAPU8[$0 + 440 | 0] & 2) {
        HEAP32[3322] = HEAP32[3322] + -1
       }
       activate_task($0);
       HEAP32[$0 + 20 >> 2] = 1;
       if (!(HEAPU8[$0 + 12 | 0] & 32)) {
        break label$8
       }
       wq_worker_waking_up($0);
      }
      ttwu_do_wakeup($0, 0);
     }
     break label$3;
    }
    HEAP32[$1 >> 2] = 0;
   }
   $4 = $1 + 656 | 0;
  }
  label$10 : {
   label$11 : {
    label$12 : {
     label$13 : {
      $0 = HEAP32[$1 + 40 >> 2];
      if (HEAP32[3052] != HEAP32[3068] | (($0 | 0) != 22768 ? ($0 | 0) != 22584 : 0)) {
       break label$13
      }
      $0 = FUNCTION_TABLE[HEAP32[5698]](12208, $1, $3 + 24 | 0) | 0;
      if (($0 | 0) == -1) {
       break label$13
      }
      if (!$0) {
       break label$12
      }
      break label$10;
     }
     $2 = 23072;
     while (1) {
      while (1) {
       $0 = FUNCTION_TABLE[HEAP32[$2 + 24 >> 2]](12208, $1, $3 + 24 | 0) | 0;
       if (!$0) {
        $2 = HEAP32[$2 >> 2];
        if ($2) {
         continue
        }
        break label$11;
       }
       break;
      };
      $2 = 23072;
      if (($0 | 0) == -1) {
       continue
      }
      break;
     };
     break label$10;
    }
    $0 = FUNCTION_TABLE[HEAP32[5652]](12208, $1, $3 + 24 | 0) | 0;
    break label$10;
   }
   HEAP32[$3 + 8 >> 2] = 22567;
   HEAP32[$3 + 4 >> 2] = 3340;
   HEAP32[$3 >> 2] = 22144;
   printk(22113, $3);
   abort();
  }
  $2 = HEAP32[$1 + 4 >> 2];
  HEAP32[$2 >> 2] = HEAP32[$2 >> 2] & -9;
  label$18 : {
   label$19 : {
    label$20 : {
     label$21 : {
      label$22 : {
       if (($0 | 0) != ($1 | 0)) {
        HEAP32[3311] = $0;
        $2 = HEAP32[3063];
        $5 = HEAP32[3062] + 1 | 0;
        if ($5 >>> 0 < 1) {
         $2 = $2 + 1 | 0
        }
        HEAP32[3062] = $5;
        HEAP32[3063] = $2;
        HEAP32[$4 >> 2] = HEAP32[$4 >> 2] + 1;
        $2 = HEAP32[$1 + 360 >> 2];
        $4 = HEAP32[$0 + 356 >> 2];
        if ($4) {
         HEAP32[$4 + 400 >> 2] = HEAP32[$4 + 400 >> 2] | 1;
         $5 = HEAP32[19828];
         HEAP32[19828] = 0;
         $0 = HEAP32[4942];
         if (($0 ^ HEAP32[$4 + 360 >> 2]) >>> 0 < 256) {
          break label$20
         }
         $0 = $0 + 1 | 0;
         HEAP32[4942] = $0;
         if (!($0 & 255)) {
          break label$22
         }
         break label$21;
        }
        HEAP32[$0 + 360 >> 2] = $2;
        HEAP32[$2 + 44 >> 2] = HEAP32[$2 + 44 >> 2] + 1;
        break label$19;
       }
       HEAP32[19828] = 1;
       HEAP32[3316] = HEAP32[3316] & -4;
       break label$18;
      }
      local_flush_tlb_all();
      $0 = HEAP32[4942];
      if ($0) {
       break label$21
      }
      $0 = 256;
      HEAP32[4942] = 256;
     }
     HEAP32[$4 + 360 >> 2] = $0;
    }
    HEAP32[19828] = $5;
   }
   if (!HEAP32[$1 + 356 >> 2]) {
    HEAP32[3315] = $2;
    HEAP32[$1 + 360 >> 2] = 0;
   }
   HEAP32[3316] = HEAP32[3316] & -4;
   printk(31166, 0);
   finish_task_switch(0);
  }
  global$0 = $3 + 32 | 0;
 }

 function __schedule_bug($0) {
  var $1 = 0, $2 = 0;
  $1 = global$0 - 16 | 0;
  global$0 = $1;
  label$1 : {
   if (HEAP32[19560]) {
    break label$1
   }
   $2 = HEAP32[$0 + 496 >> 2];
   HEAP32[$1 + 8 >> 2] = HEAP32[1];
   HEAP32[$1 + 4 >> 2] = $2;
   HEAP32[$1 >> 2] = $0 + 700;
   printk(22496, $1);
   if (!HEAP32[16692]) {
    dump_stack();
    add_taint(9, 0);
    break label$1;
   }
   panic(22542, 0);
   abort();
  }
  global$0 = $1 + 16 | 0;
 }

 function schedule() {
  while (1) {
   __schedule(0);
   if (HEAP32[0] & 8) {
    continue
   }
   break;
  };
 }

 function default_wake_function($0, $1, $2, $3) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  $3 = $3 | 0;
  return try_to_wake_up(HEAP32[$0 + 4 >> 2], $1, $2) | 0;
 }

 function _cond_resched() {
  if (!(HEAP32[0] & 8 ? !HEAP32[1] : 0)) {
   return
  }
  preempt_schedule_common();
 }

 function preempt_schedule_common() {
  while (1) {
   __schedule(1);
   if (HEAP32[0] & 8) {
    continue
   }
   break;
  };
 }

 function __cond_resched_lock() {
  var $0 = 0;
  $0 = 0;
  label$1 : {
   if (HEAP32[1]) {
    break label$1
   }
   $0 = 0;
   if (!(HEAP32[0] & 8)) {
    break label$1
   }
   preempt_schedule_common();
   $0 = 0;
  }
 }

 function io_schedule_prepare() {
  var $0 = 0, $1 = 0;
  $0 = HEAP32[2];
  $1 = HEAPU8[$0 + 440 | 0];
  HEAP8[$0 + 440 | 0] = $1 | 2;
  return $1 >>> 1 & 1;
 }

 function io_schedule_finish($0) {
  var $1 = 0;
  $1 = HEAP32[2];
  HEAP8[$1 + 440 | 0] = HEAPU8[$1 + 440 | 0] & 253 | $0 << 1 & 2;
 }

 function io_schedule_timeout() {
  var $0 = 0;
  $0 = io_schedule_prepare();
  schedule_timeout(25);
  io_schedule_finish($0);
 }

 function init_idle($0) {
  var $1 = 0, $2 = 0, wasm2js_i32$0 = 0, wasm2js_i32$1 = 0;
  $2 = HEAP32[19828];
  HEAP32[19828] = 0;
  __sched_fork($0);
  HEAP32[$0 >> 2] = 0;
  $1 = $0 + 88 | 0;
  (wasm2js_i32$0 = $1, wasm2js_i32$1 = sched_clock()), HEAP32[wasm2js_i32$0 >> 2] = wasm2js_i32$1;
  HEAP32[$1 + 4 >> 2] = i64toi32_i32$HIGH_BITS;
  HEAP32[3312] = $0;
  HEAP32[3311] = $0;
  HEAP32[$0 + 20 >> 2] = 1;
  HEAP32[$0 + 12 >> 2] = HEAP32[$0 + 12 >> 2] | 2;
  HEAP32[19828] = $2;
  HEAP32[$0 + 40 >> 2] = 22584;
  HEAP32[HEAP32[$0 + 4 >> 2] + 4 >> 2] = 0;
 }

 function sched_init() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0, $4 = 0;
  wait_bit_init();
  $2 = __wasm_i64_mul(HEAP32[3050], 0, 1e3, 0);
  $3 = i64toi32_i32$HIGH_BITS;
  $1 = HEAP32[3051];
  $0 = $1 >> 31;
  $4 = __wasm_i64_mul($1, $0, 1e3, 0);
  $0 = ($0 | 0) < 0 ? 1 : ($0 | 0) <= 0 ? ($1 >>> 0 >= 0 ? 0 : 1) : 0;
  init_rt_bandwidth($2, $3, $0 ? -1 : $4, $0 ? -1 : i64toi32_i32$HIGH_BITS);
  $2 = __wasm_i64_mul(HEAP32[3050], 0, 1e3, 0);
  $3 = i64toi32_i32$HIGH_BITS;
  $1 = HEAP32[3051];
  $0 = $1 >> 31;
  $4 = __wasm_i64_mul($1, $0, 1e3, 0);
  $0 = ($0 | 0) < 0 ? 1 : ($0 | 0) <= 0 ? ($1 >>> 0 >= 0 ? 0 : 1) : 0;
  HEAP32[19854] = $0 ? -1 : $4;
  HEAP32[19855] = $0 ? -1 : i64toi32_i32$HIGH_BITS;
  HEAP32[19856] = $2;
  HEAP32[19857] = $3;
  HEAP32[3323] = HEAP32[20749] + 1251;
  HEAP32[3324] = 0;
  HEAP32[3052] = 0;
  init_cfs_rq();
  init_rt_rq();
  init_dl_rq();
  $0 = HEAP32[19837];
  HEAP32[3292] = HEAP32[19836];
  HEAP32[3293] = $0;
  $0 = 4;
  while (1) {
   if (($0 | 0) != 24) {
    HEAP32[$0 + 12208 >> 2] = 0;
    $0 = $0 + 4 | 0;
    continue;
   }
   break;
  };
  HEAP32[3322] = 0;
  set_load_weight();
  HEAP32[3945] = HEAP32[3945] + 1;
  init_idle(HEAP32[2]);
  HEAP32[19829] = HEAP32[20749] + 1251;
  HEAP32[19827] = 1;
 }

 function sched_clock() {
  return __wasm_i64_mul(HEAP32[20749] + 75e3 | 0, 0, 4e6, 0);
 }

 function dequeue_task_idle($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  HEAP8[79324] = 1;
  printk(22652, 0);
  dump_stack();
  HEAP8[79324] = 0;
 }

 function check_preempt_curr_idle($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  resched_curr($0);
 }

 function pick_next_task_idle($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  FUNCTION_TABLE[HEAP32[HEAP32[$1 + 40 >> 2] + 28 >> 2]]($0, $1);
  return HEAP32[$0 + 1040 >> 2];
 }

 function put_prev_task_idle($0, $1) {
  $0 = $0 | 0;
  $1 = $1 | 0;
 }

 function task_tick_idle($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
 }

 function switched_to_idle($0, $1) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $0 = global$0 - 16 | 0;
  global$0 = $0;
  HEAP32[$0 + 8 >> 2] = 22731;
  HEAP32[$0 + 4 >> 2] = 421;
  HEAP32[$0 >> 2] = 22724;
  printk(22693, $0);
  abort();
 }

 function prio_changed_idle($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  $0 = global$0 - 16 | 0;
  global$0 = $0;
  HEAP32[$0 + 8 >> 2] = 22748;
  HEAP32[$0 + 4 >> 2] = 427;
  HEAP32[$0 >> 2] = 22724;
  printk(22693, $0);
  abort();
 }

 function get_rr_interval_idle($0, $1) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  return 0;
 }

 function update_curr() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0;
  label$1 : {
   $0 = HEAP32[3078];
   if (!$0) {
    break label$1
   }
   $3 = HEAP32[3321];
   $4 = HEAP32[3320];
   $1 = $4;
   $5 = HEAP32[$0 + 40 >> 2];
   $2 = $3 - (HEAP32[$0 + 44 >> 2] + ($1 >>> 0 < $5 >>> 0) | 0) | 0;
   $1 = $1 - $5 | 0;
   if (($2 | 0) < 0 ? 1 : ($2 | 0) <= 0 ? ($1 >>> 0 >= 1 ? 0 : 1) : 0) {
    break label$1
   }
   $5 = $0 + 40 | 0;
   HEAP32[$5 >> 2] = $4;
   HEAP32[$5 + 4 >> 2] = $3;
   $3 = $2 + HEAP32[$0 + 52 >> 2] | 0;
   $4 = $1 + HEAP32[$0 + 48 >> 2] | 0;
   if ($4 >>> 0 < $1 >>> 0) {
    $3 = $3 + 1 | 0
   }
   HEAP32[$0 + 48 >> 2] = $4;
   HEAP32[$0 + 52 >> 2] = $3;
   if (HEAP32[$0 >> 2] != 1024) {
    $1 = __calc_delta($1, $2, 1024, $0);
    $2 = i64toi32_i32$HIGH_BITS;
   }
   $2 = $2 + HEAP32[$0 + 60 >> 2] | 0;
   $3 = $1 + HEAP32[$0 + 56 >> 2] | 0;
   if ($3 >>> 0 < $1 >>> 0) {
    $2 = $2 + 1 | 0
   }
   HEAP32[$0 + 56 >> 2] = $3;
   HEAP32[$0 + 60 >> 2] = $2;
   update_min_vruntime();
  }
 }

 function account_entity_dequeue($0) {
  HEAP32[3064] = HEAP32[3064] - HEAP32[$0 >> 2];
  HEAP32[3067] = HEAP32[3067] + -1;
  HEAP32[3058] = HEAP32[3058] - HEAP32[$0 >> 2];
  HEAP32[3065] = 0;
  HEAP32[3059] = 0;
 }

 function account_entity_enqueue($0) {
  HEAP32[3064] = HEAP32[3064] + HEAP32[$0 >> 2];
  HEAP32[3067] = HEAP32[3067] + 1;
  HEAP32[3058] = HEAP32[3058] + HEAP32[$0 >> 2];
  HEAP32[3065] = 0;
  HEAP32[3059] = 0;
 }

 function init_cfs_rq() {
  HEAP32[3076] = 0;
  HEAP32[3077] = 0;
  HEAP32[3074] = -1048576;
  HEAP32[3075] = -1;
  HEAP32[3072] = -1048576;
  HEAP32[3073] = -1;
 }

 function enqueue_task_fair($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $2 = $2 & 1;
  $1 = $1 + 48 | 0;
  while (1) {
   if (!(HEAP32[$1 + 32 >> 2] | !$1)) {
    $6 = HEAP32[3078];
    if (!(($6 | 0) != ($1 | 0) | $2)) {
     $3 = HEAP32[$1 + 60 >> 2] + HEAP32[3073] | 0;
     $4 = HEAP32[3072];
     $5 = $4 + HEAP32[$1 + 56 >> 2] | 0;
     if ($5 >>> 0 < $4 >>> 0) {
      $3 = $3 + 1 | 0
     }
     HEAP32[$1 + 56 >> 2] = $5;
     HEAP32[$1 + 60 >> 2] = $3;
    }
    update_curr();
    if (!(($1 | 0) == ($6 | 0) | $2)) {
     $3 = HEAP32[$1 + 60 >> 2] + HEAP32[3073] | 0;
     $4 = HEAP32[3072];
     $5 = $4 + HEAP32[$1 + 56 >> 2] | 0;
     if ($5 >>> 0 < $4 >>> 0) {
      $3 = $3 + 1 | 0
     }
     HEAP32[$1 + 56 >> 2] = $5;
     HEAP32[$1 + 60 >> 2] = $3;
    }
    account_entity_enqueue($1);
    if ($2) {
     place_entity($1)
    }
    if (($1 | 0) != ($6 | 0)) {
     __enqueue_entity($1)
    }
    $2 = 1;
    HEAP32[$1 + 32 >> 2] = 1;
    $1 = 0;
    HEAP32[3068] = HEAP32[3068] + 1;
    continue;
   }
   break;
  };
  while (1) {
   if ($1) {
    $1 = 0;
    HEAP32[3068] = HEAP32[3068] + 1;
    continue;
   }
   break;
  };
  HEAP32[$0 >> 2] = HEAP32[$0 >> 2] + 1;
 }

 function place_entity($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $2 = HEAP32[3072];
  $3 = HEAP32[3358];
  $1 = $2 - $3 | 0;
  $5 = $1;
  $4 = HEAP32[$0 + 56 >> 2];
  $6 = $1 - $4 >>> 0 <= 0 ? 0 : 1;
  $2 = HEAP32[3073] - ($2 >>> 0 < $3 >>> 0) | 0;
  $3 = HEAP32[$0 + 60 >> 2];
  $1 = $2 - ($3 + ($1 >>> 0 < $4 >>> 0) | 0) | 0;
  $1 = ($1 | 0) > 0 ? 1 : ($1 | 0) >= 0 ? $6 : 0;
  HEAP32[$0 + 56 >> 2] = $1 ? $5 : $4;
  HEAP32[$0 + 60 >> 2] = $1 ? $2 : $3;
 }

 function __enqueue_entity($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  $3 = 12304;
  $5 = 1;
  $6 = $0 + 56 | 0;
  while (1) {
   $1 = HEAP32[$3 >> 2];
   if ($1) {
    $7 = HEAP32[$6 >> 2];
    $3 = $1 + 44 | 0;
    $2 = HEAP32[$3 >> 2];
    $4 = HEAP32[$6 + 4 >> 2] - (($7 >>> 0 < $2 >>> 0) + HEAP32[$3 + 4 >> 2] | 0) | 0;
    $2 = $7 - $2 | 0;
    $3 = (($4 | 0) > -1 ? 1 : ($4 | 0) >= -1 ? ($2 >>> 0 <= 4294967295 ? 0 : 1) : 0) ? $1 + 4 | 0 : $1 + 8 | 0;
    $5 = (($4 | 0) < 0 ? 1 : ($4 | 0) <= 0 ? ($2 >>> 0 >= 0 ? 0 : 1) : 0) & $5;
    $2 = $1;
    continue;
   }
   break;
  };
  $1 = $0 + 16 | 0;
  HEAP32[$1 >> 2] = 0;
  HEAP32[$1 + 4 >> 2] = 0;
  HEAP32[$0 + 12 >> 2] = $2;
  $0 = $0 + 12 | 0;
  HEAP32[$3 >> 2] = $0;
  rb_insert_color_cached($0, 12304, $5 & 1);
 }

 function dequeue_task_fair($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0, $4 = 0, $5 = 0;
  $1 = $1 + 48 | 0;
  while (1) {
   if ($1) {
    update_curr();
    clear_buddies(12256, $1);
    if (($1 | 0) != HEAP32[3078]) {
     rb_erase_cached($1 + 12 | 0, 12304)
    }
    HEAP32[$1 + 32 >> 2] = 0;
    account_entity_dequeue($1);
    if (!($2 & 1)) {
     $3 = HEAP32[$1 + 56 >> 2];
     $4 = HEAP32[3072];
     $5 = HEAP32[$1 + 60 >> 2] - (HEAP32[3073] + ($3 >>> 0 < $4 >>> 0) | 0) | 0;
     HEAP32[$1 + 56 >> 2] = $3 - $4;
     HEAP32[$1 + 60 >> 2] = $5;
    }
    if (($2 & 6) != 2) {
     update_min_vruntime()
    }
    $1 = 0;
    HEAP32[3068] = HEAP32[3068] + -1;
    $2 = $2 | 1;
    if (!HEAP32[3064]) {
     continue
    }
   }
   break;
  };
  HEAP32[$0 >> 2] = HEAP32[$0 >> 2] + -1;
 }

 function clear_buddies($0, $1) {
  var $2 = 0, $3 = 0;
  label$1 : {
   if (HEAP32[$0 + 64 >> 2] != ($1 | 0)) {
    break label$1
   }
   $3 = HEAP32[3080];
   $2 = $1;
   while (1) {
    if (!$2 | ($2 | 0) != ($3 | 0)) {
     break label$1
    }
    $3 = 0;
    HEAP32[3080] = 0;
    $2 = 0;
    continue;
   };
  }
  label$3 : {
   if (HEAP32[$0 + 60 >> 2] != ($1 | 0)) {
    break label$3
   }
   $3 = HEAP32[3079];
   $2 = $1;
   while (1) {
    if (!$2 | ($2 | 0) != ($3 | 0)) {
     break label$3
    }
    $3 = 0;
    HEAP32[3079] = 0;
    $2 = 0;
    continue;
   };
  }
  label$5 : {
   if (HEAP32[$0 + 68 >> 2] != ($1 | 0)) {
    break label$5
   }
   $2 = HEAP32[3081];
   while (1) {
    if (!$1 | ($1 | 0) != ($2 | 0)) {
     break label$5
    }
    $2 = 0;
    HEAP32[3081] = 0;
    $1 = 0;
    continue;
   };
  }
 }

 function update_min_vruntime() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  $4 = HEAP32[3072];
  $5 = HEAP32[3073];
  $2 = HEAP32[3077];
  $0 = HEAP32[3078];
  label$1 : {
   label$2 : {
    if ($0) {
     $1 = $4;
     $3 = $5;
     if (HEAP32[$0 + 32 >> 2]) {
      $3 = HEAP32[$0 + 60 >> 2];
      $6 = $0;
      $1 = HEAP32[$0 + 56 >> 2];
     }
     if ($2) {
      break label$2
     }
     break label$1;
    }
    $1 = $4;
    $3 = $5;
    if (!$2) {
     break label$1
    }
   }
   $2 = $2 + 44 | 0;
   $0 = HEAP32[$2 >> 2];
   $2 = HEAP32[$2 + 4 >> 2];
   if ($6) {
    $7 = $0;
    $6 = $2 - (($0 >>> 0 < $1 >>> 0) + $3 | 0) | 0;
    $0 = ($6 | 0) < 0 ? 1 : ($6 | 0) <= 0 ? ($0 - $1 >>> 0 >= 0 ? 0 : 1) : 0;
    $1 = $0 ? $7 : $1;
    $3 = $0 ? $2 : $3;
    break label$1;
   }
   $1 = $0;
   $3 = $2;
  }
  $2 = $1;
  $0 = $3 - (($1 >>> 0 < $4 >>> 0) + $5 | 0) | 0;
  $1 = ($0 | 0) > 0 ? 1 : ($0 | 0) >= 0 ? ($1 - $4 >>> 0 <= 0 ? 0 : 1) : 0;
  HEAP32[3072] = $1 ? $2 : $4;
  HEAP32[3073] = $1 ? $3 : $5;
  $1 = HEAP32[3073];
  HEAP32[3074] = HEAP32[3072];
  HEAP32[3075] = $1;
 }

 function yield_task_fair($0) {
  $0 = $0 | 0;
  var $1 = 0, $2 = 0;
  if (HEAP32[$0 >> 2] != 1) {
   $1 = HEAP32[$0 + 1036 >> 2];
   $2 = $1 + 48 | 0;
   clear_buddies(12256, $2);
   if (HEAP32[$1 + 336 >> 2] != 3) {
    update_rq_clock($0);
    update_curr();
    HEAP32[$0 + 1056 >> 2] = HEAP32[$0 + 1056 >> 2] | 1;
   }
   $0 = HEAP32[3081];
   while (1) {
    $1 = $0;
    $0 = $2;
    $2 = 0;
    if ($0) {
     continue
    }
    break;
   };
   HEAP32[3081] = $1;
  }
 }

 function yield_to_task_fair($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0;
  if (HEAP32[$1 + 80 >> 2]) {
   $1 = $1 + 48 | 0;
   if (HEAP32[$1 + 288 >> 2] != 5) {
    $2 = HEAP32[3079];
    while (1) {
     $3 = $2;
     $2 = $1;
     $1 = 0;
     if ($2) {
      continue
     }
     break;
    };
    HEAP32[3079] = $3;
   }
   yield_task_fair($0);
   return 1;
  }
  return 0;
 }

 function check_preempt_wakeup($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  $2 = HEAP32[$0 + 1036 >> 2];
  if (!(($2 | 0) == ($1 | 0) | HEAP32[HEAP32[$2 + 4 >> 2] >> 2] & 8 | (HEAP32[$1 + 336 >> 2] == 5 | HEAP32[$2 + 336 >> 2] != 5))) {
   resched_curr($0)
  }
 }

 function pick_next_task_fair($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0, $4 = 0;
  if (HEAP32[$0 + 60 >> 2]) {
   FUNCTION_TABLE[HEAP32[HEAP32[$1 + 40 >> 2] + 28 >> 2]]($0, $1);
   $1 = HEAP32[$0 + 100 >> 2];
   $1 = $1 ? $1 + -12 | 0 : 0;
   $3 = ($1 | 0) != HEAP32[$0 + 116 >> 2];
   $2 = $3 ? $1 : 0;
   label$2 : {
    if (!$1 | $3) {
     break label$2
    }
    $3 = rb_next($1 + 12 | 0);
    $2 = $1;
    if (!$3) {
     break label$2
    }
    $3 = $3 + -12 | 0;
    $2 = $1;
    if (!$3) {
     break label$2
    }
    $2 = (wakeup_preempt_entity($3, $1) | 0) < 1 ? $3 : $1;
   }
   $3 = HEAP32[$0 + 112 >> 2];
   label$3 : {
    if (!$3) {
     break label$3
    }
    if ((wakeup_preempt_entity($3, $1) | 0) > 0) {
     break label$3
    }
    $2 = HEAP32[$0 + 112 >> 2];
   }
   $3 = $0 + 48 | 0;
   $4 = HEAP32[$0 + 108 >> 2];
   label$4 : {
    if (!$4) {
     break label$4
    }
    if ((wakeup_preempt_entity($4, $1) | 0) > 0) {
     break label$4
    }
    $2 = HEAP32[$0 + 108 >> 2];
   }
   clear_buddies($3, $2);
   set_next_entity($3, $2);
   return $2 + -48 | 0;
  }
  return 0;
 }

 function wakeup_preempt_entity($0, $1) {
  var $2 = 0, $3 = 0;
  label$1 : {
   label$2 : {
    $2 = HEAP32[$0 + 56 >> 2];
    $3 = HEAP32[$1 + 56 >> 2];
    $0 = HEAP32[$0 + 60 >> 2] - (HEAP32[$1 + 60 >> 2] + ($2 >>> 0 < $3 >>> 0) | 0) | 0;
    $3 = $2 - $3 | 0;
    if (!(($0 | 0) < 0 ? 1 : ($0 | 0) <= 0 ? ($3 >>> 0 >= 1 ? 0 : 1) : 0)) {
     $2 = HEAP32[3360];
     if (HEAP32[$1 >> 2] != 1024) {
      break label$2
     }
     break label$1;
    }
    return -1;
   }
   $2 = __calc_delta($2, 0, 1024, $1);
  }
  return ($0 | 0) > 0 ? 1 : ($0 | 0) >= 0 ? ($3 >>> 0 <= $2 >>> 0 ? 0 : 1) : 0;
 }

 function set_next_entity($0, $1) {
  var $2 = 0;
  if (HEAP32[$1 + 32 >> 2]) {
   rb_erase_cached($1 + 12 | 0, $0 + 48 | 0)
  }
  HEAP32[$0 + 56 >> 2] = $1;
  $2 = HEAP32[$1 + 52 >> 2];
  HEAP32[$1 + 64 >> 2] = HEAP32[$1 + 48 >> 2];
  HEAP32[$1 + 68 >> 2] = $2;
  $0 = $0 + 1024 | 0;
  $2 = HEAP32[$0 + 4 >> 2];
  HEAP32[$1 + 40 >> 2] = HEAP32[$0 >> 2];
  HEAP32[$1 + 44 >> 2] = $2;
 }

 function put_prev_task_fair($0, $1) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $1 = $1 + 48 | 0;
  while (1) {
   if ($1) {
    label$3 : {
     if (!HEAP32[$1 + 32 >> 2]) {
      break label$3
     }
     update_curr();
     if (!HEAP32[$1 + 32 >> 2]) {
      break label$3
     }
     __enqueue_entity($1);
    }
    $1 = 0;
    HEAP32[3078] = 0;
    continue;
   }
   break;
  };
 }

 function set_curr_task_fair($0) {
  $0 = $0 | 0;
  $0 = HEAP32[$0 + 1036 >> 2] + 48 | 0;
  while (1) {
   if ($0) {
    set_next_entity(12256, $0);
    $0 = 0;
    continue;
   }
   break;
  };
 }

 function task_tick_fair($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $1 = $1 + 48 | 0;
  while (1) {
   $0 = $1;
   if ($0) {
    update_curr();
    $1 = 0;
    if (HEAPU32[3067] < 2) {
     continue
    }
    $2 = sched_slice($0);
    $3 = HEAP32[$0 + 48 >> 2];
    $4 = HEAP32[$0 + 64 >> 2];
    $3 = $3 - $4 | 0;
    if ($3 >>> 0 > $2 >>> 0) {
     resched_curr(12208);
     clear_buddies(12256, $0);
     continue;
    }
    if (HEAPU32[3359] > $3 >>> 0) {
     continue
    }
    $4 = HEAP32[$0 + 56 >> 2];
    $3 = HEAP32[3077];
    $5 = $3 ? $3 + -12 | 0 : 0;
    $6 = HEAP32[$5 + 56 >> 2];
    $3 = $4 - $6 | 0;
    $0 = HEAP32[$0 + 60 >> 2] - (HEAP32[$5 + 60 >> 2] + ($4 >>> 0 < $6 >>> 0) | 0) | 0;
    if ((($0 | 0) < 0 ? 1 : ($0 | 0) <= 0 ? ($3 >>> 0 >= 0 ? 0 : 1) : 0) | (($0 | 0) < 0 ? 1 : ($0 | 0) <= 0 ? ($3 >>> 0 > $2 >>> 0 ? 0 : 1) : 0)) {
     continue
    }
    resched_curr(12208);
    continue;
   }
   break;
  };
 }

 function sched_slice($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  $2 = global$0 - 16 | 0;
  global$0 = $2;
  $1 = HEAP32[3067] + !HEAP32[$0 + 32 >> 2] | 0;
  $1 = $1 >>> 0 > 8 ? Math_imul($1, HEAP32[3359]) : HEAP32[3358];
  if ($0) {
   label$3 : {
    if (HEAP32[$0 + 32 >> 2]) {
     $0 = HEAP32[$0 >> 2];
     $3 = 12256;
     break label$3;
    }
    $0 = HEAP32[$0 >> 2];
    HEAP32[$2 + 12 >> 2] = 0;
    HEAP32[$2 + 8 >> 2] = HEAP32[3064] + $0;
    $3 = $2 + 8 | 0;
   }
   $1 = __calc_delta($1, 0, $0, $3);
   $3 = i64toi32_i32$HIGH_BITS;
  }
  global$0 = $2 + 16 | 0;
  i64toi32_i32$HIGH_BITS = $3;
  return $1;
 }

 function task_fork_fair($0) {
  $0 = $0 | 0;
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0;
  update_rq_clock(12208);
  $6 = HEAP32[3078];
  label$1 : {
   if ($6) {
    update_curr();
    $4 = HEAP32[$6 + 60 >> 2];
    $1 = $0 + 104 | 0;
    $2 = HEAP32[$6 + 56 >> 2];
    HEAP32[$1 >> 2] = $2;
    HEAP32[$1 + 4 >> 2] = $4;
    break label$1;
   }
   $1 = $0 + 104 | 0;
   $2 = HEAP32[$1 >> 2];
   $4 = HEAP32[$1 + 4 >> 2];
  }
  $1 = HEAP32[3072];
  $5 = HEAP32[3073];
  $8 = $5;
  $3 = $5 - (($1 >>> 0 < $2 >>> 0) + $4 | 0) | 0;
  $3 = ($3 | 0) > 0 ? 1 : ($3 | 0) >= 0 ? ($1 - $2 >>> 0 <= 0 ? 0 : 1) : 0;
  $2 = $3 ? $1 : $2;
  $5 = $3 ? $5 : $4;
  $4 = $5;
  $3 = $0 + 104 | 0;
  HEAP32[$3 >> 2] = $2;
  HEAP32[$3 + 4 >> 2] = $5;
  label$3 : {
   if (!$6 | !HEAP32[19832]) {
    break label$3
   }
   $9 = HEAP32[$6 + 60 >> 2];
   $7 = HEAP32[$6 + 56 >> 2];
   $5 = $9 - (($7 >>> 0 < $2 >>> 0) + $4 | 0) | 0;
   if (($5 | 0) > -1 ? 1 : ($5 | 0) >= -1 ? ($7 - $2 >>> 0 <= 4294967295 ? 0 : 1) : 0) {
    break label$3
   }
   $1 = $6 + 56 | 0;
   HEAP32[$1 >> 2] = $2;
   HEAP32[$1 + 4 >> 2] = $4;
   $0 = $0 + 104 | 0;
   HEAP32[$0 >> 2] = $7;
   HEAP32[$0 + 4 >> 2] = $9;
   resched_curr(12208);
   $2 = HEAP32[$0 >> 2];
   $4 = HEAP32[$0 + 4 >> 2];
   $1 = HEAP32[3072];
   $8 = HEAP32[3073];
  }
  HEAP32[$3 >> 2] = $2 - $1;
  HEAP32[$3 + 4 >> 2] = $4 - (($2 >>> 0 < $1 >>> 0) + $8 | 0);
 }

 function switched_from_fair($0, $1) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  var $2 = 0, $3 = 0;
  label$1 : {
   if (HEAP32[$1 + 20 >> 2]) {
    break label$1
   }
   $0 = $1 + 96 | 0;
   if (!(HEAP32[$0 >> 2] | HEAP32[$0 + 4 >> 2]) | (HEAPU8[$1 + 436 | 0] & 8 ? HEAP32[$1 >> 2] == 512 : 0)) {
    break label$1
   }
   place_entity($1 + 48 | 0);
   $1 = $1 + 104 | 0;
   $0 = HEAP32[$1 >> 2];
   $2 = HEAP32[3072];
   $3 = HEAP32[$1 + 4 >> 2] - (HEAP32[3073] + ($0 >>> 0 < $2 >>> 0) | 0) | 0;
   HEAP32[$1 >> 2] = $0 - $2;
   HEAP32[$1 + 4 >> 2] = $3;
  }
 }

 function switched_to_fair($0, $1) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  var $2 = 0, $3 = 0, $4 = 0;
  label$1 : {
   $2 = HEAP32[$1 + 20 >> 2];
   label$2 : {
    if (($2 | 0) != 1) {
     if ($2) {
      break label$2
     }
     $0 = $1 + 96 | 0;
     if (!(HEAP32[$0 >> 2] | HEAP32[$0 + 4 >> 2]) | (HEAPU8[$1 + 436 | 0] & 8 ? HEAP32[$1 >> 2] == 512 : 0)) {
      break label$2
     }
     $1 = $1 + 104 | 0;
     $2 = $1;
     $4 = $1;
     $0 = HEAP32[$1 + 4 >> 2] + HEAP32[3073] | 0;
     $3 = HEAP32[3072];
     $1 = $3 + HEAP32[$1 >> 2] | 0;
     if ($1 >>> 0 < $3 >>> 0) {
      $0 = $0 + 1 | 0
     }
     HEAP32[$4 >> 2] = $1;
     HEAP32[$2 + 4 >> 2] = $0;
     return;
    }
    if (HEAP32[$0 + 1036 >> 2] == ($1 | 0)) {
     break label$1
    }
    check_preempt_curr($0, $1, 0);
   }
   return;
  }
  resched_curr($0);
 }

 function prio_changed_fair($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  label$1 : {
   if (HEAP32[$1 + 20 >> 2] != 1) {
    break label$1
   }
   if (($1 | 0) != HEAP32[$0 + 1036 >> 2]) {
    check_preempt_curr($0, $1, 0);
    break label$1;
   }
   if (HEAP32[$1 + 24 >> 2] <= ($2 | 0)) {
    break label$1
   }
   resched_curr($0);
  }
 }

 function get_rr_interval_fair($0, $1) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  if (HEAP32[$0 + 48 >> 2]) {
   return (sched_slice($1 + 48 | 0) >>> 0) / 4e6 | 0
  }
  return 0;
 }

 function update_curr_fair($0) {
  $0 = $0 | 0;
  update_curr();
 }

 function __calc_delta($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  $5 = HEAP32[$3 + 4 >> 2];
  if (!$5) {
   $6 = $3 + 4 | 0;
   $5 = HEAP32[$3 >> 2];
   label$2 : {
    if ($5) {
     $5 = 4294967295 / ($5 >>> 0) | 0;
     break label$2;
    }
    $5 = -1;
   }
   HEAP32[$6 >> 2] = $5;
  }
  $4 = __wasm_i64_mul($5, 0, $2, 0);
  $2 = i64toi32_i32$HIGH_BITS;
  $3 = 32;
  $5 = 0;
  while (1) {
   if (!(($2 | 0) == 1 & $4 >>> 0 < 0 | $2 >>> 0 < 1)) {
    $6 = $7 + 1 | 0;
    if ($6 >>> 0 < 1) {
     $5 = $5 + 1 | 0
    }
    $7 = $6;
    $3 = $3 + -1 | 0;
    $6 = $2;
    $2 = $2 >>> 1 | 0;
    $4 = ($6 & 1) << 31 | $4 >>> 1;
    continue;
   }
   break;
  };
  $5 = $4;
  $2 = __wasm_i64_mul($4, 0, $0, 0);
  $6 = i64toi32_i32$HIGH_BITS;
  $0 = $2;
  $4 = $3 & 31;
  if (32 <= ($3 & 63) >>> 0) {
   $2 = 0;
   $4 = $6 >>> $4 | 0;
  } else {
   $2 = $6 >>> $4 | 0;
   $4 = ((1 << $4) - 1 & $6) << 32 - $4 | $0 >>> $4;
  }
  $0 = 0;
  if ($0 | $1) {
   $0 = __wasm_i64_mul($5, 0, $1, 0);
   $3 = i64toi32_i32$HIGH_BITS;
   $1 = $0;
   $0 = $7 & 31;
   if (32 <= ($7 & 63) >>> 0) {
    $5 = $1 << $0;
    $0 = 0;
   } else {
    $5 = (1 << $0) - 1 & $1 >>> 32 - $0 | $3 << $0;
    $0 = $1 << $0;
   }
   $0 = $0 + $4 | 0;
   $2 = $2 + $5 | 0;
   $2 = $0 >>> 0 < $4 >>> 0 ? $2 + 1 | 0 : $2;
   $4 = $0;
  }
  i64toi32_i32$HIGH_BITS = $2;
  return $4;
 }

 function init_rt_bandwidth($0, $1, $2, $3) {
  HEAP32[19836] = $2;
  HEAP32[19837] = $3;
  HEAP32[19834] = $0;
  HEAP32[19835] = $1;
  hrtimer_init(79352);
  HEAP32[19846] = 48;
 }

 function sched_rt_period_timer($0) {
  $0 = $0 | 0;
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0;
  $12 = $0 + 36 | 0;
  $8 = $0 + -16 | 0;
  $9 = $8 + 8 | 0;
  while (1) {
   $4 = HEAP32[$8 >> 2];
   $2 = HEAP32[$8 + 4 >> 2];
   $2 = hrtimer_forward($0, FUNCTION_TABLE[HEAP32[HEAP32[$12 >> 2] + 28 >> 2]]() | 0, i64toi32_i32$HIGH_BITS, $4, $2);
   label$2 : {
    label$3 : {
     if ($2) {
      $1 = $2;
      $4 = $1 >> 31;
      $13 = $1;
      $14 = $4;
      $4 = 1;
      $7 = 0;
      $1 = 1;
      while (1) {
       label$5 : {
        if (!($1 & 1)) {
         break label$5
        }
        if (!(HEAP32[3292] == -1 & HEAP32[3293] == -1)) {
         $1 = HEAP32[$9 + 4 >> 2];
         HEAP32[3292] = HEAP32[$9 >> 2];
         HEAP32[3293] = $1;
        }
        $1 = HEAP32[3286];
        if ($1 ? 0 : !(HEAP32[3290] != 0 | HEAP32[3291] != 0)) {
         break label$5
        }
        update_rq_clock(12208);
        label$9 : {
         label$10 : {
          label$11 : {
           label$12 : {
            label$13 : {
             if (HEAP32[3290] | HEAP32[3291]) {
              $1 = HEAP32[3291];
              $2 = HEAP32[3290];
              $10 = HEAP32[3292];
              $6 = HEAP32[3293];
              $3 = __wasm_i64_mul($10, $6, $13, $14);
              $5 = i64toi32_i32$HIGH_BITS;
              $11 = ($5 | 0) == ($1 | 0) & $2 >>> 0 < $3 >>> 0 | $1 >>> 0 < $5 >>> 0;
              $3 = $11 ? $2 : $3;
              $1 = $1 - (($2 >>> 0 < $3 >>> 0) + ($11 ? $1 : $5) | 0) | 0;
              $3 = $2 - $3 | 0;
              HEAP32[3290] = $3;
              $2 = $1;
              HEAP32[3291] = $1;
              if (!HEAP32[3289] | (($1 | 0) == ($6 | 0) & $3 >>> 0 >= $10 >>> 0 | $1 >>> 0 > $6 >>> 0)) {
               break label$13
              }
              $1 = 0;
              HEAP32[3289] = 0;
              $6 = HEAP32[3286];
              if (!$6) {
               break label$12
              }
              $1 = $6;
              if (HEAP32[3311] == HEAP32[3312]) {
               HEAP32[3316] = HEAP32[3316] & -2;
               $5 = 0;
              } else {
               $5 = 0
              }
              break label$11;
             }
             $1 = HEAP32[3289];
             if (HEAP32[3286]) {
              $4 = 0;
              if (!$1) {
               break label$10
              }
             }
             $7 = $1 ? 1 : $7;
             break label$9;
            }
            $1 = HEAP32[3286];
            $5 = 1;
            break label$11;
           }
           $5 = 0;
          }
          $7 = HEAP32[3289] ? 1 : $7;
          $4 = $2 | $3 ? 0 : $1 ? 0 : $4;
          if (!HEAP32[3286] | $5) {
           break label$9
          }
         }
         enqueue_top_rt_rq();
         resched_curr(12208);
        }
        $1 = 0;
        continue;
       }
       break;
      };
      if ($7) {
       break label$3
      }
      $1 = 1;
      if (HEAP32[3051] < 0) {
       break label$2
      }
      if (HEAP32[$9 >> 2] != -1 | HEAP32[$9 + 4 >> 2] != -1) {
       break label$3
      }
      break label$2;
     }
     if ($1) {
      HEAP32[$8 + 64 >> 2] = 0
     }
     return !$1 | 0;
    }
    $1 = $4;
   }
   continue;
  };
 }

 function enqueue_top_rt_rq() {
  var $0 = 0;
  label$1 : {
   if (HEAP32[3289] | HEAP32[3288]) {
    break label$1
   }
   $0 = HEAP32[3286];
   if (!$0) {
    break label$1
   }
   HEAP32[3288] = 1;
   HEAP32[3052] = HEAP32[3052] + $0;
  }
 }

 function init_rt_rq() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0, wasm2js_i32$0 = 0, wasm2js_i32$1 = 0;
  $0 = 12344;
  while (1) {
   if (($1 | 0) != 100) {
    HEAP32[$0 + 4 >> 2] = $0;
    $2 = ($1 >>> 3 & 28) + 12328 | 0;
    $3 = HEAP32[$2 >> 2];
    (wasm2js_i32$0 = $2, wasm2js_i32$1 = __wasm_rotl_i32(-2, $1) & $3), HEAP32[wasm2js_i32$0 >> 2] = wasm2js_i32$1;
    HEAP32[$0 >> 2] = $0;
    $0 = $0 + 8 | 0;
    $1 = $1 + 1 | 0;
    continue;
   }
   break;
  };
  HEAP32[3290] = 0;
  HEAP32[3291] = 0;
  HEAP32[3292] = 0;
  HEAP32[3293] = 0;
  HEAP32[3288] = 0;
  HEAP32[3289] = 0;
  HEAP32[3085] = HEAP32[3085] | 16;
 }

 function sched_rt_bandwidth_account($0) {
  var $1 = 0, $2 = 0;
  if (hrtimer_active(79352)) {
   $0 = 1
  } else {
   $1 = HEAP32[$0 + 836 >> 2];
   $2 = HEAP32[19837];
   $0 = ($1 | 0) == ($2 | 0) & HEAPU32[$0 + 832 >> 2] < HEAPU32[19836] | $1 >>> 0 < $2 >>> 0;
  }
  return $0;
 }

 function enqueue_task_rt($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $3 = $1 + 128 | 0;
  if ($2 & 1) {
   HEAP32[$1 + 136 >> 2] = 0
  }
  dequeue_rt_stack($3, $2);
  $4 = $2 & 16;
  $5 = ($2 & 6) == 2;
  while (1) {
   if ($3) {
    if (!$5) {
     $6 = $3 + -128 | 0;
     $0 = HEAP32[$3 + -104 >> 2] << 3;
     $2 = $0 + 12344 | 0;
     label$5 : {
      if (!$4) {
       $0 = $0 + 12348 | 0;
       $1 = HEAP32[$0 >> 2];
       HEAP32[$1 >> 2] = $3;
       HEAP32[$0 >> 2] = $3;
       $0 = $2;
       $2 = $1;
       break label$5;
      }
      $0 = HEAP32[$2 >> 2];
      HEAP32[$0 + 4 >> 2] = $3;
      HEAP32[$2 >> 2] = $3;
     }
     HEAP32[$3 + 4 >> 2] = $2;
     HEAP32[$3 >> 2] = $0;
     HEAP16[$3 + 22 >> 1] = 1;
     $0 = HEAP32[$6 + 24 >> 2];
     $1 = (($0 | 0) / 32 << 2) + 12328 | 0;
     HEAP32[$1 >> 2] = HEAP32[$1 >> 2] | 1 << ($0 & 31);
    }
    HEAP16[$3 + 20 >> 1] = 1;
    HEAP32[3286] = HEAP32[3286] + 1;
    HEAP32[3287] = HEAP32[3287] + (HEAP32[$3 + 208 >> 2] == 2);
    $3 = 0;
    if (HEAP32[3051] < 0) {
     continue
    }
    if (HEAP32[19836] == -1 & HEAP32[19837] == -1) {
     continue
    }
    if (!HEAP32[19850]) {
     HEAP32[19850] = 1;
     hrtimer_forward(79352, FUNCTION_TABLE[HEAP32[HEAP32[19847] + 28 >> 2]]() | 0, i64toi32_i32$HIGH_BITS, 0, 0);
     $0 = HEAP32[19842];
     $1 = HEAP32[19844];
     $2 = $1;
     $3 = $0 - $1 | 0;
     $1 = HEAP32[19845];
     hrtimer_start_range_ns(79352, $2, $1, $3, HEAP32[19843] - ($1 + ($0 >>> 0 < $2 >>> 0) | 0) | 0, 2);
    }
    $3 = 0;
    continue;
   }
   break;
  };
  enqueue_top_rt_rq();
 }

 function dequeue_rt_stack($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, wasm2js_i32$0 = 0, wasm2js_i32$1 = 0;
  while (1) {
   if ($0) {
    $3 = $0;
    HEAP32[$3 + 24 >> 2] = $2;
    $0 = 0;
    $2 = $3;
    continue;
   }
   break;
  };
  dequeue_top_rt_rq();
  $1 = ($1 & 6) == 2;
  while (1) {
   if ($2) {
    if (HEAPU16[$2 + 20 >> 1]) {
     if (!$1) {
      $0 = HEAP32[$2 + 4 >> 2];
      $3 = HEAP32[$2 >> 2];
      HEAP32[$0 >> 2] = $3;
      HEAP32[$3 + 4 >> 2] = $0;
      HEAP32[$2 >> 2] = $2;
      HEAP32[$2 + 4 >> 2] = $2;
      $0 = HEAP32[$2 + -104 >> 2];
      $3 = ($0 << 3) + 12344 | 0;
      if (HEAP32[$3 >> 2] == ($3 | 0)) {
       $3 = (($0 | 0) / 32 << 2) + 12328 | 0;
       $4 = HEAP32[$3 >> 2];
       (wasm2js_i32$0 = $3, wasm2js_i32$1 = __wasm_rotl_i32(-2, $0) & $4), HEAP32[wasm2js_i32$0 >> 2] = wasm2js_i32$1;
      }
      HEAP16[$2 + 22 >> 1] = 0;
     }
     HEAP16[$2 + 20 >> 1] = 0;
     HEAP32[3286] = HEAP32[3286] + -1;
     HEAP32[3287] = HEAP32[3287] - (HEAP32[$2 + 208 >> 2] == 2);
    }
    $2 = HEAP32[$2 + 24 >> 2];
    continue;
   }
   break;
  };
 }

 function dequeue_task_rt($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  update_curr_rt($0);
  dequeue_rt_stack($1 + 128 | 0, $2);
  enqueue_top_rt_rq();
 }

 function update_curr_rt($0) {
  $0 = $0 | 0;
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  label$1 : {
   $2 = HEAP32[$0 + 1036 >> 2];
   if (HEAP32[$2 + 40 >> 2] != 22836) {
    break label$1
   }
   $5 = HEAP32[$0 + 1076 >> 2];
   $6 = HEAP32[$0 + 1072 >> 2];
   $3 = $6;
   $4 = $2 + 88 | 0;
   $1 = $4;
   $7 = HEAP32[$1 >> 2];
   $1 = $5 - (($3 >>> 0 < $7 >>> 0) + HEAP32[$1 + 4 >> 2] | 0) | 0;
   $3 = $3 - $7 | 0;
   if (($1 | 0) < 0 ? 1 : ($1 | 0) <= 0 ? ($3 >>> 0 >= 1 ? 0 : 1) : 0) {
    break label$1
   }
   HEAP32[$4 >> 2] = $6;
   HEAP32[$4 + 4 >> 2] = $5;
   $4 = $2 + 96 | 0;
   $5 = $4;
   $6 = $4;
   $2 = $1 + HEAP32[$4 + 4 >> 2] | 0;
   $4 = $3 + HEAP32[$4 >> 2] | 0;
   if ($4 >>> 0 < $3 >>> 0) {
    $2 = $2 + 1 | 0
   }
   HEAP32[$6 >> 2] = $4;
   HEAP32[$5 + 4 >> 2] = $2;
   if (HEAP32[3292] == -1 & HEAP32[3293] == -1 | HEAP32[3051] < 0) {
    break label$1
   }
   $1 = $1 + HEAP32[3291] | 0;
   $2 = $3 + HEAP32[3290] | 0;
   if ($2 >>> 0 < $3 >>> 0) {
    $1 = $1 + 1 | 0
   }
   $3 = $2;
   HEAP32[3290] = $3;
   HEAP32[3291] = $1;
   label$2 : {
    if (!HEAP32[3289]) {
     $2 = HEAP32[3293];
     $4 = $2;
     $5 = $3;
     $3 = HEAP32[3292];
     if (($4 | 0) == ($1 | 0) & $5 >>> 0 <= $3 >>> 0 | $1 >>> 0 < $4 >>> 0) {
      break label$2
     }
     $1 = HEAP32[19835];
     if (($1 | 0) == ($2 | 0) & $3 >>> 0 >= HEAPU32[19834] | $2 >>> 0 > $1 >>> 0) {
      break label$2
     }
     label$4 : {
      if (HEAP32[19836] | HEAP32[19837]) {
       HEAP32[3289] = 1;
       if (HEAPU8[79408]) {
        break label$4
       }
       HEAP8[79408] = 1;
       printk_deferred(22997, 0);
       if (HEAP32[3289]) {
        break label$4
       }
       break label$2;
      }
      HEAP32[3290] = 0;
      HEAP32[3291] = 0;
      break label$2;
     }
     dequeue_top_rt_rq();
    }
    resched_curr($0);
   }
  }
 }

 function yield_task_rt($0) {
  $0 = $0 | 0;
  requeue_task_rt(HEAP32[$0 + 1036 >> 2]);
 }

 function requeue_task_rt($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0;
  $4 = $0 + 128 | 0;
  while (1) {
   $0 = $4;
   if ($0) {
    $4 = 0;
    if (!HEAPU16[$0 + 20 >> 1]) {
     continue
    }
    $1 = HEAP32[$0 >> 2];
    $2 = HEAP32[$0 + 4 >> 2];
    HEAP32[$1 + 4 >> 2] = $2;
    $3 = HEAP32[$0 + -104 >> 2];
    HEAP32[$2 >> 2] = $1;
    $2 = $3 << 3;
    $3 = $2 + 12348 | 0;
    $1 = HEAP32[$3 >> 2];
    HEAP32[$3 >> 2] = $0;
    HEAP32[$0 >> 2] = $2 + 12344;
    HEAP32[$1 >> 2] = $0;
    HEAP32[$0 + 4 >> 2] = $1;
    continue;
   }
   break;
  };
 }

 function check_preempt_curr_rt($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  if (HEAP32[$1 + 24 >> 2] < HEAP32[HEAP32[$0 + 1036 >> 2] + 24 >> 2]) {
   resched_curr($0)
  }
 }

 function pick_next_task_rt($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  $2 = global$0 - 32 | 0;
  global$0 = $2;
  if (HEAP32[$1 + 40 >> 2] == 22836) {
   update_curr_rt($0)
  }
  label$2 : {
   label$3 : {
    label$4 : {
     label$5 : {
      label$6 : {
       if (HEAP32[$0 + 944 >> 2]) {
        FUNCTION_TABLE[HEAP32[HEAP32[$1 + 40 >> 2] + 28 >> 2]]($0, $1);
        $1 = HEAP32[$0 + 120 >> 2];
        if (!$1) {
         break label$6
        }
        $5 = $1 & 65535;
        $1 = $5 ? $1 : $1 >>> 16 | 0;
        $3 = $1 & 255;
        $1 = $3 ? $1 : $1 >>> 8 | 0;
        $4 = $1 & 15;
        $1 = $4 ? $1 : $1 >>> 4 | 0;
        $6 = $1 & 3;
        $7 = (($6 ? $1 : $1 >>> 2 | 0) ^ -1) & 1;
        $1 = !$5 << 4;
        $1 = $3 ? $1 : $1 | 8;
        $1 = $4 ? $1 : $1 | 4;
        $1 = $7 + ($6 ? $1 : $1 | 2) | 0;
        break label$5;
       }
       $0 = 0;
       break label$4;
      }
      $1 = HEAP32[$0 + 124 >> 2];
      if ($1) {
       $3 = $1 & 65535;
       $4 = !$3 << 4;
       $1 = $3 ? $1 : $1 >>> 16 | 0;
       $3 = $1 & 255;
       $4 = $3 ? $4 : $4 | 8;
       $1 = $3 ? $1 : $1 >>> 8 | 0;
       $3 = $1 & 15;
       $4 = $3 ? $4 : $4 | 4;
       $1 = $3 ? $1 : $1 >>> 4 | 0;
       $3 = $1 & 3;
       $1 = (($3 ? $4 : $4 | 2) + ((($3 ? $1 : $1 >>> 2 | 0) ^ -1) & 1) | 0) + 32 | 0;
       break label$5;
      }
      $1 = HEAP32[$0 + 128 >> 2];
      if ($1) {
       $3 = $1 & 65535;
       $4 = !$3 << 4;
       $1 = $3 ? $1 : $1 >>> 16 | 0;
       $3 = $1 & 255;
       $4 = $3 ? $4 : $4 | 8;
       $1 = $3 ? $1 : $1 >>> 8 | 0;
       $3 = $1 & 15;
       $4 = $3 ? $4 : $4 | 4;
       $1 = $3 ? $1 : $1 >>> 4 | 0;
       $3 = $1 & 3;
       $1 = (($3 ? $4 : $4 | 2) + ((($3 ? $1 : $1 >>> 2 | 0) ^ -1) & 1) | 0) - -64 | 0;
       break label$5;
      }
      $1 = HEAP32[$0 + 132 >> 2];
      $3 = $1 & 65535;
      $4 = !$3 << 4;
      $1 = $3 ? $1 : $1 >>> 16 | 0;
      $3 = $1 & 255;
      $4 = $3 ? $4 : $4 | 8;
      $1 = $3 ? $1 : $1 >>> 8 | 0;
      $3 = $1 & 15;
      $4 = $3 ? $4 : $4 | 4;
      $1 = $3 ? $1 : $1 >>> 4 | 0;
      $3 = $1 & 3;
      $1 = (($3 ? $4 : $4 | 2) + ((($3 ? $1 : $1 >>> 2 | 0) ^ -1) & 1) | 0) + 96 | 0;
     }
     if (($1 | 0) >= 100) {
      break label$3
     }
     $1 = HEAP32[(($1 << 3) + $0 | 0) + 136 >> 2];
     if (!$1) {
      break label$2
     }
     $4 = HEAP32[$0 + 1076 >> 2];
     $3 = $1 + -40 | 0;
     HEAP32[$3 >> 2] = HEAP32[$0 + 1072 >> 2];
     HEAP32[$3 + 4 >> 2] = $4;
     $0 = $1 + -128 | 0;
    }
    global$0 = $2 + 32 | 0;
    return $0 | 0;
   }
   HEAP32[$2 + 8 >> 2] = 22977;
   HEAP32[$2 + 4 >> 2] = 1510;
   HEAP32[$2 >> 2] = 22935;
   printk(22904, $2);
   abort();
  }
  HEAP32[$2 + 24 >> 2] = 22958;
  HEAP32[$2 + 20 >> 2] = 1526;
  HEAP32[$2 + 16 >> 2] = 22935;
  printk(22904, $2 + 16 | 0);
  abort();
 }

 function put_prev_task_rt($0, $1) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  update_curr_rt($0);
 }

 function set_curr_task_rt($0) {
  $0 = $0 | 0;
  var $1 = 0, $2 = 0;
  $2 = HEAP32[$0 + 1076 >> 2];
  $1 = HEAP32[$0 + 1036 >> 2] + 88 | 0;
  HEAP32[$1 >> 2] = HEAP32[$0 + 1072 >> 2];
  HEAP32[$1 + 4 >> 2] = $2;
 }

 function task_tick_rt($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0, $4 = 0;
  update_curr_rt($0);
  label$1 : {
   if (HEAP32[$1 + 336 >> 2] != 2) {
    break label$1
   }
   $3 = $1 + 144 | 0;
   $2 = HEAP32[$3 >> 2] + -1 | 0;
   HEAP32[$3 >> 2] = $2;
   if ($2) {
    break label$1
   }
   $2 = $1 + 128 | 0;
   HEAP32[$3 >> 2] = HEAP32[3361];
   while (1) {
    if (!$2) {
     break label$1
    }
    $3 = HEAP32[$2 >> 2];
    $4 = HEAP32[$2 + 4 >> 2];
    $2 = 0;
    if (($3 | 0) == ($4 | 0)) {
     continue
    }
    break;
   };
   requeue_task_rt($1);
   resched_curr($0);
  }
 }

 function switched_to_rt($0, $1) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  var $2 = 0;
  label$1 : {
   if (HEAP32[$1 + 20 >> 2] != 1) {
    break label$1
   }
   $2 = HEAP32[$0 + 1036 >> 2];
   if (($2 | 0) == ($1 | 0) | HEAP32[$1 + 24 >> 2] >= HEAP32[$2 + 24 >> 2]) {
    break label$1
   }
   resched_curr($0);
  }
 }

 function prio_changed_rt($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0, $4 = 0;
  label$1 : {
   if (HEAP32[$1 + 20 >> 2] != 1) {
    break label$1
   }
   $3 = HEAP32[$1 + 24 >> 2];
   $4 = $1;
   $1 = HEAP32[$0 + 1036 >> 2];
   label$2 : {
    if (($4 | 0) != ($1 | 0)) {
     if (($3 | 0) >= HEAP32[$1 + 24 >> 2]) {
      break label$1
     }
     break label$2;
    }
    if (($3 | 0) <= ($2 | 0)) {
     break label$1
    }
   }
   resched_curr($0);
  }
 }

 function get_rr_interval_rt($0, $1) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  return (HEAP32[$1 + 336 >> 2] == 2 ? HEAP32[3361] : 0) | 0;
 }

 function dequeue_top_rt_rq() {
  var $0 = 0, $1 = 0;
  $0 = global$0 - 16 | 0;
  global$0 = $0;
  label$1 : {
   if (HEAP32[3288]) {
    $1 = HEAP32[3052];
    if (!$1) {
     break label$1
    }
    HEAP32[3052] = $1 - HEAP32[3286];
    HEAP32[3288] = 0;
   }
   global$0 = $0 + 16 | 0;
   return;
  }
  HEAP32[$0 + 8 >> 2] = 22940;
  HEAP32[$0 + 4 >> 2] = 1004;
  HEAP32[$0 >> 2] = 22935;
  printk(22904, $0);
  abort();
 }

 function init_dl_bw() {
  var $0 = 0, $1 = 0;
  $0 = HEAP32[3051];
  label$1 : {
   if (($0 | 0) >= 0) {
    $0 = to_ratio(__wasm_i64_mul(HEAP32[3050], 0, 1e3, 0), i64toi32_i32$HIGH_BITS, __wasm_i64_mul($0, $0 >> 31, 1e3, 0), i64toi32_i32$HIGH_BITS);
    break label$1;
   }
   $1 = -1;
   $0 = -1;
  }
  HEAP32[3298] = $0;
  HEAP32[3299] = $1;
  HEAP32[3300] = 0;
  HEAP32[3301] = 0;
 }

 function init_dl_rq() {
  HEAP32[3294] = 0;
  HEAP32[3295] = 0;
  init_dl_bw();
  HEAP32[3304] = 0;
  HEAP32[3305] = 0;
  HEAP32[3302] = 0;
  HEAP32[3303] = 0;
  init_dl_rq_bw_ratio();
 }

 function init_dl_rq_bw_ratio() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0, $4 = 0, wasm2js_i32$0 = 0, wasm2js_i32$1 = 0;
  $0 = HEAP32[3051];
  label$1 : {
   if (($0 | 0) > -1) {
    (wasm2js_i32$0 = 13232, wasm2js_i32$1 = to_ratio(__wasm_i64_mul($0, $0 >> 31, 1e3, 0), i64toi32_i32$HIGH_BITS, __wasm_i64_mul(HEAP32[3050], 0, 1e3, 0), i64toi32_i32$HIGH_BITS) >>> 12 | 0), HEAP32[wasm2js_i32$0 >> 2] = wasm2js_i32$1;
    HEAP32[3309] = 0;
    $2 = __wasm_i64_mul(HEAP32[3050], 0, 1e3, 0);
    $3 = i64toi32_i32$HIGH_BITS;
    $1 = HEAP32[3051];
    $0 = $1 >> 31;
    $4 = __wasm_i64_mul($1, $0, 1e3, 0);
    $0 = ($0 | 0) < 0 ? 1 : ($0 | 0) <= 0 ? ($1 >>> 0 >= 0 ? 0 : 1) : 0;
    $0 = to_ratio($2, $3, $0 ? -1 : $4, $0 ? -1 : i64toi32_i32$HIGH_BITS);
    break label$1;
   }
   HEAP32[3308] = 256;
   HEAP32[3309] = 0;
   $0 = 1048576;
  }
  HEAP32[3306] = $0;
  HEAP32[3307] = 0;
 }

 function dl_task_timer($0) {
  $0 = $0 | 0;
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  $2 = $0 + -240 | 0;
  $1 = task_rq_lock($2, $3 + 8 | 0);
  $4 = HEAP32[$0 + -216 >> 2] > -1;
  $0 = $0 + -80 | 0;
  label$1 : {
   if ($4 | (HEAPU8[$0 + 76 | 0] & 3) != 1) {
    break label$1
   }
   update_rq_clock($1);
   label$2 : {
    if (HEAP32[$2 + 20 >> 2] == 1) {
     enqueue_task_dl($1, $2, 32);
     if (HEAP32[HEAP32[$1 + 1036 >> 2] + 24 >> 2] <= -1) {
      break label$2
     }
     resched_curr($1);
     break label$1;
    }
    replenish_dl_entity($0, $0);
    break label$1;
   }
   check_preempt_curr_dl($1, $2, 0);
  }
  HEAP32[19859] = HEAP32[$3 + 8 >> 2];
  $1 = $0 + -152 | 0;
  $0 = HEAP32[$1 >> 2] + -1 | 0;
  HEAP32[$1 >> 2] = $0;
  if (!$0) {
   __put_task_struct($2)
  }
  global$0 = $3 + 16 | 0;
  return 0;
 }

 function enqueue_task_dl($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0, $15 = 0;
  $8 = global$0 - 48 | 0;
  global$0 = $8;
  $9 = HEAPU8[$1 + 236 | 0];
  label$1 : {
   label$2 : {
    label$3 : {
     if (HEAP32[$1 + 32 >> 2] >= 0) {
      if (!($9 & 2) | ($2 | 0) != 32) {
       break label$3
      }
      break label$1;
     }
     $10 = $1 + 160 | 0;
     if ($9 & 1) {
      break label$2
     }
     $3 = $1 + 184 | 0;
     $4 = HEAP32[$3 >> 2];
     $5 = $1 + 192 | 0;
     $7 = HEAP32[$5 >> 2];
     $11 = HEAP32[$3 + 4 >> 2];
     $12 = HEAP32[$5 + 4 >> 2];
     if (($4 | 0) == ($7 | 0) & ($11 | 0) == ($12 | 0)) {
      break label$2
     }
     $5 = $1 + 224 | 0;
     $3 = HEAP32[$5 >> 2];
     $13 = HEAP32[$5 + 4 >> 2];
     $14 = HEAP32[3319];
     $5 = HEAP32[3318];
     $6 = $13 - ($14 + ($3 >>> 0 < $5 >>> 0) | 0) | 0;
     if (($6 | 0) > -1 ? 1 : ($6 | 0) >= -1 ? ($3 - $5 >>> 0 <= 4294967295 ? 0 : 1) : 0) {
      break label$2
     }
     $15 = $4 - $7 | 0;
     $6 = $5 + ($15 - $3 | 0) | 0;
     $3 = $14 + ($11 - (($4 >>> 0 < $7 >>> 0) + $12 | 0) - (($15 >>> 0 < $3 >>> 0) + $13) | 0) | 0;
     $3 = $6 >>> 0 < $5 >>> 0 ? $3 + 1 | 0 : $3;
     if ($9 & 2 | (($3 | 0) > -1 ? 1 : ($3 | 0) >= -1 ? ($6 >>> 0 <= 4294967295 ? 0 : 1) : 0)) {
      break label$2
     }
     if (!start_dl_timer($10 + -160 | 0)) {
      break label$2
     }
     $3 = $1 + 236 | 0;
     HEAP8[$3 | 0] = HEAPU8[$3 | 0] | 1;
     $3 = $1 + 216 | 0;
     $4 = HEAP32[$3 + 4 >> 2];
     if (($4 | 0) < 0 ? 1 : ($4 | 0) <= 0 ? (HEAPU32[$3 >> 2] >= 1 ? 0 : 1) : 0) {
      break label$2
     }
     HEAP32[$3 >> 2] = 0;
     HEAP32[$3 + 4 >> 2] = 0;
     break label$2;
    }
    HEAP32[$8 + 8 >> 2] = 23197;
    HEAP32[$8 + 4 >> 2] = 1463;
    HEAP32[$8 >> 2] = 23060;
    printk(23029, $8);
    abort();
   }
   $7 = $2 & 2;
   if (!(HEAP32[$1 + 20 >> 2] != 2 ? !$7 : 0)) {
    $3 = $0 + 1008 | 0;
    $5 = $3;
    $9 = $1 + 200 | 0;
    $6 = HEAP32[$9 >> 2];
    $4 = $6 + HEAP32[$3 >> 2] | 0;
    $9 = HEAP32[$9 + 4 >> 2];
    $3 = $9 + HEAP32[$3 + 4 >> 2] | 0;
    HEAP32[$5 >> 2] = $4;
    HEAP32[$5 + 4 >> 2] = $4 >>> 0 < $6 >>> 0 ? $3 + 1 | 0 : $3;
    $3 = $0 + 1e3 | 0;
    $4 = $3;
    $11 = $3;
    $0 = HEAP32[$3 + 4 >> 2] + $9 | 0;
    $3 = HEAP32[$3 >> 2];
    $5 = $3 + $6 | 0;
    if ($5 >>> 0 < $3 >>> 0) {
     $0 = $0 + 1 | 0
    }
    HEAP32[$11 >> 2] = $5;
    HEAP32[$4 + 4 >> 2] = $0;
   }
   $0 = $2 & 32;
   $3 = HEAP8[$1 + 236 | 0] & 1;
   if (!($0 | !$3)) {
    if (!($2 & 1)) {
     break label$1
    }
    task_contending($10);
    break label$1;
   }
   $13 = HEAP32[$10 >> 2];
   label$8 : {
    if (($10 | 0) == ($13 | 0)) {
     label$10 : {
      label$11 : {
       label$12 : {
        label$13 : {
         if (!($2 & 1)) {
          if ($0) {
           break label$13
          }
          if (!$7) {
           break label$10
          }
          $0 = $1 + 224 | 0;
          $2 = HEAP32[$0 >> 2];
          $5 = HEAP32[$0 + 4 >> 2];
          $7 = HEAP32[3319];
          $0 = HEAP32[3318];
          $4 = $5 - ($7 + ($2 >>> 0 < $0 >>> 0) | 0) | 0;
          if ($3 | (($4 | 0) > -1 ? 1 : ($4 | 0) >= -1 ? ($2 - $0 >>> 0 <= 4294967295 ? 0 : 1) : 0)) {
           break label$10
          }
          $3 = $1 + 176 | 0;
          $4 = HEAP32[$3 + 4 >> 2];
          $2 = $1 + 216 | 0;
          HEAP32[$2 >> 2] = HEAP32[$3 >> 2];
          HEAP32[$2 + 4 >> 2] = $4;
          $3 = $1 + 184 | 0;
          $2 = $0 + HEAP32[$3 >> 2] | 0;
          $3 = $7 + HEAP32[$3 + 4 >> 2] | 0;
          $4 = $1 + 224 | 0;
          HEAP32[$4 >> 2] = $2;
          HEAP32[$4 + 4 >> 2] = $2 >>> 0 < $0 >>> 0 ? $3 + 1 | 0 : $3;
          break label$10;
         }
         task_contending($10);
         $0 = $1 + 184 | 0;
         $9 = HEAP32[$0 >> 2];
         $2 = HEAP32[$0 + 4 >> 2];
         $0 = $1 + 224 | 0;
         $3 = HEAP32[$0 >> 2];
         $14 = HEAP32[3319];
         $7 = HEAP32[3318];
         $4 = $7;
         $0 = HEAP32[$0 + 4 >> 2] - ($14 + ($3 >>> 0 < $4 >>> 0) | 0) | 0;
         $11 = $3 - $4 | 0;
         if (($0 | 0) < -1 ? 1 : ($0 | 0) <= -1 ? ($11 >>> 0 > 4294967295 ? 0 : 1) : 0) {
          break label$12
         }
         $4 = $1 + 176 | 0;
         $3 = HEAP32[$4 + 4 >> 2];
         $4 = HEAP32[$4 >> 2];
         $5 = __wasm_i64_mul(($3 & 1023) << 22 | $4 >>> 10, $3 >>> 10 | 0, ($0 & 1023) << 22 | $11 >>> 10, $0 >>> 10 | 0);
         $15 = i64toi32_i32$HIGH_BITS;
         $6 = $1 + 216 | 0;
         $12 = HEAP32[$6 + 4 >> 2];
         $6 = HEAP32[$6 >> 2];
         $6 = __wasm_i64_mul(($12 & 1023) << 22 | $6 >>> 10, $12 >> 10, ($2 & 1023) << 22 | $9 >>> 10, $2 >>> 10 | 0);
         $12 = $15 - (i64toi32_i32$HIGH_BITS + ($5 >>> 0 < $6 >>> 0) | 0) | 0;
         if (($12 | 0) > -1 ? 1 : ($12 | 0) >= -1 ? ($5 - $6 >>> 0 <= 4294967295 ? 0 : 1) : 0) {
          break label$10
         }
         $5 = $1 + 192 | 0;
         if (HEAP32[$5 >> 2] == ($9 | 0) & HEAP32[$5 + 4 >> 2] == ($2 | 0) | HEAPU8[$1 + 236 | 0] & 2) {
          break label$11
         }
         $2 = $1 + 208 | 0;
         $4 = __wasm_i64_mul(HEAP32[$2 >> 2], HEAP32[$2 + 4 >> 2], $11, $0);
         $2 = i64toi32_i32$HIGH_BITS;
         $0 = $2 >>> 20 | 0;
         $3 = $1 + 216 | 0;
         HEAP32[$3 >> 2] = ($2 & 1048575) << 12 | $4 >>> 20;
         HEAP32[$3 + 4 >> 2] = $0;
         break label$10;
        }
        replenish_dl_entity($10, $10);
        break label$10;
       }
       $0 = $1 + 176 | 0;
       $4 = HEAP32[$0 >> 2];
       $3 = HEAP32[$0 + 4 >> 2];
      }
      $0 = $1 + 216 | 0;
      HEAP32[$0 >> 2] = $4;
      HEAP32[$0 + 4 >> 2] = $3;
      $3 = $2 + $14 | 0;
      $2 = $7 + $9 | 0;
      if ($2 >>> 0 < $7 >>> 0) {
       $3 = $3 + 1 | 0
      }
      $0 = $1 + 224 | 0;
      HEAP32[$0 >> 2] = $2;
      HEAP32[$0 + 4 >> 2] = $3;
     }
     if (($13 | 0) != HEAP32[$10 >> 2]) {
      break label$8
     }
     $4 = 13176;
     $3 = 0;
     $0 = 1;
     $7 = $1 + 224 | 0;
     while (1) {
      $2 = HEAP32[$4 >> 2];
      if ($2) {
       $3 = HEAP32[$7 >> 2];
       $4 = $2 - -64 | 0;
       $5 = HEAP32[$4 >> 2];
       $6 = $3 - $5 >>> 0 >= 0 ? 0 : 1;
       $3 = HEAP32[$7 + 4 >> 2] - (HEAP32[$4 + 4 >> 2] + ($3 >>> 0 < $5 >>> 0) | 0) | 0;
       $4 = (($3 | 0) < 0 ? 1 : ($3 | 0) <= 0 ? $6 : 0) ? $2 + 8 | 0 : $2 + 4 | 0;
       $0 = $3 >> 31 & $0;
       $3 = $2;
       continue;
      }
      break;
     };
     $2 = $1 + 164 | 0;
     HEAP32[$2 >> 2] = 0;
     HEAP32[$2 + 4 >> 2] = 0;
     HEAP32[$1 + 160 >> 2] = $3;
     HEAP32[$4 >> 2] = $10;
     rb_insert_color_cached($10, 13176, ($0 | 0) != 0);
     HEAP32[3296] = HEAP32[3296] + 1;
     HEAP32[3052] = HEAP32[3052] + 1;
     global$0 = $8 + 48 | 0;
     return;
    }
    HEAP32[$8 + 40 >> 2] = 23213;
    HEAP32[$8 + 36 >> 2] = 1414;
    HEAP32[$8 + 32 >> 2] = 23060;
    printk(23029, $8 + 32 | 0);
    abort();
   }
   HEAP32[$8 + 24 >> 2] = 23231;
   HEAP32[$8 + 20 >> 2] = 1378;
   HEAP32[$8 + 16 >> 2] = 23060;
   printk(23029, $8 + 16 | 0);
   abort();
  }
  global$0 = $8 + 48 | 0;
 }

 function replenish_dl_entity($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0;
  $6 = global$0 - 16 | 0;
  global$0 = $6;
  $5 = HEAP32[$1 + 16 >> 2];
  $7 = HEAP32[$1 + 20 >> 2];
  label$1 : {
   label$2 : {
    if ($5 | $7) {
     if (!(HEAP32[$0 + 24 >> 2] != 0 | HEAP32[$0 + 28 >> 2] != 0)) {
      HEAP32[$0 + 56 >> 2] = $5;
      HEAP32[$0 + 60 >> 2] = $7;
      $2 = HEAP32[$1 + 28 >> 2] + HEAP32[3319] | 0;
      $3 = HEAP32[3318];
      $4 = $3 + HEAP32[$1 + 24 >> 2] | 0;
      if ($4 >>> 0 < $3 >>> 0) {
       $2 = $2 + 1 | 0
      }
      HEAP32[$0 + 64 >> 2] = $4;
      HEAP32[$0 + 68 >> 2] = $2;
     }
     $8 = HEAPU8[$0 + 76 | 0];
     $11 = $8 & 4;
     $3 = HEAP32[$0 + 56 >> 2];
     $2 = HEAP32[$0 + 60 >> 2];
     if (!(!$11 | (($2 | 0) < 0 ? 1 : ($2 | 0) <= 0 ? ($3 >>> 0 >= 1 ? 0 : 1) : 0))) {
      $3 = 0;
      $4 = $0 + 56 | 0;
      HEAP32[$4 >> 2] = 0;
      HEAP32[$4 + 4 >> 2] = 0;
      $2 = 0;
     }
     $9 = $0 + 56 | 0;
     $12 = $1 + 32 | 0;
     $4 = $0 - -64 | 0;
     while (1) {
      if (!(($2 | 0) > 0 ? 1 : ($2 | 0) >= 0 ? ($3 >>> 0 <= 0 ? 0 : 1) : 0)) {
       $2 = $2 + $7 | 0;
       $3 = $3 + $5 | 0;
       if ($3 >>> 0 < $5 >>> 0) {
        $2 = $2 + 1 | 0
       }
       HEAP32[$9 >> 2] = $3;
       HEAP32[$9 + 4 >> 2] = $2;
       $10 = HEAP32[$4 + 4 >> 2] + HEAP32[$12 + 4 >> 2] | 0;
       $13 = HEAP32[$12 >> 2];
       $14 = $13 + HEAP32[$4 >> 2] | 0;
       if ($14 >>> 0 < $13 >>> 0) {
        $10 = $10 + 1 | 0
       }
       HEAP32[$4 >> 2] = $14;
       HEAP32[$4 + 4 >> 2] = $10;
       continue;
      }
      break;
     };
     $2 = $0 - -64 | 0;
     $4 = HEAP32[$2 >> 2];
     $10 = HEAP32[$2 + 4 >> 2];
     $2 = HEAP32[3319];
     $3 = HEAP32[3318];
     $9 = $10 - ($2 + ($4 >>> 0 < $3 >>> 0) | 0) | 0;
     if (($9 | 0) > -1 ? 1 : ($9 | 0) >= -1 ? ($4 - $3 >>> 0 <= 4294967295 ? 0 : 1) : 0) {
      break label$1
     }
     if (HEAPU8[79432]) {
      break label$2
     }
     HEAP8[79432] = 1;
     printk_deferred(23160, 0);
     $8 = HEAPU8[$0 + 76 | 0];
     $11 = $8 & 4;
     $2 = $1 + 16 | 0;
     $5 = HEAP32[$2 >> 2];
     $7 = HEAP32[$2 + 4 >> 2];
     $3 = HEAP32[3318];
     $2 = HEAP32[3319];
     break label$2;
    }
    HEAP32[$6 + 8 >> 2] = 23140;
    HEAP32[$6 + 4 >> 2] = 672;
    HEAP32[$6 >> 2] = 23060;
    printk(23029, $6);
    abort();
   }
   $4 = $0 + 56 | 0;
   HEAP32[$4 >> 2] = $5;
   HEAP32[$4 + 4 >> 2] = $7;
   $2 = $2 + HEAP32[$1 + 28 >> 2] | 0;
   $1 = $3 + HEAP32[$1 + 24 >> 2] | 0;
   if ($1 >>> 0 < $3 >>> 0) {
    $2 = $2 + 1 | 0
   }
   $5 = $0 - -64 | 0;
   HEAP32[$5 >> 2] = $1;
   HEAP32[$5 + 4 >> 2] = $2;
  }
  $1 = $11 ? $8 & 251 : $8;
  if ($1 & 1 | $11) {
   HEAP8[$0 + 76 | 0] = $1 & 254
  }
  global$0 = $6 + 16 | 0;
 }

 function check_preempt_curr_dl($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0, $4 = 0;
  $2 = $1 + 224 | 0;
  $1 = HEAP32[$2 >> 2];
  $4 = HEAP32[$2 + 4 >> 2];
  $2 = HEAP32[$0 + 1036 >> 2] + 224 | 0;
  $3 = HEAP32[$2 >> 2];
  $2 = $4 - (($1 >>> 0 < $3 >>> 0) + HEAP32[$2 + 4 >> 2] | 0) | 0;
  if (!(($2 | 0) < -1 ? 1 : ($2 | 0) <= -1 ? ($1 - $3 >>> 0 > 4294967295 ? 0 : 1) : 0)) {
   return
  }
  resched_curr($0);
 }

 function inactive_task_timer($0) {
  $0 = $0 | 0;
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0;
  $7 = global$0 - 16 | 0;
  global$0 = $7;
  $6 = $0 + -288 | 0;
  $1 = task_rq_lock($6, $7 + 8 | 0);
  update_rq_clock($1);
  $4 = $0 + -128 | 0;
  label$1 : {
   if (!(HEAP32[$6 >> 2] != 128 ? HEAP32[$0 + -264 >> 2] <= -1 : 0)) {
    if (!(!(HEAPU8[$4 + 76 | 0] & 8) | HEAP32[$6 >> 2] != 128)) {
     $3 = HEAP32[3303];
     $1 = HEAP32[$4 + 44 >> 2];
     $2 = HEAP32[3302];
     $0 = HEAP32[$4 + 40 >> 2];
     $5 = ($3 | 0) == ($1 | 0) & $2 >>> 0 < $0 >>> 0 | $3 >>> 0 < $1 >>> 0;
     $2 = $5 ? $0 : $2;
     HEAP32[3302] = $2 - $0;
     HEAP32[3303] = ($5 ? $1 : $3) - (($2 >>> 0 < $0 >>> 0) + $1 | 0);
     $3 = HEAP32[3305];
     $2 = HEAP32[3304];
     $5 = ($3 | 0) == ($1 | 0) & $2 >>> 0 < $0 >>> 0 | $3 >>> 0 < $1 >>> 0;
     $2 = $5 ? $0 : $2;
     HEAP32[3304] = $2 - $0;
     HEAP32[3305] = ($5 ? $1 : $3) - (($2 >>> 0 < $0 >>> 0) + $1 | 0);
     $0 = $4 + 76 | 0;
     HEAP8[$0 | 0] = HEAPU8[$0 | 0] & 247;
    }
    $1 = HEAP32[3300];
    $3 = HEAP32[$4 + 40 >> 2];
    $2 = HEAP32[3301] - (HEAP32[$4 + 44 >> 2] + ($1 >>> 0 < $3 >>> 0) | 0) | 0;
    HEAP32[3300] = $1 - $3;
    HEAP32[3301] = $2;
    $0 = $3;
    $3 = $0 >> 31;
    $2 = $0;
    $1 = $0 + HEAP32[3306] | 0;
    $0 = $3 + HEAP32[3307] | 0;
    HEAP32[3306] = $1;
    HEAP32[3307] = $1 >>> 0 < $2 >>> 0 ? $0 + 1 | 0 : $0;
    __dl_clear_params($6);
    break label$1;
   }
   if (!(HEAPU8[$4 + 76 | 0] & 8)) {
    break label$1
   }
   $3 = $1 + 1e3 | 0;
   $1 = $3;
   $5 = HEAP32[$1 >> 2];
   $0 = HEAP32[$4 + 40 >> 2];
   $8 = $5;
   $2 = HEAP32[$1 + 4 >> 2];
   $1 = HEAP32[$4 + 44 >> 2];
   $5 = ($2 | 0) == ($1 | 0) & $5 >>> 0 < $0 >>> 0 | $2 >>> 0 < $1 >>> 0;
   $8 = $5 ? $0 : $8;
   HEAP32[$3 >> 2] = $8 - $0;
   HEAP32[$3 + 4 >> 2] = ($5 ? $1 : $2) - (($8 >>> 0 < $0 >>> 0) + $1 | 0);
   $0 = $4 + 76 | 0;
   HEAP8[$0 | 0] = HEAPU8[$0 | 0] & 247;
  }
  HEAP32[19859] = HEAP32[$7 + 8 >> 2];
  $1 = $4 + -152 | 0;
  $0 = HEAP32[$1 >> 2] + -1 | 0;
  HEAP32[$1 >> 2] = $0;
  if (!$0) {
   __put_task_struct($6)
  }
  global$0 = $7 + 16 | 0;
  return 0;
 }

 function __dl_clear_params($0) {
  var $1 = 0;
  HEAP32[$0 + 232 >> 2] = 0;
  $1 = $0 + 192 | 0;
  HEAP32[$1 >> 2] = 0;
  HEAP32[$1 + 4 >> 2] = 0;
  $1 = $0 + 184 | 0;
  HEAP32[$1 >> 2] = 0;
  HEAP32[$1 + 4 >> 2] = 0;
  $1 = $0 + 176 | 0;
  HEAP32[$1 >> 2] = 0;
  HEAP32[$1 + 4 >> 2] = 0;
  $1 = $0 + 208 | 0;
  HEAP32[$1 >> 2] = 0;
  HEAP32[$1 + 4 >> 2] = 0;
  $1 = $0 + 200 | 0;
  HEAP32[$1 >> 2] = 0;
  HEAP32[$1 + 4 >> 2] = 0;
  $0 = $0 + 236 | 0;
  HEAP8[$0 | 0] = HEAPU8[$0 | 0] & 226;
 }

 function start_dl_timer($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0, $15 = 0, $16 = 0;
  $5 = $0 + 184 | 0;
  $1 = HEAP32[$5 >> 2];
  $3 = HEAP32[$5 + 4 >> 2];
  $2 = $0 + 224 | 0;
  $5 = HEAP32[$2 >> 2];
  $9 = HEAP32[$2 + 4 >> 2];
  $2 = $0 + 192 | 0;
  $7 = HEAP32[$2 >> 2];
  $8 = HEAP32[$2 + 4 >> 2];
  $12 = FUNCTION_TABLE[HEAP32[HEAP32[$0 + 276 >> 2] + 28 >> 2]]() | 0;
  $14 = i64toi32_i32$HIGH_BITS;
  $2 = $7;
  $7 = $5 - $1 | 0;
  $2 = $2 + $7 | 0;
  $1 = ($9 - (($5 >>> 0 < $1 >>> 0) + $3 | 0) | 0) + $8 | 0;
  $9 = $2 >>> 0 < $7 >>> 0 ? $1 + 1 | 0 : $1;
  $13 = HEAP32[3319];
  $7 = $2;
  $8 = HEAP32[3318];
  $1 = $8;
  $5 = $9 - ($13 + ($2 >>> 0 < $1 >>> 0) | 0) | 0;
  $2 = $2 - $1 | 0;
  $15 = $2;
  $1 = $5;
  $6 = $1 >> 31;
  $3 = $1 >> 31;
  $1 = $1 + $6 | 0;
  $2 = $2 + $3 | 0;
  if ($2 >>> 0 < $3 >>> 0) {
   $1 = $1 + 1 | 0
  }
  $2 = $2 ^ $3;
  $3 = $1 ^ $6;
  $6 = $2;
  $4 = __wasm_i64_mul($2, 0, -1924145349, 0);
  $1 = i64toi32_i32$HIGH_BITS;
  $10 = $1;
  $1 = $1 + -2095944041 | 0;
  $2 = $4 + -1924145349 | 0;
  if ($2 >>> 0 < 2370821947) {
   $1 = $1 + 1 | 0
  }
  $11 = $2;
  $2 = $1;
  $1 = ($10 | 0) == ($1 | 0) & $11 >>> 0 < $4 >>> 0 | $1 >>> 0 < $10 >>> 0;
  $10 = $3;
  $4 = 0;
  $3 = __wasm_i64_mul($3, $4, -1924145349, 0);
  $2 = $3 + $2 | 0;
  $1 = i64toi32_i32$HIGH_BITS + $1 | 0;
  $1 = $2 >>> 0 < $3 >>> 0 ? $1 + 1 | 0 : $1;
  $4 = $2;
  $6 = __wasm_i64_mul($6, 0, -2095944041, 0);
  $2 = $2 + $6 | 0;
  $3 = $1;
  $1 = $1 + i64toi32_i32$HIGH_BITS | 0;
  $1 = $2 >>> 0 < $6 >>> 0 ? $1 + 1 | 0 : $1;
  $11 = $2;
  $2 = $1;
  $1 = ($3 | 0) == ($1 | 0) & $11 >>> 0 < $4 >>> 0 | $1 >>> 0 < $3 >>> 0;
  $6 = __wasm_i64_mul($10, 0, -2095944041, 0);
  $2 = $6 + $2 | 0;
  $4 = i64toi32_i32$HIGH_BITS + $1 | 0;
  $1 = $2;
  $4 = $1 >>> 0 < $6 >>> 0 ? $4 + 1 | 0 : $4;
  $1 = ($4 & 511) << 23 | $1 >>> 9;
  $2 = (0 - $1 & $15) >>> 0 >= 0 ? 0 : 1;
  $1 = 0 - (($4 >>> 9 | 0) + (0 < $1 >>> 0) | 0) & $5;
  label$1 : {
   if (($1 | 0) < 0 ? 1 : ($1 | 0) <= 0 ? $2 : 0) {
    break label$1
   }
   $16 = 1;
   if (HEAP8[$0 + 280 | 0] & 1) {
    break label$1
   }
   HEAP32[$0 + 8 >> 2] = HEAP32[$0 + 8 >> 2] + 1;
   $2 = $0 + 240 | 0;
   $1 = ($14 - (($12 >>> 0 < $8 >>> 0) + $13 | 0) | 0) + $9 | 0;
   $5 = $12 - $8 | 0;
   $0 = $5 + $7 | 0;
   if ($0 >>> 0 < $5 >>> 0) {
    $1 = $1 + 1 | 0
   }
   hrtimer_start_range_ns($2, $0, $1, 0, 0, 0);
  }
  return $16;
 }

 function task_contending($0) {
  var $1 = 0, $2 = 0;
  label$1 : {
   label$2 : {
    if (!(HEAP32[$0 + 16 >> 2] | HEAP32[$0 + 20 >> 2])) {
     break label$2
    }
    $1 = HEAPU8[$0 + 76 | 0];
    if (!($1 & 8)) {
     $1 = HEAP32[3303] + HEAP32[$0 + 44 >> 2] | 0;
     $0 = HEAP32[$0 + 40 >> 2];
     $2 = $0 + HEAP32[3302] | 0;
     if ($2 >>> 0 < $0 >>> 0) {
      $1 = $1 + 1 | 0
     }
     HEAP32[3302] = $2;
     HEAP32[3303] = $1;
     return;
    }
    HEAP8[$0 + 76 | 0] = $1 & 247;
    if ((hrtimer_try_to_cancel($0 + 128 | 0) | 0) != 1) {
     break label$2
    }
    $2 = $0 + -152 | 0;
    $1 = HEAP32[$2 >> 2] + -1 | 0;
    HEAP32[$2 >> 2] = $1;
    if (!$1) {
     break label$1
    }
   }
   return;
  }
  __put_task_struct($0 + -160 | 0);
 }

 function dequeue_task_dl($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0;
  update_curr_dl($0);
  __dequeue_task_dl($1);
  if (!(HEAP32[$1 + 20 >> 2] != 2 ? !($2 & 2) : 0)) {
   $8 = $0 + 1e3 | 0;
   $3 = $8;
   $5 = HEAP32[$3 >> 2];
   $4 = $1 + 200 | 0;
   $6 = HEAP32[$4 >> 2];
   $9 = $5;
   $7 = HEAP32[$3 + 4 >> 2];
   $4 = HEAP32[$4 + 4 >> 2];
   $5 = ($7 | 0) == ($4 | 0) & $5 >>> 0 < $6 >>> 0 | $7 >>> 0 < $4 >>> 0;
   $3 = $5 ? $6 : $9;
   HEAP32[$8 >> 2] = $3 - $6;
   HEAP32[$8 + 4 >> 2] = ($5 ? $4 : $7) - (($3 >>> 0 < $6 >>> 0) + $4 | 0);
   $7 = $0 + 1008 | 0;
   $0 = $7;
   $3 = HEAP32[$0 >> 2];
   $8 = $3;
   $5 = HEAP32[$0 + 4 >> 2];
   $3 = ($5 | 0) == ($4 | 0) & $3 >>> 0 < $6 >>> 0 | $5 >>> 0 < $4 >>> 0;
   $0 = $3 ? $6 : $8;
   HEAP32[$7 >> 2] = $0 - $6;
   HEAP32[$7 + 4 >> 2] = ($3 ? $4 : $5) - (($0 >>> 0 < $6 >>> 0) + $4 | 0);
  }
  if ($2 & 1) {
   task_non_contending($1)
  }
 }

 function update_curr_dl($0) {
  $0 = $0 | 0;
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0;
  label$1 : {
   $4 = HEAP32[$0 + 1036 >> 2];
   if (HEAP32[$4 + 24 >> 2] > -1) {
    break label$1
   }
   $5 = $4 + 160 | 0;
   if (HEAP32[$5 >> 2] == ($5 | 0)) {
    break label$1
   }
   label$2 : {
    label$3 : {
     label$4 : {
      $1 = $4 + 88 | 0;
      $5 = HEAP32[$1 >> 2];
      $2 = HEAP32[$0 + 1076 >> 2];
      $3 = HEAP32[$0 + 1072 >> 2];
      $8 = $2 - (HEAP32[$1 + 4 >> 2] + ($3 >>> 0 < $5 >>> 0) | 0) | 0;
      $5 = $3 - $5 | 0;
      if (!(($8 | 0) < 0 ? 1 : ($8 | 0) <= 0 ? ($5 >>> 0 > 0 ? 0 : 1) : 0)) {
       HEAP32[$1 >> 2] = $3;
       HEAP32[$1 + 4 >> 2] = $2;
       $1 = $4 + 96 | 0;
       $2 = $1;
       $12 = $1;
       $3 = $8 + HEAP32[$1 + 4 >> 2] | 0;
       $1 = $5 + HEAP32[$1 >> 2] | 0;
       if ($1 >>> 0 < $5 >>> 0) {
        $3 = $3 + 1 | 0
       }
       HEAP32[$12 >> 2] = $1;
       HEAP32[$2 + 4 >> 2] = $3;
       if (HEAPU8[$4 + 232 | 0] & 2) {
        break label$4
       }
       $3 = $8 & 4194303;
       $1 = $5;
       break label$3;
      }
      $2 = HEAPU8[$4 + 236 | 0];
      if (!($2 & 4)) {
       break label$1
      }
      $3 = $4 + 216 | 0;
      $1 = HEAP32[$3 >> 2];
      $3 = HEAP32[$3 + 4 >> 2];
      break label$2;
     }
     $1 = $0 + 1024 | 0;
     $3 = HEAP32[$1 >> 2];
     $2 = HEAP32[$1 + 4 >> 2];
     $1 = $4 + 200 | 0;
     $2 = __wasm_i64_mul($3, $2, HEAP32[$1 >> 2], HEAP32[$1 + 4 >> 2]);
     $1 = i64toi32_i32$HIGH_BITS;
     $3 = $1 >>> 8 | 0;
     $1 = ($1 & 255) << 24 | $2 >>> 8;
     $12 = $3;
     $6 = $0 + 1008 | 0;
     $7 = HEAP32[$6 >> 2];
     $9 = $0 + 1e3 | 0;
     $10 = HEAP32[$9 >> 2];
     $2 = $7 - $10 | 0;
     $11 = 1048576 - $2 | 0;
     $14 = $0 + 1016 | 0;
     $13 = HEAP32[$14 >> 2];
     $6 = HEAP32[$6 + 4 >> 2] - (HEAP32[$9 + 4 >> 2] + ($7 >>> 0 < $10 >>> 0) | 0) | 0;
     $7 = HEAP32[$14 + 4 >> 2];
     $9 = 0 - ($6 + (1048576 < $2 >>> 0) | 0) - ($7 + ($11 >>> 0 < $13 >>> 0)) | 0;
     $10 = $1;
     $11 = $11 - $13 | 0;
     $6 = $6 + $7 | 0;
     $7 = $2 + $13 | 0;
     if ($7 >>> 0 < $2 >>> 0) {
      $6 = $6 + 1 | 0
     }
     $2 = $7;
     $7 = 1048576 - $1 | 0;
     $1 = 0 - ((1048576 < $1 >>> 0) + $3 | 0) | 0;
     $1 = ($1 | 0) == ($6 | 0) & $2 >>> 0 > $7 >>> 0 | $6 >>> 0 > $1 >>> 0;
     $2 = __wasm_i64_mul($1 ? $10 : $11, $1 ? $12 : $9, $5, $8);
     $1 = i64toi32_i32$HIGH_BITS;
     $3 = $1 >>> 20 | 0;
     $1 = ($1 & 1048575) << 12 | $2 >>> 20;
    }
    $2 = $4 + 216 | 0;
    $6 = HEAP32[$2 >> 2];
    $3 = HEAP32[$2 + 4 >> 2] - (($6 >>> 0 < $1 >>> 0) + $3 | 0) | 0;
    $1 = $6 - $1 | 0;
    HEAP32[$2 >> 2] = $1;
    HEAP32[$2 + 4 >> 2] = $3;
    $2 = HEAPU8[$4 + 236 | 0];
   }
   label$6 : {
    label$7 : {
     label$8 : {
      if (!(($3 | 0) < 0 ? 1 : ($3 | 0) <= 0 ? ($1 >>> 0 >= 1 ? 0 : 1) : 0)) {
       $1 = 1;
       if ($2 & 4) {
        break label$8
       }
       break label$6;
      }
      HEAP8[$4 + 236 | 0] = $2 | 1;
      $1 = 17;
      if (!(HEAPU8[$4 + 232 | 0] & 4)) {
       break label$7
      }
     }
     HEAP8[$4 + 236 | 0] = $1 | $2;
    }
    __dequeue_task_dl($4);
    label$10 : {
     if (!(HEAPU8[$4 + 236 | 0] & 2)) {
      if (start_dl_timer($4)) {
       break label$10
      }
     }
     enqueue_task_dl($0, $4, 32);
    }
    if (HEAP32[$0 + 972 >> 2] == ($4 + 160 | 0)) {
     break label$6
    }
    resched_curr($0);
   }
   if (HEAP32[3051] < 0) {
    break label$1
   }
   if (sched_rt_bandwidth_account($0 + 120 | 0)) {
    $1 = $0 + 952 | 0;
    $3 = $1;
    $2 = $1;
    $0 = $8 + HEAP32[$1 + 4 >> 2] | 0;
    $1 = $5 + HEAP32[$1 >> 2] | 0;
    if ($1 >>> 0 < $5 >>> 0) {
     $0 = $0 + 1 | 0
    }
    HEAP32[$2 >> 2] = $1;
    HEAP32[$3 + 4 >> 2] = $0;
   }
  }
 }

 function __dequeue_task_dl($0) {
  var $1 = 0;
  $1 = HEAP32[$0 + 160 >> 2];
  $0 = $0 + 160 | 0;
  if (($1 | 0) != ($0 | 0)) {
   rb_erase_cached($0, 13176);
   HEAP32[3296] = HEAP32[3296] + -1;
   HEAP32[3052] = HEAP32[3052] + -1;
   HEAP32[$0 >> 2] = $0;
  }
 }

 function task_non_contending($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0;
  $6 = global$0 - 16 | 0;
  global$0 = $6;
  $1 = $0 + 176 | 0;
  label$1 : {
   if (!(HEAP32[$1 >> 2] | HEAP32[$1 + 4 >> 2])) {
    break label$1
   }
   $5 = $0 + 288 | 0;
   hrtimer_active($5);
   $4 = $0 + 224 | 0;
   $2 = HEAP32[$4 >> 2];
   $4 = HEAP32[$4 + 4 >> 2];
   $3 = $0 + 192 | 0;
   $7 = HEAP32[$3 >> 2];
   $8 = HEAP32[$3 + 4 >> 2];
   $3 = $0 + 216 | 0;
   $3 = div_s64_rem(__wasm_i64_mul($7, $8, HEAP32[$3 >> 2], HEAP32[$3 + 4 >> 2]), i64toi32_i32$HIGH_BITS, HEAP32[$1 >> 2], $6 + 12 | 0);
   $1 = $2 - $3 | 0;
   $2 = $4 - (i64toi32_i32$HIGH_BITS + ($2 >>> 0 < $3 >>> 0) | 0) | 0;
   $4 = HEAP32[3318];
   $2 = $2 - (HEAP32[3319] + ($1 >>> 0 < $4 >>> 0) | 0) | 0;
   $1 = $1 - $4 | 0;
   if (!(($2 | 0) < -1 ? 1 : ($2 | 0) <= -1 ? ($1 >>> 0 > 4294967295 ? 0 : 1) : 0)) {
    HEAP32[$0 + 8 >> 2] = HEAP32[$0 + 8 >> 2] + 1;
    $0 = $0 + 236 | 0;
    HEAP8[$0 | 0] = HEAPU8[$0 | 0] | 8;
    hrtimer_start_range_ns($5, $1, $2, 0, 0, 1);
    break label$1;
   }
   if (HEAP32[$0 + 24 >> 2] <= -1) {
    $1 = $0 + 200 | 0;
    $2 = HEAP32[$1 >> 2];
    $5 = HEAP32[3303];
    $1 = HEAP32[$1 + 4 >> 2];
    $3 = HEAP32[3302];
    $4 = ($5 | 0) == ($1 | 0) & $3 >>> 0 < $2 >>> 0 | $5 >>> 0 < $1 >>> 0;
    $3 = $4 ? $2 : $3;
    HEAP32[3302] = $3 - $2;
    HEAP32[3303] = ($4 ? $1 : $5) - (($3 >>> 0 < $2 >>> 0) + $1 | 0);
    if (HEAP32[$0 >> 2] != 128) {
     break label$1
    }
   }
   if (HEAP32[$0 >> 2] == 128) {
    $1 = $0 + 200 | 0;
    $2 = HEAP32[$1 >> 2];
    $5 = HEAP32[3305];
    $1 = HEAP32[$1 + 4 >> 2];
    $3 = HEAP32[3304];
    $4 = ($5 | 0) == ($1 | 0) & $3 >>> 0 < $2 >>> 0 | $5 >>> 0 < $1 >>> 0;
    $3 = $4 ? $2 : $3;
    HEAP32[3304] = $3 - $2;
    HEAP32[3305] = ($4 ? $1 : $5) - (($3 >>> 0 < $2 >>> 0) + $1 | 0);
   }
   $2 = $0 + 200 | 0;
   $5 = HEAP32[$2 >> 2];
   $1 = $5;
   $4 = HEAP32[3300];
   $3 = HEAP32[3301] - (HEAP32[$2 + 4 >> 2] + ($4 >>> 0 < $1 >>> 0) | 0) | 0;
   HEAP32[3300] = $4 - $1;
   HEAP32[3301] = $3;
   $5 = $1 >> 31;
   $3 = $1;
   $1 = $1 + HEAP32[3306] | 0;
   $2 = $5 + HEAP32[3307] | 0;
   HEAP32[3306] = $1;
   HEAP32[3307] = $1 >>> 0 < $3 >>> 0 ? $2 + 1 | 0 : $2;
   __dl_clear_params($0);
  }
  global$0 = $6 + 16 | 0;
 }

 function yield_task_dl($0) {
  $0 = $0 | 0;
  var $1 = 0;
  $1 = HEAP32[$0 + 1036 >> 2] + 236 | 0;
  HEAP8[$1 | 0] = HEAPU8[$1 | 0] | 4;
  update_rq_clock($0);
  update_curr_dl($0);
  HEAP32[$0 + 1056 >> 2] = HEAP32[$0 + 1056 >> 2] | 1;
 }

 function pick_next_task_dl($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0, $4 = 0;
  $2 = global$0 - 16 | 0;
  global$0 = $2;
  if (HEAP32[$1 + 40 >> 2] == 23072) {
   update_curr_dl($0)
  }
  label$2 : {
   label$3 : {
    if (HEAP32[$0 + 976 >> 2]) {
     FUNCTION_TABLE[HEAP32[HEAP32[$1 + 40 >> 2] + 28 >> 2]]($0, $1);
     $1 = HEAP32[$0 + 972 >> 2];
     if (!$1) {
      break label$3
     }
     $4 = HEAP32[$0 + 1076 >> 2];
     $3 = $1 + -72 | 0;
     HEAP32[$3 >> 2] = HEAP32[$0 + 1072 >> 2];
     HEAP32[$3 + 4 >> 2] = $4;
     $0 = $1 + -160 | 0;
     break label$2;
    }
    $0 = 0;
    break label$2;
   }
   HEAP32[$2 + 8 >> 2] = 23251;
   HEAP32[$2 + 4 >> 2] = 1750;
   HEAP32[$2 >> 2] = 23060;
   printk(23029, $2);
   abort();
  }
  global$0 = $2 + 16 | 0;
  return $0 | 0;
 }

 function put_prev_task_dl($0, $1) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  update_curr_dl($0);
 }

 function task_tick_dl($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  update_curr_dl($0);
 }

 function switched_from_dl($0, $1) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  label$1 : {
   if (HEAP32[$1 + 20 >> 2] == 1) {
    $3 = $1 + 176 | 0;
    if (!(HEAP32[$3 >> 2] | HEAP32[$3 + 4 >> 2])) {
     break label$1
    }
    task_non_contending($1);
    if (HEAP32[$1 + 20 >> 2] == 1) {
     break label$1
    }
   }
   $4 = $1 + 200 | 0;
   $3 = HEAP32[$4 >> 2];
   $4 = HEAP32[$4 + 4 >> 2];
   if (HEAPU8[$1 + 236 | 0] & 8) {
    $5 = $0 + 1e3 | 0;
    $2 = HEAP32[$5 >> 2];
    $6 = $2;
    $7 = HEAP32[$5 + 4 >> 2];
    $2 = ($4 | 0) == ($7 | 0) & $2 >>> 0 < $3 >>> 0 | $7 >>> 0 < $4 >>> 0;
    $6 = $2 ? $3 : $6;
    HEAP32[$5 >> 2] = $6 - $3;
    HEAP32[$5 + 4 >> 2] = ($2 ? $4 : $7) - (($6 >>> 0 < $3 >>> 0) + $4 | 0);
   }
   $0 = $0 + 1008 | 0;
   $2 = $0;
   $5 = HEAP32[$2 >> 2];
   $6 = $5;
   $2 = HEAP32[$2 + 4 >> 2];
   $5 = ($4 | 0) == ($2 | 0) & $5 >>> 0 < $3 >>> 0 | $2 >>> 0 < $4 >>> 0;
   $7 = $5 ? $3 : $6;
   HEAP32[$0 >> 2] = $7 - $3;
   HEAP32[$0 + 4 >> 2] = ($5 ? $4 : $2) - (($7 >>> 0 < $3 >>> 0) + $4 | 0);
  }
  $0 = $1 + 236 | 0;
  $1 = HEAPU8[$0 | 0];
  if ($1 & 8) {
   HEAP8[$0 | 0] = $1 & 247
  }
 }

 function switched_to_dl($0, $1) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  var $2 = 0, $3 = 0, $4 = 0;
  label$1 : {
   if ((hrtimer_try_to_cancel($1 + 288 | 0) | 0) != 1) {
    break label$1
   }
   $2 = HEAP32[$1 + 8 >> 2] + -1 | 0;
   HEAP32[$1 + 8 >> 2] = $2;
   if ($2) {
    break label$1
   }
   __put_task_struct($1);
  }
  label$2 : {
   if (HEAP32[$1 + 20 >> 2] == 1) {
    $2 = HEAP32[$0 + 1036 >> 2];
    if (($1 | 0) != ($2 | 0)) {
     if (HEAP32[$2 + 24 >> 2] <= -1) {
      break label$2
     }
     resched_curr($0);
    }
    return;
   }
   $0 = $0 + 1008 | 0;
   $2 = $0;
   $3 = $1 + 200 | 0;
   $4 = HEAP32[$3 >> 2];
   $1 = $4 + HEAP32[$0 >> 2] | 0;
   $0 = HEAP32[$0 + 4 >> 2] + HEAP32[$3 + 4 >> 2] | 0;
   HEAP32[$2 >> 2] = $1;
   HEAP32[$2 + 4 >> 2] = $1 >>> 0 < $4 >>> 0 ? $0 + 1 | 0 : $0;
   return;
  }
  check_preempt_curr_dl($0, $1, 0);
 }

 function prio_changed_dl($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  if (!(HEAP32[$1 + 20 >> 2] == 1 | HEAP32[$0 + 1036 >> 2] == ($1 | 0))) {
   return
  }
  resched_curr($0);
 }

 function __init_waitqueue_head($0) {
  HEAP32[$0 + 4 >> 2] = $0;
  HEAP32[$0 >> 2] = $0;
 }

 function __wake_up($0, $1, $2) {
  __wake_up_common_lock($0, $1, $2);
 }

 function __wake_up_common_lock($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0;
  $3 = global$0 - 32 | 0;
  global$0 = $3;
  $4 = $3 + 20 | 0;
  HEAP32[$3 + 24 >> 2] = $4;
  HEAP32[$3 + 16 >> 2] = 0;
  HEAP32[$3 + 8 >> 2] = 0;
  HEAP32[$3 + 12 >> 2] = 0;
  HEAP32[$3 + 20 >> 2] = $4;
  $5 = HEAPU8[79440];
  HEAP8[79440] = 0;
  $4 = __wake_up_common($0, $1, 1, $2, $3 + 8 | 0);
  HEAP8[79440] = $5 & 1;
  while (1) {
   if (HEAPU8[$3 + 8 | 0] & 4) {
    $5 = HEAPU8[79440];
    HEAP8[79440] = 0;
    $4 = __wake_up_common($0, $1, $4, $2, $3 + 8 | 0);
    HEAP8[79440] = $5 & 1;
    continue;
   }
   break;
  };
  global$0 = $3 + 32 | 0;
 }

 function __wake_up_common($0, $1, $2, $3, $4) {
  var $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0;
  label$1 : {
   if (!(HEAPU8[$4 | 0] & 4 ? !!$4 : 0)) {
    $6 = HEAP32[$0 >> 2];
    break label$1;
   }
   $7 = $4 + 16 | 0;
   $5 = HEAP32[$7 >> 2];
   $6 = HEAP32[$4 + 12 >> 2];
   HEAP32[$5 >> 2] = $6;
   HEAP32[$6 + 4 >> 2] = $5;
   HEAP32[$4 + 12 >> 2] = 256;
   HEAP32[$4 >> 2] = 0;
   HEAP32[$7 >> 2] = 512;
  }
  label$4 : {
   label$5 : {
    if (($0 | 0) == ($6 | 0)) {
     break label$5
    }
    $7 = 0;
    while (1) {
     $5 = $6;
     if (($5 | 0) == ($0 | 0)) {
      break label$5
     }
     $6 = HEAP32[$5 >> 2];
     $9 = $5 + -12 | 0;
     $8 = HEAP32[$9 >> 2];
     if ($8 & 4) {
      continue
     }
     $5 = FUNCTION_TABLE[HEAP32[$5 + -4 >> 2]]($9, $1, 0, $3) | 0;
     if (($5 | 0) < 0) {
      break label$5
     }
     if (!(!($8 & 1) | !$5)) {
      $2 = $2 + -1 | 0;
      if (!$2) {
       break label$4
      }
     }
     if (!$4) {
      continue
     }
     $8 = $7 >>> 0 < 64;
     $5 = $7 + 1 | 0;
     $7 = $5;
     if ($8) {
      continue
     }
     $7 = $5;
     if (($0 | 0) == ($6 | 0)) {
      continue
     }
     break;
    };
    HEAP32[$4 >> 2] = 4;
    $1 = HEAP32[$6 + 4 >> 2];
    $0 = $4 + 12 | 0;
    HEAP32[$6 + 4 >> 2] = $0;
    HEAP32[$4 + 12 >> 2] = $6;
    HEAP32[$1 >> 2] = $0;
    HEAP32[$4 + 16 >> 2] = $1;
   }
   return $2;
  }
  return 0;
 }

 function __wake_up_locked_key_bookmark($0, $1, $2) {
  __wake_up_common($0, 3, 1, $1, $2);
 }

 function prepare_to_wait($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  HEAP32[$0 >> 2] = HEAP32[$0 >> 2] & -2;
  $3 = HEAPU8[79440];
  HEAP8[79440] = 0;
  $1 = $0 + 12 | 0;
  if (($1 | 0) == HEAP32[$0 + 12 >> 2]) {
   $2 = HEAP32[4128];
   HEAP32[$2 + 4 >> 2] = $1;
   HEAP32[$1 >> 2] = $2;
   HEAP32[4128] = $1;
   HEAP32[$0 + 16 >> 2] = 16512;
  }
  HEAP32[(global$0 - 16 | 0) + 12 >> 2] = 2;
  HEAP32[HEAP32[2] >> 2] = 2;
  HEAP8[79440] = $3 & 1;
 }

 function init_wait_entry($0) {
  var $1 = 0;
  HEAP32[$0 >> 2] = 0;
  HEAP32[$0 + 8 >> 2] = 76;
  $1 = $0 + 12 | 0;
  HEAP32[$0 + 12 >> 2] = $1;
  HEAP32[$0 + 4 >> 2] = HEAP32[2];
  HEAP32[$0 + 16 >> 2] = $1;
 }

 function autoremove_wake_function($0, $1, $2, $3) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  $3 = $3 | 0;
  var $4 = 0;
  $1 = default_wake_function($0, $1, $2, $3);
  if ($1) {
   $2 = $0 + 16 | 0;
   $3 = HEAP32[$2 >> 2];
   $4 = HEAP32[$0 + 12 >> 2];
   HEAP32[$3 >> 2] = $4;
   HEAP32[$4 + 4 >> 2] = $3;
   $3 = $0;
   $0 = $0 + 12 | 0;
   HEAP32[$3 + 12 >> 2] = $0;
   HEAP32[$2 >> 2] = $0;
  }
  return $1 | 0;
 }

 function prepare_to_wait_event($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0;
  $7 = global$0 - 16 | 0;
  $8 = HEAPU8[79440];
  HEAP8[79440] = 0;
  label$1 : {
   label$2 : {
    label$3 : {
     if ($2 & 257) {
      $4 = HEAP32[2];
      if (HEAP32[HEAP32[$4 + 4 >> 2] >> 2] & 4) {
       break label$3
      }
     }
     $3 = $1 + 12 | 0;
     break label$2;
    }
    label$5 : {
     if (!($2 & 1)) {
      $3 = $1 + 12 | 0;
      if (!(HEAP8[$4 + 761 | 0] & 1)) {
       break label$2
      }
      break label$5;
     }
     $3 = $1 + 12 | 0;
    }
    $0 = HEAP32[$1 + 12 >> 2];
    $1 = $1 + 16 | 0;
    $2 = HEAP32[$1 >> 2];
    HEAP32[$0 + 4 >> 2] = $2;
    HEAP32[$2 >> 2] = $0;
    HEAP32[$1 >> 2] = $3;
    HEAP32[$3 >> 2] = $3;
    $3 = -512;
    break label$1;
   }
   if (($3 | 0) == HEAP32[$3 >> 2]) {
    label$8 : {
     if (!(HEAP8[$1 | 0] & 1)) {
      $5 = HEAP32[$0 >> 2];
      $6 = $5 + 4 | 0;
      break label$8;
     }
     $6 = $0 + 4 | 0;
     $5 = $0;
     $0 = HEAP32[$0 + 4 >> 2];
    }
    $4 = $0;
    HEAP32[$6 >> 2] = $3;
    HEAP32[$1 + 12 >> 2] = $5;
    HEAP32[$4 >> 2] = $3;
    HEAP32[$1 + 16 >> 2] = $4;
   }
   HEAP32[$7 + 12 >> 2] = $2;
   HEAP32[HEAP32[2] >> 2] = $2;
   $3 = 0;
  }
  HEAP8[79440] = $8 & 1;
  return $3;
 }

 function finish_wait($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0;
  HEAP32[HEAP32[2] >> 2] = 0;
  $1 = $0 + 12 | 0;
  if (!(HEAP32[$0 + 16 >> 2] == ($1 | 0) ? ($1 | 0) == HEAP32[$0 + 12 >> 2] : 0)) {
   $5 = HEAPU8[79440];
   HEAP8[79440] = 0;
   $2 = $0 + 16 | 0;
   $3 = HEAP32[$2 >> 2];
   $4 = HEAP32[$0 + 12 >> 2];
   HEAP32[$3 >> 2] = $4;
   HEAP32[$4 + 4 >> 2] = $3;
   HEAP32[$0 + 12 >> 2] = $1;
   HEAP32[$2 >> 2] = $1;
   HEAP8[79440] = $5 & 1;
  }
 }

 function __wake_up_bit($0, $1) {
  var $2 = 0;
  $2 = global$0 - 16 | 0;
  global$0 = $2;
  HEAP32[$2 + 8 >> 2] = 0;
  HEAP32[$2 + 4 >> 2] = 21;
  HEAP32[$2 >> 2] = $1;
  if (($0 | 0) != HEAP32[$0 >> 2]) {
   __wake_up($0, 3, $2)
  }
  global$0 = $2 + 16 | 0;
 }

 function wait_bit_init() {
  var $0 = 0;
  while (1) {
   if (!(($0 | 0) == 2048)) {
    __init_waitqueue_head($0 + 13568 | 0);
    $0 = $0 + 8 | 0;
    continue;
   }
   break;
  };
 }

 function complete($0) {
  var $1 = 0, $2 = 0;
  $2 = HEAPU8[79444];
  HEAP8[79444] = 0;
  $1 = HEAP32[$0 >> 2];
  if (($1 | 0) != -1) {
   HEAP32[$0 >> 2] = $1 + 1
  }
  __wake_up_common($0 + 4 | 0, 3, 1, 0, 0);
  HEAP8[79444] = $2 & 1;
 }

 function wait_for_common($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0;
  $3 = 2147483647;
  $2 = global$0 - 32 | 0;
  global$0 = $2;
  HEAP8[79444] = 0;
  $1 = HEAP32[$0 >> 2];
  label$1 : {
   if (!$1) {
    $1 = $0 + 8 | 0;
    $4 = HEAP32[$1 >> 2];
    HEAP32[$2 + 8 >> 2] = 1;
    $5 = $2 + 20 | 0;
    HEAP32[$4 >> 2] = $5;
    HEAP32[$1 >> 2] = $5;
    HEAP32[$2 + 24 >> 2] = $4;
    HEAP32[$2 + 16 >> 2] = 77;
    HEAP32[$2 + 12 >> 2] = HEAP32[2];
    HEAP32[$2 + 20 >> 2] = $0 + 4;
    while (1) {
     label$4 : {
      $1 = HEAP32[2];
      if (HEAP8[$1 + 761 | 0] & 1 ? !(!(HEAP32[HEAP32[$1 + 4 >> 2] >> 2] & 4) | 1) : 0) {
       break label$4
      }
      HEAP32[$1 >> 2] = 2;
      HEAP8[79444] = 1;
      $3 = schedule_timeout($3);
      HEAP8[79444] = 0;
      if ($3) {
       if (!HEAP32[$0 >> 2]) {
        continue
       }
      }
     }
     break;
    };
    $3 = HEAP32[$2 + 24 >> 2];
    $1 = HEAP32[$2 + 20 >> 2];
    HEAP32[$3 >> 2] = $1;
    HEAP32[$1 + 4 >> 2] = $3;
    $1 = HEAP32[$0 >> 2];
    if (!$1) {
     break label$1
    }
   }
   if (($1 | 0) != -1) {
    HEAP32[$0 >> 2] = $1 + -1
   }
  }
  HEAP8[79444] = 1;
  global$0 = $2 + 32 | 0;
 }

 function __kmalloc($0, $1) {
  var $2 = 0, $3 = 0;
  $1 = HEAP32[4221] & $1;
  label$1 : {
   label$2 : {
    if ($0 >>> 0 <= 65407) {
     if (!$0) {
      break label$2
     }
     $1 = slob_alloc($0 + 128 | 0, $1, 128);
     if (!$1) {
      break label$1
     }
     HEAP32[$1 >> 2] = $0;
     return $1 + 128 | 0;
    }
    label$4 : {
     label$5 : {
      $0 = $0 + -1 | 0;
      if ($0 >>> 0 < 65536) {
       break label$5
      }
      $0 = $0 & -65536;
      $2 = $0 >>> 0 > 16777215;
      $3 = $2 ? 16 : 8;
      $0 = $2 ? $0 : $0 << 8;
      $2 = $0 >>> 0 > 268435455;
      $3 = $2 ? $3 : $3 + -4 | 0;
      $0 = $2 ? $0 : $0 << 4;
      $2 = $0 >>> 0 > 1073741823;
      $0 = ($2 ? $3 : $3 + -2 | 0) + (($2 ? $0 : $0 << 2) >> 31 ^ -1) | 0;
      if (!$0) {
       break label$5
      }
      $1 = $1 | 16384;
      break label$4;
     }
     $0 = 0;
    }
    return slob_new_pages($1, $0);
   }
   return 16;
  }
  return 0;
 }

 function slob_alloc($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0;
  $7 = global$0 - 16 | 0;
  global$0 = $7;
  $3 = 15660;
  $6 = 15660;
  if ($0 >>> 0 >= 256) {
   $3 = $0 >>> 0 < 1024 ? 15668 : 15676;
   $6 = $3;
  }
  $8 = $0 + 3 >>> 2 | 0;
  label$2 : {
   label$3 : {
    label$4 : {
     label$5 : {
      while (1) {
       $3 = HEAP32[$3 >> 2];
       if (($6 | 0) == ($3 | 0)) {
        break label$5
       }
       if (HEAPU32[$3 + 20 >> 2] < $8 >>> 0) {
        continue
       }
       $5 = HEAP32[$3 + 4 >> 2];
       $4 = slob_page_alloc($3 + -4 | 0, $0, $2);
       if (!$4) {
        continue
       }
       break;
      };
      $3 = HEAP32[$6 + 4 >> 2];
      label$7 : {
       if (($3 | 0) == ($5 | 0)) {
        break label$7
       }
       $8 = HEAP32[$6 >> 2];
       $2 = HEAP32[$5 >> 2];
       if (($8 | 0) == ($2 | 0)) {
        break label$7
       }
       HEAP32[$8 + 4 >> 2] = $3;
       HEAP32[$3 >> 2] = $8;
       $3 = HEAP32[$2 + 4 >> 2];
       HEAP32[$2 + 4 >> 2] = $6;
       HEAP32[$6 >> 2] = $2;
       HEAP32[$3 >> 2] = $6;
       HEAP32[$6 + 4 >> 2] = $3;
      }
      break label$4;
     }
     $4 = 0;
     $5 = slob_new_pages($1 & -32769, 0);
     if (!$5) {
      break label$2
     }
     $3 = HEAP32[20650] + Math_imul($5 >>> 16 | 0, 36) | 0;
     $4 = HEAP32[$3 + 4 >> 2];
     $4 = $4 & 1 ? $4 + -1 | 0 : $3;
     HEAP32[$4 >> 2] = HEAP32[$4 >> 2] | 512;
     $4 = $3 + 4 | 0;
     HEAP32[$3 + 8 >> 2] = $4;
     HEAP32[$3 + 16 >> 2] = $5;
     HEAP32[$3 + 24 >> 2] = 16384;
     HEAP32[$3 + 4 >> 2] = $4;
     HEAP32[$5 >> 2] = 16384;
     HEAP32[$5 + 4 >> 2] = ($5 + 65536 | 0) - ($5 & -65536) >> 2;
     set_slob_page_free($3, $6);
     $4 = slob_page_alloc($3, $0, $2);
     if (!$4) {
      break label$3
     }
    }
    if (!($1 & 32768)) {
     break label$2
    }
    memset($4, 0, $0);
    break label$2;
   }
   HEAP32[$7 + 8 >> 2] = 23337;
   HEAP32[$7 + 4 >> 2] = 330;
   HEAP32[$7 >> 2] = 23319;
   printk(23288, $7);
   abort();
  }
  global$0 = $7 + 16 | 0;
  return $4;
 }

 function slob_new_pages($0, $1) {
  $0 = __alloc_pages_nodemask($0, $1);
  if ($0) {
   $0 = HEAP32[$0 + 32 >> 2]
  } else {
   $0 = 0
  }
  return $0;
 }

 function kfree($0) {
  var $1 = 0, $2 = 0;
  label$1 : {
   if ($0 >>> 0 >= 17) {
    $1 = HEAP32[20650] + Math_imul($0 >>> 16 | 0, 36) | 0;
    $2 = HEAP32[$1 + 4 >> 2];
    if (HEAP32[($2 & 1 ? $2 + -1 | 0 : $1) >> 2] & 512) {
     break label$1
    }
    __free_pages($1, HEAP32[$1 >> 2] & 65536 ? HEAPU8[$1 + 45 | 0] : 0);
   }
   return;
  }
  $0 = $0 + -128 | 0;
  slob_free($0, HEAP32[$0 >> 2] + 128 | 0);
 }

 function slob_free($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0;
  $6 = global$0 - 16 | 0;
  global$0 = $6;
  label$1 : {
   label$2 : {
    if ($0 >>> 0 < 17) {
     break label$2
    }
    if (!$1) {
     break label$1
    }
    $5 = HEAP32[20650];
    $2 = $0 >>> 16 | 0;
    $3 = $5 + Math_imul($2, 36) | 0;
    $7 = HEAP32[$3 + 4 >> 2];
    $10 = HEAP32[($7 & 1 ? $7 + -1 | 0 : $3) >> 2] & 8192;
    $8 = $3 + 24 | 0;
    $9 = $1 + 3 | 0;
    $4 = $9 >>> 2 | 0;
    $11 = $4 + HEAP32[$3 + 24 >> 2] | 0;
    if (($11 | 0) == 16384) {
     $1 = $3 + 4 | 0;
     if ($10) {
      $2 = $5 + Math_imul($2, 36) | 0;
      $4 = $2 + 8 | 0;
      $5 = HEAP32[$4 >> 2];
      HEAP32[$7 + 4 >> 2] = $5;
      HEAP32[$2 + 4 >> 2] = 256;
      HEAP32[$5 >> 2] = $7;
      HEAP32[$4 >> 2] = 512;
      $2 = HEAP32[$1 >> 2];
      $2 = $2 & 1 ? $2 + -1 | 0 : $3;
      HEAP32[$2 >> 2] = HEAP32[$2 >> 2] & -8193;
     }
     $1 = HEAP32[$1 >> 2];
     HEAP32[$8 >> 2] = -1;
     $1 = $1 & 1 ? $1 + -1 | 0 : $3;
     HEAP32[$1 >> 2] = HEAP32[$1 >> 2] & -513;
     slob_free_pages($0, 0);
     break label$2;
    }
    label$5 : {
     label$6 : {
      label$7 : {
       label$8 : {
        label$9 : {
         label$10 : {
          label$11 : {
           label$12 : {
            label$13 : {
             label$14 : {
              label$15 : {
               if ($10) {
                HEAP32[$8 >> 2] = $11;
                $3 = ($5 + Math_imul($2, 36) | 0) + 16 | 0;
                $2 = HEAP32[$3 >> 2];
                if ($2 >>> 0 <= $0 >>> 0) {
                 break label$15
                }
                if ((($4 << 2) + $0 | 0) != ($2 | 0)) {
                 break label$8
                }
                $5 = $2 & -65536;
                $1 = HEAP32[$2 >> 2];
                $7 = ($1 | 0) > 1 ? $1 : 1;
                if (($1 | 0) <= -1) {
                 break label$10
                }
                $1 = HEAP32[$2 + 4 >> 2];
                break label$9;
               }
               HEAP32[$8 >> 2] = $4;
               HEAP32[($5 + Math_imul($2, 36) | 0) + 16 >> 2] = $0;
               $2 = ($0 + 65536 & -65536) - ($0 & -65536) >> 2;
               if ($9 >>> 0 < 8) {
                break label$14
               }
               HEAP32[$0 + 4 >> 2] = $2;
               break label$13;
              }
              $3 = $2 & -65536;
              $1 = HEAP32[$2 >> 2];
              if (($1 | 0) <= -1) {
               break label$12
              }
              $1 = HEAP32[$2 + 4 >> 2];
              break label$11;
             }
             $4 = 0 - $2 | 0;
            }
            HEAP32[$0 >> 2] = $4;
            set_slob_page_free($3, ($1 | 0) < 256 ? 15660 : ($1 | 0) < 1024 ? 15668 : 15676);
            break label$5;
           }
           $1 = 0 - $1 | 0;
          }
          $1 = ($1 << 2) + $3 | 0;
          while (1) {
           $3 = $1;
           if (!($1 >>> 0 >= $0 >>> 0)) {
            $1 = $3 & -65536;
            $2 = HEAP32[$3 >> 2];
            $5 = HEAP32[$3 + 4 >> 2];
            label$19 : {
             if (($2 | 0) > -1) {
              break label$19
             }
             $5 = 0 - $2 | 0;
            }
            $1 = $1 + ($5 << 2) | 0;
            $2 = $3;
            continue;
           }
           break;
          };
          label$21 : {
           label$22 : {
            label$23 : {
             if (!(slob_last($2) | ($3 | 0) != (($4 << 2) + $0 | 0))) {
              $5 = $3 & -65536;
              $1 = HEAP32[$3 >> 2];
              $4 = (($1 | 0) > 1 ? $1 : 1) + $4 | 0;
              if (($1 | 0) <= -1) {
               break label$23
              }
              $1 = HEAP32[$3 + 4 >> 2];
              break label$22;
             }
             $1 = $3 - ($0 & -65536) >> 2;
             if ($9 >>> 0 >= 8) {
              HEAP32[$0 + 4 >> 2] = $1;
              break label$21;
             }
             $4 = 0 - $1 | 0;
             break label$21;
            }
            $1 = 0 - $1 | 0;
           }
           $1 = (($1 << 2) + $5 | 0) - ($0 & -65536) >> 2;
           if (($4 | 0) >= 2) {
            HEAP32[$0 + 4 >> 2] = $1;
            break label$21;
           }
           $4 = 0 - $1 | 0;
          }
          HEAP32[$0 >> 2] = $4;
          label$27 : {
           label$28 : {
            $1 = HEAP32[$2 >> 2];
            $3 = ($1 | 0) > 1 ? $1 : 1;
            if (($0 | 0) != (($3 << 2) + $2 | 0)) {
             $0 = $0 - ($2 & -65536) >> 2;
             if (($1 | 0) < 2) {
              break label$28
             }
             HEAP32[$2 + 4 >> 2] = $0;
             break label$27;
            }
            $5 = $0 & -65536;
            $1 = $3 + (($4 | 0) > 1 ? $4 : 1) | 0;
            if (($4 | 0) <= -1) {
             break label$7
            }
            $0 = HEAP32[$0 + 4 >> 2];
            break label$6;
           }
           $1 = 0 - $0 | 0;
          }
          HEAP32[$2 >> 2] = $1;
          break label$5;
         }
         $1 = 0 - $1 | 0;
        }
        $4 = $4 + $7 | 0;
        $2 = $5 + ($1 << 2) | 0;
        HEAP32[$3 >> 2] = $2;
       }
       $1 = $2 - ($0 & -65536) >> 2;
       label$30 : {
        if (($4 | 0) >= 2) {
         HEAP32[$0 + 4 >> 2] = $1;
         break label$30;
        }
        $4 = 0 - $1 | 0;
       }
       HEAP32[$0 >> 2] = $4;
       HEAP32[$3 >> 2] = $0;
       break label$5;
      }
      $0 = 0 - $4 | 0;
     }
     $0 = (($0 << 2) + $5 | 0) - ($2 & -65536) >> 2;
     label$32 : {
      if (($1 | 0) >= 2) {
       HEAP32[$2 + 4 >> 2] = $0;
       break label$32;
      }
      $1 = 0 - $0 | 0;
     }
     HEAP32[$2 >> 2] = $1;
    }
   }
   global$0 = $6 + 16 | 0;
   return;
  }
  HEAP32[$6 + 8 >> 2] = 23348;
  HEAP32[$6 + 4 >> 2] = 351;
  HEAP32[$6 >> 2] = 23319;
  printk(23288, $6);
  abort();
 }

 function slob_free_pages($0, $1) {
  var $2 = 0;
  $2 = HEAP32[HEAP32[2] + 804 >> 2];
  if ($2) {
   HEAP32[$2 >> 2] = HEAP32[$2 >> 2] + (1 << $1)
  }
  free_pages($0, $1);
 }

 function set_slob_page_free($0, $1) {
  var $2 = 0, $3 = 0;
  $2 = HEAP32[$1 >> 2];
  $3 = $0 + 4 | 0;
  HEAP32[$2 + 4 >> 2] = $3;
  HEAP32[$0 + 4 >> 2] = $2;
  HEAP32[$1 >> 2] = $3;
  HEAP32[$0 + 8 >> 2] = $1;
  $1 = HEAP32[$0 + 4 >> 2];
  $0 = $1 & 1 ? $1 + -1 | 0 : $0;
  HEAP32[$0 >> 2] = HEAP32[$0 >> 2] | 8192;
 }

 function slob_last($0) {
  var $1 = 0, $2 = 0;
  $2 = $0 & -65536;
  $1 = HEAP32[$0 >> 2];
  $0 = HEAP32[$0 + 4 >> 2];
  label$1 : {
   if (($1 | 0) > -1) {
    break label$1
   }
   $0 = 0 - $1 | 0;
  }
  return !($2 + ($0 << 2) & 65532);
 }

 function kmem_cache_alloc($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0;
  $1 = HEAP32[4221] & $1;
  $2 = HEAP32[$0 + 4 >> 2];
  label$1 : {
   label$2 : {
    if ($2 >>> 0 <= 65535) {
     $1 = slob_alloc($2, $1, HEAP32[$0 + 8 >> 2]);
     if ($1) {
      break label$2
     }
     break label$1;
    }
    $4 = $1;
    $2 = $2 + -1 | 0;
    if ($2 >>> 0 >= 65536) {
     $3 = $2 & -65536;
     $2 = $3 >>> 0 > 16777215;
     $1 = $2 ? 16 : 8;
     $3 = $2 ? $3 : $3 << 8;
     $2 = $3 >>> 0 > 268435455;
     $1 = $2 ? $1 : $1 + -4 | 0;
     $3 = $2 ? $3 : $3 << 4;
     $2 = $3 >>> 0 > 1073741823;
     $1 = ($2 ? $1 : $1 + -2 | 0) + (($2 ? $3 : $3 << 2) >> 31 ^ -1) | 0;
    } else {
     $1 = 0
    }
    $1 = slob_new_pages($4, $1);
    if (!$1) {
     break label$1
    }
   }
   $0 = HEAP32[$0 + 32 >> 2];
   if (!$0) {
    break label$1
   }
   FUNCTION_TABLE[$0]($1);
  }
  return $1;
 }

 function kmem_cache_free($0, $1) {
  var $2 = 0;
  $2 = HEAP32[$0 + 4 >> 2];
  if (!(HEAPU8[$0 + 14 | 0] & 8)) {
   __kmem_cache_free($1, $2);
   return;
  }
  $0 = $1 + $2 | 0;
  HEAP32[$0 + -4 >> 2] = $2;
  call_rcu($0 + -12 | 0, 78);
 }

 function __kmem_cache_free($0, $1) {
  var $2 = 0, $3 = 0;
  if ($1 >>> 0 <= 65535) {
   slob_free($0, $1);
   return;
  }
  $3 = $0;
  $1 = $1 + -1 | 0;
  if ($1 >>> 0 >= 65536) {
   $1 = $1 & -65536;
   $2 = $1 >>> 0 > 16777215;
   $0 = $2 ? 16 : 8;
   $1 = $2 ? $1 : $1 << 8;
   $2 = $1 >>> 0 > 268435455;
   $0 = $2 ? $0 : $0 + -4 | 0;
   $1 = $2 ? $1 : $1 << 4;
   $2 = $1 >>> 0 > 1073741823;
   $0 = ($2 ? $0 : $0 + -2 | 0) + (($2 ? $1 : $1 << 2) >> 31 ^ -1) | 0;
  } else {
   $0 = 0
  }
  slob_free_pages($3, $0);
 }

 function kmem_rcu_free($0) {
  $0 = $0 | 0;
  var $1 = 0;
  $1 = $0;
  $0 = HEAP32[$0 + 8 >> 2];
  __kmem_cache_free($1 + (12 - $0 | 0) | 0, $0);
 }

 function slob_page_alloc($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0;
  $9 = 0 - $2 | 0;
  $10 = $2 + -1 | 0;
  $7 = $1 + 3 >>> 2 | 0;
  $1 = HEAP32[$0 + 16 >> 2];
  label$1 : {
   label$2 : {
    label$3 : {
     label$4 : {
      label$5 : {
       while (1) {
        if ($2) {
         $5 = $9 & $1 + $10;
         $6 = $5 - $1 >> 2;
        }
        $4 = HEAP32[$1 >> 2];
        $8 = ($4 | 0) > 1 ? $4 : 1;
        if (($8 | 0) < ($6 + $7 | 0)) {
         if (slob_last($1)) {
          break label$5
         }
         $8 = $1 & -65536;
         $3 = $1;
         if (($4 | 0) > -1) {
          $1 = HEAP32[$1 + 4 >> 2]
         } else {
          $1 = 0 - $4 | 0
         }
         $1 = $8 + ($1 << 2) | 0;
         continue;
        }
        break;
       };
       $2 = $1 & -65536;
       if (!$6) {
        break label$4
       }
       if (($4 | 0) <= -1) {
        break label$3
       }
       $3 = HEAP32[$1 + 4 >> 2];
       break label$2;
      }
      return 0;
     }
     $9 = $2;
     $5 = $1;
     break label$1;
    }
    $3 = 0 - $4 | 0;
   }
   $9 = $5 & -65536;
   $3 = (($3 << 2) + $2 | 0) - $9 >> 2;
   $4 = $8 - $6 | 0;
   label$11 : {
    if (($4 | 0) >= 2) {
     HEAP32[$5 + 4 >> 2] = $3;
     break label$11;
    }
    $4 = 0 - $3 | 0;
   }
   HEAP32[$5 >> 2] = $4;
   $2 = $5 - $2 >> 2;
   label$13 : {
    if (($6 | 0) >= 2) {
     HEAP32[$1 + 4 >> 2] = $2;
     break label$13;
    }
    $6 = 0 - $2 | 0;
   }
   HEAP32[$1 >> 2] = $6;
   $4 = HEAP32[$5 >> 2];
   $8 = ($4 | 0) > 1 ? $4 : 1;
   $3 = $1;
  }
  if (($4 | 0) > -1) {
   $1 = HEAP32[$5 + 4 >> 2]
  } else {
   $1 = 0 - $4 | 0
  }
  $1 = ($1 << 2) + $9 | 0;
  label$17 : {
   label$18 : {
    label$19 : {
     label$20 : {
      label$21 : {
       label$22 : {
        label$23 : {
         label$24 : {
          if (($7 | 0) == ($8 | 0)) {
           if (!$3) {
            break label$24
           }
           $2 = $1 - ($3 & -65536) >> 2;
           $1 = HEAP32[$3 >> 2];
           if (($1 | 0) < 2) {
            break label$22
           }
           HEAP32[$3 + 4 >> 2] = $2;
           break label$21;
          }
          if (!$3) {
           break label$23
          }
          $6 = ($7 << 2) + $5 | 0;
          $2 = $6 - ($3 & -65536) >> 2;
          $4 = HEAP32[$3 >> 2];
          if (($4 | 0) < 2) {
           break label$20
          }
          HEAP32[$3 + 4 >> 2] = $2;
          break label$19;
         }
         HEAP32[$0 + 16 >> 2] = $1;
         break label$17;
        }
        $6 = ($7 << 2) + $5 | 0;
        HEAP32[$0 + 16 >> 2] = $6;
        break label$18;
       }
       $1 = 0 - $2 | 0;
      }
      HEAP32[$3 >> 2] = $1;
      break label$17;
     }
     $4 = 0 - $2 | 0;
    }
    HEAP32[$3 >> 2] = $4;
   }
   $2 = ($7 << 2) + $5 | 0;
   $3 = $1 - ($6 & -65536) >> 2;
   $1 = $8 - $7 | 0;
   label$26 : {
    if (($1 | 0) >= 2) {
     HEAP32[$2 + 4 >> 2] = $3;
     break label$26;
    }
    $1 = 0 - $3 | 0;
   }
   HEAP32[$2 >> 2] = $1;
  }
  $1 = HEAP32[$0 + 24 >> 2] - $7 | 0;
  HEAP32[$0 + 24 >> 2] = $1;
  if ($1) {
   return $5
  }
  $1 = HEAP32[$0 + 4 >> 2];
  $2 = $0 + 8 | 0;
  $3 = HEAP32[$2 >> 2];
  HEAP32[$1 + 4 >> 2] = $3;
  HEAP32[$0 + 4 >> 2] = 256;
  HEAP32[$3 >> 2] = $1;
  HEAP32[$2 >> 2] = 512;
  $1 = HEAP32[$0 + 4 >> 2];
  $0 = $1 & 1 ? $1 + -1 | 0 : $0;
  HEAP32[$0 >> 2] = HEAP32[$0 >> 2] & -8193;
  return $5;
 }

 function memblock_find_in_range_node($0, $1, $2, $3, $4, $5) {
  var $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0;
  $6 = global$0 - 16 | 0;
  global$0 = $6;
  $8 = $2 >>> 0 > 65536 ? $2 : 65536;
  $2 = $3 ? $3 : HEAP32[3922];
  $2 = $8 >>> 0 > $2 >>> 0 ? $8 : $2;
  label$1 : {
   if (!(!HEAPU8[15684] | $2 >>> 0 <= 19448)) {
    HEAP32[$6 >> 2] = 0;
    HEAP32[$6 + 4 >> 2] = 0;
    __next_mem_range($6, $4, $5, $6 + 12 | 0, $6 + 8 | 0);
    $9 = $8 >>> 0 > 19448 ? $8 : 19448;
    $10 = $1 + -1 | 0;
    label$3 : {
     while (1) {
      if (!(HEAP32[$6 >> 2] == -1 & HEAP32[$6 + 4 >> 2] == -1)) {
       $3 = HEAP32[$6 + 12 >> 2];
       $3 = $3 >>> 0 > $9 >>> 0 ? $3 : $9;
       $3 = $3 >>> 0 < $2 >>> 0 ? $3 : $2;
       HEAP32[$6 + 12 >> 2] = $3;
       $7 = HEAP32[$6 + 8 >> 2];
       $7 = $7 >>> 0 > $9 >>> 0 ? $7 : $9;
       $7 = $7 >>> 0 < $2 >>> 0 ? $7 : $2;
       HEAP32[$6 + 8 >> 2] = $7;
       $3 = ($10 | $3 + -1) + 1 | 0;
       if ($7 - $3 >>> 0 >= $0 >>> 0 ? $7 >>> 0 > $3 >>> 0 : 0) {
        break label$3
       }
       __next_mem_range($6, $4, $5, $6 + 12 | 0, $6 + 8 | 0);
       continue;
      }
      break;
     };
     $3 = 0;
    }
    if ($3) {
     break label$1
    }
   }
   HEAP32[$6 >> 2] = -1;
   HEAP32[$6 + 4 >> 2] = -1;
   __next_mem_range_rev($6, $4, $5, $6 + 12 | 0, $6 + 8 | 0);
   $9 = 0 - $1 | 0;
   while (1) {
    if (!(HEAP32[$6 >> 2] == -1 & HEAP32[$6 + 4 >> 2] == -1)) {
     $1 = HEAP32[$6 + 12 >> 2];
     $1 = $1 >>> 0 > $8 >>> 0 ? $1 : $8;
     $7 = $1 >>> 0 < $2 >>> 0 ? $1 : $2;
     HEAP32[$6 + 12 >> 2] = $7;
     $1 = HEAP32[$6 + 8 >> 2];
     $1 = $1 >>> 0 > $8 >>> 0 ? $1 : $8;
     $1 = $1 >>> 0 < $2 >>> 0 ? $1 : $2;
     HEAP32[$6 + 8 >> 2] = $1;
     if ($1 >>> 0 >= $0 >>> 0) {
      $3 = $9 & $1 - $0;
      if ($3 >>> 0 >= $7 >>> 0) {
       break label$1
      }
     }
     __next_mem_range_rev($6, $4, $5, $6 + 12 | 0, $6 + 8 | 0);
     continue;
    }
    break;
   };
   $3 = 0;
  }
  global$0 = $6 + 16 | 0;
  return $3;
 }

 function __next_mem_range($0, $1, $2, $3, $4) {
  var $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0, $15 = 0, $16 = 0;
  $11 = $2 & 4;
  $12 = $2 & 2;
  $2 = HEAP32[$0 + 4 >> 2];
  $13 = HEAP32[3923];
  $6 = HEAP32[$0 >> 2];
  $14 = (($1 | 0) == 1 ? -1 : $1) + 1 >>> 0 > 1;
  $15 = $0;
  label$1 : {
   label$3 : {
    while (1) {
     if ($6 >>> 0 < $13 >>> 0) {
      label$6 : {
       if ($14) {
        break label$6
       }
       $1 = HEAP32[3926] + Math_imul($6, 12) | 0;
       $9 = HEAP32[$1 >> 2];
       if ((HEAPU8[$1 + 8 | 0] & 2 ? 0 : $12) | (HEAPU8[$1 + 8 | 0] & 4 ? !$11 : 0)) {
        break label$6
       }
       $7 = HEAP32[$1 + 4 >> 2] + $9 | 0;
       $1 = Math_imul($2, 12);
       $10 = HEAP32[3928];
       $16 = $10 + 1 | 0;
       while (1) {
        if ($2 >>> 0 >= $16 >>> 0) {
         break label$6
        }
        $5 = HEAP32[3931];
        $8 = $2 >>> 0 < $10 >>> 0 ? HEAP32[$5 + $1 >> 2] : -1;
        label$10 : {
         if ($2) {
          $5 = $1 + $5 | 0;
          $5 = HEAP32[$5 + -8 >> 2] + HEAP32[$5 + -12 >> 2] | 0;
          break label$10;
         }
         $5 = 0;
        }
        if ($5 >>> 0 >= $7 >>> 0) {
         break label$6
        }
        if ($9 >>> 0 < $8 >>> 0) {
         break label$3
        }
        $1 = $1 + 12 | 0;
        $2 = $2 + 1 | 0;
        continue;
       };
      }
      $6 = $6 + 1 | 0;
      continue;
     }
     break;
    };
    $1 = -1;
    $2 = -1;
    break label$1;
   }
   if ($3) {
    HEAP32[$3 >> 2] = $9 >>> 0 > $5 >>> 0 ? $9 : $5
   }
   if ($4) {
    HEAP32[$4 >> 2] = $7 >>> 0 < $8 >>> 0 ? $7 : $8
   }
   $1 = ($7 >>> 0 > $8 >>> 0) + $2 | 0;
   $2 = $6 + ($7 >>> 0 <= $8 >>> 0) | 0;
  }
  HEAP32[$15 >> 2] = $2;
  HEAP32[$0 + 4 >> 2] = $1;
 }

 function __next_mem_range_rev($0, $1, $2, $3, $4) {
  var $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0;
  $6 = ($1 | 0) == 1 ? -1 : $1;
  $7 = HEAP32[$0 >> 2];
  $1 = HEAP32[$0 + 4 >> 2];
  label$1 : {
   if (!(($7 | 0) == -1 & ($1 | 0) == -1)) {
    break label$1
   }
   $7 = HEAP32[3923] + -1 | 0;
   $1 = HEAP32[3928];
   if (15712) {
    break label$1
   }
   $1 = 0;
  }
  $10 = $2 & 4;
  $11 = $2 & 2;
  $12 = $6 + 1 >>> 0 > 1;
  $13 = $0;
  label$4 : {
   label$6 : {
    while (1) {
     if (($7 | 0) >= 0) {
      label$9 : {
       if ($12) {
        break label$9
       }
       $2 = HEAP32[3926] + Math_imul($7, 12) | 0;
       $6 = HEAP32[$2 >> 2];
       if ((HEAPU8[$2 + 8 | 0] & 2 ? 0 : $11) | (HEAPU8[$2 + 8 | 0] & 4 ? !$10 : 0)) {
        break label$9
       }
       $9 = HEAP32[$2 + 4 >> 2] + $6 | 0;
       $2 = Math_imul($1, 12);
       while (1) {
        if (($1 | 0) < 0) {
         break label$9
        }
        $8 = HEAP32[3931];
        label$13 : {
         if ($1) {
          $5 = $2 + $8 | 0;
          $5 = HEAP32[$5 + -8 >> 2] + HEAP32[$5 + -12 >> 2] | 0;
          break label$13;
         }
         $5 = 0;
        }
        $8 = $1 >>> 0 < HEAPU32[3928] ? HEAP32[$2 + $8 >> 2] : -1;
        if ($8 >>> 0 <= $6 >>> 0) {
         break label$9
        }
        if ($9 >>> 0 > $5 >>> 0) {
         break label$6
        }
        $2 = $2 + -12 | 0;
        $1 = $1 + -1 | 0;
        continue;
       };
      }
      $7 = $7 + -1 | 0;
      continue;
     }
     break;
    };
    $1 = -1;
    $2 = -1;
    break label$4;
   }
   if ($3) {
    HEAP32[$3 >> 2] = $6 >>> 0 > $5 >>> 0 ? $6 : $5
   }
   if ($4) {
    HEAP32[$4 >> 2] = $9 >>> 0 < $8 >>> 0 ? $9 : $8
   }
   $1 = $1 - ($6 >>> 0 < $5 >>> 0) | 0;
   $2 = $7 - ($6 >>> 0 >= $5 >>> 0) | 0;
  }
  HEAP32[$13 >> 2] = $2;
  HEAP32[$0 + 4 >> 2] = $1;
 }

 function memblock_find_in_range($0, $1, $2) {
  var $3 = 0, $4 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  HEAP32[$3 + 12 >> 2] = $2;
  $4 = HEAPU8[82528] ? 2 : 0;
  while (1) {
   $2 = memblock_find_in_range_node($2, 65536, $0, $1, -1, $4);
   if (!($2 | !($4 & 2))) {
    HEAP32[$3 >> 2] = $3 + 12;
    printk(23374, $3);
    $4 = $4 & -3;
    $2 = HEAP32[$3 + 12 >> 2];
    continue;
   }
   break;
  };
  global$0 = $3 + 16 | 0;
  return $2;
 }

 function memblock_add_range($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0;
  label$1 : {
   label$2 : {
    label$3 : {
     label$4 : {
      $3 = $1 ^ -1;
      $7 = $3 >>> 0 > $2 >>> 0 ? $2 : $3;
      if (!$7) {
       break label$4
      }
      $4 = HEAP32[$0 + 12 >> 2];
      if (!HEAP32[$4 + 4 >> 2]) {
       break label$2
      }
      $8 = $1 + $7 | 0;
      $11 = $0 + 12 | 0;
      $12 = $0 + 4 | 0;
      while (1) {
       $5 = $4;
       $6 = 0;
       $2 = 0;
       $3 = $1;
       while (1) {
        label$6 : {
         if ($2 >>> 0 >= HEAPU32[$0 >> 2]) {
          break label$6
         }
         $9 = HEAP32[$5 >> 2];
         if ($9 >>> 0 >= $8 >>> 0) {
          break label$6
         }
         $5 = $9 + HEAP32[$5 + 4 >> 2] | 0;
         if ($5 >>> 0 > $3 >>> 0) {
          label$9 : {
           if ($9 >>> 0 <= $3 >>> 0) {
            break label$9
           }
           $6 = $6 + 1 | 0;
           if (!$10) {
            break label$9
           }
           memblock_insert_region($0, $2, $3, $9 - $3 | 0, 0);
           $2 = $2 + 1 | 0;
           $4 = HEAP32[$11 >> 2];
          }
          $3 = $5 >>> 0 < $8 >>> 0 ? $5 : $8;
         }
         $2 = $2 + 1 | 0;
         $5 = Math_imul($2, 12) + $4 | 0;
         continue;
        }
        break;
       };
       label$10 : {
        if ($8 >>> 0 <= $3 >>> 0) {
         break label$10
        }
        $6 = $6 + 1 | 0;
        if (!$10) {
         break label$10
        }
        memblock_insert_region($0, $2, $3, $8 - $3 | 0, 0);
       }
       if (!$6) {
        break label$4
       }
       if ($10) {
        break label$1
       }
       while (1) {
        if (HEAP32[$0 >> 2] + $6 >>> 0 > HEAPU32[$12 >> 2]) {
         if ((memblock_double_array($0, $1, $7) | 0) >= 0) {
          continue
         }
         break label$3;
        }
        break;
       };
       $4 = HEAP32[$11 >> 2];
       $10 = 1;
       continue;
      };
     }
     return 0;
    }
    return -12;
   }
   HEAP32[$4 + 8 >> 2] = 0;
   HEAP32[$4 >> 2] = $1;
   HEAP32[$0 + 8 >> 2] = $7;
   HEAP32[$4 + 4 >> 2] = $7;
   return 0;
  }
  memblock_merge_regions($0);
  return 0;
 }

 function memblock_insert_region($0, $1, $2, $3, $4) {
  var $5 = 0, $6 = 0, $7 = 0;
  $5 = global$0 - 16 | 0;
  global$0 = $5;
  $7 = HEAP32[$0 >> 2];
  if ($7 >>> 0 < HEAPU32[$0 + 4 >> 2]) {
   $6 = HEAP32[$0 + 12 >> 2] + Math_imul($1, 12) | 0;
   memmove($6 + 12 | 0, $6, Math_imul($7 - $1 | 0, 12));
   HEAP32[$6 + 8 >> 2] = $4;
   HEAP32[$6 + 4 >> 2] = $3;
   HEAP32[$6 >> 2] = $2;
   HEAP32[$0 >> 2] = HEAP32[$0 >> 2] + 1;
   HEAP32[$0 + 8 >> 2] = HEAP32[$0 + 8 >> 2] + $3;
   global$0 = $5 + 16 | 0;
   return;
  }
  HEAP32[$5 + 8 >> 2] = 23802;
  HEAP32[$5 + 4 >> 2] = 551;
  HEAP32[$5 >> 2] = 23791;
  printk(23760, $5);
  abort();
 }

 function memblock_double_array($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0;
  $3 = global$0 + -64 | 0;
  global$0 = $3;
  $7 = slab_is_available();
  $5 = -1;
  label$1 : {
   label$2 : {
    if (!HEAPU8[82536]) {
     break label$2
    }
    $6 = HEAP32[$0 + 4 >> 2];
    $4 = Math_imul($6, 24);
    $9 = $4 + 65535 & -65536;
    $10 = $3;
    label$3 : {
     label$4 : {
      if ($7) {
       $1 = __kmalloc($4, 6291648);
       break label$4;
      }
      $8 = $2;
      $2 = ($0 | 0) == 15712;
      $8 = $2 ? $8 : 0;
      $2 = $2 ? $1 : 0;
      $1 = memblock_find_in_range($8 + $2 | 0, HEAP32[3922], $9);
      HEAP32[$3 + 60 >> 2] = $1;
      if ($1 | !$8) {
       break label$3
      }
      $1 = HEAP32[3922];
      $1 = memblock_find_in_range(0, $2 >>> 0 < $1 >>> 0 ? $2 : $1, $9);
     }
     HEAP32[$10 + 60 >> 2] = $1;
    }
    label$6 : {
     label$7 : {
      if ($1) {
       $5 = Math_imul($6, 12);
       $6 = ($0 | 0) == 15692 ? 82552 : 82556;
       HEAP32[$3 + 56 >> 2] = ($1 + $4 | 0) + -1;
       if (HEAP32[20633]) {
        break label$7
       }
       break label$6;
      }
      $1 = HEAP32[$0 + 16 >> 2];
      $0 = HEAP32[$0 + 4 >> 2];
      HEAP32[$3 + 4 >> 2] = $0;
      HEAP32[$3 >> 2] = $1;
      HEAP32[$3 + 8 >> 2] = $0 << 1;
      printk(23825, $3);
      break label$2;
     }
     $2 = HEAP32[$0 + 4 >> 2];
     HEAP32[$3 + 32 >> 2] = HEAP32[$0 + 16 >> 2];
     HEAP32[$3 + 36 >> 2] = $2 << 1;
     HEAP32[$3 + 44 >> 2] = $3 + 56;
     HEAP32[$3 + 40 >> 2] = $3 + 60;
     printk(23890, $3 + 32 | 0);
    }
    memcpy($1, HEAP32[$0 + 12 >> 2], $5);
    $4 = $0 + 4 | 0;
    memset(Math_imul(HEAP32[$4 >> 2], 12) + $1 | 0, 0, $5);
    $2 = HEAP32[$0 + 12 >> 2];
    HEAP32[$0 + 12 >> 2] = $1;
    HEAP32[$4 >> 2] = HEAP32[$4 >> 2] << 1;
    label$9 : {
     label$10 : {
      if (HEAP32[$6 >> 2]) {
       kfree($2);
       if (!$7) {
        break label$10
       }
       break label$9;
      }
      if (!(($2 | 0) == 79456 | ($2 | 0) == 80992)) {
       memblock_free($2, $5 + 65535 & -65536)
      }
      if ($7) {
       break label$9
      }
     }
     if (memblock_reserve(HEAP32[$3 + 60 >> 2], $9)) {
      break label$1
     }
    }
    HEAP32[$6 >> 2] = $7;
    $5 = 0;
   }
   global$0 = $3 - -64 | 0;
   return $5;
  }
  HEAP32[$3 + 24 >> 2] = 23936;
  HEAP32[$3 + 20 >> 2] = 492;
  HEAP32[$3 + 16 >> 2] = 23791;
  printk(23760, $3 + 16 | 0);
  abort();
 }

 function memblock_merge_regions($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0;
  $2 = global$0 - 16 | 0;
  global$0 = $2;
  $3 = HEAP32[$0 >> 2];
  label$1 : {
   while (1) {
    $4 = Math_imul($5, 12);
    $11 = $3 + -1 | 0;
    label$3 : {
     while (1) {
      if ($5 >>> 0 >= $11 >>> 0) {
       break label$3
      }
      $1 = HEAP32[$0 + 12 >> 2] + $4 | 0;
      $6 = $1 + 4 | 0;
      $7 = HEAP32[$6 >> 2];
      $8 = $7 + HEAP32[$1 >> 2] | 0;
      $9 = $1 + 12 | 0;
      $10 = HEAP32[$9 >> 2];
      if (!(HEAP32[$1 + 8 >> 2] == HEAP32[$1 + 20 >> 2] ? ($8 | 0) == ($10 | 0) : 0)) {
       $4 = $4 + 12 | 0;
       $5 = $5 + 1 | 0;
       if ($8 >>> 0 <= $10 >>> 0) {
        continue
       }
       break label$1;
      }
      break;
     };
     HEAP32[$6 >> 2] = HEAP32[$1 + 16 >> 2] + $7;
     memmove($9, $1 + 24 | 0, (Math_imul($3, 12) + -24 | 0) - $4 | 0);
     $3 = HEAP32[$0 >> 2] + -1 | 0;
     HEAP32[$0 >> 2] = $3;
     continue;
    }
    break;
   };
   global$0 = $2 + 16 | 0;
   return;
  }
  HEAP32[$2 + 8 >> 2] = 23958;
  HEAP32[$2 + 4 >> 2] = 519;
  HEAP32[$2 >> 2] = 23791;
  printk(23760, $2);
  abort();
 }

 function memblock_free($0, $1) {
  var $2 = 0;
  $2 = global$0 - 32 | 0;
  global$0 = $2;
  HEAP32[$2 + 28 >> 2] = $0;
  HEAP32[$2 + 24 >> 2] = ($0 + $1 | 0) + -1;
  if (HEAP32[20633]) {
   HEAP32[$2 + 8 >> 2] = 0;
   HEAP32[$2 + 4 >> 2] = $2 + 24;
   HEAP32[$2 >> 2] = $2 + 28;
   printk(23426, $2);
   $0 = HEAP32[$2 + 28 >> 2];
  }
  memblock_remove_range($0, $1);
  global$0 = $2 + 32 | 0;
 }

 function memblock_reserve($0, $1) {
  var $2 = 0;
  $2 = global$0 - 32 | 0;
  global$0 = $2;
  HEAP32[$2 + 28 >> 2] = $0;
  HEAP32[$2 + 24 >> 2] = ($0 + $1 | 0) + -1;
  if (HEAP32[20633]) {
   HEAP32[$2 + 8 >> 2] = 0;
   HEAP32[$2 + 4 >> 2] = $2 + 24;
   HEAP32[$2 >> 2] = $2 + 28;
   printk(23461, $2);
   $0 = HEAP32[$2 + 28 >> 2];
  }
  $0 = memblock_add_range(15712, $0, $1);
  global$0 = $2 + 32 | 0;
  return $0;
 }

 function memblock_remove_range($0, $1) {
  var $2 = 0;
  $2 = global$0 - 16 | 0;
  global$0 = $2;
  if (!memblock_isolate_range(15712, $0, $1, $2 + 12 | 0, $2 + 8 | 0)) {
   $1 = HEAP32[$2 + 12 >> 2];
   $0 = HEAP32[$2 + 8 >> 2];
   while (1) {
    if (($0 | 0) > ($1 | 0)) {
     $0 = $0 + -1 | 0;
     memblock_remove_region($0);
     continue;
    }
    break;
   };
  }
  global$0 = $2 + 16 | 0;
 }

 function memblock_isolate_range($0, $1, $2, $3, $4) {
  var $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0;
  HEAP32[$4 >> 2] = 0;
  HEAP32[$3 >> 2] = 0;
  label$1 : {
   $5 = $1 ^ -1;
   $2 = $5 >>> 0 > $2 >>> 0 ? $2 : $5;
   if (!$2) {
    break label$1
   }
   $9 = $1 + $2 | 0;
   $5 = $0 + 4 | 0;
   label$2 : {
    while (1) {
     $6 = HEAP32[$0 >> 2];
     if ($6 + 2 >>> 0 <= HEAPU32[$5 >> 2]) {
      break label$2
     }
     if ((memblock_double_array($0, $1, $2) | 0) >= 0) {
      continue
     }
     break;
    };
    return -12;
   }
   $2 = HEAP32[$0 + 12 >> 2];
   $10 = $0 + 8 | 0;
   $5 = 0;
   while (1) {
    if ($5 >>> 0 >= $6 >>> 0) {
     break label$1
    }
    $6 = HEAP32[$2 >> 2];
    if ($9 >>> 0 <= $6 >>> 0) {
     break label$1
    }
    $7 = HEAP32[$2 + 4 >> 2];
    $8 = $6 + $7 | 0;
    label$5 : {
     if ($8 >>> 0 <= $1 >>> 0) {
      break label$5
     }
     if ($6 >>> 0 < $1 >>> 0) {
      HEAP32[$2 >> 2] = $1;
      $8 = $7;
      $7 = $1 - $6 | 0;
      HEAP32[$2 + 4 >> 2] = $8 - $7;
      HEAP32[$10 >> 2] = HEAP32[$10 >> 2] - $7;
      memblock_insert_region($0, $5, $6, $7, HEAP32[$2 + 8 >> 2]);
      break label$5;
     }
     if ($8 >>> 0 > $9 >>> 0) {
      HEAP32[$2 >> 2] = $9;
      $8 = $7;
      $7 = $9 - $6 | 0;
      HEAP32[$2 + 4 >> 2] = $8 - $7;
      HEAP32[$10 >> 2] = HEAP32[$10 >> 2] - $7;
      memblock_insert_region($0, $5, $6, $7, HEAP32[$2 + 8 >> 2]);
      $5 = $5 + -1 | 0;
      break label$5;
     }
     if (!HEAP32[$4 >> 2]) {
      HEAP32[$3 >> 2] = $5
     }
     HEAP32[$4 >> 2] = $5 + 1;
    }
    $5 = $5 + 1 | 0;
    $2 = HEAP32[$0 + 12 >> 2] + Math_imul($5, 12) | 0;
    $6 = HEAP32[$0 >> 2];
    continue;
   };
  }
  return 0;
 }

 function memblock_remove_region($0) {
  var $1 = 0;
  $1 = HEAP32[3931] + Math_imul($0, 12) | 0;
  HEAP32[3930] = HEAP32[3930] - HEAP32[$1 + 4 >> 2];
  memmove($1, $1 + 12 | 0, Math_imul(HEAP32[3928] - ($0 + 1 | 0) | 0, 12));
  $0 = HEAP32[3928] + -1 | 0;
  HEAP32[3928] = $0;
  if ($0) {
   return
  }
  HEAP32[3928] = 1;
  $0 = HEAP32[3931];
  HEAP32[$0 + 8 >> 2] = 0;
  HEAP32[$0 >> 2] = 0;
  HEAP32[$0 + 4 >> 2] = 0;
 }

 function memblock_setclr_flag() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0;
  $0 = global$0 - 16 | 0;
  global$0 = $0;
  if (!memblock_isolate_range(15692, 0, -1, $0 + 12 | 0, $0 + 8 | 0)) {
   $1 = HEAP32[$0 + 12 >> 2];
   $2 = (HEAP32[3926] + Math_imul($1, 12) | 0) + 8 | 0;
   $3 = HEAP32[$0 + 8 >> 2];
   while (1) {
    if (($1 | 0) < ($3 | 0)) {
     HEAP32[$2 >> 2] = HEAP32[$2 >> 2] & -2;
     $2 = $2 + 12 | 0;
     $1 = $1 + 1 | 0;
     continue;
    }
    break;
   };
   memblock_merge_regions(15692);
  }
  global$0 = $0 + 16 | 0;
 }

 function __next_reserved_mem_region($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $4 = -1;
  $3 = -1;
  $5 = HEAP32[$0 + 4 >> 2];
  $6 = HEAP32[$0 >> 2];
  if (!(!$5 & $6 >>> 0 >= HEAPU32[3928] | $5 >>> 0 > 0)) {
   $3 = HEAP32[3931] + Math_imul($6, 12) | 0;
   $4 = HEAP32[$3 + 4 >> 2];
   $3 = HEAP32[$3 >> 2];
   if ($1) {
    HEAP32[$1 >> 2] = $3
   }
   if ($2) {
    HEAP32[$2 >> 2] = ($3 + $4 | 0) + -1
   }
   $1 = $5;
   $2 = $6 + 1 | 0;
   if ($2 >>> 0 < 1) {
    $1 = $1 + 1 | 0
   }
   $4 = $2;
   $3 = $1;
  }
  HEAP32[$0 >> 2] = $4;
  HEAP32[$0 + 4 >> 2] = $3;
 }

 function memblock_alloc_internal($0, $1, $2, $3, $4) {
  var $5 = 0, $6 = 0, $7 = 0;
  $5 = global$0 - 32 | 0;
  global$0 = $5;
  HEAP32[$5 + 28 >> 2] = $0;
  HEAP32[$5 + 16 >> 2] = 23999;
  $6 = HEAPU8[82528];
  printk(23981, $5 + 16 | 0);
  label$1 : {
   label$2 : {
    if (!slab_is_available()) {
     $7 = ($4 | 0) == 1 ? -1 : $4;
     if ($1) {
      break label$2
     }
     dump_stack();
     $1 = 128;
     break label$2;
    }
    $2 = __kmalloc($0, 4227072);
    break label$1;
   }
   $4 = $6 ? 2 : 0;
   $0 = HEAP32[3922];
   $3 = $0 >>> 0 < $3 >>> 0 ? $0 : $3;
   $6 = ($7 | 0) == -1;
   while (1) {
    $0 = $2;
    $2 = memblock_find_in_range_node(HEAP32[$5 + 28 >> 2], $1, $0, $3, $7, $4);
    if ($2) {
     if (!memblock_reserve($2, HEAP32[$5 + 28 >> 2])) {
      break label$1
     }
    }
    label$6 : {
     if ($6) {
      break label$6
     }
     $2 = memblock_find_in_range_node(HEAP32[$5 + 28 >> 2], $1, $0, $3, -1, $4);
     if (!$2) {
      break label$6
     }
     if (!memblock_reserve($2, HEAP32[$5 + 28 >> 2])) {
      break label$1
     }
    }
    $2 = 0;
    if ($0) {
     continue
    }
    if (!($4 & 2)) {
     break label$1
    }
    HEAP32[$5 >> 2] = $5 + 28;
    printk(23374, $5);
    $4 = $4 & -3;
    continue;
   };
  }
  global$0 = $5 + 32 | 0;
  return $2;
 }

 function memblock_alloc_try_nid_nopanic($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $3 = global$0 - 48 | 0;
  global$0 = $3;
  HEAP32[$3 + 40 >> 2] = 0;
  HEAP32[$3 + 44 >> 2] = 0;
  $5 = $0;
  $6 = $1;
  if (HEAP32[20633]) {
   HEAP32[$3 + 36 >> 2] = 0;
   HEAP32[$3 + 24 >> 2] = $2;
   $4 = $3 + 16 | 0;
   HEAP32[$4 >> 2] = $1;
   HEAP32[$4 + 4 >> 2] = 0;
   HEAP32[$3 >> 2] = 23560;
   HEAP32[$3 + 32 >> 2] = $3 + 40;
   HEAP32[$3 + 28 >> 2] = $3 + 44;
   HEAP32[$3 + 8 >> 2] = $0;
   HEAP32[$3 + 12 >> 2] = 0;
   printk(23496, $3);
   $4 = HEAP32[$3 + 40 >> 2];
   $1 = HEAP32[$3 + 44 >> 2];
  } else {
   $1 = 0
  }
  $1 = memblock_alloc_internal($5, $6, $1, $4, $2);
  if ($1) {
   memset($1, 0, $0)
  }
  global$0 = $3 + 48 | 0;
  return $1;
 }

 function __memblock_dump_all() {
  var $0 = 0;
  $0 = global$0 - 16 | 0;
  global$0 = $0;
  printk(23691, 0);
  HEAP32[$0 + 4 >> 2] = 15720;
  HEAP32[$0 >> 2] = 15700;
  printk(23718, $0);
  memblock_dump(15692);
  memblock_dump(15712);
  global$0 = $0 + 16 | 0;
 }

 function memblock_dump($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0;
  $1 = global$0 - 96 | 0;
  global$0 = $1;
  $3 = HEAP32[$0 + 16 >> 2];
  HEAP32[$1 + 36 >> 2] = HEAP32[$0 >> 2];
  HEAP32[$1 + 32 >> 2] = $3;
  printk(24023, $1 + 32 | 0);
  $3 = HEAP32[$0 + 12 >> 2];
  $7 = $1 + 20 | 0;
  $4 = 12;
  while (1) {
   if (!($5 >>> 0 >= HEAPU32[$0 >> 2])) {
    $2 = $1 + 72 | 0;
    HEAP32[$2 >> 2] = 0;
    HEAP32[$2 + 4 >> 2] = 0;
    $2 = $1 - -64 | 0;
    HEAP32[$2 >> 2] = 0;
    HEAP32[$2 + 4 >> 2] = 0;
    HEAP32[$1 + 56 >> 2] = 0;
    HEAP32[$1 + 60 >> 2] = 0;
    HEAP32[$1 + 48 >> 2] = 0;
    HEAP32[$1 + 52 >> 2] = 0;
    $8 = HEAP32[$0 + 16 >> 2];
    $2 = HEAP32[$3 + 4 >> 2];
    $6 = HEAP32[$3 >> 2];
    HEAP32[$1 + 24 >> 2] = HEAP32[$3 + 8 >> 2];
    HEAP32[$1 + 92 >> 2] = $6;
    HEAP32[$7 >> 2] = $1 + 48;
    HEAP32[$1 + 16 >> 2] = $1 + 84;
    HEAP32[$1 >> 2] = $8;
    HEAP32[$1 + 84 >> 2] = $2;
    HEAP32[$1 + 88 >> 2] = ($2 + $6 | 0) + -1;
    HEAP32[$1 + 12 >> 2] = $1 + 88;
    HEAP32[$1 + 8 >> 2] = $1 + 92;
    HEAP32[$1 + 4 >> 2] = $5;
    printk(24043, $1);
    $5 = $5 + 1 | 0;
    $3 = HEAP32[$0 + 12 >> 2] + $4 | 0;
    $4 = $4 + 12 | 0;
    continue;
   }
   break;
  };
  global$0 = $1 + 96 | 0;
 }

 function reset_node_managed_pages($0) {
  var $1 = 0;
  $1 = $0 + 1032 | 0;
  while (1) {
   if (!($0 >>> 0 >= $1 >>> 0)) {
    HEAP32[$0 + 40 >> 2] = 0;
    $0 = $0 + 516 | 0;
    continue;
   }
   break;
  };
 }

 function reset_all_zones_managed_pages() {
  var $0 = 0;
  if (!HEAPU8[141164]) {
   $0 = 141176;
   while (1) {
    if ($0) {
     reset_node_managed_pages($0);
     $0 = 0;
     continue;
    }
    break;
   };
   HEAP8[141164] = 1;
  }
 }

 function memblock_free_all() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0;
  $1 = global$0 - 16 | 0;
  global$0 = $1;
  reset_all_zones_managed_pages();
  memblock_setclr_flag();
  HEAP32[$1 >> 2] = 0;
  HEAP32[$1 + 4 >> 2] = 0;
  __next_reserved_mem_region($1, $1 + 12 | 0, $1 + 8 | 0);
  while (1) {
   if (!(HEAP32[$1 >> 2] == -1 & HEAP32[$1 + 4 >> 2] == -1)) {
    reserve_bootmem_region(HEAP32[$1 + 12 >> 2], HEAP32[$1 + 8 >> 2]);
    __next_reserved_mem_region($1, $1 + 12 | 0, $1 + 8 | 0);
    continue;
   }
   break;
  };
  HEAP32[$1 >> 2] = 0;
  HEAP32[$1 + 4 >> 2] = 0;
  __next_mem_range($1, -1, 0, $1 + 12 | 0, $1 + 8 | 0);
  while (1) {
   if (!(HEAP32[$1 >> 2] == -1 & HEAP32[$1 + 4 >> 2] == -1)) {
    $2 = 0;
    $3 = HEAP32[$1 + 8 >> 2] >>> 16 | 0;
    $0 = HEAP32[20635];
    $4 = $3 >>> 0 < $0 >>> 0 ? $3 : $0;
    $5 = HEAP32[$1 + 12 >> 2] + 65535 >>> 16 | 0;
    if ($4 >>> 0 > $5 >>> 0) {
     $3 = $5;
     while (1) {
      if ($3 >>> 0 < $4 >>> 0) {
       $6 = $3 & 65535;
       $0 = $6 ? $3 : $3 >>> 16 | 0;
       $2 = $0 & 255;
       $0 = $2 ? $0 : $0 >>> 8 | 0;
       $7 = $0 & 15;
       $0 = $7 ? $0 : $0 >>> 4 | 0;
       $8 = $0 & 3;
       $10 = (($8 ? $0 : $0 >>> 2 | 0) ^ -1) & 1;
       $0 = !$6 << 4;
       $0 = $2 ? $0 : $0 | 8;
       $0 = $7 ? $0 : $0 | 4;
       $0 = $10 + ($8 ? $0 : $0 | 2) | 0;
       $2 = ($0 >>> 0 < 10 ? $0 : 10) + 1 | 0;
       while (1) {
        $2 = $2 + -1 | 0;
        $0 = (1 << $2) + $3 | 0;
        if ($0 >>> 0 > $4 >>> 0) {
         continue
        }
        break;
       };
       memblock_free_pages(HEAP32[20650] + Math_imul($3, 36) | 0, $2);
       $3 = $0;
       continue;
      }
      break;
     };
     $2 = $4 - $5 | 0;
    }
    __next_mem_range($1, -1, 0, $1 + 12 | 0, $1 + 8 | 0);
    $9 = $2 + $9 | 0;
    continue;
   }
   break;
  };
  HEAP32[20709] = HEAP32[20709] + $9;
  global$0 = $1 + 16 | 0;
 }

 function __purge_vmap_area_lazy() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0, $4 = 0;
  $3 = -1;
  $0 = HEAP32[20643];
  HEAP32[20643] = 0;
  $0 = $0 + -32 | 0;
  $1 = $0;
  while (1) {
   if (($1 | 0) != -32) {
    $2 = HEAP32[$1 + 4 >> 2];
    $4 = $2 >>> 0 > $4 >>> 0 ? $2 : $4;
    $2 = HEAP32[$1 >> 2];
    $3 = $2 >>> 0 < $3 >>> 0 ? $2 : $3;
    $1 = HEAP32[$1 + 32 >> 2] + -32 | 0;
    $2 = 1;
    continue;
   }
   break;
  };
  if ($2) {
   local_flush_tlb_kernel_range($3, $4);
   while (1) {
    if (($0 | 0) != -32) {
     $1 = HEAP32[$0 + 32 >> 2];
     $3 = HEAP32[$0 >> 2];
     $4 = HEAP32[$0 + 4 >> 2];
     __free_vmap_area($0);
     HEAP32[20640] = HEAP32[20640] - ($4 - $3 >>> 16 | 0);
     __cond_resched_lock();
     $0 = $1 + -32 | 0;
     continue;
    }
    break;
   };
  }
 }

 function __free_vmap_area($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, wasm2js_i32$0 = 0, wasm2js_i32$1 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  $1 = $0 + 12 | 0;
  if (($1 | 0) != HEAP32[$0 + 12 >> 2]) {
   $2 = HEAP32[20644];
   label$2 : {
    if (!$2) {
     break label$2
    }
    if (HEAPU32[$0 + 4 >> 2] < HEAPU32[20645]) {
     HEAP32[20644] = 0;
     break label$2;
    }
    if (HEAPU32[$0 >> 2] > HEAPU32[$2 + -12 >> 2]) {
     break label$2
    }
    (wasm2js_i32$0 = 82576, wasm2js_i32$1 = rb_prev($1)), HEAP32[wasm2js_i32$0 >> 2] = wasm2js_i32$1;
   }
   rb_erase($1, 82584);
   $2 = HEAP32[$0 + 24 >> 2];
   $4 = $0 + 28 | 0;
   $5 = HEAP32[$4 >> 2];
   HEAP32[$2 + 4 >> 2] = $5;
   HEAP32[$0 + 12 >> 2] = $1;
   HEAP32[$5 >> 2] = $2;
   HEAP32[$4 >> 2] = 512;
   $1 = HEAP32[$0 + 4 >> 2];
   if ($1 + -2136997889 >>> 0 <= 2097151) {
    $2 = HEAP32[20642];
    HEAP32[20642] = $2 >>> 0 > $1 >>> 0 ? $2 : $1;
   }
   call_rcu($0 + 40 | 0, 40);
   global$0 = $3 + 16 | 0;
   return;
  }
  HEAP32[$3 + 8 >> 2] = 24136;
  HEAP32[$3 + 4 >> 2] = 555;
  HEAP32[$3 >> 2] = 24120;
  printk(24089, $3);
  abort();
 }

 function vunmap_page_range() {
  var $0 = 0;
  $0 = global$0 - 16 | 0;
  global$0 = $0;
  HEAP32[$0 + 8 >> 2] = 24172;
  HEAP32[$0 + 4 >> 2] = 124;
  HEAP32[$0 >> 2] = 24120;
  printk(24089, $0);
  abort();
 }

 function find_vmap_area($0) {
  var $1 = 0, $2 = 0;
  $1 = 82584;
  label$1 : {
   while (1) {
    $1 = HEAP32[$1 >> 2];
    if ($1) {
     $2 = $1 + -12 | 0;
     if (HEAPU32[$2 >> 2] > $0 >>> 0) {
      $1 = $1 + 8 | 0;
      continue;
     }
     if (HEAPU32[$1 + -8 >> 2] > $0 >>> 0) {
      break label$1
     }
     $1 = $1 + 4 | 0;
     continue;
    }
    break;
   };
   $2 = 0;
  }
  return $2;
 }

 function free_vmap_area_noflush($0) {
  var $1 = 0;
  $1 = HEAP32[20640] + (HEAP32[$0 + 4 >> 2] - HEAP32[$0 >> 2] >>> 16 | 0) | 0;
  HEAP32[20640] = $1;
  $0 = $0 + 32 | 0;
  llist_add_batch($0, $0, 82572);
  label$1 : {
   if ($1 >>> 0 < 513) {
    break label$1
   }
   if (!mutex_trylock(16180)) {
    break label$1
   }
   __purge_vmap_area_lazy();
   mutex_unlock(16180);
  }
 }

 function __insert_vmap_area($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  $4 = 82584;
  $5 = $0 + 4 | 0;
  label$1 : {
   while (1) {
    $1 = HEAP32[$4 >> 2];
    if ($1) {
     if (HEAPU32[$0 >> 2] < HEAPU32[$1 + -8 >> 2]) {
      $4 = $1 + 8 | 0
     } else {
      if (HEAPU32[$5 >> 2] <= HEAPU32[$1 + -12 >> 2]) {
       break label$1
      }
      $4 = $1 + 4 | 0;
     }
     $2 = $1;
     continue;
    }
    break;
   };
   $1 = $0 + 16 | 0;
   HEAP32[$1 >> 2] = 0;
   HEAP32[$1 + 4 >> 2] = 0;
   HEAP32[$0 + 12 >> 2] = $2;
   $2 = $0 + 12 | 0;
   HEAP32[$4 >> 2] = $2;
   rb_insert_color($2, 82584);
   $1 = $0 + 24 | 0;
   $2 = rb_prev($2);
   label$6 : {
    if ($2) {
     HEAP32[$0 + 28 >> 2] = $2 + 12;
     $0 = HEAP32[$2 + 12 >> 2];
     HEAP32[$1 >> 2] = $0;
     HEAP32[$2 + 12 >> 2] = $1;
     break label$6;
    }
    HEAP32[$0 + 28 >> 2] = 16144;
    $0 = HEAP32[4036];
    HEAP32[$1 >> 2] = $0;
    HEAP32[4036] = $1;
   }
   HEAP32[$0 + 4 >> 2] = $1;
   global$0 = $3 + 16 | 0;
   return;
  }
  HEAP32[$3 + 8 >> 2] = 24153;
  HEAP32[$3 + 4 >> 2] = 378;
  HEAP32[$3 >> 2] = 24120;
  printk(24089, $3);
  abort();
 }

 function vmalloc_init() {
  var $0 = 0, $1 = 0, $2 = 0;
  HEAP32[4038] = 16152;
  HEAP32[4039] = 16152;
  HEAP32[4040] = 0;
  HEAP32[4041] = -32;
  HEAP32[4044] = 79;
  HEAP32[4043] = 16168;
  HEAP32[4042] = 16168;
  $0 = 141168;
  while (1) {
   $0 = HEAP32[$0 >> 2];
   if ($0) {
    $1 = __kmalloc(48, 4227072);
    HEAP32[$1 + 8 >> 2] = 4;
    HEAP32[$1 + 36 >> 2] = $0;
    $2 = HEAP32[$0 + 4 >> 2];
    HEAP32[$1 >> 2] = $2;
    HEAP32[$1 + 4 >> 2] = HEAP32[$0 + 8 >> 2] + $2;
    __insert_vmap_area($1);
    continue;
   }
   break;
  };
  HEAP8[82564] = 1;
  HEAP32[20642] = 2139095040;
 }

 function free_work($0) {
  $0 = $0 | 0;
  var $1 = 0;
  $1 = $0 + -4 | 0;
  $0 = HEAP32[$1 >> 2];
  HEAP32[$1 >> 2] = 0;
  while (1) {
   if ($0) {
    $1 = HEAP32[$0 >> 2];
    __vunmap($0);
    $0 = $1;
    continue;
   }
   break;
  };
 }

 function __vunmap($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $1 = global$0 - 16 | 0;
  global$0 = $1;
  label$1 : {
   label$2 : {
    if (!$0 | $0 & 65535) {
     break label$2
    }
    $2 = HEAP32[find_vmap_area($0) + 36 >> 2];
    if (!$2) {
     break label$2
    }
    remove_vm_area($0);
    $5 = $2 + 20 | 0;
    $6 = $2 + 16 | 0;
    $0 = 0;
    while (1) {
     if ($0 >>> 0 < HEAPU32[$5 >> 2]) {
      $4 = HEAP32[HEAP32[$6 >> 2] + $3 >> 2];
      if (!$4) {
       break label$1
      }
      __free_pages($4, 0);
      $3 = $3 + 4 | 0;
      $0 = $0 + 1 | 0;
      continue;
     }
     break;
    };
    kvfree(HEAP32[$2 + 16 >> 2]);
    kfree($2);
   }
   global$0 = $1 + 16 | 0;
   return;
  }
  HEAP32[$1 + 8 >> 2] = 24190;
  HEAP32[$1 + 4 >> 2] = 1525;
  HEAP32[$1 >> 2] = 24120;
  printk(24089, $1);
  abort();
 }

 function remove_vm_area($0) {
  var $1 = 0;
  $0 = find_vmap_area($0);
  if (!(!$0 | !(HEAPU8[$0 + 8 | 0] & 4))) {
   HEAP32[$0 + 36 >> 2] = 0;
   $1 = $0 + 8 | 0;
   HEAP32[$1 >> 2] = HEAP32[$1 >> 2] & -7 | 2;
   vunmap_page_range();
   free_vmap_area_noflush($0);
  }
 }

 function vfree($0) {
  var $1 = 0;
  $1 = global$0 - 16 | 0;
  global$0 = $1;
  label$1 : {
   if (!(HEAP32[1] & 1048576)) {
    if (!$0) {
     break label$1
    }
    if (!(HEAP32[1] & 2096896)) {
     __vunmap($0);
     break label$1;
    }
    if (!llist_add_batch($0, $0, 16160)) {
     break label$1
    }
    queue_work_on(1, HEAP32[16393], 16164);
    break label$1;
   }
   HEAP32[$1 + 8 >> 2] = 24130;
   HEAP32[$1 + 4 >> 2] = 1586;
   HEAP32[$1 >> 2] = 24120;
   printk(24089, $1);
   abort();
  }
  global$0 = $1 + 16 | 0;
 }

 function __put_anon_vma($0) {
  var $1 = 0;
  $1 = HEAP32[$0 >> 2];
  if (rwsem_is_locked($1 + 4 | 0)) {
   __down_write_common(HEAP32[$0 >> 2] + 4 | 0);
   __up_write(HEAP32[$0 >> 2] + 4 | 0);
  }
  kmem_cache_free(HEAP32[20647], $0);
  label$2 : {
   if (($0 | 0) != ($1 | 0)) {
    $0 = HEAP32[$1 + 16 >> 2] + -1 | 0;
    HEAP32[$1 + 16 >> 2] = $0;
    if (!$0) {
     break label$2
    }
   }
   return;
  }
  if (rwsem_is_locked(HEAP32[$1 >> 2] + 4 | 0)) {
   __down_write_common(HEAP32[$1 >> 2] + 4 | 0);
   __up_write(HEAP32[$1 >> 2] + 4 | 0);
  }
  kmem_cache_free(HEAP32[20647], $1);
 }

 function page_lock_anon_vma_read($0) {
  $0 = $0 | 0;
  var $1 = 0, $2 = 0, $3 = 0;
  $1 = HEAP32[$0 + 12 >> 2];
  label$1 : {
   label$2 : {
    if (($1 & 3) != 1) {
     break label$2
    }
    if (!page_mapped($0)) {
     break label$2
    }
    $1 = $1 + -1 | 0;
    $2 = HEAP32[$1 >> 2] + 4 | 0;
    if (__down_read_trylock($2)) {
     if (page_mapped($0)) {
      break label$1
     }
     __up_read($2);
     break label$2;
    }
    $3 = HEAP32[$1 + 16 >> 2];
    if (!$3) {
     break label$2
    }
    $2 = $1 + 16 | 0;
    HEAP32[$2 >> 2] = $3 + 1;
    label$4 : {
     if (page_mapped($0)) {
      __down_read_common(HEAP32[$1 >> 2] + 4 | 0);
      $0 = HEAP32[$2 >> 2] + -1 | 0;
      HEAP32[$2 >> 2] = $0;
      if ($0) {
       break label$1
      }
      __up_read(HEAP32[$1 >> 2] + 4 | 0);
      break label$4;
     }
     $0 = HEAP32[$2 >> 2] + -1 | 0;
     HEAP32[$2 >> 2] = $0;
     if ($0) {
      break label$2
     }
    }
    __put_anon_vma($1);
   }
   $1 = 0;
  }
  return $1 | 0;
 }

 function page_referenced($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  $4 = global$0 - 48 | 0;
  global$0 = $4;
  if (HEAP32[$0 >> 2] & 65536 | HEAP32[$0 + 4 >> 2] & 1) {
   $5 = __page_mapcount($0)
  } else {
   $5 = HEAP32[$0 + 24 >> 2] + 1 | 0
  }
  HEAP32[$4 + 36 >> 2] = $2;
  HEAP32[$4 + 28 >> 2] = 0;
  HEAP32[$4 + 32 >> 2] = 0;
  HEAP32[$4 + 24 >> 2] = $5;
  $5 = 0;
  HEAP32[$3 >> 2] = 0;
  HEAP32[$4 + 16 >> 2] = 0;
  HEAP32[$4 + 12 >> 2] = 80;
  HEAP32[$4 + 8 >> 2] = 0;
  HEAP32[$4 + 4 >> 2] = 81;
  HEAP32[$4 >> 2] = $4 + 24;
  label$3 : {
   if (!page_mapped($0)) {
    break label$3
   }
   $6 = HEAP32[$0 + 4 >> 2];
   if (!(HEAP32[($6 & 1 ? $6 + -1 | 0 : $0) + 12 >> 2] & -4)) {
    break label$3
   }
   label$4 : {
    if ($1) {
     break label$4
    }
    $5 = 1;
    $1 = HEAP32[$0 + 4 >> 2];
    if (HEAP8[($1 & 1 ? $1 + -1 | 0 : $0) + 12 | 0] & 1) {
     break label$4
    }
    $1 = HEAP32[$0 + 4 >> 2];
    $6 = $1 & 1 ? $1 + -1 | 0 : $0;
    $1 = HEAP32[$6 >> 2];
    HEAP32[$4 + 44 >> 2] = $1;
    if (HEAP32[$4 + 44 >> 2] & 1) {
     break label$3
    }
    HEAP32[$6 >> 2] = $1 | 1;
    $1 = $1 & 1;
    if ($1) {
     break label$3
    }
    $7 = $1 ^ 1;
   }
   if ($2) {
    HEAP32[$4 + 16 >> 2] = 82
   }
   rmap_walk($0, $4);
   HEAP32[$3 >> 2] = HEAP32[$4 + 32 >> 2];
   if ($7) {
    unlock_page($0)
   }
   $5 = HEAP32[$4 + 28 >> 2];
  }
  global$0 = $4 + 48 | 0;
  return $5;
 }

 function page_referenced_one($0, $1, $2, $3) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  $3 = $3 | 0;
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  $4 = global$0 - 32 | 0;
  global$0 = $4;
  HEAP32[$4 + 20 >> 2] = 0;
  HEAP32[$4 + 24 >> 2] = 0;
  HEAP32[$4 + 12 >> 2] = 0;
  HEAP32[$4 + 16 >> 2] = 0;
  HEAP32[$4 + 8 >> 2] = $2;
  HEAP32[$4 + 4 >> 2] = $1;
  HEAP32[$4 >> 2] = $0;
  $0 = 0;
  $2 = $1 + 41 | 0;
  $6 = $4 + 16 | 0;
  $7 = $1 + 40 | 0;
  label$1 : {
   label$2 : {
    while (1) {
     if (page_vma_mapped_walk($4)) {
      if (HEAPU8[$2 | 0] & 32) {
       break label$2
      }
      $5 = HEAP32[$6 >> 2];
      label$5 : {
       if (!$5) {
        break label$5
       }
       if (!ptep_clear_flush_young($1, $5)) {
        break label$5
       }
       $0 = ((HEAP32[$7 >> 2] >>> 15 ^ -1) & 1) + $0 | 0;
      }
      HEAP32[$3 >> 2] = HEAP32[$3 >> 2] + -1;
      continue;
     }
     break;
    };
    if ($0) {
     HEAP32[$3 + 4 >> 2] = HEAP32[$3 + 4 >> 2] + 1;
     HEAP32[$3 + 8 >> 2] = HEAP32[$3 + 8 >> 2] | HEAP32[$1 + 40 >> 2];
    }
    $3 = HEAP32[$3 >> 2] != 0;
    break label$1;
   }
   label$7 : {
    if (!HEAP32[$4 + 20 >> 2]) {
     break label$7
    }
   }
   HEAP32[$3 + 8 >> 2] = HEAP32[$3 + 8 >> 2] | 8192;
   $3 = 0;
  }
  global$0 = $4 + 32 | 0;
  return $3 | 0;
 }

 function rmap_walk($0, $1) {
  var $2 = 0;
  $2 = HEAP32[$0 + 4 >> 2];
  if (!(HEAP8[($2 & 1 ? $2 + -1 | 0 : $0) + 12 | 0] & 1)) {
   rmap_walk_file($0, $1, 0);
   return;
  }
  rmap_walk_anon($0, $1, 0);
 }

 function rmap_walk_file($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0;
  label$1 : {
   $5 = page_mapping($0);
   if (!$5) {
    break label$1
   }
   $8 = $0 + 16 | 0;
   $6 = HEAP32[$8 >> 2];
   if (!$2) {
    __down_read_common($5 + 28 | 0)
   }
   $3 = vma_interval_tree_iter_first($5 + 20 | 0, $6, $6);
   $10 = $1 + 4 | 0;
   $11 = $1 + 8 | 0;
   while (1) {
    label$3 : {
     if (!$3) {
      break label$3
     }
     $7 = HEAP32[$8 >> 2];
     $12 = HEAP32[$3 + 76 >> 2];
     $4 = HEAP32[$3 >> 2];
     _cond_resched();
     $9 = HEAP32[$1 + 16 >> 2];
     label$5 : {
      if ($9) {
       if (FUNCTION_TABLE[$9]($3, HEAP32[$1 >> 2])) {
        break label$5
       }
      }
      $7 = $4 + ($7 - $12 << 16) | 0;
      if (!FUNCTION_TABLE[HEAP32[$10 >> 2]]($0, $3, $7 >>> 0 > $4 >>> 0 ? $7 : $4, HEAP32[$1 >> 2])) {
       break label$3
      }
      $4 = HEAP32[$11 >> 2];
      if (!$4) {
       break label$5
      }
      if (FUNCTION_TABLE[$4]($0)) {
       break label$3
      }
     }
     $3 = vma_interval_tree_iter_next($3, $6, $6);
     continue;
    }
    break;
   };
   if ($2) {
    break label$1
   }
   __up_read($5 + 28 | 0);
  }
 }

 function rmap_walk_anon($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0;
  label$1 : {
   label$2 : {
    label$3 : {
     label$4 : {
      if ($2) {
       $3 = page_anon_vma($0);
       break label$4;
      }
      $3 = HEAP32[$1 + 12 >> 2];
      if (!$3) {
       break label$3
      }
      $3 = FUNCTION_TABLE[$3]($0) | 0;
     }
     if ($3) {
      break label$2
     }
     break label$1;
    }
    $3 = page_anon_vma($0);
    if (!$3) {
     break label$1
    }
    __down_read_common(HEAP32[$3 >> 2] + 4 | 0);
   }
   $9 = $0 + 16 | 0;
   $5 = HEAP32[$9 >> 2];
   $6 = anon_vma_interval_tree_iter_first($3 + 28 | 0, $5, $5);
   $10 = $1 + 4 | 0;
   $11 = $1 + 8 | 0;
   while (1) {
    label$6 : {
     if (!$6) {
      break label$6
     }
     $12 = HEAP32[$9 >> 2];
     $4 = HEAP32[$6 >> 2];
     $13 = HEAP32[$4 + 76 >> 2];
     $8 = HEAP32[$4 >> 2];
     _cond_resched();
     $7 = HEAP32[$1 + 16 >> 2];
     label$8 : {
      if ($7) {
       if (FUNCTION_TABLE[$7]($4, HEAP32[$1 >> 2])) {
        break label$8
       }
      }
      $7 = $4;
      $4 = ($12 - $13 << 16) + $8 | 0;
      if (!FUNCTION_TABLE[HEAP32[$10 >> 2]]($0, $7, $4 >>> 0 > $8 >>> 0 ? $4 : $8, HEAP32[$1 >> 2])) {
       break label$6
      }
      $4 = HEAP32[$11 >> 2];
      if (!$4) {
       break label$8
      }
      if (FUNCTION_TABLE[$4]($0)) {
       break label$6
      }
     }
     $6 = anon_vma_interval_tree_iter_next($6, $5, $5);
     continue;
    }
    break;
   };
   if ($2) {
    break label$1
   }
   __up_read(HEAP32[$3 >> 2] + 4 | 0);
  }
 }

 function page_mkclean($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  $1 = global$0 - 48 | 0;
  global$0 = $1;
  HEAP32[$1 + 44 >> 2] = 0;
  HEAP32[$1 + 40 >> 2] = 83;
  HEAP32[$1 + 32 >> 2] = 0;
  HEAP32[$1 + 36 >> 2] = 0;
  HEAP32[$1 + 28 >> 2] = 84;
  $2 = HEAP32[$0 + 4 >> 2];
  $2 = HEAP32[($2 & 1 ? $2 + -1 | 0 : $0) >> 2];
  HEAP32[$1 + 24 >> 2] = $1 + 44;
  if ($2 & 1) {
   label$2 : {
    if (!page_mapped($0)) {
     break label$2
    }
    if (!page_mapping($0)) {
     break label$2
    }
    rmap_walk($0, $1 + 24 | 0);
    $3 = HEAP32[$1 + 44 >> 2];
   }
   global$0 = $1 + 48 | 0;
   return $3;
  }
  HEAP32[$1 + 8 >> 2] = 24237;
  HEAP32[$1 + 4 >> 2] = 975;
  HEAP32[$1 >> 2] = 24230;
  printk(24199, $1);
  abort();
 }

 function invalid_mkclean_vma($0, $1) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  return !(HEAPU8[$0 + 40 | 0] & 8) | 0;
 }

 function page_mkclean_one($0, $1, $2, $3) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  $3 = $3 | 0;
  var $4 = 0, wasm2js_i32$0 = 0, wasm2js_i32$1 = 0;
  $4 = global$0 - 32 | 0;
  global$0 = $4;
  HEAP32[$4 + 20 >> 2] = 0;
  HEAP32[$4 + 24 >> 2] = 1;
  HEAP32[$4 + 12 >> 2] = 0;
  HEAP32[$4 + 16 >> 2] = 0;
  HEAP32[$4 + 8 >> 2] = $2;
  HEAP32[$4 + 4 >> 2] = $1;
  HEAP32[$4 >> 2] = $0;
  $2 = $4 + 16 | 0;
  while (1) {
   if (page_vma_mapped_walk($4)) {
    $0 = HEAP32[$2 >> 2];
    if (!$0 | !(HEAPU8[$0 | 0] & 36)) {
     continue
    }
    (wasm2js_i32$0 = $0, wasm2js_i32$1 = ptep_clear_flush($1, $0) & -37), HEAP32[wasm2js_i32$0 >> 2] = wasm2js_i32$1;
    HEAP32[$3 >> 2] = HEAP32[$3 >> 2] + 1;
    continue;
   }
   break;
  };
  global$0 = $4 + 32 | 0;
  return 1;
 }

 function page_remove_rmap($0) {
  var $1 = 0;
  label$1 : {
   $1 = HEAP32[$0 + 4 >> 2];
   label$2 : {
    if (!(HEAP8[($1 & 1 ? $1 + -1 | 0 : $0) + 12 | 0] & 1)) {
     $1 = HEAP32[$0 + 24 >> 2];
     HEAP32[$0 + 24 >> 2] = $1 + -1;
     if (($1 | 0) > 0) {
      break label$2
     }
     HEAP32[35605] = HEAP32[35605] + -1;
     HEAP32[20687] = HEAP32[20687] + -1;
     $1 = HEAP32[$0 + 4 >> 2];
     if (!(HEAP32[($1 & 1 ? $1 + -1 | 0 : $0) >> 2] & 2097152)) {
      break label$2
     }
     break label$1;
    }
    $1 = HEAP32[$0 + 24 >> 2];
    HEAP32[$0 + 24 >> 2] = $1 + -1;
    if (($1 | 0) > 0) {
     break label$2
    }
    HEAP32[35604] = HEAP32[35604] + -1;
    HEAP32[20686] = HEAP32[20686] + -1;
    $1 = HEAP32[$0 + 4 >> 2];
    if (HEAP32[($1 & 1 ? $1 + -1 | 0 : $0) >> 2] & 2097152) {
     break label$1
    }
   }
   return;
  }
  clear_page_mlock($0);
 }

 function try_to_unmap($0) {
  var $1 = 0;
  $1 = global$0 - 32 | 0;
  global$0 = $1;
  HEAP32[$1 + 24 >> 2] = 0;
  HEAP32[$1 + 20 >> 2] = 80;
  HEAP32[$1 + 16 >> 2] = 85;
  HEAP32[$1 + 12 >> 2] = 86;
  HEAP32[$1 + 8 >> 2] = 64;
  rmap_walk($0, $1 + 8 | 0);
  if (HEAP32[$0 >> 2] & 65536 | HEAP32[$0 + 4 >> 2] & 1) {
   $0 = __page_mapcount($0)
  } else {
   $0 = HEAP32[$0 + 24 >> 2] + 1 | 0
  }
  global$0 = $1 + 32 | 0;
  return !$0;
 }

 function page_mapcount_is_zero($0) {
  $0 = $0 | 0;
  if (HEAP32[$0 >> 2] & 65536 | HEAP32[$0 + 4 >> 2] & 1) {
   $0 = __page_mapcount($0)
  } else {
   $0 = HEAP32[$0 + 24 >> 2] + 1 | 0
  }
  return !$0 | 0;
 }

 function try_to_unmap_one($0, $1, $2, $3) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  $3 = $3 | 0;
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0, $15 = 0, $16 = 0, $17 = 0, $18 = 0, $19 = 0, $20 = 0, $21 = 0, $22 = 0, $23 = 0;
  $5 = global$0 - 32 | 0;
  global$0 = $5;
  $8 = HEAP32[$1 + 32 >> 2];
  HEAP32[$5 + 20 >> 2] = 0;
  HEAP32[$5 + 24 >> 2] = 0;
  HEAP32[$5 + 12 >> 2] = 0;
  HEAP32[$5 + 16 >> 2] = 0;
  HEAP32[$5 + 8 >> 2] = $2;
  HEAP32[$5 + 4 >> 2] = $1;
  HEAP32[$5 >> 2] = $0;
  $13 = $3 & 2;
  label$1 : {
   if ($13) {
    $10 = 1;
    if (!(HEAPU8[$1 + 41 | 0] & 32)) {
     break label$1
    }
   }
   $9 = $8 + 68 | 0;
   $17 = $3 & 16;
   $18 = $3 & 8;
   $19 = $1 + 41 | 0;
   $20 = $8 + 340 | 0;
   $11 = $8 + 344 | 0;
   $21 = $8 + 352 | 0;
   $14 = $8 + 76 | 0;
   $3 = $0 + 4 | 0;
   $10 = 1;
   $22 = $8 + 72 | 0;
   $15 = $8 + 348 | 0;
   label$3 : {
    label$4 : {
     label$5 : {
      while (1) {
       if (!page_vma_mapped_walk($5)) {
        break label$1
       }
       label$7 : {
        if (!$18) {
         if (HEAPU8[$19 | 0] & 32) {
          break label$7
         }
         if ($13) {
          continue
         }
        }
        $7 = $5 + 16 | 0;
        $2 = HEAP32[$7 >> 2];
        $6 = HEAPU16[$2 + 2 >> 1];
        $4 = ($0 - HEAP32[20650] | 0) / -36 | 0;
        $5 + 8 | 0;
        if (!$17) {
         if (ptep_clear_flush_young($1, $2)) {
          break label$5
         }
         $2 = HEAP32[$7 >> 2];
        }
        $4 = Math_imul($4, 36);
        $16 = ptep_clear_flush($1, $2);
        if ($16 & 32) {
         set_page_dirty($0)
        }
        $12 = Math_imul($6, 36);
        $6 = $0 + $4 | 0;
        $2 = HEAP32[$11 >> 2];
        $4 = HEAP32[$20 >> 2];
        $23 = (($2 | 0) > 0 ? $2 : 0) + (($4 | 0) > 0 ? $4 : 0) | 0;
        $4 = HEAP32[$21 >> 2];
        $4 = $23 + (($4 | 0) > 0 ? $4 : 0) | 0;
        if (HEAPU32[$14 >> 2] < $4 >>> 0) {
         HEAP32[$14 >> 2] = $4
        }
        $12 = $6 + $12 | 0;
        $6 = HEAP32[$3 >> 2];
        label$12 : {
         if (!(HEAP8[($6 & 1 ? $6 + -1 | 0 : $0) + 12 | 0] & 1)) {
          $2 = HEAP32[$3 >> 2];
          $2 = ((HEAP32[($2 & 1 ? $2 + -1 | 0 : $0) >> 2] << 12 >> 31 & 12) + $8 | 0) + 340 | 0;
          HEAP32[$2 >> 2] = HEAP32[$2 >> 2] + -1;
          break label$12;
         }
         $6 = HEAP32[$3 >> 2];
         if (HEAP32[($6 & 1 ? $6 + -1 | 0 : $0) >> 2] & 524288) {
          break label$3
         }
         $6 = HEAP32[$12 + 20 >> 2];
         $4 = HEAP32[$3 >> 2];
         if (!(HEAP32[($4 & 1 ? $4 + -1 | 0 : $0) >> 2] & 524288)) {
          $7 = HEAP32[$3 >> 2];
          if (HEAP32[($7 & 1 ? $7 + -1 | 0 : $0) >> 2] & 8) {
           break label$4
          }
          HEAP32[$11 >> 2] = $2 + -1;
          break label$12;
         }
         $4 = $11;
         if (($9 | 0) == HEAP32[$9 >> 2]) {
          if (($9 | 0) == HEAP32[$9 >> 2]) {
           $2 = HEAP32[3951];
           HEAP32[$2 + 4 >> 2] = $9;
           HEAP32[$9 >> 2] = $2;
           HEAP32[3951] = $9;
           HEAP32[$22 >> 2] = 15804;
          }
          $2 = HEAP32[$11 >> 2];
         }
         HEAP32[$4 >> 2] = $2 + -1;
         HEAP32[$15 >> 2] = HEAP32[$15 >> 2] + 1;
         HEAP32[HEAP32[$7 >> 2] >> 2] = $6 >>> 26 & 31 | $6 << 13;
        }
        page_remove_rmap($12);
        $2 = HEAP32[$3 >> 2];
        $2 = $2 & 1 ? $2 + -1 | 0 : $0;
        $7 = HEAP32[$2 + 28 >> 2] + -1 | 0;
        HEAP32[$2 + 28 >> 2] = $7;
        if ($7) {
         continue
        }
        __put_page($2);
        continue;
       }
       break;
      };
      mlock_vma_page($0);
      $10 = 0;
      break label$1;
     }
     $10 = 0;
     break label$1;
    }
    HEAP32[HEAP32[$5 + 16 >> 2] >> 2] = $16;
    $1 = HEAP32[$0 + 4 >> 2];
    $0 = $1 & 1 ? $1 + -1 | 0 : $0;
    HEAP32[$0 >> 2] = HEAP32[$0 >> 2] | 524288;
    $10 = 0;
    break label$1;
   }
   $10 = 0;
   if (!HEAP32[$5 + 20 >> 2]) {
    break label$1
   }
  }
  global$0 = $5 + 32 | 0;
  return $10 | 0;
 }

 function invalid_migration_vma($0, $1) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  return (HEAP32[$0 + 40 >> 2] & 98560) == 98560 | 0;
 }

 function ptep_clear_flush_young($0, $1) {
  var $2 = 0;
  $2 = HEAP32[$1 >> 2];
  if ($2 & 16) {
   HEAP32[$1 >> 2] = $2 & -17;
   local_flush_tlb_page($0);
   $0 = 1;
  } else {
   $0 = 0
  }
  return $0;
 }

 function ptep_clear_flush($0, $1) {
  var $2 = 0;
  $2 = HEAP32[$1 >> 2];
  HEAP32[$1 >> 2] = 0;
  local_flush_tlb_page($0);
  return $2;
 }

 function page_vma_mapped_walk($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0;
  $1 = HEAP32[$0 + 16 >> 2];
  label$1 : {
   label$2 : {
    if (HEAP32[$0 + 12 >> 2]) {
     if ($1) {
      break label$2
     }
     $1 = 0;
     if (!HEAP32[$0 + 20 >> 2]) {
      break label$1
     }
     return 0;
    }
    if ($1) {
     break label$2
    }
    $1 = 0;
    HEAP32[$0 + 12 >> 2] = 0;
    $2 = HEAP32[0];
    if (!$2) {
     break label$1
    }
    $3 = $0 + 16 | 0;
    $1 = $2 & -65536 | HEAP32[$0 + 8 >> 2] >>> 14 & 124;
    HEAP32[$3 >> 2] = $1;
    $4 = HEAP32[$0 + 24 >> 2];
    label$4 : {
     if ($4 & 1) {
      break label$4
     }
     $5 = HEAP32[$1 >> 2];
     $1 = $5 & 512;
     if (!($4 & 2)) {
      if (!$1) {
       break label$2
      }
      break label$4;
     }
     if ($1 | !$5) {
      break label$2
     }
    }
    HEAP32[$0 + 20 >> 2] = (HEAP32[20650] + Math_imul($2 >>> 16 | 0, 36) | 0) + 20;
    if (HEAPU8[$0 + 24 | 0] & 2) {
     break label$2
    }
    $2 = HEAP32[HEAP32[$3 >> 2] >> 2];
    if (!($2 & 512)) {
     break label$2
    }
    $1 = 1;
    if (((HEAP32[$0 >> 2] - HEAP32[20650] | 0) / 36 | 0) == ($2 >>> 16 | 0)) {
     break label$1
    }
   }
   $1 = 0;
   if (!HEAP32[$0 + 20 >> 2]) {
    break label$1
   }
  }
  return $1;
 }

 function clear_page_mlock($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  $2 = global$0 - 16 | 0;
  global$0 = $2;
  $1 = HEAP32[$0 + 4 >> 2];
  $3 = $1 & 1 ? $1 + -1 | 0 : $0;
  $1 = HEAP32[$3 >> 2];
  HEAP32[$2 + 12 >> 2] = $1;
  label$1 : {
   if (!(HEAP32[$2 + 12 >> 2] & 2097152)) {
    break label$1
   }
   HEAP32[$3 >> 2] = $1 & -2097153;
   if (!($1 & 2097152)) {
    break label$1
   }
   HEAP32[20667] = HEAP32[20667] + -1;
   $1 = Math_imul(HEAP32[$0 >> 2] >>> 31 | 0, 516) + 141672 | 0;
   HEAP32[$1 >> 2] = HEAP32[$1 >> 2] + -1;
   if (isolate_lru_page($0)) {
    $1 = HEAP32[$0 + 4 >> 2];
    $1 & 1 ? $1 + -1 | 0 : $0;
    break label$1;
   }
   putback_lru_page($0);
  }
  global$0 = $2 + 16 | 0;
 }

 function mlock_vma_page($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  $2 = global$0 - 16 | 0;
  global$0 = $2;
  $1 = HEAP32[$0 + 4 >> 2];
  if (HEAP32[($1 & 1 ? $1 + -1 | 0 : $0) >> 2] & 1) {
   $1 = HEAP32[$0 + 4 >> 2];
   $3 = $1 & 1 ? $1 + -1 | 0 : $0;
   $1 = HEAP32[$3 >> 2];
   HEAP32[$2 + 12 >> 2] = $1;
   label$2 : {
    if (HEAP32[$2 + 12 >> 2] & 2097152) {
     break label$2
    }
    HEAP32[$3 >> 2] = $1 | 2097152;
    if ($1 & 2097152) {
     break label$2
    }
    HEAP32[20667] = HEAP32[20667] + 1;
    $1 = Math_imul(HEAP32[$0 >> 2] >>> 31 | 0, 516) + 141672 | 0;
    HEAP32[$1 >> 2] = HEAP32[$1 >> 2] + 1;
    if (isolate_lru_page($0)) {
     break label$2
    }
    putback_lru_page($0);
   }
   global$0 = $2 + 16 | 0;
   return;
  }
  HEAP32[$2 + 8 >> 2] = 24289;
  HEAP32[$2 + 4 >> 2] = 91;
  HEAP32[$2 >> 2] = 24281;
  printk(24250, $2);
  abort();
 }

 function __dump_page($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $2 = global$0 - 96 | 0;
  global$0 = $2;
  label$1 : {
   if (HEAP32[$0 >> 2] == -1) {
    HEAP32[$2 + 16 >> 2] = $0;
    printk(25960, $2 + 16 | 0);
    break label$1;
   }
   $4 = HEAP32[$0 + 4 >> 2];
   $3 = 0;
   label$3 : {
    if (HEAP32[($4 & 1 ? $4 + -1 | 0 : $0) >> 2] & 512) {
     break label$3
    }
    $3 = HEAP32[$0 + 24 >> 2] + 1 | 0;
    if (!(HEAP32[$0 >> 2] & 65536 | HEAP32[$0 + 4 >> 2] & 1)) {
     break label$3
    }
    $3 = __page_mapcount($0);
   }
   $4 = HEAP32[$0 + 28 >> 2];
   $5 = $0 + 12 | 0;
   $6 = HEAP32[$5 + 4 >> 2];
   HEAP32[$2 + 76 >> 2] = HEAP32[$5 >> 2];
   HEAP32[$2 + 80 >> 2] = $6;
   HEAP32[$2 + 72 >> 2] = $3;
   HEAP32[$2 + 68 >> 2] = $4;
   HEAP32[$2 + 64 >> 2] = $0;
   printk(26001, $2 - -64 | 0);
   if (!(HEAP32[$0 + 4 >> 2] & 1 ? 0 : !(HEAP32[$0 >> 2] & 65536))) {
    $3 = HEAP32[$0 + 4 >> 2];
    HEAP32[$2 + 48 >> 2] = HEAP32[($3 & 1 ? $3 + -1 | 0 : $0) + 48 >> 2] + 1;
    printk(26056, $2 + 48 | 0);
   }
   printk(26081, 0);
   $3 = HEAP32[$0 >> 2];
   HEAP32[$2 + 36 >> 2] = $0;
   HEAP32[$2 + 32 >> 2] = $3;
   printk(26085, $2 + 32 | 0);
  }
  print_hex_dump($0);
  if ($1) {
   HEAP32[$2 >> 2] = $1;
   printk(26115, $2);
  }
  global$0 = $2 + 96 | 0;
 }

 function workingset_eviction($0) {
  var $1 = 0, $2 = 0;
  $1 = HEAP32[35586] + 1 | 0;
  HEAP32[35586] = $1;
  $2 = HEAP32[$0 + 4 >> 2];
  return (HEAP32[($2 & 1 ? $2 + -1 | 0 : $0) >> 2] >>> 6 & 1 | (HEAP32[35562] | $1 >>> HEAP32[20652]) << 1) << 1 | 1;
 }

 function workingset_update_node($0) {
  $0 = $0 | 0;
  var $1 = 0;
  label$1 : {
   $1 = HEAPU8[$0 + 2 | 0];
   if (!(!$1 | ($1 | 0) != HEAPU8[$0 + 3 | 0])) {
    $1 = HEAP32[$0 + 12 >> 2];
    $0 = $0 + 12 | 0;
    if (($1 | 0) != ($0 | 0)) {
     break label$1
    }
    list_lru_add($0);
    HEAP32[35599] = HEAP32[35599] + 1;
    HEAP32[20681] = HEAP32[20681] + 1;
    return;
   }
   $1 = HEAP32[$0 + 12 >> 2];
   $0 = $0 + 12 | 0;
   if (($1 | 0) == ($0 | 0)) {
    break label$1
   }
   list_lru_del($0);
   HEAP32[35599] = HEAP32[35599] + -1;
   HEAP32[20681] = HEAP32[20681] + -1;
  }
 }

 function list_lru_add($0) {
  var $1 = 0, $2 = 0;
  if (($0 | 0) != HEAP32[$0 >> 2]) {
   return
  }
  $1 = HEAP32[20651];
  $2 = HEAP32[$1 + 4 >> 2];
  HEAP32[$1 + 4 >> 2] = $0;
  HEAP32[$0 >> 2] = $1;
  HEAP32[$2 >> 2] = $0;
  HEAP32[$0 + 4 >> 2] = $2;
  HEAP32[$1 + 8 >> 2] = HEAP32[$1 + 8 >> 2] + 1;
  HEAP32[$1 + 12 >> 2] = HEAP32[$1 + 12 >> 2] + 1;
 }

 function list_lru_del($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  $1 = HEAP32[20651];
  $2 = HEAP32[$0 >> 2];
  if (($0 | 0) != ($2 | 0)) {
   $3 = HEAP32[$0 + 4 >> 2];
   HEAP32[$3 >> 2] = $2;
   HEAP32[$2 + 4 >> 2] = $3;
   HEAP32[$1 + 8 >> 2] = HEAP32[$1 + 8 >> 2] + -1;
   HEAP32[$1 + 12 >> 2] = HEAP32[$1 + 12 >> 2] + -1;
   HEAP32[$0 >> 2] = $0;
   HEAP32[$0 + 4 >> 2] = $0;
  }
 }

 function vma_interval_tree_iter_first($0, $1, $2) {
  var $3 = 0, $4 = 0;
  $3 = HEAP32[$0 >> 2];
  if (!(!$3 | HEAPU32[$3 + 12 >> 2] < $1 >>> 0 | HEAPU32[HEAP32[$0 + 4 >> 2] + 32 >> 2] > $2 >>> 0)) {
   $4 = vma_interval_tree_subtree_search($3 + -44 | 0, $1, $2)
  }
  return $4;
 }

 function vma_interval_tree_subtree_search($0, $1, $2) {
  var $3 = 0, $4 = 0;
  label$1 : {
   while (1) {
    $3 = HEAP32[$0 + 52 >> 2];
    if (!(!$3 | HEAPU32[$3 + 12 >> 2] < $1 >>> 0)) {
     $0 = $3 + -44 | 0;
     continue;
    }
    $3 = 0;
    $4 = HEAP32[$0 + 76 >> 2];
    if ($4 >>> 0 > $2 >>> 0) {
     break label$1
    }
    if (($4 + (HEAP32[$0 + 4 >> 2] - HEAP32[$0 >> 2] >>> 16 | 0) | 0) + -1 >>> 0 < $1 >>> 0) {
     $0 = HEAP32[$0 + 48 >> 2];
     if (!$0 | HEAPU32[$0 + 12 >> 2] < $1 >>> 0) {
      break label$1
     }
     $0 = $0 + -44 | 0;
     continue;
    }
    break;
   };
   $3 = $0;
  }
  return $3;
 }

 function vma_interval_tree_iter_next($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $3 = HEAP32[$0 + 48 >> 2];
  label$1 : {
   label$2 : {
    while (1) {
     if (HEAPU32[$3 + 12 >> 2] >= $1 >>> 0 ? $3 : 0) {
      break label$1
     }
     while (1) {
      $4 = HEAP32[$0 + 44 >> 2] & -4;
      if (!$4) {
       break label$2
      }
      $5 = $0 + 44 | 0;
      $0 = $4 + -44 | 0;
      $3 = HEAP32[$4 + 4 >> 2];
      if (($5 | 0) == ($3 | 0)) {
       continue
      }
      break;
     };
     $5 = HEAP32[$4 + 32 >> 2];
     if ($5 >>> 0 > $2 >>> 0) {
      break label$2
     }
     if (($5 + (HEAP32[$4 + -40 >> 2] - HEAP32[$0 >> 2] >>> 16 | 0) | 0) + -1 >>> 0 < $1 >>> 0) {
      continue
     }
     break;
    };
    $6 = $0;
   }
   return $6;
  }
  return vma_interval_tree_subtree_search($3 + -44 | 0, $1, $2);
 }

 function anon_vma_interval_tree_iter_first($0, $1, $2) {
  var $3 = 0, $4 = 0;
  $3 = HEAP32[$0 >> 2];
  if (!(!$3 | HEAPU32[$3 + 12 >> 2] < $1 >>> 0 | HEAPU32[HEAP32[HEAP32[$0 + 4 >> 2] + -16 >> 2] + 76 >> 2] > $2 >>> 0)) {
   $4 = __anon_vma_interval_tree_subtree_search($3 + -16 | 0, $1, $2)
  }
  return $4;
 }

 function __anon_vma_interval_tree_subtree_search($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0;
  label$1 : {
   while (1) {
    $3 = HEAP32[$0 + 24 >> 2];
    if (!(!$3 | HEAPU32[$3 + 12 >> 2] < $1 >>> 0)) {
     $0 = $3 + -16 | 0;
     continue;
    }
    $3 = 0;
    $4 = HEAP32[$0 >> 2];
    $5 = HEAP32[$4 + 76 >> 2];
    if ($5 >>> 0 > $2 >>> 0) {
     break label$1
    }
    if (((HEAP32[$4 + 4 >> 2] - HEAP32[$4 >> 2] >>> 16 | 0) + $5 | 0) + -1 >>> 0 < $1 >>> 0) {
     $0 = HEAP32[$0 + 20 >> 2];
     if (!$0 | HEAPU32[$0 + 12 >> 2] < $1 >>> 0) {
      break label$1
     }
     $0 = $0 + -16 | 0;
     continue;
    }
    break;
   };
   $3 = $0;
  }
  return $3;
 }

 function anon_vma_interval_tree_iter_next($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $3 = HEAP32[$0 + 20 >> 2];
  label$1 : {
   label$2 : {
    while (1) {
     if (HEAPU32[$3 + 12 >> 2] >= $1 >>> 0 ? $3 : 0) {
      break label$1
     }
     while (1) {
      $3 = HEAP32[$0 + 16 >> 2] & -4;
      if (!$3) {
       break label$2
      }
      $4 = $0 + 16 | 0;
      $0 = $3 + -16 | 0;
      $3 = HEAP32[$3 + 4 >> 2];
      if (($4 | 0) == ($3 | 0)) {
       continue
      }
      break;
     };
     $4 = HEAP32[$0 >> 2];
     $5 = HEAP32[$4 + 76 >> 2];
     if ($5 >>> 0 > $2 >>> 0) {
      break label$2
     }
     if (((HEAP32[$4 + 4 >> 2] - HEAP32[$4 >> 2] >>> 16 | 0) + $5 | 0) + -1 >>> 0 < $1 >>> 0) {
      continue
     }
     break;
    };
    $6 = $0;
   }
   return $6;
  }
  return __anon_vma_interval_tree_subtree_search($3 + -16 | 0, $1, $2);
 }

 function slab_is_available() {
  return HEAPU32[20654] > 2;
 }

 function congestion_wait() {
  var $0 = 0, $1 = 0;
  $0 = global$0 - 32 | 0;
  global$0 = $0;
  $1 = $0 + 20 | 0;
  HEAP32[$0 + 24 >> 2] = $1;
  HEAP32[$0 + 8 >> 2] = 0;
  HEAP32[$0 + 20 >> 2] = $1;
  HEAP32[$0 + 16 >> 2] = 76;
  HEAP32[$0 + 12 >> 2] = HEAP32[2];
  prepare_to_wait($0 + 8 | 0);
  io_schedule_timeout();
  finish_wait($0 + 8 | 0);
  global$0 = $0 + 32 | 0;
 }

 function wait_iff_congested() {
  var $0 = 0, $1 = 0;
  $0 = global$0 - 32 | 0;
  global$0 = $0;
  $1 = $0 + 20 | 0;
  HEAP32[$0 + 24 >> 2] = $1;
  HEAP32[$0 + 8 >> 2] = 0;
  HEAP32[$0 + 20 >> 2] = $1;
  HEAP32[$0 + 16 >> 2] = 76;
  HEAP32[$0 + 12 >> 2] = HEAP32[2];
  label$1 : {
   if (HEAP32[20656]) {
    prepare_to_wait($0 + 8 | 0);
    io_schedule_timeout();
    finish_wait($0 + 8 | 0);
    break label$1;
   }
   _cond_resched();
  }
  global$0 = $0 + 32 | 0;
 }

 function next_zone($0) {
  return HEAP32[$0 + 24 >> 2] + 516 >>> 0 > $0 >>> 0 ? $0 + 516 | 0 : 0;
 }

 function __next_zones_zonelist($0, $1, $2) {
  var $3 = 0;
  if ($2) {
   $2 = $0 + 4 | 0;
   while (1) {
    $0 = HEAP32[$2 >> 2];
    $3 = $2 + 8 | 0;
    $2 = $3;
    if ($0 >>> 0 > $1 >>> 0) {
     continue
    }
    break;
   };
   return $3 + -12 | 0;
  }
  $2 = $0 + 4 | 0;
  while (1) {
   $0 = HEAP32[$2 >> 2];
   $3 = $2 + 8 | 0;
   $2 = $3;
   if ($0 >>> 0 > $1 >>> 0) {
    continue
   }
   break;
  };
  return $3 + -12 | 0;
 }

 function lruvec_init() {
  var $0 = 0, $1 = 0;
  memset(142288, 0, 64);
  while (1) {
   if (($1 | 0) != 40) {
    $0 = $1 + 142288 | 0;
    HEAP32[$0 + 4 >> 2] = $0;
    HEAP32[$0 >> 2] = $0;
    $1 = $1 + 8 | 0;
    continue;
   }
   break;
  };
 }

 function kvfree($0) {
  if (!($0 >>> 0 < 2136997888 | $0 >>> 0 > 2139095039)) {
   vfree($0);
   return;
  }
  kfree($0);
 }

 function page_mapped($0) {
  var $1 = 0;
  label$1 : {
   if (HEAP32[$0 + 4 >> 2] & 1 ? 0 : !(HEAP32[$0 >> 2] & 65536)) {
    break label$1
   }
   $1 = HEAP32[$0 + 4 >> 2];
   $0 = $1 & 1 ? $1 + -1 | 0 : $0;
   if (HEAP32[$0 + 48 >> 2] <= -1) {
    break label$1
   }
   return 1;
  }
  return HEAP32[$0 + 24 >> 2] > -1;
 }

 function page_anon_vma($0) {
  var $1 = 0;
  $1 = HEAP32[$0 + 4 >> 2];
  $0 = HEAP32[($1 & 1 ? $1 + -1 | 0 : $0) + 12 >> 2];
  return ($0 & 3) == 1 ? $0 & -4 : 0;
 }

 function page_mapping($0) {
  var $1 = 0, $2 = 0;
  $1 = HEAP32[$0 + 4 >> 2];
  $0 = $1 & 1 ? $1 + -1 | 0 : $0;
  $1 = HEAP32[$0 + 4 >> 2];
  label$1 : {
   if (HEAP32[($1 & 1 ? $1 + -1 | 0 : $0) >> 2] & 512) {
    break label$1
   }
   $0 = HEAP32[$0 + 12 >> 2];
   if ($0 & 1) {
    break label$1
   }
   $2 = $0 & -4;
  }
  return $2;
 }

 function __page_mapcount($0) {
  var $1 = 0, $2 = 0;
  $1 = HEAP32[$0 + 24 >> 2];
  $2 = HEAP32[$0 + 4 >> 2];
  if (!(HEAP8[($2 & 1 ? $2 + -1 | 0 : $0) + 12 | 0] & 1)) {
   return $1 + 1 | 0
  }
  $2 = $1;
  $1 = HEAP32[$0 + 4 >> 2];
  return ($2 + HEAP32[($1 & 1 ? $1 + -1 | 0 : $0) + 48 >> 2] | 0) + 2 | 0;
 }

 function lruvec_lru_size($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $5 = $0 + -640 | 0;
  $3 = $1 << 2;
  $0 = HEAP32[$3 + 82688 >> 2];
  while (1) {
   $1 = Math_imul($2, 516) + $5 | 0;
   label$2 : {
    while (1) {
     $2 = $2 + 1 | 0;
     if (($2 | 0) > 1) {
      break label$2
     }
     $6 = $1 + 84 | 0;
     $4 = $1 + 516 | 0;
     $1 = $4;
     if (!HEAP32[$6 >> 2]) {
      continue
     }
     break;
    };
    $1 = HEAP32[$3 + $4 >> 2];
    $0 = $0 - ($1 >>> 0 < $0 >>> 0 ? $1 : $0) | 0;
    continue;
   }
   break;
  };
  return $0;
 }

 function shrink_slab($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0, $15 = 0, $16 = 0, $17 = 0, $18 = 0;
  $5 = global$0 - 48 | 0;
  global$0 = $5;
  if (__down_read_trylock(16528)) {
   $17 = $5 + 32 | 0;
   $13 = $5 + 24 | 0;
   $15 = $5 + 28 | 0;
   $10 = 16540;
   while (1) {
    $10 = HEAP32[$10 >> 2];
    if (($10 | 0) != 16540) {
     HEAP32[$17 >> 2] = 0;
     HEAP32[$13 >> 2] = 0;
     HEAP32[$13 + 4 >> 2] = 0;
     HEAP32[$5 + 16 >> 2] = $0;
     HEAP32[$5 + 20 >> 2] = $1;
     $4 = HEAP32[$10 + -4 >> 2];
     $3 = HEAP32[$10 + -12 >> 2];
     $14 = $10 + -20 | 0;
     $7 = FUNCTION_TABLE[HEAP32[$14 >> 2]]($14, $5 + 16 | 0) | 0;
     label$5 : {
      if (!($7 ? ($7 | 0) != -2 : 0)) {
       $4 = $7;
       break label$5;
      }
      $11 = $3 ? $3 : 128;
      $16 = (0 - ($4 & 1) & $1) << 2;
      $3 = $16 + HEAP32[$10 + 8 >> 2] | 0;
      $12 = HEAP32[$3 >> 2];
      HEAP32[$3 >> 2] = 0;
      label$8 : {
       label$9 : {
        $4 = HEAP32[$10 + -8 >> 2];
        label$10 : {
         if ($4) {
          $6 = $7 >> $2;
          $3 = $6 >> 31 << 2 | $6 >>> 30;
          $6 = $6 << 2;
          HEAP32[$5 + 40 >> 2] = $6;
          HEAP32[$5 + 44 >> 2] = $3;
          if (!$3 & $6 >>> 0 > 4294967295 | $3 >>> 0 > 0) {
           break label$9
          }
          $4 = ($6 >>> 0) / ($4 >>> 0) | 0;
          $6 = 0;
          break label$10;
         }
         $3 = ($7 | 0) / 2 | 0;
         $4 = $3;
         $6 = $3 >> 31;
        }
        HEAP32[$5 + 40 >> 2] = $4;
        HEAP32[$5 + 44 >> 2] = $6;
        break label$8;
       }
       __div64_32($5 + 40 | 0, $4);
       $4 = HEAP32[$5 + 40 >> 2];
       $6 = HEAP32[$5 + 44 >> 2];
      }
      $3 = ($7 | 0) < ($11 | 0) ? $7 : $11;
      $8 = $3;
      $9 = $3;
      $3 = $3 >> 31;
      $8 = ($3 | 0) == ($6 | 0) & $4 >>> 0 > $8 >>> 0 | $6 >>> 0 > $3 >>> 0;
      $4 = $8 ? $4 : $9;
      $3 = $8 ? $6 : $3;
      $6 = $3;
      HEAP32[$5 + 40 >> 2] = $4;
      HEAP32[$5 + 44 >> 2] = $3;
      $3 = $4 + $12 | 0;
      label$12 : {
       if (($3 | 0) > -1) {
        $12 = $3;
        break label$12;
       }
       $4 = HEAP32[$10 + -16 >> 2];
       HEAP32[$5 + 4 >> 2] = $3;
       HEAP32[$5 >> 2] = $4;
       printk(26211, $5);
       $4 = HEAP32[$5 + 40 >> 2];
       $6 = HEAP32[$5 + 44 >> 2];
       $3 = $7;
      }
      $8 = ($7 | 0) / 4 | 0;
      $9 = $8;
      $8 = $8 >> 31;
      if (!(($8 | 0) == ($6 | 0) & $4 >>> 0 >= $9 >>> 0 | $6 >>> 0 > $8 >>> 0)) {
       $4 = ($7 | 0) / 2 | 0;
       $3 = ($3 | 0) < ($4 | 0) ? $3 : $4;
      }
      $4 = $7 << 1;
      $3 = ($3 | 0) > ($4 | 0) ? $4 : $3;
      $8 = $10 + -16 | 0;
      $6 = 0;
      $4 = 0;
      while (1) {
       label$15 : {
        if (($3 | 0) < ($7 | 0) ? ($3 | 0) < ($11 | 0) : 0) {
         break label$15
        }
        $9 = ($11 | 0) < ($3 | 0) ? $11 : $3;
        HEAP32[$15 >> 2] = $9;
        HEAP32[$13 >> 2] = $9;
        $9 = FUNCTION_TABLE[HEAP32[$8 >> 2]]($14, $5 + 16 | 0) | 0;
        if (($9 | 0) == -1) {
         break label$15
        }
        $4 = $4 + $9 | 0;
        $9 = HEAP32[$15 >> 2];
        $6 = $9 + $6 | 0;
        $3 = $3 - $9 | 0;
        _cond_resched();
        continue;
       }
       break;
      };
      $3 = HEAP32[$10 + 8 >> 2] + $16 | 0;
      $7 = ($12 | 0) < ($6 | 0) ? 0 : $12 - $6 | 0;
      if (($7 | 0) >= 1) {
       HEAP32[$3 >> 2] = $7 + HEAP32[$3 >> 2]
      }
     }
     $18 = (($4 | 0) == -2 ? 0 : $4) + $18 | 0;
     if (HEAP32[4133] == 16532) {
      continue
     }
    }
    break;
   };
   __up_read(16528);
  }
  _cond_resched();
  global$0 = $5 + 48 | 0;
 }

 function __remove_mapping($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  $2 = global$0 - 32 | 0;
  global$0 = $2;
  $4 = HEAP32[$1 + 4 >> 2];
  label$1 : {
   label$2 : {
    label$3 : {
     if (HEAP32[($4 & 1 ? $4 + -1 | 0 : $1) >> 2] & 1) {
      if ((page_mapping($1) | 0) != ($0 | 0)) {
       break label$3
      }
      $4 = HEAPU8[82812];
      HEAP8[82812] = 0;
      $3 = HEAPU8[82812];
      HEAP8[82812] = 0;
      label$5 : {
       if (HEAP32[$1 + 28 >> 2] == 2) {
        $5 = $1 + 28 | 0;
        HEAP32[$5 >> 2] = 0;
        HEAP8[82812] = $3 & 1;
        $3 = HEAP32[$1 + 4 >> 2];
        if (HEAP32[($3 & 1 ? $3 + -1 | 0 : $1) >> 2] & 8) {
         break label$5
        }
        $3 = HEAP32[HEAP32[$0 + 52 >> 2] + 40 >> 2];
        $7 = $1;
        $5 = HEAP32[$1 + 4 >> 2];
        $6 = 0;
        label$7 : {
         if (HEAP32[($5 & 1 ? $5 + -1 | 0 : $1) >> 2] & 524288) {
          break label$7
         }
         $6 = 0;
         if (HEAP32[$0 + 56 >> 2] & 16) {
          break label$7
         }
         $6 = workingset_eviction($1);
        }
        __delete_from_page_cache($7, $6);
        $0 = 1;
        HEAP8[82812] = $4 & 1;
        if (!$3) {
         break label$1
        }
        FUNCTION_TABLE[$3]($1);
        break label$1;
       }
       HEAP8[82812] = $3 & 1;
       break label$2;
      }
      HEAP32[$5 >> 2] = 2;
      break label$2;
     }
     HEAP32[$2 + 8 >> 2] = 26272;
     HEAP32[$2 + 4 >> 2] = 891;
     HEAP32[$2 >> 2] = 26202;
     printk(26164, $2);
     abort();
    }
    HEAP32[$2 + 24 >> 2] = 26272;
    HEAP32[$2 + 20 >> 2] = 892;
    HEAP32[$2 + 16 >> 2] = 26202;
    printk(26164, $2 + 16 | 0);
    abort();
   }
   $0 = 0;
   HEAP8[82812] = $4 & 1;
  }
  global$0 = $2 + 32 | 0;
  return $0;
 }

 function putback_lru_page($0) {
  var $1 = 0;
  __lru_cache_add($0);
  $1 = HEAP32[$0 + 4 >> 2];
  $0 = $1 & 1 ? $1 + -1 | 0 : $0;
  $1 = HEAP32[$0 + 28 >> 2] + -1 | 0;
  HEAP32[$0 + 28 >> 2] = $1;
  if ($1) {
   return
  }
  __put_page($0);
 }

 function shrink_page_list($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0, $15 = 0, $16 = 0, $17 = 0, $18 = 0, $19 = 0, $20 = 0, $21 = 0, $22 = 0, $23 = 0, $24 = 0, $25 = 0, $26 = 0;
  $7 = global$0 + -64 | 0;
  global$0 = $7;
  HEAP32[$7 + 20 >> 2] = $7 + 16;
  HEAP32[$7 + 16 >> 2] = $7 + 16;
  HEAP32[$7 + 12 >> 2] = $7 + 8;
  HEAP32[$7 + 8 >> 2] = $7 + 8;
  _cond_resched();
  $25 = $0 + 4 | 0;
  $12 = $2 + 20 | 0;
  $14 = $2 + 12 | 0;
  $13 = $2 + 16 | 0;
  $15 = $1 + 1176 | 0;
  while (1) {
   label$2 : {
    label$3 : {
     label$4 : {
      label$5 : {
       if (($0 | 0) != HEAP32[$0 >> 2]) {
        _cond_resched();
        $6 = HEAP32[$25 >> 2];
        $1 = HEAP32[$6 >> 2];
        $4 = HEAP32[$6 + 4 >> 2];
        HEAP32[$1 + 4 >> 2] = $4;
        HEAP32[$4 >> 2] = $1;
        HEAP32[$6 >> 2] = 256;
        HEAP32[$6 + 4 >> 2] = 512;
        $4 = HEAP32[$6 >> 2];
        $1 = $6 + -4 | 0;
        $5 = $4 & 1 ? $4 + -1 | 0 : $1;
        $4 = HEAP32[$5 >> 2];
        HEAP32[$7 + 24 >> 2] = $4;
        if (HEAP32[$7 + 24 >> 2] & 1) {
         break label$2
        }
        HEAP32[$5 >> 2] = $4 | 1;
        if ($4 & 1) {
         break label$2
        }
        HEAP32[$12 >> 2] = HEAP32[$12 >> 2] + 1;
        if (!page_evictable($1)) {
         break label$4
        }
        if (!(HEAPU8[$14 | 0] & 2)) {
         if (page_mapped($1)) {
          break label$3
         }
        }
        label$8 : {
         if (!page_mapped($1)) {
          break label$8
         }
         $4 = HEAP32[$6 >> 2];
         if (HEAP8[($4 & 1 ? $4 + -1 | 0 : $1) + 12 | 0] & 1) {
          $4 = HEAP32[$6 >> 2];
          if (!(HEAP32[($4 & 1 ? $4 + -1 | 0 : $1) >> 2] & 524288)) {
           break label$8
          }
         }
         HEAP32[$12 >> 2] = HEAP32[$12 >> 2] + 1;
        }
        $26 = HEAP32[$13 >> 2];
        label$10 : {
         $4 = HEAP32[$6 >> 2];
         if (!(HEAP32[($4 & 1 ? $4 + -1 | 0 : $1) >> 2] & 524288)) {
          $4 = HEAP32[$6 >> 2];
          if (!(HEAP8[($4 & 1 ? $4 + -1 | 0 : $1) + 12 | 0] & 1)) {
           break label$10
          }
          $4 = HEAP32[$6 >> 2];
          if (HEAP32[($4 & 1 ? $4 + -1 | 0 : $1) >> 2] & 524288) {
           break label$10
          }
         }
         HEAP8[$7 + 6 | 0] = 0;
         HEAP8[$7 + 7 | 0] = 0;
         break label$5;
        }
        $4 = HEAP32[$6 >> 2];
        HEAP8[$7 + 7 | 0] = HEAP32[($4 & 1 ? $4 + -1 | 0 : $1) >> 2] >>> 3 & 1;
        $4 = HEAP32[$6 >> 2];
        HEAP8[$7 + 6 | 0] = HEAP32[($4 & 1 ? $4 + -1 | 0 : $1) >> 2] >>> 15 & 1;
        if (!(HEAPU8[$1 + 1 | 0] & 96)) {
         break label$5
        }
        $4 = page_mapping($1);
        if (!$4) {
         break label$5
        }
        $4 = HEAP32[HEAP32[$4 + 52 >> 2] + 68 >> 2];
        if (!$4) {
         break label$5
        }
        FUNCTION_TABLE[$4]($1, $7 + 7 | 0, $7 + 6 | 0);
        break label$5;
       }
       free_unref_page_list($7 + 8 | 0);
       $1 = HEAP32[$7 + 16 >> 2];
       if (($1 | 0) != ($7 + 16 | 0)) {
        $2 = HEAP32[$7 + 20 >> 2];
        HEAP32[$1 + 4 >> 2] = $0;
        $6 = HEAP32[$0 >> 2];
        HEAP32[$0 >> 2] = $1;
        HEAP32[$6 + 4 >> 2] = $2;
        HEAP32[$2 >> 2] = $6;
       }
       if ($3) {
        HEAP32[$3 + 8 >> 2] = $16;
        HEAP32[$3 >> 2] = $17;
        HEAP32[$3 + 28 >> 2] = $18;
        HEAP32[$3 + 24 >> 2] = $19;
        HEAP32[$3 + 20 >> 2] = $20;
        HEAP32[$3 + 16 >> 2] = $21;
        HEAP32[$3 + 12 >> 2] = $22;
        HEAP32[$3 + 4 >> 2] = $23;
       }
       global$0 = $7 - -64 | 0;
       return $24;
      }
      $4 = HEAPU8[$7 + 6 | 0];
      $5 = HEAPU8[$7 + 7 | 0];
      $8 = !$4 & ($5 | 0) != 0;
      $5 = ($4 | $5) != 0;
      $4 = page_mapping($1);
      $9 = HEAPU8[$7 + 6 | 0];
      label$14 : {
       label$15 : {
        if (!(!$4 | !($9 | HEAPU8[$7 + 7 | 0]))) {
         $9 = HEAP32[$4 >> 2];
         label$17 : {
          if ($9) {
           $9 = HEAP32[HEAP32[$9 + 20 >> 2] + 108 >> 2];
           break label$17;
          }
          $9 = 16192;
         }
         $10 = HEAP32[$9 + 56 >> 2];
         $11 = HEAP32[$10 + 16 >> 2];
         label$19 : {
          if ($11) {
           if (FUNCTION_TABLE[$11](HEAP32[$10 + 20 >> 2], 1)) {
            break label$15
           }
           break label$19;
          }
          if (HEAP32[HEAP32[$9 + 136 >> 2] >> 2] & 1) {
           break label$15
          }
         }
         $9 = HEAPU8[$7 + 6 | 0];
        }
        if (!$9) {
         break label$14
        }
        $9 = HEAP32[$6 >> 2];
        if (!(HEAP32[($9 & 1 ? $9 + -1 | 0 : $1) >> 2] & 262144)) {
         break label$14
        }
       }
       $16 = $16 + 1 | 0;
      }
      $23 = $8 + $23 | 0;
      $17 = $5 + $17 | 0;
      label$21 : {
       label$22 : {
        $5 = HEAP32[$6 >> 2];
        if (!(HEAP32[($5 & 1 ? $5 + -1 | 0 : $1) >> 2] & 32768)) {
         $9 = page_referenced($1, 1, HEAP32[$2 + 8 >> 2], $7 + 60 | 0);
         $5 = HEAP32[$6 >> 2];
         $11 = $5 & 1 ? $5 + -1 | 0 : $1;
         $10 = HEAP32[$11 >> 2];
         HEAP32[$7 + 24 >> 2] = $10;
         $5 = 0;
         $8 = 0;
         if (HEAP32[$7 + 24 >> 2] & 2) {
          HEAP32[$11 >> 2] = $10 & -3;
          $8 = $10 >>> 1 & 1;
         }
         $10 = HEAP32[$7 + 60 >> 2];
         if ($10 & 8192) {
          break label$21
         }
         if (!$9) {
          break label$22
         }
         $4 = HEAP32[$6 >> 2];
         if (HEAP32[($4 & 1 ? $4 + -1 | 0 : $1) >> 2] & 524288) {
          break label$4
         }
         $4 = HEAP32[$6 >> 2];
         $4 = $4 & 1 ? $4 + -1 | 0 : $1;
         HEAP32[$4 >> 2] = HEAP32[$4 >> 2] | 2;
         if ($10 & 4 | $8 | ($9 | 0) > 1) {
          break label$4
         }
         $19 = $19 + 1 | 0;
         break label$3;
        }
        label$25 : {
         label$26 : {
          if (!(HEAPU8[HEAP32[2] + 14 | 0] & 2)) {
           break label$26
          }
          $4 = HEAP32[$6 >> 2];
          if (!(HEAP32[($4 & 1 ? $4 + -1 | 0 : $1) >> 2] & 262144)) {
           break label$26
          }
          if (HEAP32[$15 >> 2] & 4) {
           break label$25
          }
         }
         $4 = HEAP32[$6 >> 2];
         $4 = $4 & 1 ? $4 + -1 | 0 : $1;
         HEAP32[$4 >> 2] = HEAP32[$4 >> 2] | 262144;
         $22 = $22 + 1 | 0;
         break label$4;
        }
        $21 = $21 + 1 | 0;
        break label$4;
       }
       if ($8) {
        $5 = 1;
        $8 = HEAP32[$6 >> 2];
        if (!(HEAP32[($8 & 1 ? $8 + -1 | 0 : $1) >> 2] & 524288)) {
         break label$21
        }
       }
       $5 = 0;
      }
      label$28 : {
       label$29 : {
        label$30 : {
         label$31 : {
          $8 = HEAP32[$6 >> 2];
          if (HEAP8[($8 & 1 ? $8 + -1 | 0 : $1) + 12 | 0] & 1) {
           $8 = HEAP32[$6 >> 2];
           if (HEAP32[($8 & 1 ? $8 + -1 | 0 : $1) >> 2] & 524288) {
            break label$31
           }
          }
          if (page_mapped($1)) {
           if (!try_to_unmap($1)) {
            break label$30
           }
          }
          $8 = HEAP32[$6 >> 2];
          if (!(HEAP32[($8 & 1 ? $8 + -1 | 0 : $1) >> 2] & 8)) {
           break label$28
          }
          $8 = HEAP32[$6 >> 2];
          if (HEAP32[($8 & 1 ? $8 + -1 | 0 : $1) >> 2] & 524288) {
           break label$29
          }
          label$34 : {
           if (!(HEAPU8[HEAP32[2] + 14 | 0] & 2)) {
            break label$34
           }
           $8 = HEAP32[$6 >> 2];
           if (!(HEAP32[($8 & 1 ? $8 + -1 | 0 : $1) >> 2] & 262144)) {
            break label$34
           }
           if (HEAP32[$15 >> 2] & 2) {
            break label$29
           }
          }
          HEAP32[35616] = HEAP32[35616] + 1;
          HEAP32[20698] = HEAP32[20698] + 1;
          $4 = HEAP32[$6 >> 2];
          $4 = $4 & 1 ? $4 + -1 | 0 : $1;
          HEAP32[$4 >> 2] = HEAP32[$4 >> 2] | 262144;
          break label$4;
         }
         if (HEAPU8[$13 | 0] & 64) {
          break label$4
         }
         break label$3;
        }
        $18 = $18 + 1 | 0;
        break label$4;
       }
       if (!(HEAP8[$14 | 0] & 1) | ($5 | !($26 & 128))) {
        break label$3
       }
       $5 = HEAP32[$6 >> 2];
       $9 = HEAP32[($5 & 1 ? $5 + -1 | 0 : $1) + 28 >> 2];
       $5 = HEAP32[$1 >> 2] & 24576;
       if (($9 - (($5 | 0) != 0) | 0) != 2) {
        break label$3
       }
       label$35 : {
        label$36 : {
         label$37 : {
          if ($4) {
           if (!HEAP32[HEAP32[$4 + 52 >> 2] >> 2]) {
            break label$4
           }
           if (HEAPU8[HEAP32[2] + 14 | 0] & 128) {
            break label$35
           }
           $5 = HEAP32[$4 >> 2];
           if (!$5) {
            break label$37
           }
           $8 = HEAP32[HEAP32[$5 + 20 >> 2] + 108 >> 2];
           break label$36;
          }
          if (!$5) {
           break label$3
          }
          $4 = HEAP32[$6 >> 2];
          $4 = $4 & 1 ? $4 + -1 | 0 : $1;
          HEAP32[$4 >> 2] = HEAP32[$4 >> 2] & -9;
          HEAP32[$7 >> 2] = 26317;
          printk(26289, $7);
          $4 = 0;
          break label$28;
         }
         $8 = 16192;
        }
        $9 = HEAP32[$8 + 56 >> 2];
        $10 = HEAP32[$9 + 16 >> 2];
        label$39 : {
         if ($10) {
          if (FUNCTION_TABLE[$10](HEAP32[$9 + 20 >> 2], 1)) {
           break label$39
          }
          break label$35;
         }
         if (!(HEAP32[HEAP32[$8 + 136 >> 2] >> 2] & 1)) {
          break label$35
         }
        }
        if (HEAP32[HEAP32[2] + 808 >> 2] != (($5 ? HEAP32[HEAP32[$5 + 20 >> 2] + 108 >> 2] : 16192) | 0)) {
         break label$3
        }
       }
       if (!clear_page_dirty_for_io($1)) {
        break label$28
       }
       $5 = HEAP32[6589];
       $8 = $7 + 48 | 0;
       HEAP32[$8 >> 2] = HEAP32[6588];
       HEAP32[$8 + 4 >> 2] = $5;
       $5 = HEAP32[6587];
       $8 = $7 + 40 | 0;
       HEAP32[$8 >> 2] = HEAP32[6586];
       HEAP32[$8 + 4 >> 2] = $5;
       $5 = HEAP32[6585];
       $8 = $7 + 32 | 0;
       HEAP32[$8 >> 2] = HEAP32[6584];
       HEAP32[$8 + 4 >> 2] = $5;
       $5 = HEAP32[6583];
       HEAP32[$7 + 24 >> 2] = HEAP32[6582];
       HEAP32[$7 + 28 >> 2] = $5;
       $5 = HEAP32[$6 >> 2];
       $5 = $5 & 1 ? $5 + -1 | 0 : $1;
       HEAP32[$5 >> 2] = HEAP32[$5 >> 2] | 262144;
       $5 = FUNCTION_TABLE[HEAP32[HEAP32[$4 + 52 >> 2] >> 2]]($1, $7 + 24 | 0) | 0;
       label$43 : {
        if (($5 | 0) > -1) {
         if (($5 | 0) != 524288) {
          break label$43
         }
         $4 = HEAP32[$6 >> 2];
         $4 = $4 & 1 ? $4 + -1 | 0 : $1;
         HEAP32[$4 >> 2] = HEAP32[$4 >> 2] & -262145;
         break label$4;
        }
        $8 = HEAP32[$6 >> 2];
        $9 = $8 & 1 ? $8 + -1 | 0 : $1;
        $8 = HEAP32[$9 >> 2];
        HEAP32[$7 + 60 >> 2] = $8;
        label$45 : {
         if (!(HEAP32[$7 + 60 >> 2] & 1)) {
          HEAP32[$9 >> 2] = $8 | 1;
          if (!($8 & 1)) {
           break label$45
          }
         }
         __lock_page($1);
        }
        if ((page_mapping($1) | 0) == ($4 | 0)) {
         errseq_set($4 + 60 | 0, $5);
         HEAP32[$4 + 56 >> 2] = HEAP32[$4 + 56 >> 2] | (($5 | 0) == -28 ? 2 : 1);
        }
        unlock_page($1);
       }
       $4 = HEAP32[$6 >> 2];
       if (!(HEAP32[($4 & 1 ? $4 + -1 | 0 : $1) >> 2] & 32768)) {
        $4 = HEAP32[$6 >> 2];
        $4 = $4 & 1 ? $4 + -1 | 0 : $1;
        HEAP32[$4 >> 2] = HEAP32[$4 >> 2] & -262145;
       }
       HEAP32[35615] = HEAP32[35615] + 1;
       HEAP32[20697] = HEAP32[20697] + 1;
       $4 = HEAP32[$6 >> 2];
       if (HEAP32[($4 & 1 ? $4 + -1 | 0 : $1) >> 2] & 32768) {
        break label$2
       }
       $4 = HEAP32[$6 >> 2];
       if (HEAP32[($4 & 1 ? $4 + -1 | 0 : $1) >> 2] & 8) {
        break label$2
       }
       $4 = HEAP32[$6 >> 2];
       $5 = $4 & 1 ? $4 + -1 | 0 : $1;
       $4 = HEAP32[$5 >> 2];
       HEAP32[$7 + 24 >> 2] = $4;
       if (HEAP32[$7 + 24 >> 2] & 1) {
        break label$2
       }
       HEAP32[$5 >> 2] = $4 | 1;
       if ($4 & 1) {
        break label$2
       }
       $4 = HEAP32[$6 >> 2];
       if (HEAP32[($4 & 1 ? $4 + -1 | 0 : $1) >> 2] & 8) {
        break label$3
       }
       $4 = HEAP32[$6 >> 2];
       if (HEAP32[($4 & 1 ? $4 + -1 | 0 : $1) >> 2] & 32768) {
        break label$3
       }
       $4 = page_mapping($1);
      }
      label$49 : {
       label$50 : {
        label$51 : {
         label$52 : {
          if (!(HEAPU8[$1 + 1 | 0] & 96)) {
           break label$52
          }
          if (!try_to_release_page($1, HEAP32[$13 >> 2])) {
           break label$4
          }
          if ($4) {
           break label$52
          }
          $5 = HEAP32[$6 >> 2];
          if (HEAP32[($5 & 1 ? $5 + -1 | 0 : $1) + 28 >> 2] != 1) {
           break label$52
          }
          unlock_page($1);
          $1 = HEAP32[$6 + 24 >> 2] + -1 | 0;
          HEAP32[$6 + 24 >> 2] = $1;
          if ($1) {
           break label$50
          }
          break label$51;
         }
         label$53 : {
          label$54 : {
           $5 = HEAP32[$6 >> 2];
           if (!(HEAP8[($5 & 1 ? $5 + -1 | 0 : $1) + 12 | 0] & 1)) {
            break label$54
           }
           $5 = HEAP32[$6 >> 2];
           if (HEAP32[($5 & 1 ? $5 + -1 | 0 : $1) >> 2] & 524288) {
            break label$54
           }
           $4 = HEAPU8[82812];
           HEAP8[82812] = 0;
           if (HEAP32[$6 + 24 >> 2] != 1) {
            break label$49
           }
           $5 = $6 + 24 | 0;
           HEAP32[$5 >> 2] = 0;
           HEAP8[82812] = $4 & 1;
           $4 = HEAP32[$6 >> 2];
           if (!(HEAP32[($4 & 1 ? $4 + -1 | 0 : $1) >> 2] & 8)) {
            break label$53
           }
           HEAP32[$5 >> 2] = 1;
           break label$3;
          }
          if (!$4) {
           break label$3
          }
          if (!__remove_mapping($4, $1)) {
           break label$3
          }
         }
         $4 = HEAP32[$6 >> 2];
         $1 = $4 & 1 ? $4 + -1 | 0 : $1;
         HEAP32[$1 >> 2] = HEAP32[$1 >> 2] & -2;
        }
        $1 = HEAP32[$7 + 8 >> 2];
        HEAP32[$1 + 4 >> 2] = $6;
        HEAP32[$6 >> 2] = $1;
        HEAP32[$7 + 8 >> 2] = $6;
        HEAP32[$6 + 4 >> 2] = $7 + 8;
       }
       $24 = $24 + 1 | 0;
       continue;
      }
      HEAP8[82812] = $4 & 1;
      break label$3;
     }
     $4 = HEAP32[$6 >> 2];
     if (HEAP32[($4 & 1 ? $4 + -1 | 0 : $1) >> 2] & 2097152) {
      break label$3
     }
     $4 = HEAP32[$6 >> 2];
     $4 = $4 & 1 ? $4 + -1 | 0 : $1;
     HEAP32[$4 >> 2] = HEAP32[$4 >> 2] | 32;
     $20 = $20 + 1 | 0;
    }
    unlock_page($1);
   }
   $1 = HEAP32[$7 + 16 >> 2];
   HEAP32[$1 + 4 >> 2] = $6;
   HEAP32[$6 >> 2] = $1;
   HEAP32[$7 + 16 >> 2] = $6;
   HEAP32[$6 + 4 >> 2] = $7 + 16;
   continue;
  };
 }

 function page_evictable($0) {
  var $1 = 0, $2 = 0;
  $1 = page_mapping($0);
  label$1 : {
   if ($1) {
    $2 = 0;
    if (HEAP32[$1 + 56 >> 2] & 8) {
     break label$1
    }
   }
   $1 = HEAP32[$0 + 4 >> 2];
   $2 = (HEAP32[($1 & 1 ? $1 + -1 | 0 : $0) >> 2] >>> 21 ^ -1) & 1;
  }
  return $2;
 }

 function __isolate_lru_page($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0;
  $5 = global$0 - 16 | 0;
  global$0 = $5;
  $3 = -22;
  $2 = HEAP32[$0 + 4 >> 2];
  label$1 : {
   if (!(HEAP32[($2 & 1 ? $2 + -1 | 0 : $0) >> 2] & 16)) {
    break label$1
   }
   $2 = HEAP32[$0 + 4 >> 2];
   $2 = HEAP32[($2 & 1 ? $2 + -1 | 0 : $0) >> 2];
   if ($2 & 1048576 ? !($1 & 8) : 0) {
    break label$1
   }
   label$3 : {
    if (!($1 & 4)) {
     break label$3
    }
    $3 = -16;
    $2 = $0 + 4 | 0;
    $4 = HEAP32[$2 >> 2];
    if (HEAP32[($4 & 1 ? $4 + -1 | 0 : $0) >> 2] & 32768) {
     break label$1
    }
    $2 = HEAP32[$2 >> 2];
    if (!(HEAP32[($2 & 1 ? $2 + -1 | 0 : $0) >> 2] & 8)) {
     break label$3
    }
    $2 = HEAP32[$0 + 4 >> 2];
    $4 = $2 & 1 ? $2 + -1 | 0 : $0;
    $2 = HEAP32[$4 >> 2];
    HEAP32[$5 + 12 >> 2] = $2;
    if (HEAP32[$5 + 12 >> 2] & 1) {
     break label$1
    }
    HEAP32[$4 >> 2] = $2 | 1;
    if ($2 & 1) {
     break label$1
    }
    $2 = page_mapping($0);
    if ($2) {
     $2 = HEAP32[HEAP32[$2 + 52 >> 2] + 48 >> 2];
     unlock_page($0);
     if ($2) {
      break label$3
     }
     break label$1;
    }
    unlock_page($0);
   }
   if ($1 & 2) {
    $3 = -16;
    if (page_mapped($0)) {
     break label$1
    }
   }
   $1 = HEAP32[$0 + 28 >> 2];
   if ($1) {
    HEAP32[$0 + 28 >> 2] = $1 + 1;
    $1 = HEAP32[$0 + 4 >> 2];
    $0 = $1 & 1 ? $1 + -1 | 0 : $0;
    HEAP32[$0 >> 2] = HEAP32[$0 >> 2] & -17;
    $3 = 0;
    break label$1;
   }
   $3 = -16;
  }
  global$0 = $5 + 16 | 0;
  return $3;
 }

 function isolate_lru_page($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  if (HEAP32[$0 + 4 >> 2] & 1) {
   ___ratelimit(16548, 26147)
  }
  $3 = -16;
  $1 = $0 + 4 | 0;
  $2 = HEAP32[$1 >> 2];
  if (HEAP32[($2 & 1 ? $2 + -1 | 0 : $0) >> 2] & 16) {
   $2 = HEAP32[$0 >> 2];
   HEAP8[82812] = 0;
   $1 = HEAP32[$1 >> 2];
   if (HEAP32[($1 & 1 ? $1 + -1 | 0 : $0) >> 2] & 16) {
    $6 = HEAP32[Math_imul($2 >>> 31 | 0, 516) + 141200 >> 2] + 1112 | 0;
    $2 = 4;
    $3 = $0 + 4 | 0;
    $1 = HEAP32[$3 >> 2];
    if (!(HEAP32[($1 & 1 ? $1 + -1 | 0 : $0) >> 2] & 1048576)) {
     $2 = $0 + 4 | 0;
     $1 = HEAP32[$2 >> 2];
     $2 = HEAP32[$2 >> 2];
     $2 = (HEAP32[($2 & 1 ? $2 + -1 | 0 : $0) >> 2] >>> 5 & 1 | HEAP32[($1 & 1 ? $1 + -1 | 0 : $0) >> 2] >>> 18 & 2) ^ 2;
    }
    $1 = HEAP32[$3 >> 2];
    $1 = $1 & 1 ? $1 + -1 | 0 : $0;
    HEAP32[$1 + 28 >> 2] = HEAP32[$1 + 28 >> 2] + 1;
    $1 = HEAP32[$3 >> 2];
    $4 = $1 & 1 ? $1 + -1 | 0 : $0;
    HEAP32[$4 >> 2] = HEAP32[$4 >> 2] & -17;
    $4 = $0 + 8 | 0;
    $7 = HEAP32[$4 >> 2];
    HEAP32[$7 >> 2] = $1;
    $6 = $6 + -1112 | 0;
    $2 = $2 << 2;
    $5 = ($6 + $2 | 0) + 1184 | 0;
    HEAP32[$5 >> 2] = HEAP32[$5 >> 2] + -1;
    $5 = $2 + 82688 | 0;
    HEAP32[$5 >> 2] = HEAP32[$5 >> 2] + -1;
    HEAP32[$1 + 4 >> 2] = $7;
    $0 = ($2 + ($6 + Math_imul(HEAP32[$0 >> 2] >>> 31 | 0, 516) | 0) | 0) + 472 | 0;
    HEAP32[$0 >> 2] = HEAP32[$0 >> 2] + -1;
    HEAP32[$3 >> 2] = 256;
    HEAP32[$4 >> 2] = 512;
    $0 = $2 + 82644 | 0;
    HEAP32[$0 >> 2] = HEAP32[$0 >> 2] + -1;
    $3 = 0;
   }
   HEAP8[82812] = 1;
  }
  return $3;
 }

 function try_to_free_pages($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0, $15 = 0, $16 = 0;
  $4 = global$0 - 80 | 0;
  global$0 = $4;
  HEAP32[$4 + 8 >> 2] = 0;
  HEAP8[$4 + 12 | 0] = !HEAP32[20706] | 6;
  HEAP32[$4 + 4 >> 2] = $3;
  HEAP32[$4 >> 2] = 32;
  HEAP8[$4 + 14 | 0] = 12;
  HEAP8[$4 + 13 | 0] = $1;
  HEAP8[$4 + 15 | 0] = 1024 >>> ($2 & 15) & 1;
  $1 = HEAP32[2];
  $5 = HEAP32[$1 + 12 >> 2];
  label$1 : {
   if (!($5 & 524288)) {
    $5 = $5 & 262144 ? $2 & -129 : $2;
    break label$1;
   }
   $5 = $2 & -193;
  }
  HEAP32[$4 + 52 >> 2] = 0;
  $2 = $4 + 44 | 0;
  HEAP32[$2 >> 2] = 0;
  HEAP32[$2 + 4 >> 2] = 0;
  $2 = $4 + 36 | 0;
  HEAP32[$2 >> 2] = 0;
  HEAP32[$2 + 4 >> 2] = 0;
  $11 = $4 + 16 | 0;
  HEAP32[$11 >> 2] = $5;
  HEAP32[$4 + 28 >> 2] = 0;
  HEAP32[$4 + 32 >> 2] = 0;
  HEAP32[$4 + 20 >> 2] = 0;
  HEAP32[$4 + 24 >> 2] = 0;
  label$3 : {
   label$4 : {
    if (HEAPU8[$1 + 14 | 0] & 32 | (HEAP8[$1 + 761 | 0] & 1 ? HEAP32[HEAP32[$1 + 4 >> 2] >> 2] & 4 : 0)) {
     break label$4
    }
    $6 = 1024 >>> ($5 & 15) & 1;
    label$6 : {
     if (!$3) {
      $2 = $0;
      if (HEAPU32[$2 + 4 >> 2] <= $6 >>> 0) {
       break label$6
      }
     }
     $2 = __next_zones_zonelist($0, $6, $3);
    }
    while (1) {
     $7 = HEAP32[$2 >> 2];
     if (!$7) {
      break label$4
     }
     $1 = HEAP32[$7 + 24 >> 2];
     if (($7 - $1 | 0) > 0) {
      $1 = $2 + 8 | 0;
      if (!$3) {
       $7 = $2 + 12 | 0;
       $2 = $1;
       if (HEAPU32[$7 >> 2] <= $6 >>> 0) {
        continue
       }
      }
      $2 = __next_zones_zonelist($1, $6, $3);
      continue;
     }
     break;
    };
    if (allow_direct_reclaim($1) | !$1) {
     break label$4
    }
    $2 = allow_direct_reclaim($1);
    label$11 : {
     label$12 : {
      if (!($5 & 128)) {
       if ($2) {
        break label$11
       }
       init_wait_entry($4 + 56 | 0);
       $3 = $1 + 1084 | 0;
       $2 = 250;
       while (1) {
        $5 = prepare_to_wait_event($3, $4 + 56 | 0, 1);
        $6 = allow_direct_reclaim($1);
        if ($6) {
         break label$12
        }
        $2 = $2 ? $2 : $6 ? 1 : $2;
        if (!$2) {
         break label$12
        }
        if ($5) {
         break label$11
        }
        $2 = schedule_timeout($2);
        continue;
       };
      }
      if ($2) {
       break label$11
      }
      init_wait_entry($4 + 56 | 0);
      $2 = $7 + 24 | 0;
      while (1) {
       label$15 : {
        $3 = prepare_to_wait_event(HEAP32[$2 >> 2] + 1084 | 0, $4 + 56 | 0, 258);
        if (allow_direct_reclaim($1)) {
         break label$15
        }
        if ($3) {
         break label$11
        }
        schedule();
        continue;
       }
       break;
      };
      finish_wait($4 + 56 | 0);
      break label$11;
     }
     finish_wait($4 + 56 | 0);
    }
    $1 = HEAP32[2];
    if (!(HEAP32[HEAP32[$1 + 4 >> 2] >> 2] & 4)) {
     break label$4
    }
    $2 = 1;
    if (HEAP8[$1 + 761 | 0] & 1) {
     break label$3
    }
   }
   $7 = $4 + 14 | 0;
   $14 = HEAPU8[$7 | 0];
   $15 = $4 + 20 | 0;
   $5 = $4 + 15 | 0;
   $12 = $0 + 4 | 0;
   $13 = $4 + 24 | 0;
   $6 = $4 + 12 | 0;
   label$17 : {
    while (1) {
     $9 = HEAP32[$11 >> 2];
     while (1) {
      HEAP32[$15 >> 2] = 0;
      $1 = HEAP8[$5 | 0];
      $3 = HEAP32[$4 + 4 >> 2];
      label$20 : {
       if (!$3) {
        $2 = $0;
        if (HEAPU32[$12 >> 2] <= $1 >>> 0) {
         break label$20
        }
       }
       $2 = __next_zones_zonelist($0, $1, $3);
      }
      $1 = 0;
      while (1) {
       $3 = HEAP32[$2 >> 2];
       if ($3) {
        $3 = HEAP32[$3 + 24 >> 2];
        if (($1 | 0) != ($3 | 0)) {
         shrink_node($3, $4);
         $1 = $3;
        }
        $3 = $2 + 8 | 0;
        $8 = HEAP8[$5 | 0];
        $10 = HEAP32[$4 + 4 >> 2];
        if (!$10) {
         $16 = $2 + 12 | 0;
         $2 = $3;
         if (HEAPU32[$16 >> 2] <= $8 >>> 0) {
          continue
         }
        }
        $2 = __next_zones_zonelist($3, $8, $10);
        continue;
       }
       break;
      };
      HEAP32[$11 >> 2] = $9;
      label$26 : {
       if (HEAPU32[$13 >> 2] >= HEAPU32[$4 >> 2]) {
        break label$26
       }
       $1 = HEAPU8[$6 | 0];
       if ($1 & 64) {
        break label$26
       }
       $2 = HEAP8[$7 | 0];
       if (($2 | 0) <= 9) {
        HEAP8[$6 | 0] = $1 | 1
       }
       $1 = $2 + -1 | 0;
       HEAP8[$7 | 0] = $1;
       if ($1 << 24 >> 24 > -1) {
        continue
       }
      }
      break;
     };
     $1 = HEAP8[$5 | 0];
     $3 = HEAP32[$4 + 4 >> 2];
     label$28 : {
      if (!$3) {
       $2 = $0;
       if (HEAPU32[$12 >> 2] <= $1 >>> 0) {
        break label$28
       }
      }
      $2 = __next_zones_zonelist($0, $1, $3);
     }
     $1 = 0;
     while (1) {
      $3 = HEAP32[$2 >> 2];
      if ($3) {
       $3 = HEAP32[$3 + 24 >> 2];
       if (($1 | 0) != ($3 | 0)) {
        HEAP32[$3 + 1172 >> 2] = HEAP32[20683];
        $1 = $3;
       }
       $3 = $2 + 8 | 0;
       $8 = HEAP8[$5 | 0];
       $9 = HEAP32[$4 + 4 >> 2];
       if (!$9) {
        $10 = $2 + 12 | 0;
        $2 = $3;
        if (HEAPU32[$10 >> 2] <= $8 >>> 0) {
         continue
        }
       }
       $2 = __next_zones_zonelist($3, $8, $9);
       continue;
      }
      break;
     };
     $2 = HEAP32[$13 >> 2];
     if ($2) {
      break label$3
     }
     $1 = HEAPU8[$6 | 0];
     if (!($1 & 64)) {
      if (!($1 & 16)) {
       break label$17
      }
      HEAP8[$7 | 0] = $14;
      HEAP8[$6 | 0] = $1 & 231 | 8;
      continue;
     }
     break;
    };
    $2 = 1;
    break label$3;
   }
   $2 = 0;
  }
  global$0 = $4 + 80 | 0;
  return $2;
 }

 function allow_direct_reclaim($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  $2 = 1;
  label$1 : {
   if (HEAP32[$0 + 1104 >> 2] > 15) {
    break label$1
   }
   $4 = $0 + 40 | 0;
   $5 = $0 + 480 | 0;
   $6 = $0 + 484 | 0;
   $7 = $0 + 468 | 0;
   while (1) {
    if (!(!$2 | !HEAP32[$4 >> 2] | HEAP32[$6 >> 2] == (0 - HEAP32[$5 >> 2] | 0))) {
     $1 = HEAP32[$0 >> 2] + $1 | 0;
     $3 = HEAP32[$7 >> 2] + $3 | 0;
     $2 = 0;
     continue;
    }
    break;
   };
   $2 = 1;
   if (!$1 | $3 >>> 0 > $1 >>> 1 >>> 0) {
    break label$1
   }
   $2 = 0;
   $1 = $0 + 1076 | 0;
   if (($1 | 0) == HEAP32[$0 + 1076 >> 2]) {
    break label$1
   }
   HEAP32[$0 + 1100 >> 2] = 0;
   __wake_up($1, 1, 0);
  }
  return $2;
 }

 function shrink_node($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0, $15 = 0, $16 = 0, $17 = 0, $18 = 0, $19 = 0, $20 = 0, $21 = 0, $22 = 0, $23 = 0, $24 = 0, $25 = 0, wasm2js_i32$0 = 0, wasm2js_i32$1 = 0, wasm2js_i32$2 = 0, wasm2js_i32$3 = 0, wasm2js_i32$4 = 0;
  $3 = global$0 - 96 | 0;
  global$0 = $3;
  $12 = HEAP32[HEAP32[2] + 804 >> 2];
  $14 = $1 + 28 | 0;
  memset($14, 0, 28);
  $9 = $0 + 1112 | 0;
  $20 = HEAP32[$1 + 24 >> 2];
  $21 = HEAP32[$1 >> 2];
  $4 = $3 + 32 | 0;
  $5 = $1 + 15 | 0;
  $6 = $1 + 14 | 0;
  while (1) {
   if (($2 | 0) != 4) {
    (wasm2js_i32$0 = $4, wasm2js_i32$1 = (wasm2js_i32$2 = lruvec_lru_size($9, $2, HEAP8[$5 | 0]) >>> HEAP8[$6 | 0] | 0, wasm2js_i32$3 = 0, wasm2js_i32$4 = ($2 | 1) == 3, wasm2js_i32$4 ? wasm2js_i32$2 : wasm2js_i32$3)), HEAP32[wasm2js_i32$0 >> 2] = wasm2js_i32$1;
    $4 = $4 + 4 | 0;
    $2 = $2 + 1 | 0;
    continue;
   }
   break;
  };
  memcpy($3, $3 + 32 | 0, 20);
  $15 = HEAPU8[HEAP32[2] + 14 | 0] & 2 ? 0 : HEAPU8[$1 + 14 | 0] == 12;
  $22 = $3 + 32 | 4;
  $23 = $3 + 32 | 12;
  $16 = $1 + 15 | 0;
  $24 = $0 + 1172 | 0;
  $11 = $0 + 1216 | 0;
  $17 = $0 + 1164 | 0;
  $18 = $0 + 1156 | 0;
  $25 = $1 + 8 | 0;
  label$5 : while (1) {
   label$4 : {
    if (!(HEAP32[$3 + 40 >> 2] | (HEAP32[$3 + 44 >> 2] | HEAP32[$3 + 32 >> 2]))) {
     break label$4
    }
    $6 = 0;
    while (1) {
     label$7 : {
      label$8 : {
       if (($6 | 0) != 4) {
        $5 = ($3 + 32 | 0) + ($6 << 2) | 0;
        $2 = HEAP32[$5 >> 2];
        if (!$2) {
         break label$7
        }
        $8 = $5;
        $5 = $2 >>> 0 < 32 ? $2 : 32;
        HEAP32[$8 >> 2] = $2 - $5;
        label$10 : {
         label$11 : {
          if (($6 | 2) == 3) {
           $2 = 0;
           $4 = $6 | 1;
           if (($4 | 0) != 3) {
            break label$8
           }
           $4 = (($4 | 0) == 3) << 1;
           $10 = lruvec_lru_size($9, $4, HEAP8[$16 | 0]);
           $19 = $4 | 1;
           $7 = lruvec_lru_size($9, $19, HEAP8[$16 | 0]);
           $8 = 0;
           if (HEAP32[$24 >> 2] != HEAP32[20683]) {
            break label$10
           }
           $8 = $7 + $10 >>> 14 | 0;
           if (!$8) {
            break label$11
           }
           $8 = int_sqrt(Math_imul($8, 10));
           break label$10;
          }
          $2 = shrink_inactive_list($5, $9, $1, $6);
          break label$8;
         }
         $8 = 1;
        }
        lruvec_lru_size($9, $4, 2);
        lruvec_lru_size($9, $19, 2);
        if (Math_imul($10, $8) >>> 0 >= $7 >>> 0) {
         break label$8
        }
        HEAP32[$3 + 84 >> 2] = $3 + 80;
        HEAP32[$3 + 80 >> 2] = $3 + 80;
        HEAP32[$3 + 76 >> 2] = $3 + 72;
        HEAP32[$3 + 72 >> 2] = $3 + 72;
        HEAP32[$3 + 68 >> 2] = $3 - -64;
        HEAP32[$3 + 64 >> 2] = $3 - -64;
        lru_add_drain_cpu();
        $2 = HEAPU8[$1 + 12 | 0];
        $10 = 0;
        HEAP8[82812] = 0;
        $5 = isolate_lru_pages($5, $9, $3 + 80 | 0, $3 + 92 | 0, $1, ($2 ^ -1) & 2, $6);
        HEAP32[$11 >> 2] = $5 + HEAP32[$11 >> 2];
        HEAP32[$17 >> 2] = $5 + HEAP32[$17 >> 2];
        HEAP8[82812] = 1;
        HEAP32[20680] = $5 + HEAP32[20680];
        while (1) {
         if (HEAP32[$3 + 80 >> 2] != ($3 + 80 | 0)) {
          _cond_resched();
          $2 = HEAP32[$3 + 84 >> 2];
          $4 = HEAP32[$2 >> 2];
          $7 = HEAP32[$2 + 4 >> 2];
          HEAP32[$4 + 4 >> 2] = $7;
          HEAP32[$7 >> 2] = $4;
          HEAP32[$2 >> 2] = 256;
          HEAP32[$2 + 4 >> 2] = 512;
          $4 = $2 + -4 | 0;
          if (page_evictable($4)) {
           label$16 : {
            label$17 : {
             if (!page_referenced($4, 0, HEAP32[$25 >> 2], $3 + 88 | 0)) {
              break label$17
             }
             $10 = $10 + 1 | 0;
             if (!(HEAPU8[$3 + 88 | 0] & 4)) {
              break label$17
             }
             $7 = HEAP32[$2 >> 2];
             $8 = $3 + 72 | 0;
             if (!(HEAP32[($7 & 1 ? $7 + -1 | 0 : $4) >> 2] & 524288)) {
              break label$16
             }
            }
            $7 = HEAP32[$2 >> 2];
            $7 = $7 & 1 ? $7 + -1 | 0 : $4;
            HEAP32[$7 >> 2] = HEAP32[$7 >> 2] & -33;
            $7 = HEAP32[$2 >> 2];
            $4 = $7 & 1 ? $7 + -1 | 0 : $4;
            HEAP32[$4 >> 2] = HEAP32[$4 >> 2] | 64;
            $8 = $3 - -64 | 0;
           }
           $4 = $8;
           $7 = HEAP32[$4 >> 2];
           HEAP32[$7 + 4 >> 2] = $2;
           HEAP32[$4 >> 2] = $2;
           HEAP32[$2 >> 2] = $7;
           HEAP32[$2 + 4 >> 2] = $4;
          } else {
           putback_lru_page($4)
          }
          continue;
         }
         break;
        };
        $2 = 0;
        HEAP8[82812] = 0;
        HEAP32[$18 >> 2] = HEAP32[$18 >> 2] + $10;
        move_active_pages_to_lru($9, $3 + 72 | 0, $3 + 80 | 0, $6);
        move_active_pages_to_lru($9, $3 - -64 | 0, $3 + 80 | 0, $6 + -1 | 0);
        HEAP32[$11 >> 2] = HEAP32[$11 >> 2] - $5;
        HEAP8[82812] = 1;
        HEAP32[20680] = HEAP32[20680] - $5;
        free_unref_page_list($3 + 80 | 0);
        break label$8;
       }
       _cond_resched();
       if (($13 >>> 0 < $21 >>> 0 | $15) & 1) {
        continue label$5
       }
       $2 = HEAP32[$3 + 40 >> 2];
       $4 = $2 + HEAP32[$3 + 44 >> 2] | 0;
       if (!$4) {
        break label$4
       }
       $5 = HEAP32[$3 + 32 >> 2];
       $6 = $5 + HEAP32[$3 + 36 >> 2] | 0;
       if (!$6) {
        break label$4
       }
       label$18 : {
        if ($4 >>> 0 > $6 >>> 0) {
         HEAP32[$3 + 32 >> 2] = 0;
         $4 = (Math_imul($6, 100) >>> 0) / ((HEAP32[$3 >> 2] + HEAP32[$3 + 4 >> 2] | 0) + 1 >>> 0) | 0;
         $6 = 2;
         $5 = $22;
         break label$18;
        }
        $6 = 0;
        HEAP32[$3 + 40 >> 2] = 0;
        $4 = (Math_imul($4, 100) >>> 0) / ((HEAP32[$3 + 8 >> 2] + HEAP32[$3 + 12 >> 2] | 0) + 1 >>> 0) | 0;
        $2 = $5;
        $5 = $23;
       }
       HEAP32[$5 >> 2] = 0;
       $6 = $6 << 2;
       $10 = HEAP32[($6 | $3) >> 2];
       $4 = 100 - $4 | 0;
       $5 = (Math_imul($10, $4) >>> 0) / 100 | 0;
       $2 = $10 - $2 | 0;
       HEAP32[($6 | $3 + 32) >> 2] = $5 - ($5 >>> 0 < $2 >>> 0 ? $5 : $2);
       $2 = $6 | 4;
       $5 = $2 | $3 + 32;
       $8 = $5;
       $6 = HEAP32[($3 | $2) >> 2];
       $2 = (Math_imul($6, $4) >>> 0) / 100 | 0;
       $5 = $6 - HEAP32[$5 >> 2] | 0;
       HEAP32[$8 >> 2] = $2 - ($2 >>> 0 < $5 >>> 0 ? $2 : $5);
       $15 = 1;
       continue label$5;
      }
      $13 = $2 + $13 | 0;
     }
     $6 = $6 + 1 | 0;
     continue;
    };
   }
   break;
  };
  $2 = $1 + 24 | 0;
  HEAP32[$2 >> 2] = HEAP32[$2 >> 2] + $13;
  shrink_slab(HEAP32[$1 + 16 >> 2], HEAP32[$0 + 1072 >> 2], HEAP8[$1 + 14 | 0]);
  label$20 : {
   if ($12) {
    $5 = HEAP32[$12 >> 2];
    HEAP32[$12 >> 2] = 0;
    $4 = $5 + HEAP32[$2 >> 2] | 0;
    HEAP32[$2 >> 2] = $4;
    break label$20;
   }
   $4 = HEAP32[$2 >> 2];
  }
  label$22 : {
   if (!(HEAPU8[HEAP32[2] + 14 | 0] & 2)) {
    break label$22
   }
   $2 = HEAP32[$1 + 40 >> 2];
   if (!(!$2 | ($2 | 0) != HEAP32[$1 + 52 >> 2])) {
    HEAP32[$0 + 1176 >> 2] = HEAP32[$0 + 1176 >> 2] | 4
   }
   $2 = HEAP32[$14 >> 2];
   if (!(!$2 | ($2 | 0) != HEAP32[$1 + 36 >> 2])) {
    HEAP32[$0 + 1176 >> 2] = HEAP32[$0 + 1176 >> 2] | 1
   }
   if (HEAP32[$1 + 32 >> 2] == HEAP32[$1 + 48 >> 2]) {
    HEAP32[$0 + 1176 >> 2] = HEAP32[$0 + 1176 >> 2] | 2
   }
   if (!HEAP32[$1 + 44 >> 2]) {
    break label$22
   }
   congestion_wait();
  }
  label$26 : {
   if (HEAPU8[$1 + 12 | 0] & 32) {
    break label$26
   }
   $1 = HEAP32[2];
   $2 = HEAP32[$1 + 12 >> 2];
   if ($2 & 131072) {
    break label$26
   }
   label$27 : {
    if (!($2 & 1048576)) {
     break label$27
    }
    $1 = HEAP32[$1 + 808 >> 2];
    if (!$1) {
     break label$27
    }
    $2 = HEAP32[$1 + 56 >> 2];
    $5 = HEAP32[$2 + 16 >> 2];
    if ($5) {
     if (FUNCTION_TABLE[$5](HEAP32[$2 + 20 >> 2], 1)) {
      break label$27
     }
     break label$26;
    }
    if (!(HEAP32[HEAP32[$1 + 136 >> 2] >> 2] & 1)) {
     break label$26
    }
   }
   if (!(HEAP32[$0 + 1176 >> 2] & 1)) {
    break label$26
   }
   wait_iff_congested();
  }
  if (($4 | 0) != ($20 | 0)) {
   HEAP32[$0 + 1104 >> 2] = 0
  }
  global$0 = $3 + 96 | 0;
 }

 function wakeup_kswapd($0, $1, $2) {
  var $3 = 0;
  label$1 : {
   if (!HEAP32[$0 + 40 >> 2]) {
    break label$1
   }
   $0 = HEAP32[$0 + 24 >> 2];
   $3 = HEAP32[$0 + 1096 >> 2];
   HEAP32[$0 + 1096 >> 2] = ($3 | 0) > ($1 | 0) ? $3 : $1;
   $3 = HEAP32[$0 + 1100 >> 2];
   HEAP32[$0 + 1100 >> 2] = ($3 | 0) == 2 ? $2 : $3 >>> 0 > $2 >>> 0 ? $3 : $2;
   $3 = $0 + 1076 | 0;
   if (($3 | 0) == HEAP32[$0 + 1076 >> 2] | HEAP32[$0 + 1104 >> 2] > 15) {
    break label$1
   }
   if (pgdat_balanced($0, $1, $2)) {
    break label$1
   }
   __wake_up($3, 1, 0);
  }
 }

 function pgdat_balanced($0, $1, $2) {
  var $3 = 0, $4 = 0;
  $3 = -1;
  label$1 : {
   while (1) {
    if (($4 | 0) <= ($2 | 0)) {
     if (HEAP32[$0 + 40 >> 2]) {
      $3 = HEAP32[$0 + 8 >> 2];
      if (zone_watermark_ok_safe($0, $1, $3, $2)) {
       break label$1
      }
     }
     $0 = $0 + 516 | 0;
     $4 = $4 + 1 | 0;
     continue;
    }
    break;
   };
   return ($3 | 0) == -1;
  }
  return 1;
 }

 function shrink_inactive_list($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0;
  $5 = global$0 - 48 | 0;
  global$0 = $5;
  HEAP32[$5 + 44 >> 2] = $5 + 40;
  HEAP32[$5 + 40 >> 2] = $5 + 40;
  $4 = $5 + 24 | 0;
  HEAP32[$4 >> 2] = 0;
  HEAP32[$4 + 4 >> 2] = 0;
  $4 = $5 + 16 | 0;
  HEAP32[$4 >> 2] = 0;
  HEAP32[$4 + 4 >> 2] = 0;
  $4 = $5 + 8 | 0;
  HEAP32[$4 >> 2] = 0;
  HEAP32[$4 + 4 >> 2] = 0;
  HEAP32[$5 >> 2] = 0;
  HEAP32[$5 + 4 >> 2] = 0;
  $9 = $1 + -1112 | 0;
  $4 = HEAP32[2];
  $8 = $3 | 1;
  $6 = ($8 | 0) == 3;
  $7 = ($6 << 3) + 82688 | 0;
  $11 = ($6 ? 32 : 28) + 82688 | 0;
  label$1 : {
   label$2 : {
    label$3 : {
     while (1) {
      if (HEAPU8[$4 + 14 | 0] & 2) {
       break label$3
      }
      $4 = HEAP32[$7 >> 2];
      if (HEAPU32[$11 >> 2] <= ((HEAP32[$2 + 16 >> 2] & 192) == 192 ? $4 >>> 3 | 0 : $4) >>> 0) {
       break label$3
      }
      if ($12) {
       break label$2
      }
      $4 = 26;
      while (1) {
       if ($4) {
        $4 = schedule_timeout_uninterruptible($4);
        continue;
       }
       break;
      };
      $12 = 1;
      $4 = HEAP32[2];
      if (HEAP32[HEAP32[$4 + 4 >> 2] >> 2] & 4) {
       $10 = HEAP32[$4 + 760 >> 2] >>> 8 & 1
      } else {
       $10 = 0
      }
      if (!$10) {
       continue
      }
      break;
     };
     $4 = 32;
     break label$1;
    }
    lru_add_drain_cpu();
    $4 = 0;
    HEAP8[82812] = 0;
    $0 = isolate_lru_pages($0, $1, $5 + 40 | 0, $5 + 36 | 0, $2, (HEAPU8[$2 + 12 | 0] ^ -1) & 2, $3);
    $7 = ($8 | 0) == 3 ? 32 : 28;
    $3 = ($7 + $9 | 0) + 1184 | 0;
    HEAP32[$3 >> 2] = $0 + HEAP32[$3 >> 2];
    $6 = (($6 << 2) + $1 | 0) + 48 | 0;
    HEAP32[$6 >> 2] = $0 + HEAP32[$6 >> 2];
    HEAP8[82812] = 1;
    $6 = $7 + 82688 | 0;
    HEAP32[$6 >> 2] = $0 + HEAP32[$6 >> 2];
    if (!$0) {
     break label$1
    }
    $4 = shrink_page_list($5 + 40 | 0, $9, $2, $5);
    HEAP8[82812] = 0;
    putback_inactive_pages($1, $5 + 40 | 0);
    HEAP32[$3 >> 2] = HEAP32[$3 >> 2] - $0;
    HEAP8[82812] = 1;
    HEAP32[$6 >> 2] = HEAP32[$6 >> 2] - $0;
    free_unref_page_list($5 + 40 | 0);
    $1 = HEAP32[$5 + 4 >> 2];
    if (($1 | 0) == ($0 | 0)) {
     $1 = 16496;
     while (1) {
      $1 = HEAP32[$1 >> 2];
      if (($1 | 0) != 16496) {
       __wakeup_flusher_threads_bdi($1);
       continue;
      }
      break;
     };
     $1 = HEAP32[$5 + 4 >> 2];
    }
    HEAP32[$2 + 28 >> 2] = HEAP32[$2 + 28 >> 2] + HEAP32[$5 >> 2];
    $3 = $2 + 36 | 0;
    HEAP32[$3 >> 2] = HEAP32[$3 >> 2] + HEAP32[$5 + 8 >> 2];
    $3 = $2 + 32 | 0;
    HEAP32[$3 >> 2] = HEAP32[$3 >> 2] + $1;
    $1 = $2 + 40 | 0;
    HEAP32[$1 >> 2] = HEAP32[$1 >> 2] + HEAP32[$5 + 12 >> 2];
    $1 = $2 + 44 | 0;
    HEAP32[$1 >> 2] = HEAP32[$1 >> 2] + HEAP32[$5 + 16 >> 2];
    $1 = $2 + 52 | 0;
    HEAP32[$1 >> 2] = $0 + HEAP32[$1 >> 2];
    if (($8 | 0) != 3) {
     break label$1
    }
    $1 = $2 + 48 | 0;
    HEAP32[$1 >> 2] = $0 + HEAP32[$1 >> 2];
    break label$1;
   }
   $4 = 0;
  }
  global$0 = $5 + 48 | 0;
  return $4;
 }

 function isolate_lru_pages($0, $1, $2, $3, $4, $5, $6) {
  var $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0, $15 = 0, $16 = 0;
  $7 = global$0 - 48 | 0;
  global$0 = $7;
  HEAP32[$7 + 40 >> 2] = 0;
  HEAP32[$7 + 44 >> 2] = 0;
  HEAP32[$7 + 32 >> 2] = 0;
  HEAP32[$7 + 36 >> 2] = 0;
  $10 = ($6 << 3) + $1 | 0;
  $15 = $10 + 4 | 0;
  HEAP32[$7 + 28 >> 2] = $7 + 24;
  HEAP32[$7 + 24 >> 2] = $7 + 24;
  $16 = $4 + 15 | 0;
  label$1 : {
   while (1) {
    if (!($13 >>> 0 >= $0 >>> 0 | $12 >>> 0 >= $0 >>> 0 | ($10 | 0) == HEAP32[$10 >> 2])) {
     $4 = HEAP32[$15 >> 2];
     $8 = $4 + -4 | 0;
     $9 = HEAP32[$8 >> 2] >>> 31 | 0;
     label$4 : {
      if ($9 >>> 0 > HEAP8[$16 | 0] >>> 0) {
       $8 = HEAP32[$4 >> 2];
       $11 = HEAP32[$4 + 4 >> 2];
       HEAP32[$8 + 4 >> 2] = $11;
       HEAP32[$11 >> 2] = $8;
       $8 = HEAP32[$7 + 24 >> 2];
       HEAP32[$8 + 4 >> 2] = $4;
       HEAP32[$4 >> 2] = $8;
       $8 = $7 + 32 | $9 << 2;
       HEAP32[$8 >> 2] = HEAP32[$8 >> 2] + 1;
       HEAP32[$7 + 24 >> 2] = $4;
       HEAP32[$4 + 4 >> 2] = $7 + 24;
       break label$4;
      }
      $13 = $13 + 1 | 0;
      $9 = __isolate_lru_page($8, $5);
      if (($9 | 0) != -16) {
       if ($9) {
        break label$1
       }
       $9 = HEAP32[$4 >> 2];
       $11 = HEAP32[$4 + 4 >> 2];
       HEAP32[$9 + 4 >> 2] = $11;
       HEAP32[$11 >> 2] = $9;
       $9 = HEAP32[$2 >> 2];
       HEAP32[$9 + 4 >> 2] = $4;
       HEAP32[$4 >> 2] = $9;
       HEAP32[$2 >> 2] = $4;
       HEAP32[$4 + 4 >> 2] = $2;
       $4 = $7 + 40 | HEAP32[$8 >> 2] >>> 29 & 4;
       HEAP32[$4 >> 2] = HEAP32[$4 >> 2] + 1;
       $12 = $12 + 1 | 0;
       break label$4;
      }
      $8 = HEAP32[$4 >> 2];
      $9 = HEAP32[$4 + 4 >> 2];
      HEAP32[$8 + 4 >> 2] = $9;
      HEAP32[$9 >> 2] = $8;
      $8 = HEAP32[$10 >> 2];
      HEAP32[$8 + 4 >> 2] = $4;
      HEAP32[$4 >> 2] = $8;
      HEAP32[$10 >> 2] = $4;
      HEAP32[$4 + 4 >> 2] = $10;
     }
     $14 = $14 + 1 | 0;
     continue;
    }
    break;
   };
   label$7 : {
    if (HEAP32[$7 + 24 >> 2] == ($7 + 24 | 0)) {
     break label$7
    }
    $0 = HEAP32[$7 + 24 >> 2];
    if (($0 | 0) == ($7 + 24 | 0)) {
     break label$7
    }
    $2 = HEAP32[$7 + 28 >> 2];
    HEAP32[$0 + 4 >> 2] = $10;
    $4 = HEAP32[$10 >> 2];
    HEAP32[$10 >> 2] = $0;
    HEAP32[$4 + 4 >> 2] = $2;
    HEAP32[$2 >> 2] = $4;
   }
   HEAP32[$3 >> 2] = $14;
   $0 = $6 << 2;
   $2 = $0 + 82644 | 0;
   $3 = $0 + 82688 | 0;
   $1 = $0 + $1 | 0;
   $0 = $1 + -640 | 0;
   $5 = $1 + 72 | 0;
   $4 = 0;
   while (1) {
    if (($4 | 0) != 8) {
     $1 = HEAP32[($7 + 40 | 0) + $4 >> 2];
     if ($1) {
      HEAP32[$5 >> 2] = HEAP32[$5 >> 2] - $1;
      HEAP32[$3 >> 2] = HEAP32[$3 >> 2] - $1;
      HEAP32[$0 >> 2] = HEAP32[$0 >> 2] - $1;
      HEAP32[$2 >> 2] = HEAP32[$2 >> 2] - $1;
     }
     $4 = $4 + 4 | 0;
     $0 = $0 + 516 | 0;
     continue;
    }
    break;
   };
   global$0 = $7 + 48 | 0;
   return $12;
  }
  HEAP32[$7 + 8 >> 2] = 26360;
  HEAP32[$7 + 4 >> 2] = 1716;
  HEAP32[$7 >> 2] = 26202;
  printk(26164, $7);
  abort();
 }

 function move_active_pages_to_lru($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0;
  $7 = $0 + -1112 | 0;
  $6 = ($7 + ($3 << 3) | 0) + 1112 | 0;
  $0 = $3 << 2;
  $8 = ($0 + $7 | 0) + 1184 | 0;
  $9 = $0 + 82688 | 0;
  $11 = $3 + 1 << 2;
  $10 = $11 + 82640 | 0;
  $12 = $1 + 4 | 0;
  while (1) {
   if (($1 | 0) != HEAP32[$1 >> 2]) {
    $0 = HEAP32[$12 >> 2];
    $4 = HEAP32[$0 >> 2];
    $3 = $0 + -4 | 0;
    $5 = $4 & 1 ? $4 + -1 | 0 : $3;
    HEAP32[$5 >> 2] = HEAP32[$5 >> 2] | 16;
    HEAP32[$8 >> 2] = HEAP32[$8 >> 2] + 1;
    HEAP32[$9 >> 2] = HEAP32[$9 >> 2] + 1;
    $5 = ((Math_imul(HEAP32[$3 >> 2] >>> 31 | 0, 516) + $7 | 0) + $11 | 0) + 468 | 0;
    HEAP32[$5 >> 2] = HEAP32[$5 >> 2] + 1;
    HEAP32[$10 >> 2] = HEAP32[$10 >> 2] + 1;
    $5 = HEAP32[$0 + 4 >> 2];
    HEAP32[$4 + 4 >> 2] = $5;
    HEAP32[$5 >> 2] = $4;
    $4 = HEAP32[$6 >> 2];
    HEAP32[$4 + 4 >> 2] = $0;
    HEAP32[$6 >> 2] = $0;
    HEAP32[$0 >> 2] = $4;
    HEAP32[$0 + 4 >> 2] = $6;
    $4 = HEAP32[$0 + 24 >> 2] + -1 | 0;
    HEAP32[$0 + 24 >> 2] = $4;
    if ($4) {
     continue
    }
    $5 = HEAP32[$0 >> 2];
    $4 = HEAP32[$0 >> 2];
    HEAP32[$6 >> 2] = $4;
    $5 = $5 & 1 ? $5 + -1 | 0 : $3;
    HEAP32[$5 >> 2] = HEAP32[$5 >> 2] & -17;
    HEAP32[$8 >> 2] = HEAP32[$8 >> 2] + -1;
    $5 = $4 & 1 ? $4 + -1 | 0 : $3;
    HEAP32[$5 >> 2] = HEAP32[$5 >> 2] & -33;
    HEAP32[$9 >> 2] = HEAP32[$9 >> 2] + -1;
    HEAP32[$4 + 4 >> 2] = $6;
    $4 = ((Math_imul(HEAP32[$3 >> 2] >>> 31 | 0, 516) + $7 | 0) + $11 | 0) + 468 | 0;
    HEAP32[$4 >> 2] = HEAP32[$4 >> 2] + -1;
    HEAP32[$0 >> 2] = 256;
    $4 = $0 + 4 | 0;
    HEAP32[$4 >> 2] = 512;
    HEAP32[$10 >> 2] = HEAP32[$10 >> 2] + -1;
    if (HEAP32[$3 >> 2] & 65536 | HEAP32[$0 >> 2] & 1) {
     HEAP8[82812] = 1;
     FUNCTION_TABLE[HEAP32[(HEAPU8[$0 + 40 | 0] << 2) + 26460 >> 2]]($3);
     HEAP8[82812] = 0;
     continue;
    } else {
     $3 = HEAP32[$2 >> 2];
     HEAP32[$3 + 4 >> 2] = $0;
     HEAP32[$0 >> 2] = $3;
     HEAP32[$2 >> 2] = $0;
     HEAP32[$4 >> 2] = $2;
     continue;
    }
   }
   break;
  };
 }

 function putback_inactive_pages($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0;
  $6 = global$0 - 16 | 0;
  global$0 = $6;
  $12 = $0 + -1112 | 0;
  HEAP32[$6 + 12 >> 2] = $6 + 8;
  HEAP32[$6 + 8 >> 2] = $6 + 8;
  $14 = $1 + 4 | 0;
  while (1) {
   if (($1 | 0) != HEAP32[$1 >> 2]) {
    $3 = HEAP32[$14 >> 2];
    $4 = HEAP32[$3 >> 2];
    $2 = HEAP32[$3 + 4 >> 2];
    HEAP32[$4 + 4 >> 2] = $2;
    HEAP32[$2 >> 2] = $4;
    HEAP32[$3 >> 2] = 256;
    HEAP32[$3 + 4 >> 2] = 512;
    $4 = $3 + -4 | 0;
    if (page_evictable($4)) {
     $2 = HEAP32[$3 >> 2];
     $2 = $2 & 1 ? $2 + -1 | 0 : $4;
     HEAP32[$2 >> 2] = HEAP32[$2 >> 2] | 16;
     $2 = 4;
     $5 = HEAP32[$3 >> 2];
     if (!(HEAP32[($5 & 1 ? $5 + -1 | 0 : $4) >> 2] & 1048576)) {
      $2 = HEAP32[$3 >> 2];
      $5 = HEAP32[($2 & 1 ? $2 + -1 | 0 : $4) >> 2] >>> 5 & 1;
      $2 = HEAP32[$3 >> 2];
      $2 = ($5 | HEAP32[($2 & 1 ? $2 + -1 | 0 : $4) >> 2] >>> 18 & 2) ^ 2;
     }
     $5 = $2 << 2;
     $7 = ($5 + $12 | 0) + 1184 | 0;
     HEAP32[$7 >> 2] = HEAP32[$7 >> 2] + 1;
     $10 = $5 + 82688 | 0;
     HEAP32[$10 >> 2] = HEAP32[$10 >> 2] + 1;
     $13 = $2 + 1 << 2;
     $5 = ($13 + (Math_imul(HEAP32[$4 >> 2] >>> 31 | 0, 516) + $12 | 0) | 0) + 468 | 0;
     HEAP32[$5 >> 2] = HEAP32[$5 >> 2] + 1;
     $5 = ($2 << 3) + $0 | 0;
     $8 = HEAP32[$5 >> 2];
     HEAP32[$8 + 4 >> 2] = $3;
     $11 = $13 + 82640 | 0;
     HEAP32[$11 >> 2] = HEAP32[$11 >> 2] + 1;
     HEAP32[$3 >> 2] = $8;
     $8 = $3 + 4 | 0;
     HEAP32[$8 >> 2] = $5;
     HEAP32[$5 >> 2] = $3;
     if (($2 | 2) == 3) {
      $2 = (((($2 | 1) == 3) << 2) + $0 | 0) + 40 | 0;
      HEAP32[$2 >> 2] = HEAP32[$2 >> 2] + 1;
     }
     $2 = HEAP32[$3 + 24 >> 2] + -1 | 0;
     HEAP32[$3 + 24 >> 2] = $2;
     if ($2) {
      continue
     }
     $9 = HEAP32[$3 >> 2];
     $2 = HEAP32[$3 >> 2];
     HEAP32[$5 >> 2] = $2;
     $9 = $9 & 1 ? $9 + -1 | 0 : $4;
     HEAP32[$9 >> 2] = HEAP32[$9 >> 2] & -17;
     HEAP32[$7 >> 2] = HEAP32[$7 >> 2] + -1;
     $7 = $2 & 1 ? $2 + -1 | 0 : $4;
     HEAP32[$7 >> 2] = HEAP32[$7 >> 2] & -33;
     HEAP32[$10 >> 2] = HEAP32[$10 >> 2] + -1;
     HEAP32[$2 + 4 >> 2] = $5;
     $2 = ((Math_imul(HEAP32[$4 >> 2] >>> 31 | 0, 516) + $12 | 0) + $13 | 0) + 468 | 0;
     HEAP32[$2 >> 2] = HEAP32[$2 >> 2] + -1;
     HEAP32[$3 >> 2] = 256;
     HEAP32[$8 >> 2] = 512;
     HEAP32[$11 >> 2] = HEAP32[$11 >> 2] + -1;
     if (!(HEAP32[$4 >> 2] & 65536 | HEAP32[$3 >> 2] & 1)) {
      $4 = HEAP32[$6 + 8 >> 2];
      HEAP32[$4 + 4 >> 2] = $3;
      HEAP32[$3 >> 2] = $4;
      HEAP32[$6 + 8 >> 2] = $3;
      HEAP32[$8 >> 2] = $6 + 8;
      continue;
     }
     HEAP8[82812] = 1;
     FUNCTION_TABLE[HEAP32[(HEAPU8[$3 + 40 | 0] << 2) + 26460 >> 2]]($4);
     HEAP8[82812] = 0;
     continue;
    } else {
     HEAP8[82812] = 1;
     putback_lru_page($4);
     HEAP8[82812] = 0;
     continue;
    }
   }
   break;
  };
  $0 = HEAP32[$6 + 8 >> 2];
  if (($0 | 0) != ($6 + 8 | 0)) {
   HEAP32[$1 >> 2] = $0;
   $3 = HEAP32[$6 + 12 >> 2];
   HEAP32[$0 + 4 >> 2] = $1;
   HEAP32[$3 >> 2] = $1;
   HEAP32[$1 + 4 >> 2] = $3;
  }
  global$0 = $6 + 16 | 0;
 }

 function __put_page($0) {
  if (!(HEAP32[$0 >> 2] & 65536 | HEAP32[$0 + 4 >> 2] & 1)) {
   __page_cache_release($0);
   free_unref_page($0);
   return;
  }
  __put_compound_page($0);
 }

 function __page_cache_release($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  $1 = HEAP32[$0 + 4 >> 2];
  if (HEAP32[($1 & 1 ? $1 + -1 | 0 : $0) >> 2] & 16) {
   $7 = HEAP32[20704];
   $5 = HEAP32[$0 >> 2];
   HEAP32[20704] = 0;
   $3 = 4;
   $4 = $0 + 4 | 0;
   $1 = HEAP32[$4 >> 2];
   $1 = $1 & 1 ? $1 + -1 | 0 : $0;
   HEAP32[$1 >> 2] = HEAP32[$1 >> 2] & -17;
   $1 = HEAP32[$4 >> 2];
   $2 = $1 & 1 ? $1 + -1 | 0 : $0;
   $5 = HEAP32[Math_imul($5 >>> 31 | 0, 516) + 141200 >> 2] + 1112 | 0;
   $4 = HEAP32[$4 >> 2];
   label$2 : {
    if (!(HEAP32[($4 & 1 ? $4 + -1 | 0 : $0) >> 2] & 1048576)) {
     $3 = (HEAP32[$2 >> 2] >>> 18 ^ -1) & 2;
     $2 = $0 + 4 | 0;
     $1 = HEAP32[$2 >> 2];
     if (!(HEAP32[($1 & 1 ? $1 + -1 | 0 : $0) >> 2] & 32)) {
      break label$2
     }
     $1 = HEAP32[$2 >> 2];
     $2 = $1 & 1 ? $1 + -1 | 0 : $0;
     HEAP32[$2 >> 2] = HEAP32[$2 >> 2] & -33;
     $3 = $3 | 1;
     break label$2;
    }
    HEAP32[$2 >> 2] = HEAP32[$2 >> 2] & -1048577;
   }
   $2 = $0 + 8 | 0;
   $4 = HEAP32[$2 >> 2];
   HEAP32[$4 >> 2] = $1;
   $5 = $5 + -1112 | 0;
   $3 = $3 << 2;
   $6 = ($5 + $3 | 0) + 1184 | 0;
   HEAP32[$6 >> 2] = HEAP32[$6 >> 2] + -1;
   $6 = $3 + 82688 | 0;
   HEAP32[$6 >> 2] = HEAP32[$6 >> 2] + -1;
   HEAP32[$1 + 4 >> 2] = $4;
   $1 = ($3 + ($5 + Math_imul(HEAP32[$0 >> 2] >>> 31 | 0, 516) | 0) | 0) + 472 | 0;
   HEAP32[$1 >> 2] = HEAP32[$1 >> 2] + -1;
   HEAP32[$0 + 4 >> 2] = 256;
   HEAP32[20704] = $7;
   HEAP32[$2 >> 2] = 512;
   $1 = $3 + 82644 | 0;
   HEAP32[$1 >> 2] = HEAP32[$1 >> 2] + -1;
  }
  HEAP32[$0 >> 2] = HEAP32[$0 >> 2] & -129;
 }

 function __put_compound_page($0) {
  __page_cache_release($0);
  FUNCTION_TABLE[HEAP32[(HEAPU8[$0 + 44 | 0] << 2) + 26460 >> 2]]($0);
 }

 function pagevec_move_tail() {
  var $0 = 0;
  $0 = global$0 - 16 | 0;
  global$0 = $0;
  HEAP32[$0 + 12 >> 2] = 0;
  pagevec_lru_move_fn(16572, 88, $0 + 12 | 0);
  global$0 = $0 + 16 | 0;
 }

 function pagevec_move_tail_fn($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0;
  label$1 : {
   $4 = HEAP32[$0 + 4 >> 2];
   if (!(HEAP32[($4 & 1 ? $4 + -1 | 0 : $0) >> 2] & 16)) {
    break label$1
   }
   $4 = 4;
   $3 = $0 + 4 | 0;
   $7 = HEAP32[$3 >> 2];
   if (HEAP32[($7 & 1 ? $7 + -1 | 0 : $0) >> 2] & 1048576) {
    break label$1
   }
   $3 = HEAP32[$3 >> 2];
   if (!(HEAP32[($3 & 1 ? $3 + -1 | 0 : $0) >> 2] & 1048576)) {
    $3 = $0 + 4 | 0;
    $4 = HEAP32[$3 >> 2];
    $3 = HEAP32[$3 >> 2];
    $4 = (HEAP32[($3 & 1 ? $3 + -1 | 0 : $0) >> 2] >>> 5 & 1 | HEAP32[($4 & 1 ? $4 + -1 | 0 : $0) >> 2] >>> 18 & 2) ^ 2;
   }
   $7 = $0 + 8 | 0;
   $8 = HEAP32[$7 >> 2];
   HEAP32[$8 >> 2] = $3;
   $5 = $1 + -1112 | 0;
   $4 = $4 << 2;
   $6 = ($5 + $4 | 0) + 1184 | 0;
   HEAP32[$6 >> 2] = HEAP32[$6 >> 2] + -1;
   $6 = $4 + 82688 | 0;
   HEAP32[$6 >> 2] = HEAP32[$6 >> 2] + -1;
   $6 = $5 + Math_imul(HEAP32[$0 >> 2] >>> 31 | 0, 516) | 0;
   $9 = ($6 + $4 | 0) + 472 | 0;
   HEAP32[$9 >> 2] = HEAP32[$9 >> 2] + -1;
   HEAP32[$0 + 4 >> 2] = 256;
   $4 = $4 + 82644 | 0;
   HEAP32[$4 >> 2] = HEAP32[$4 >> 2] + -1;
   HEAP32[$3 + 4 >> 2] = $8;
   $4 = HEAP32[$0 + 4 >> 2];
   $4 = $4 & 1 ? $4 + -1 | 0 : $0;
   HEAP32[$4 >> 2] = HEAP32[$4 >> 2] & -33;
   HEAP32[$7 >> 2] = 512;
   $4 = 4;
   $3 = HEAP32[$0 + 4 >> 2];
   if (!(HEAP32[($3 & 1 ? $3 + -1 | 0 : $0) >> 2] & 1048576)) {
    $3 = $0 + 4 | 0;
    $4 = HEAP32[$3 >> 2];
    $3 = HEAP32[$3 >> 2];
    $4 = (HEAP32[($3 & 1 ? $3 + -1 | 0 : $0) >> 2] >>> 5 & 1 | HEAP32[($4 & 1 ? $4 + -1 | 0 : $0) >> 2] >>> 18 & 2) ^ 2;
   }
   $3 = $4 << 2;
   $5 = ($3 + $5 | 0) + 1184 | 0;
   HEAP32[$5 >> 2] = HEAP32[$5 >> 2] + 1;
   $5 = $3 + 82688 | 0;
   HEAP32[$5 >> 2] = HEAP32[$5 >> 2] + 1;
   $5 = ($3 + $6 | 0) + 472 | 0;
   HEAP32[$5 >> 2] = HEAP32[$5 >> 2] + 1;
   $3 = $3 + 82644 | 0;
   HEAP32[$3 >> 2] = HEAP32[$3 >> 2] + 1;
   $1 = ($4 << 3) + $1 | 0;
   $4 = HEAP32[$1 + 4 >> 2];
   $3 = $0 + 4 | 0;
   HEAP32[$1 + 4 >> 2] = $3;
   HEAP32[$4 >> 2] = $3;
   HEAP32[$0 + 4 >> 2] = $1;
   HEAP32[$7 >> 2] = $4;
   HEAP32[$2 >> 2] = HEAP32[$2 >> 2] + 1;
  }
 }

 function pagevec_lru_move_fn($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  $4 = $0 + 4 | 0;
  while (1) {
   $3 = HEAPU8[$0 | 0];
   if ($6 >>> 0 < $3 >>> 0) {
    $3 = HEAP32[$4 >> 2];
    if (($5 | 0) != 141176) {
     if ($5) {
      HEAP32[20704] = $7
     }
     $7 = HEAP32[20704];
     HEAP32[20704] = 0;
    }
    FUNCTION_TABLE[$1]($3, 142288, $2);
    $4 = $4 + 4 | 0;
    $6 = $6 + 1 | 0;
    $5 = 141176;
    continue;
   }
   break;
  };
  $1 = $0 + 4 | 0;
  if ($5) {
   HEAP32[20704] = $7;
   $3 = HEAPU8[$0 | 0];
  }
  release_pages($1, $3);
  HEAP8[$0 | 0] = 0;
 }

 function __lru_cache_add($0) {
  var $1 = 0, $2 = 0;
  $1 = HEAPU8[16636];
  $2 = $1 + 1 | 0;
  HEAP8[16636] = $2;
  HEAP32[($1 << 2) + 16640 >> 2] = $0;
  $1 = HEAP32[$0 + 4 >> 2];
  $1 = $1 & 1 ? $1 + -1 | 0 : $0;
  HEAP32[$1 + 28 >> 2] = HEAP32[$1 + 28 >> 2] + 1;
  if (!(HEAP32[$0 + 4 >> 2] & 1 ? 0 : !(HEAP32[$0 >> 2] & 65536 | ($2 & 255) == 15))) {
   __pagevec_lru_add()
  }
 }

 function __pagevec_lru_add() {
  pagevec_lru_move_fn(16636, 89, 0);
 }

 function lru_add_drain_cpu() {
  var $0 = 0;
  if (HEAPU8[16636]) {
   __pagevec_lru_add()
  }
  if (HEAPU8[16572]) {
   $0 = HEAP32[20704];
   HEAP32[20704] = 0;
   pagevec_move_tail();
   HEAP32[20704] = $0;
  }
  if (HEAPU8[16700]) {
   pagevec_lru_move_fn(16700, 90, 0)
  }
  if (HEAPU8[16764]) {
   pagevec_lru_move_fn(16764, 91, 0)
  }
 }

 function lru_deactivate_file_fn($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0;
  label$1 : {
   $2 = HEAP32[$0 + 4 >> 2];
   if (!(HEAP32[($2 & 1 ? $2 + -1 | 0 : $0) >> 2] & 16)) {
    break label$1
   }
   $2 = HEAP32[$0 + 4 >> 2];
   if (HEAP32[($2 & 1 ? $2 + -1 | 0 : $0) >> 2] & 1048576) {
    break label$1
   }
   if (page_mapped($0)) {
    break label$1
   }
   $2 = $0 + 4 | 0;
   $4 = HEAP32[$2 >> 2];
   $6 = HEAP32[($4 & 1 ? $4 + -1 | 0 : $0) >> 2];
   $4 = HEAP32[$2 >> 2];
   $8 = HEAP32[($4 & 1 ? $4 + -1 | 0 : $0) >> 2];
   $4 = HEAP32[$2 >> 2];
   $3 = HEAP32[($4 & 1 ? $4 + -1 | 0 : $0) >> 2];
   $9 = $0 + 8 | 0;
   $10 = HEAP32[$9 >> 2];
   HEAP32[$10 >> 2] = $4;
   $7 = $1 + 72 | 0;
   $5 = $6 >>> 5 & 1;
   $6 = ($3 >>> 18 ^ -1) & 2;
   $3 = ($5 | $6) << 2;
   $5 = $7 + $3 | 0;
   HEAP32[$5 >> 2] = HEAP32[$5 >> 2] + -1;
   $5 = $3 + 82688 | 0;
   HEAP32[$5 >> 2] = HEAP32[$5 >> 2] + -1;
   $5 = (Math_imul(HEAP32[$0 >> 2] >>> 31 | 0, 516) + $1 | 0) + -644 | 0;
   $11 = ($5 + $3 | 0) + 4 | 0;
   HEAP32[$11 >> 2] = HEAP32[$11 >> 2] + -1;
   HEAP32[$2 >> 2] = 256;
   $3 = $3 + 82644 | 0;
   HEAP32[$3 >> 2] = HEAP32[$3 >> 2] + -1;
   $3 = HEAP32[$2 >> 2];
   $3 = $3 & 1 ? $3 + -1 | 0 : $0;
   HEAP32[$3 >> 2] = HEAP32[$3 >> 2] & -33;
   $3 = HEAP32[$2 >> 2];
   $3 = $3 & 1 ? $3 + -1 | 0 : $0;
   HEAP32[$3 >> 2] = HEAP32[$3 >> 2] & -3;
   $3 = $6 << 2;
   $7 = $3 + $7 | 0;
   HEAP32[$7 >> 2] = HEAP32[$7 >> 2] + 1;
   $7 = $3 + 82688 | 0;
   HEAP32[$7 >> 2] = HEAP32[$7 >> 2] + 1;
   HEAP32[$4 + 4 >> 2] = $10;
   $4 = $3 | 4;
   $3 = $4 + $5 | 0;
   HEAP32[$3 >> 2] = HEAP32[$3 >> 2] + 1;
   HEAP32[$9 >> 2] = 512;
   $4 = $4 + 82640 | 0;
   HEAP32[$4 >> 2] = HEAP32[$4 >> 2] + 1;
   $4 = ($6 << 3) + $1 | 0;
   $3 = HEAP32[$4 >> 2];
   HEAP32[$3 + 4 >> 2] = $2;
   HEAP32[$2 >> 2] = $3;
   HEAP32[$4 >> 2] = $2;
   HEAP32[$9 >> 2] = $4;
   $9 = ($8 >>> 19 ^ -1) & 1;
   label$2 : {
    label$3 : {
     $8 = HEAP32[$2 >> 2];
     if (HEAP32[($8 & 1 ? $8 + -1 | 0 : $0) >> 2] & 32768) {
      break label$3
     }
     $8 = HEAP32[$2 >> 2];
     if (HEAP32[($8 & 1 ? $8 + -1 | 0 : $0) >> 2] & 8) {
      break label$3
     }
     HEAP32[$3 + 4 >> 2] = $4;
     HEAP32[$4 >> 2] = $3;
     $3 = ($6 << 3) + $1 | 0;
     $6 = HEAP32[$3 + 4 >> 2];
     HEAP32[$3 + 4 >> 2] = $2;
     HEAP32[$0 + 4 >> 2] = $4;
     HEAP32[$6 >> 2] = $2;
     HEAP32[$0 + 8 >> 2] = $6;
     break label$2;
    }
    $2 = HEAP32[$2 >> 2];
    $0 = $2 & 1 ? $2 + -1 | 0 : $0;
    HEAP32[$0 >> 2] = HEAP32[$0 >> 2] | 262144;
   }
   $0 = (($9 << 2) + $1 | 0) + 48 | 0;
   HEAP32[$0 >> 2] = HEAP32[$0 >> 2] + 1;
  }
 }

 function lru_lazyfree_fn($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0;
  label$1 : {
   $2 = HEAP32[$0 + 4 >> 2];
   if (!(HEAP32[($2 & 1 ? $2 + -1 | 0 : $0) >> 2] & 16)) {
    break label$1
   }
   $2 = $0 + 4 | 0;
   $4 = HEAP32[$2 >> 2];
   if (!(HEAP8[($4 & 1 ? $4 + -1 | 0 : $0) + 12 | 0] & 1)) {
    break label$1
   }
   $2 = HEAP32[$2 >> 2];
   if (!(HEAP32[($2 & 1 ? $2 + -1 | 0 : $0) >> 2] & 524288)) {
    break label$1
   }
   $2 = $0 + 4 | 0;
   $4 = HEAP32[$2 >> 2];
   if (HEAP32[($4 & 1 ? $4 + -1 | 0 : $0) >> 2] & 1048576) {
    break label$1
   }
   $4 = HEAP32[$2 >> 2];
   $3 = HEAP32[($4 & 1 ? $4 + -1 | 0 : $0) >> 2];
   $7 = $0 + 8 | 0;
   $8 = HEAP32[$7 >> 2];
   HEAP32[$8 >> 2] = $4;
   $6 = $1 + -1112 | 0;
   $3 = $3 >>> 3 & 4;
   $5 = ($6 + $3 | 0) + 1184 | 0;
   HEAP32[$5 >> 2] = HEAP32[$5 >> 2] + -1;
   $5 = $3 + 82688 | 0;
   HEAP32[$5 >> 2] = HEAP32[$5 >> 2] + -1;
   $6 = $6 + Math_imul(HEAP32[$0 >> 2] >>> 31 | 0, 516) | 0;
   $5 = ($6 + $3 | 0) + 472 | 0;
   HEAP32[$5 >> 2] = HEAP32[$5 >> 2] + -1;
   HEAP32[$2 >> 2] = 256;
   $3 = $3 + 82644 | 0;
   HEAP32[$3 >> 2] = HEAP32[$3 >> 2] + -1;
   $3 = HEAP32[$2 >> 2];
   $3 = $3 & 1 ? $3 + -1 | 0 : $0;
   HEAP32[$3 >> 2] = HEAP32[$3 >> 2] & -33;
   $3 = HEAP32[$2 >> 2];
   $3 = $3 & 1 ? $3 + -1 | 0 : $0;
   HEAP32[$3 >> 2] = HEAP32[$3 >> 2] & -3;
   $3 = HEAP32[$2 >> 2];
   $0 = $3 & 1 ? $3 + -1 | 0 : $0;
   HEAP32[$0 >> 2] = HEAP32[$0 >> 2] & -524289;
   HEAP32[20674] = HEAP32[20674] + 1;
   $0 = $1 + 80 | 0;
   HEAP32[$0 >> 2] = HEAP32[$0 >> 2] + 1;
   HEAP32[$4 + 4 >> 2] = $8;
   $0 = $6 + 480 | 0;
   HEAP32[$0 >> 2] = HEAP32[$0 >> 2] + 1;
   HEAP32[$7 >> 2] = 512;
   HEAP32[20663] = HEAP32[20663] + 1;
   $0 = HEAP32[$1 + 16 >> 2];
   HEAP32[$0 + 4 >> 2] = $2;
   HEAP32[$2 >> 2] = $0;
   HEAP32[$1 + 16 >> 2] = $2;
   HEAP32[$7 >> 2] = $1 + 16;
   $0 = $1 + 52 | 0;
   HEAP32[$0 >> 2] = HEAP32[$0 >> 2] + 1;
  }
 }

 function __pagevec_lru_add_fn($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $6 = global$0 - 16 | 0;
  global$0 = $6;
  $2 = HEAP32[$0 + 4 >> 2];
  $2 = $2 & 1 ? $2 + -1 | 0 : $0;
  $3 = HEAP32[$2 >> 2];
  HEAP32[$6 + 12 >> 2] = $3;
  if (HEAP32[$6 + 12 >> 2] & 1048576) {
   HEAP32[$2 >> 2] = $3 & -1048577
  }
  $2 = 4;
  $3 = $0 + 4 | 0;
  $4 = HEAP32[$3 >> 2];
  $4 = $4 & 1 ? $4 + -1 | 0 : $0;
  HEAP32[$4 >> 2] = HEAP32[$4 >> 2] | 16;
  $4 = page_evictable($0);
  $3 = HEAP32[$3 >> 2];
  $3 = $3 & 1 ? $3 + -1 | 0 : $0;
  label$2 : {
   if ($4) {
    if (!(HEAP32[$3 >> 2] & 1048576)) {
     $3 = $0 + 4 | 0;
     $2 = HEAP32[$3 >> 2];
     $3 = HEAP32[$3 >> 2];
     $2 = (HEAP32[($3 & 1 ? $3 + -1 | 0 : $0) >> 2] >>> 5 & 1 | HEAP32[($2 & 1 ? $2 + -1 | 0 : $0) >> 2] >>> 18 & 2) ^ 2;
    }
    $4 = $0 + 4 | 0;
    $3 = HEAP32[$4 >> 2];
    $4 = HEAP32[$4 >> 2];
    $4 = HEAP32[($4 & 1 ? $4 + -1 | 0 : $0) >> 2];
    $3 = (((HEAP32[($3 & 1 ? $3 + -1 | 0 : $0) >> 2] >>> 19 ^ -1) & 1) << 2) + $1 | 0;
    $5 = $3 + 48 | 0;
    HEAP32[$5 >> 2] = HEAP32[$5 >> 2] + 1;
    if (!($4 & 32)) {
     break label$2
    }
    $3 = $3 + 40 | 0;
    HEAP32[$3 >> 2] = HEAP32[$3 >> 2] + 1;
    break label$2;
   }
   HEAP32[$3 >> 2] = HEAP32[$3 >> 2] & -33;
   $3 = HEAP32[$0 + 4 >> 2];
   $3 = $3 & 1 ? $3 + -1 | 0 : $0;
   HEAP32[$3 >> 2] = HEAP32[$3 >> 2] | 1048576;
  }
  $4 = $1 + -1112 | 0;
  $3 = $2 << 2;
  $5 = ($4 + $3 | 0) + 1184 | 0;
  HEAP32[$5 >> 2] = HEAP32[$5 >> 2] + 1;
  $5 = $3 + 82688 | 0;
  HEAP32[$5 >> 2] = HEAP32[$5 >> 2] + 1;
  $4 = ($3 + ($4 + Math_imul(HEAP32[$0 >> 2] >>> 31 | 0, 516) | 0) | 0) + 472 | 0;
  HEAP32[$4 >> 2] = HEAP32[$4 >> 2] + 1;
  $1 = ($2 << 3) + $1 | 0;
  $2 = HEAP32[$1 >> 2];
  $4 = $0 + 4 | 0;
  HEAP32[$2 + 4 >> 2] = $4;
  $3 = $3 + 82644 | 0;
  HEAP32[$3 >> 2] = HEAP32[$3 >> 2] + 1;
  HEAP32[$0 + 4 >> 2] = $2;
  HEAP32[$0 + 8 >> 2] = $1;
  HEAP32[$1 >> 2] = $4;
  global$0 = $6 + 16 | 0;
 }

 function release_pages($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0;
  $7 = global$0 - 16 | 0;
  global$0 = $7;
  HEAP32[$7 + 12 >> 2] = $7 + 8;
  HEAP32[$7 + 8 >> 2] = $7 + 8;
  while (1) {
   if (!(($10 | 0) >= ($1 | 0))) {
    $4 = HEAP32[$0 >> 2];
    label$3 : {
     if ($2) {
      $8 = $8 + 1 | 0;
      if (($8 | 0) != 32) {
       break label$3
      }
      $2 = 0;
      HEAP32[20704] = $9;
      $8 = 32;
      break label$3;
     }
     $2 = 0;
    }
    $5 = HEAP32[$4 + 4 >> 2];
    $4 = $5 & 1 ? $5 + -1 | 0 : $4;
    $5 = HEAP32[$4 + 28 >> 2] + -1 | 0;
    HEAP32[$4 + 28 >> 2] = $5;
    label$5 : {
     if ($5) {
      break label$5
     }
     label$6 : {
      label$7 : {
       label$8 : {
        if (!(HEAP32[$4 >> 2] & 65536 | HEAP32[$4 + 4 >> 2] & 1)) {
         $5 = $4 + 4 | 0;
         $3 = HEAP32[$5 >> 2];
         if (!(HEAP32[($3 & 1 ? $3 + -1 | 0 : $4) >> 2] & 16)) {
          break label$6
         }
         if (($2 | 0) != 141176) {
          if ($2) {
           HEAP32[20704] = $9
          }
          $9 = HEAP32[20704];
          HEAP32[20704] = 0;
          $8 = 0;
         }
         $2 = HEAP32[$5 >> 2];
         $2 = $2 & 1 ? $2 + -1 | 0 : $4;
         HEAP32[$2 >> 2] = HEAP32[$2 >> 2] & -17;
         $2 = HEAP32[$5 >> 2];
         $3 = $2 & 1 ? $2 + -1 | 0 : $4;
         $6 = HEAP32[$5 >> 2];
         if (HEAP32[($6 & 1 ? $6 + -1 | 0 : $4) >> 2] & 1048576) {
          break label$8
         }
         $3 = (HEAP32[$3 >> 2] >>> 18 ^ -1) & 2;
         $2 = HEAP32[$5 >> 2];
         $6 = $3;
         if (!(HEAP32[($2 & 1 ? $2 + -1 | 0 : $4) >> 2] & 32)) {
          break label$7
         }
         $2 = HEAP32[$5 >> 2];
         $6 = $2 & 1 ? $2 + -1 | 0 : $4;
         HEAP32[$6 >> 2] = HEAP32[$6 >> 2] & -33;
         $6 = $3 | 1;
         break label$7;
        }
        if ($2) {
         HEAP32[20704] = $9
        }
        __put_compound_page($4);
        $2 = 0;
        break label$5;
       }
       HEAP32[$3 >> 2] = HEAP32[$3 >> 2] & -1048577;
       $6 = 4;
      }
      $3 = $6;
      $6 = $4 + 8 | 0;
      $11 = HEAP32[$6 >> 2];
      HEAP32[$11 >> 2] = $2;
      HEAP32[$2 + 4 >> 2] = $11;
      $2 = $3 << 2;
      $3 = $2 + 142360 | 0;
      HEAP32[$3 >> 2] = HEAP32[$3 >> 2] + -1;
      HEAP32[$4 + 4 >> 2] = 256;
      HEAP32[$6 >> 2] = 512;
      $3 = $2 + 82644 | 0;
      HEAP32[$3 >> 2] = HEAP32[$3 >> 2] + -1;
      $3 = $2 + 82688 | 0;
      HEAP32[$3 >> 2] = HEAP32[$3 >> 2] + -1;
      $2 = ($2 + Math_imul(HEAP32[$4 >> 2] >>> 31 | 0, 516) | 0) + 141648 | 0;
      HEAP32[$2 >> 2] = HEAP32[$2 >> 2] + -1;
      $2 = 141176;
     }
     $3 = HEAP32[$5 >> 2];
     $3 = $3 & 1 ? $3 + -1 | 0 : $4;
     HEAP32[$3 >> 2] = HEAP32[$3 >> 2] & -33;
     $3 = HEAP32[$7 + 8 >> 2];
     HEAP32[$3 + 4 >> 2] = $5;
     HEAP32[$5 >> 2] = $3;
     HEAP32[$4 >> 2] = HEAP32[$4 >> 2] & -129;
     HEAP32[$4 + 8 >> 2] = $7 + 8;
     HEAP32[$7 + 8 >> 2] = $5;
    }
    $0 = $0 + 4 | 0;
    $10 = $10 + 1 | 0;
    continue;
   }
   break;
  };
  if ($2) {
   HEAP32[20704] = $9
  }
  free_unref_page_list($7 + 8 | 0);
  global$0 = $7 + 16 | 0;
 }

 function global_dirtyable_memory() {
  var $0 = 0, $1 = 0;
  $0 = HEAP32[20660];
  $1 = HEAP32[20708];
  return HEAP32[20675] + ((($0 + HEAP32[20674] | 0) + 1 | 0) - ($0 >>> 0 < $1 >>> 0 ? $0 : $1) | 0) | 0;
 }

 function node_dirty_ok($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  while (1) {
   if (!(($1 | 0) == 1032)) {
    $3 = $0 + $1 | 0;
    if (HEAP32[$3 + 48 >> 2]) {
     $2 = HEAP32[$3 + 468 >> 2] + $2 | 0
    }
    $1 = $1 + 516 | 0;
    continue;
   }
   break;
  };
  $0 = HEAP32[$0 + 1108 >> 2];
  $0 = HEAP32[20675] + ((HEAP32[20674] + $2 | 0) - ($2 >>> 0 < $0 >>> 0 ? $2 : $0) | 0) | 0;
  $2 = HEAP32[2];
  $1 = HEAP32[20705];
  label$4 : {
   if ($1) {
    $1 = (Math_imul($0, $1 + 65535 >>> 16 | 0) >>> 0) / (global_dirtyable_memory() >>> 0) | 0;
    break label$4;
   }
   $1 = (Math_imul($0, HEAP32[4211]) >>> 0) / 100 | 0;
  }
  if (!(HEAP32[$2 + 24 >> 2] > 99 ? !(HEAPU8[$2 + 14 | 0] & 16) : 0)) {
   $1 = ($1 >>> 2 | 0) + $1 | 0
  }
  return HEAP32[20690] + (HEAP32[20689] + HEAP32[20696] | 0) >>> 0 <= $1 >>> 0;
 }

 function clear_page_dirty_for_io($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  $1 = page_mapping($0);
  $2 = HEAP32[$0 + 4 >> 2];
  if (HEAP32[($2 & 1 ? $2 + -1 | 0 : $0) >> 2] & 1) {
   label$2 : {
    label$3 : {
     label$4 : {
      label$5 : {
       if (!$1) {
        break label$5
       }
       $1 = HEAP32[$1 >> 2];
       label$6 : {
        if ($1) {
         $2 = HEAP32[HEAP32[$1 + 20 >> 2] + 108 >> 2];
         break label$6;
        }
        $2 = 16192;
       }
       if (HEAP8[$2 + 32 | 0] & 1) {
        break label$5
       }
       if (page_mkclean($0)) {
        set_page_dirty($0)
       }
       if (!$1) {
        break label$4
       }
       $2 = HEAP32[HEAP32[$1 + 20 >> 2] + 108 >> 2];
       break label$3;
      }
      $1 = HEAP32[$0 + 4 >> 2];
      $2 = $1 & 1 ? $1 + -1 | 0 : $0;
      $0 = HEAP32[$2 >> 2];
      HEAP32[$3 + 12 >> 2] = $0;
      $1 = 0;
      if (!(HEAP32[$3 + 12 >> 2] & 8)) {
       break label$2
      }
      HEAP32[$2 >> 2] = $0 & -9;
      $1 = $0 >>> 3 & 1;
      break label$2;
     }
     $2 = 16192;
    }
    $1 = HEAP32[$0 + 4 >> 2];
    $4 = $1 & 1 ? $1 + -1 | 0 : $0;
    $5 = HEAP32[$4 >> 2];
    HEAP32[$3 + 12 >> 2] = $5;
    $1 = 0;
    if (!(HEAP32[$3 + 12 >> 2] & 8)) {
     break label$2
    }
    HEAP32[$4 >> 2] = $5 & -9;
    if (!($5 & 8)) {
     break label$2
    }
    HEAP32[35607] = HEAP32[35607] + -1;
    HEAP32[20689] = HEAP32[20689] + -1;
    HEAP32[20666] = HEAP32[20666] + -1;
    $0 = Math_imul(HEAP32[$0 >> 2] >>> 31 | 0, 516) + 141668 | 0;
    HEAP32[$0 >> 2] = HEAP32[$0 >> 2] + -1;
    $1 = $2 + 104 | 0;
    $2 = $1;
    $4 = $1;
    $0 = HEAP32[$1 + 4 >> 2] + -1 | 0;
    $1 = HEAP32[$1 >> 2] + -1 | 0;
    if ($1 >>> 0 < 4294967295) {
     $0 = $0 + 1 | 0
    }
    HEAP32[$4 >> 2] = $1;
    HEAP32[$2 + 4 >> 2] = $0;
    $1 = 1;
   }
   global$0 = $3 + 16 | 0;
   return $1;
  }
  HEAP32[$3 + 8 >> 2] = 26426;
  HEAP32[$3 + 4 >> 2] = 2639;
  HEAP32[$3 >> 2] = 26409;
  printk(26378, $3);
  abort();
 }

 function set_page_dirty($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  $1 = page_mapping($0);
  $2 = HEAP32[$0 + 4 >> 2];
  $0 = $2 & 1 ? $2 + -1 | 0 : $0;
  label$1 : {
   if ($1) {
    $1 = HEAP32[HEAP32[$1 + 52 >> 2] + 12 >> 2];
    $2 = HEAP32[$0 + 4 >> 2];
    if (HEAP32[($2 & 1 ? $2 + -1 | 0 : $0) >> 2] & 262144) {
     $2 = HEAP32[$0 + 4 >> 2];
     $2 = $2 & 1 ? $2 + -1 | 0 : $0;
     HEAP32[$2 >> 2] = HEAP32[$2 >> 2] & -262145;
    }
    FUNCTION_TABLE[$1]($0) | 0;
    break label$1;
   }
   $1 = HEAP32[$0 + 4 >> 2];
   label$4 : {
    if (HEAP32[($1 & 1 ? $1 + -1 | 0 : $0) >> 2] & 8) {
     break label$4
    }
    $1 = HEAP32[$0 + 4 >> 2];
    $1 = $1 & 1 ? $1 + -1 | 0 : $0;
    $0 = HEAP32[$1 >> 2];
    HEAP32[$3 + 12 >> 2] = $0;
    if (HEAP32[$3 + 12 >> 2] & 8) {
     break label$4
    }
    HEAP32[$1 >> 2] = $0 | 8;
    if (!($0 & 8)) {
     break label$1
    }
   }
  }
  global$0 = $3 + 16 | 0;
 }

 function account_page_cleaned($0, $1, $2) {
  $1 = HEAP32[$1 >> 2];
  label$1 : {
   if ($1) {
    $1 = HEAP32[HEAP32[$1 + 20 >> 2] + 108 >> 2];
    break label$1;
   }
   $1 = 16192;
  }
  if (!(HEAP8[$1 + 32 | 0] & 1)) {
   HEAP32[35607] = HEAP32[35607] + -1;
   HEAP32[20689] = HEAP32[20689] + -1;
   HEAP32[20666] = HEAP32[20666] + -1;
   $0 = Math_imul(HEAP32[$0 >> 2] >>> 31 | 0, 516) + 141668 | 0;
   HEAP32[$0 >> 2] = HEAP32[$0 >> 2] + -1;
   $0 = HEAP32[$2 + 52 >> 2] + -1 | 0;
   $1 = HEAP32[$2 + 48 >> 2] + -1 | 0;
   if ($1 >>> 0 < 4294967295) {
    $0 = $0 + 1 | 0
   }
   HEAP32[$2 + 48 >> 2] = $1;
   HEAP32[$2 + 52 >> 2] = $0;
  }
 }

 function free_compound_page($0) {
  $0 = $0 | 0;
  __free_pages_ok($0, HEAP32[$0 >> 2] & 65536 ? HEAPU8[$0 + 45 | 0] : 0);
 }

 function __free_pages_ok($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0;
  $4 = ($0 - HEAP32[20650] | 0) / 36 | 0;
  label$1 : {
   if (!$1) {
    break label$1
   }
   $6 = HEAP32[$0 >> 2] & 65536 ? 1 : HEAP32[$0 + 4 >> 2] & 1;
   $2 = $0 + 36 | 0;
   $10 = 1 << $1;
   $7 = 1;
   while (1) {
    if (($7 | 0) >= ($10 | 0)) {
     break label$1
    }
    if ($6) {
     HEAP32[$2 + 4 >> 2] = 0;
     HEAP32[$2 + 12 >> 2] = 0;
    }
    $9 = $2 + 24 | 0;
    label$5 : {
     label$6 : {
      if (HEAP32[$9 >> 2] == -1) {
       $11 = HEAP32[$2 >> 2];
       $3 = $11 & 3207729;
       $8 = HEAP32[$2 + 12 >> 2];
       if ($3 | ($8 | HEAP32[$2 + 28 >> 2])) {
        break label$6
       }
       HEAP32[$2 >> 2] = $11 & -4194304;
       break label$5;
      }
      $3 = HEAP32[$2 >> 2] & 3207729;
      $8 = HEAP32[$2 + 12 >> 2];
     }
     bad_page($2, $3 ? 27813 : HEAP32[$2 + 28 >> 2] ? 27795 : $8 ? 27778 : HEAP32[$9 >> 2] == -1 ? 0 : 27761, $3 ? 3207729 : 0);
     $5 = $5 + 1 | 0;
    }
    $2 = $2 + 36 | 0;
    $7 = $7 + 1 | 0;
    continue;
   };
  }
  $3 = $0 + 12 | 0;
  $2 = HEAP32[$3 >> 2];
  if ($2 & 3) {
   HEAP32[$3 >> 2] = 0;
   $2 = 0;
  }
  label$9 : {
   label$10 : {
    if (HEAP32[$0 + 24 >> 2] == -1) {
     $7 = 0;
     $3 = HEAP32[$0 >> 2] & 3207729;
     if ($3 | (HEAP32[$0 + 28 >> 2] | $2)) {
      break label$10
     }
     break label$9;
    }
    $3 = HEAP32[$0 >> 2] & 3207729;
   }
   bad_page($0, $3 ? 27813 : HEAP32[$0 + 28 >> 2] ? 27795 : $2 ? 27778 : HEAP32[$0 + 24 >> 2] == -1 ? 0 : 27761, $3 ? 3207729 : 0);
   $7 = 1;
  }
  if (($7 | 0) == (0 - $5 | 0)) {
   $2 = HEAP32[$0 >> 2];
   HEAP32[$0 >> 2] = $2 & -4194304;
   $2 = Math_imul($2 >>> 31 | 0, 516);
   $5 = $4 - (HEAP32[$2 + 141212 >> 2] & -1024) | 0;
   $7 = HEAP32[HEAP32[$2 + 141208 >> 2] + ($5 >>> 11 & 2097148) >> 2];
   $6 = $2 + 141644 | 0;
   $3 = 1 << $1;
   HEAP32[$6 >> 2] = $3 + HEAP32[$6 >> 2];
   HEAP32[20660] = HEAP32[20660] + $3;
   $2 = ($2 + Math_imul($1, 36) | 0) + 141268 | 0;
   $7 = $7 >>> 29 - ($5 >>> 8 & 28) & 7;
   $5 = $1 + 1 | 0;
   while (1) {
    label$13 : {
     $6 = $5 + -1 | 0;
     if ($6 >>> 0 > 9) {
      break label$13
     }
     $3 = 1 << $6 ^ $4;
     $1 = Math_imul($3 - $4 | 0, 36) + $0 | 0;
     if ((HEAP32[$1 + 24 >> 2] & -268435328) != -268435456) {
      break label$13
     }
     $8 = $1 + 20 | 0;
     if (($6 | 0) != HEAP32[$8 >> 2] | (HEAP32[$1 >> 2] ^ HEAP32[$0 >> 2]) < 0) {
      break label$13
     }
     HEAP32[$2 >> 2] = HEAP32[$2 >> 2] + -1;
     $6 = $1 + 8 | 0;
     $10 = HEAP32[$6 >> 2];
     $9 = HEAP32[$1 + 4 >> 2];
     HEAP32[$10 >> 2] = $9;
     HEAP32[$9 + 4 >> 2] = $10;
     HEAP32[$1 + 4 >> 2] = 256;
     HEAP32[$8 >> 2] = 0;
     HEAP32[$6 >> 2] = 512;
     $1 = $1 + 24 | 0;
     HEAP32[$1 >> 2] = HEAP32[$1 >> 2] | 128;
     $5 = $5 + 1 | 0;
     $2 = $2 + 36 | 0;
     $1 = $4 & $3;
     $0 = Math_imul($1 - $4 | 0, 36) + $0 | 0;
     $4 = $1;
     continue;
    }
    break;
   };
   $1 = $5 + -1 | 0;
   HEAP32[$0 + 20 >> 2] = $1;
   HEAP32[$0 + 24 >> 2] = HEAP32[$0 + 24 >> 2] & -129;
   label$15 : {
    label$16 : {
     if ($1 >>> 0 > 8) {
      break label$16
     }
     $1 = $4 & $3;
     $4 = Math_imul($1 - $4 | 0, 36) + $0 | 0;
     $1 = $4 + Math_imul(($1 ^ 1 << $5) - $1 | 0, 36) | 0;
     if ((HEAP32[$1 + 24 >> 2] & -268435328) != -268435456 | HEAP32[$1 + 20 >> 2] != ($5 | 0) | (HEAP32[$1 >> 2] ^ HEAP32[$4 >> 2]) < 0) {
      break label$16
     }
     $5 = ($7 << 3) + $2 | 0;
     $4 = $5 + -28 | 0;
     $1 = HEAP32[$4 >> 2];
     $3 = $4;
     $4 = $0 + 4 | 0;
     HEAP32[$3 >> 2] = $4;
     $5 = $5 + -32 | 0;
     break label$15;
    }
    $1 = (($7 << 3) + $2 | 0) + -32 | 0;
    $5 = HEAP32[$1 >> 2];
    $4 = $0 + 4 | 0;
    HEAP32[$5 + 4 >> 2] = $4;
   }
   HEAP32[$0 + 4 >> 2] = $5;
   HEAP32[$1 >> 2] = $4;
   HEAP32[$0 + 8 >> 2] = $1;
   HEAP32[$2 >> 2] = HEAP32[$2 >> 2] + 1;
  }
 }

 function get_pfnblock_flags_mask($0, $1) {
  var $2 = 0;
  $2 = $1;
  $1 = Math_imul(HEAP32[$0 >> 2] >>> 31 | 0, 516);
  $0 = $2 - (HEAP32[$1 + 141212 >> 2] & -1024) | 0;
  return HEAP32[HEAP32[$1 + 141208 >> 2] + ($0 >>> 11 & 2097148) >> 2] >>> 29 - ($0 >>> 8 & 28) & 7;
 }

 function set_pfnblock_flags_mask($0, $1, $2) {
  var $3 = 0;
  $3 = $2;
  $2 = Math_imul(HEAP32[$0 >> 2] >>> 31 | 0, 516);
  $0 = $3 - (HEAP32[$2 + 141212 >> 2] & -1024) | 0;
  $2 = HEAP32[$2 + 141208 >> 2] + ($0 >>> 11 & 2097148) | 0;
  $0 = 29 - ($0 >>> 8 & 28) | 0;
  HEAP32[$2 >> 2] = HEAP32[$2 >> 2] & (7 << $0 ^ -1) | $1 << $0;
 }

 function set_pageblock_migratetype($0, $1) {
  set_pfnblock_flags_mask($0, ($1 | 0) < 3 ? (HEAP32[20707] ? 0 : $1) : $1, ($0 - HEAP32[20650] | 0) / 36 | 0);
 }

 function bad_page($0, $1, $2) {
  var $3 = 0, $4 = 0;
  $3 = global$0 - 48 | 0;
  global$0 = $3;
  HEAP32[$3 + 44 >> 2] = $2;
  label$1 : {
   label$2 : {
    label$3 : {
     label$4 : {
      $4 = HEAP32[20712];
      if (($4 | 0) == 60) {
       $4 = HEAP32[20713];
       if ((HEAP32[20749] - HEAP32[20711] | 0) > -1) {
        break label$4
       }
       HEAP32[20713] = $4 + 1;
       break label$1;
      }
      HEAP32[20712] = $4 + 1;
      if (!$4) {
       break label$3
      }
      break label$2;
     }
     if ($4) {
      HEAP32[$3 + 32 >> 2] = $4;
      printk(27850, $3 + 32 | 0);
      HEAP32[20713] = 0;
     }
     HEAP32[20712] = 1;
    }
    HEAP32[20711] = HEAP32[20749] + 15e3;
   }
   HEAP32[$3 + 16 >> 2] = HEAP32[2] + 700;
   HEAP32[$3 + 20 >> 2] = ($0 - HEAP32[20650] | 0) / 36;
   printk(27898, $3 + 16 | 0);
   __dump_page($0, $1);
   $1 = HEAP32[$0 >> 2] & $2;
   HEAP32[$3 + 44 >> 2] = $1;
   if ($1) {
    HEAP32[$3 >> 2] = $1;
    HEAP32[$3 + 4 >> 2] = $3 + 44;
    printk(27946, $3);
   }
   dump_stack();
  }
  HEAP32[$0 + 24 >> 2] = -1;
  add_taint(5, 1);
  global$0 = $3 + 48 | 0;
 }

 function prep_compound_page($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0;
  HEAP8[$0 + 45 | 0] = $1;
  HEAP8[$0 + 44 | 0] = 1;
  HEAP32[$0 >> 2] = HEAP32[$0 >> 2] | 65536;
  $2 = $0 + 40 | 0;
  $3 = $0 + 1 | 0;
  $4 = 1 << $1;
  $1 = 1;
  while (1) {
   if (!(($1 | 0) >= ($4 | 0))) {
    HEAP32[$2 + 24 >> 2] = 0;
    HEAP32[$2 + 8 >> 2] = 1024;
    HEAP32[$2 >> 2] = $3;
    $2 = $2 + 36 | 0;
    $1 = $1 + 1 | 0;
    continue;
   }
   break;
  };
  HEAP32[$0 + 48 >> 2] = -1;
 }

 function reserve_bootmem_region($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0;
  $4 = $1 + 65535 >>> 16 | 0;
  $0 = $0 >>> 16 | 0;
  $1 = Math_imul($0, 36) + 4 | 0;
  while (1) {
   if ($0 >>> 0 < $4 >>> 0) {
    if ($0 >>> 0 < HEAPU32[20648]) {
     $2 = HEAP32[20650] + $1 | 0;
     HEAP32[$2 + 4 >> 2] = $2;
     $3 = $2 + -4 | 0;
     HEAP32[$3 >> 2] = HEAP32[$3 >> 2] | 4096;
     HEAP32[$2 >> 2] = $2;
    }
    $1 = $1 + 36 | 0;
    $0 = $0 + 1 | 0;
    continue;
   }
   break;
  };
 }

 function memblock_free_pages($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0;
  $4 = 1 << $1;
  $3 = $4 + -1 | 0;
  $2 = $0;
  while (1) {
   if ($3) {
    HEAP32[$2 + 28 >> 2] = 0;
    HEAP32[$2 >> 2] = HEAP32[$2 >> 2] & -4097;
    $3 = $3 + -1 | 0;
    $2 = $2 + 36 | 0;
    continue;
   }
   break;
  };
  HEAP32[$2 + 28 >> 2] = 0;
  HEAP32[$2 >> 2] = HEAP32[$2 >> 2] & -4097;
  HEAP32[$0 + 28 >> 2] = 1;
  $2 = Math_imul(HEAP32[$0 >> 2] >>> 31 | 0, 516) + 141216 | 0;
  HEAP32[$2 >> 2] = HEAP32[$2 >> 2] + $4;
  __free_pages($0, $1);
 }

 function __free_pages($0, $1) {
  var $2 = 0;
  $2 = HEAP32[$0 + 28 >> 2] + -1 | 0;
  HEAP32[$0 + 28 >> 2] = $2;
  if ($2) {
   return
  }
  if ($1) {
   __free_pages_ok($0, $1);
   return;
  }
  free_unref_page($0);
 }

 function move_freepages_block($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0;
  if ($3) {
   HEAP32[$3 >> 2] = 0
  }
  $4 = HEAP32[20650];
  $6 = ($1 - $4 | 0) / 36 | 0;
  $5 = $6 | 1023;
  $6 = $6 & -1024;
  $8 = $4 + Math_imul($6, 36) | 0;
  $4 = HEAP32[$0 + 36 >> 2];
  if ($4 >>> 0 <= $6 >>> 0) {
   $1 = $4 + HEAP32[$0 + 44 >> 2] >>> 0 > $6 >>> 0 ? $8 : $1
  }
  label$3 : {
   if ($4 + HEAP32[$0 + 44 >> 2] >>> 0 <= $5 >>> 0 | $4 >>> 0 > $5 >>> 0) {
    break label$3
   }
   $6 = $8 + 36828 | 0;
   $8 = $2 << 3;
   while (1) {
    if ($1 >>> 0 > $6 >>> 0) {
     break label$3
    }
    if ((HEAP32[$1 + 24 >> 2] & -268435328) != -268435456) {
     label$6 : {
      if (!$3) {
       break label$6
      }
      $2 = HEAP32[$1 + 4 >> 2];
      if ((HEAP32[$1 + 12 >> 2] & 3) != 2 ? !(HEAP32[($2 & 1 ? $2 + -1 | 0 : $1) >> 2] & 16) : 0) {
       break label$6
      }
      HEAP32[$3 >> 2] = HEAP32[$3 >> 2] + 1;
     }
     $1 = $1 + 36 | 0;
     continue;
    } else {
     $4 = HEAP32[$1 + 20 >> 2];
     $2 = $1 + 4 | 0;
     $5 = HEAP32[$2 >> 2];
     $9 = $1 + 8 | 0;
     $7 = HEAP32[$9 >> 2];
     HEAP32[$5 + 4 >> 2] = $7;
     HEAP32[$7 >> 2] = $5;
     $5 = ($8 + (Math_imul($4, 36) + $0 | 0) | 0) + 60 | 0;
     $7 = HEAP32[$5 >> 2];
     HEAP32[$7 + 4 >> 2] = $2;
     HEAP32[$5 >> 2] = $2;
     HEAP32[$2 >> 2] = $7;
     HEAP32[$9 >> 2] = $5;
     $2 = 1 << $4;
     $10 = $2 + $10 | 0;
     $1 = Math_imul($2, 36) + $1 | 0;
     continue;
    }
   };
  }
  return $10;
 }

 function find_suitable_fallback($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0;
  label$1 : {
   label$2 : {
    if (!HEAP32[$0 + 32 >> 2]) {
     break label$2
    }
    HEAP8[$3 | 0] = 0;
    $5 = ($2 << 4) + 26480 | 0;
    $6 = $1 >>> 0 > 9;
    $2 = (($2 | 2) == 2 | $1 >>> 0 > 4) ^ -1;
    while (1) {
     $1 = HEAP32[$5 >> 2];
     if (($1 | 0) == 4) {
      break label$2
     }
     $4 = ($1 << 3) + $0 | 0;
     if (HEAP32[$4 >> 2] != ($4 | 0)) {
      label$5 : {
       if (!$6) {
        $4 = 1;
        if (!HEAP32[20707] & $2) {
         break label$5
        }
       }
       HEAP8[$3 | 0] = 1;
       $4 = 0;
      }
      if (!$4 | 1) {
       break label$1
      }
     }
     $5 = $5 + 4 | 0;
     continue;
    };
   }
   $1 = -1;
  }
  return $1;
 }

 function drain_pages() {
  var $0 = 0, $1 = 0, $2 = 0;
  $0 = 141176;
  while (1) {
   if ($0) {
    if (HEAP32[$0 + 48 >> 2]) {
     $1 = HEAP32[$0 + 28 >> 2];
     $2 = HEAP32[$1 >> 2];
     if ($2) {
      free_pcppages_bulk($0, $2, $1)
     }
    }
    $0 = next_zone($0);
    continue;
   }
   break;
  };
 }

 function free_pcppages_bulk($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0, $15 = 0, $16 = 0, $17 = 0, $18 = 0, $19 = 0, $20 = 0, $21 = 0, $22 = 0, $23 = 0, $24 = 0, $25 = 0, $26 = 0, $27 = 0, $28 = 0, $29 = 0, $30 = 0, $31 = 0, $32 = 0, $33 = 0, $34 = 0, $35 = 0, $36 = 0, $37 = 0, $38 = 0;
  $9 = global$0 - 16 | 0;
  global$0 = $9;
  HEAP32[$9 + 12 >> 2] = $9 + 8;
  HEAP32[$9 + 8 >> 2] = $9 + 8;
  label$1 : while (1) {
   label$2 : {
    if (!$4) {
     if (!$1) {
      break label$2
     }
     while (1) {
      $12 = $12 + 1 | 0;
      $3 = $20 + 1 | 0;
      $20 = ($3 | 0) == 3 ? 0 : $3;
      $11 = ($20 << 3) + $2 | 0;
      $4 = $11 + 12 | 0;
      if (HEAP32[$4 >> 2] == ($4 | 0)) {
       continue
      }
      break;
     };
     $12 = ($12 | 0) == 3 ? $1 : $12;
     $3 = $1 + -1 | 0;
     $13 = $11 + 16 | 0;
     label$6 : {
      label$7 : {
       while (1) {
        $1 = $3;
        $6 = HEAP32[$13 >> 2];
        $11 = HEAP32[$6 + 4 >> 2];
        $3 = HEAP32[$6 >> 2];
        HEAP32[$11 >> 2] = $3;
        HEAP32[$3 + 4 >> 2] = $11;
        HEAP32[$2 >> 2] = HEAP32[$2 >> 2] + -1;
        HEAP32[$6 >> 2] = 256;
        HEAP32[$6 + 4 >> 2] = 512;
        $3 = $6 + -4 | 0;
        label$9 : {
         label$10 : {
          label$11 : {
           if (HEAP32[$6 + 20 >> 2] == -1) {
            $7 = HEAP32[$3 >> 2] & 3207729;
            $10 = HEAP32[$6 + 8 >> 2];
            if ($7 | ($10 | HEAP32[$6 + 24 >> 2])) {
             break label$11
            }
            $3 = HEAP32[$9 + 12 >> 2];
            HEAP32[$3 >> 2] = $6;
            HEAP32[$9 + 12 >> 2] = $6;
            HEAP32[$6 + 4 >> 2] = $3;
            HEAP32[$6 >> 2] = $9 + 8;
            $29 = $29 + 1 | 0;
            if (!$1) {
             break label$10
            }
            break label$9;
           }
           $7 = HEAP32[$3 >> 2] & 3207729;
           $10 = HEAP32[$6 + 8 >> 2];
          }
          bad_page($3, $7 ? 27813 : HEAP32[$6 + 24 >> 2] ? 27795 : $10 ? 27778 : HEAP32[$6 + 20 >> 2] == -1 ? 0 : 27761, $7 ? 3207729 : 0);
          if ($1) {
           break label$9
          }
          $4 = 0;
          continue label$1;
         }
         $4 = 0;
         continue label$1;
        }
        $11 = $12 + -1 | 0;
        if (($12 | 0) != 1) {
         $3 = $1 + -1 | 0;
         $12 = $11;
         if (($4 | 0) != HEAP32[$4 >> 2]) {
          continue
         }
         break label$7;
        }
        break;
       };
       $12 = 0;
       break label$6;
      }
      $4 = 0;
      continue;
     }
     $4 = 0;
     continue;
    }
    if (($5 | 0) != ($9 + 8 | 0)) {
     $11 = HEAP32[$5 >> 2];
     $21 = HEAP32[$5 + 12 >> 2];
     HEAP32[$22 >> 2] = HEAP32[$22 >> 2] + $16;
     $8 = 0;
     HEAP32[20660] = HEAP32[20660] + $16;
     $7 = $5 + $30 | 0;
     $3 = ($7 - HEAP32[20650] | 0) / ($15 | 0) | 0;
     $13 = $31;
     while (1) {
      label$15 : {
       if ($8 >>> 0 > $32 >>> 0) {
        break label$15
       }
       $10 = $16 << $8 ^ $3;
       $14 = Math_imul($10 - $3 | 0, $15) + $7 | 0;
       if ((HEAP32[$14 + 24 >> 2] & $23) != ($24 | 0)) {
        break label$15
       }
       $25 = $14 + $17 | 0;
       if (HEAP32[$25 >> 2] != ($8 | 0) | (HEAP32[$14 >> 2] ^ HEAP32[$7 >> 2]) < 0) {
        break label$15
       }
       $5 = $13 + $26 | 0;
       HEAP32[$5 >> 2] = HEAP32[$5 >> 2] + $27;
       $6 = $14 + $18 | 0;
       $4 = HEAP32[$6 >> 2];
       $5 = HEAP32[$14 + 4 >> 2];
       HEAP32[$4 >> 2] = $5;
       HEAP32[$5 + 4 >> 2] = $4;
       HEAP32[$14 + 4 >> 2] = $33;
       HEAP32[$25 >> 2] = 0;
       HEAP32[$6 >> 2] = $34;
       $5 = $14 + $35 | 0;
       HEAP32[$5 >> 2] = HEAP32[$5 >> 2] | $36;
       $13 = $13 + $15 | 0;
       $8 = $8 + $16 | 0;
       $5 = $3 & $10;
       $7 = Math_imul($5 - $3 | 0, $15) + $7 | 0;
       $3 = $5;
       continue;
      }
      break;
     };
     HEAP32[$7 + $17 >> 2] = $8;
     HEAP32[$7 + 24 >> 2] = HEAP32[$7 + 24 >> 2] & $37;
     label$17 : {
      label$18 : {
       if ($8 >>> 0 > $18 >>> 0) {
        break label$18
       }
       $4 = $3 & $10;
       $5 = Math_imul($4 - $3 | 0, $15) + $7 | 0;
       $3 = $5 + Math_imul(($4 ^ $38 << $8) - $4 | 0, $15) | 0;
       if ((HEAP32[$3 + 24 >> 2] & $23) != ($24 | 0) | (HEAP32[$3 + $17 >> 2] + $27 | 0) != ($8 | 0) | (HEAP32[$3 >> 2] ^ HEAP32[$5 >> 2]) < 0) {
        break label$18
       }
       $8 = ($21 << $28) + $13 | 0;
       $10 = $19 + $8 | 0;
       $4 = HEAP32[$10 >> 2];
       $3 = $7 + $19 | 0;
       HEAP32[$10 >> 2] = $3;
       break label$17;
      }
      $4 = ($21 << $28) + $13 | 0;
      $8 = HEAP32[$4 >> 2];
      $3 = $7 + $19 | 0;
      HEAP32[$8 + 4 >> 2] = $3;
     }
     HEAP32[$7 + 4 >> 2] = $8;
     HEAP32[$4 >> 2] = $3;
     HEAP32[$7 + $18 >> 2] = $4;
     $3 = $13 + $26 | 0;
     HEAP32[$3 >> 2] = HEAP32[$3 >> 2] + $16;
     $5 = $11;
     $4 = 1;
     continue;
    }
    global$0 = $9 + 16 | 0;
    return;
   }
   $31 = $0 + 60 | 0;
   $5 = HEAP32[$9 + 8 >> 2];
   $30 = -4;
   $22 = $0 + 468 | 0;
   $16 = 1;
   $15 = 36;
   $32 = 9;
   $35 = 24;
   $23 = -268435328;
   $24 = -268435456;
   $17 = 20;
   $26 = 32;
   $27 = -1;
   $18 = 8;
   $33 = 256;
   $34 = 512;
   $36 = 128;
   $37 = -129;
   $38 = 2;
   $28 = 3;
   $19 = 4;
   $4 = 1;
   continue;
  };
 }

 function drain_all_pages() {
  var $0 = 0;
  label$1 : {
   if (!HEAP32[20658]) {
    break label$1
   }
   if (!mutex_trylock(16848)) {
    break label$1
   }
   $0 = 141176;
   label$2 : {
    label$3 : {
     while (1) {
      if ($0) {
       if (HEAP32[HEAP32[$0 + 28 >> 2] >> 2] ? HEAP32[$0 + 48 >> 2] : 0) {
        break label$3
       }
       $0 = next_zone($0);
       continue;
      }
      break;
     };
     $0 = HEAP32[20714] & -2;
     break label$2;
    }
    $0 = HEAP32[20714] | 1;
   }
   HEAP32[4223] = 16892;
   HEAP32[4222] = -32;
   HEAP32[20714] = $0;
   HEAP32[4225] = 92;
   HEAP32[4224] = 16892;
   queue_work_on(0, HEAP32[20658], 16888);
   __flush_work();
   mutex_unlock(16848);
  }
 }

 function drain_local_pages_wq($0) {
  $0 = $0 | 0;
  drain_pages();
 }

 function free_unref_page($0) {
  if (free_unref_page_prepare($0, ($0 - HEAP32[20650] | 0) / 36 | 0)) {
   free_unref_page_commit($0)
  }
 }

 function free_unref_page_prepare($0, $1) {
  var $2 = 0;
  $2 = $0 + 12 | 0;
  if (HEAPU8[$2 | 0] & 3) {
   HEAP32[$2 >> 2] = 0
  }
  $2 = HEAP32[$0 >> 2];
  HEAP32[$0 >> 2] = $2 & -4194304;
  $2 = Math_imul($2 >>> 31 | 0, 516);
  $1 = $1 - (HEAP32[$2 + 141212 >> 2] & -1024) | 0;
  HEAP32[$0 + 16 >> 2] = HEAP32[HEAP32[$2 + 141208 >> 2] + ($1 >>> 11 & 2097148) >> 2] >>> 29 - ($1 >>> 8 & 28) & 7;
  return 1;
 }

 function free_unref_page_commit($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0;
  $4 = Math_imul(HEAP32[$0 >> 2] >>> 31 | 0, 516);
  $1 = HEAP32[$4 + 141204 >> 2];
  $2 = HEAP32[$0 + 16 >> 2];
  $2 = ($1 + ((($2 | 0) > 2 ? 1 : $2) << 3) | 0) + 12 | 0;
  $5 = HEAP32[$2 >> 2];
  $3 = $0 + 4 | 0;
  HEAP32[$5 + 4 >> 2] = $3;
  HEAP32[$2 >> 2] = $3;
  $3 = HEAP32[$1 >> 2] + 1 | 0;
  HEAP32[$1 >> 2] = $3;
  HEAP32[$0 + 4 >> 2] = $5;
  HEAP32[$0 + 8 >> 2] = $2;
  if (($3 | 0) >= HEAP32[$1 + 4 >> 2]) {
   free_pcppages_bulk($4 + 141176 | 0, HEAP32[$1 + 8 >> 2], $1)
  }
 }

 function free_unref_page_list($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0;
  $1 = HEAP32[$0 >> 2];
  while (1) {
   if (!(($0 | 0) == ($1 | 0))) {
    $3 = HEAP32[$1 >> 2];
    $2 = $1 + -4 | 0;
    $4 = ($2 - HEAP32[20650] | 0) / 36 | 0;
    if (!free_unref_page_prepare($2, $4)) {
     $5 = HEAP32[$1 >> 2];
     $2 = HEAP32[$1 + 4 >> 2];
     HEAP32[$5 + 4 >> 2] = $2;
     HEAP32[$2 >> 2] = $5;
     HEAP32[$1 >> 2] = 256;
     HEAP32[$1 + 4 >> 2] = 512;
    }
    HEAP32[$1 + 16 >> 2] = $4;
    $1 = $3;
    continue;
   }
   break;
  };
  $1 = HEAP32[$0 >> 2];
  while (1) {
   if (!(($0 | 0) == ($1 | 0))) {
    HEAP32[$1 + 16 >> 2] = 0;
    $3 = $1 + -4 | 0;
    $1 = HEAP32[$1 >> 2];
    free_unref_page_commit($3);
    continue;
   }
   break;
  };
 }

 function __zone_watermark_ok($0, $1, $2, $3, $4, $5) {
  var $6 = 0;
  $6 = $4 & 24;
  $2 = $4 & 32 ? $2 - (($2 | 0) / 2 | 0) | 0 : $2;
  $5 = $5 - (-1 << $1 ^ -1) | 0;
  label$2 : {
   if (!$6) {
    $5 = $5 - HEAP32[$0 + 12 >> 2] | 0;
    break label$2;
   }
   if (!($4 & 8)) {
    $2 = $2 - (($2 | 0) / 4 | 0) | 0;
    break label$2;
   }
   $2 = $2 - (($2 | 0) / 2 | 0) | 0;
  }
  label$5 : {
   label$6 : {
    if (($5 | 0) <= (HEAP32[(($3 << 2) + $0 | 0) + 16 >> 2] + $2 | 0)) {
     break label$6
    }
    if (!$1) {
     break label$5
    }
    $4 = (Math_imul($1, 36) + $0 | 0) + 52 | 0;
    while (1) {
     if (($1 | 0) > 10) {
      break label$6
     }
     $3 = Math_imul($1, 36) + $0 | 0;
     label$8 : {
      if (!HEAP32[$3 + 92 >> 2]) {
       break label$8
      }
      $2 = -1;
      $5 = $4;
      while (1) {
       $2 = $2 + 1 | 0;
       if ($2 >>> 0 <= 2) {
        $5 = $5 + 8 | 0;
        if (($5 | 0) == HEAP32[$5 >> 2]) {
         continue
        }
        break label$5;
       }
       break;
      };
      if (!$6) {
       break label$8
      }
      $2 = $3 + 84 | 0;
      if (HEAP32[$2 >> 2] != ($2 | 0)) {
       break label$5
      }
     }
     $4 = $4 + 36 | 0;
     $1 = $1 + 1 | 0;
     continue;
    };
   }
   return 0;
  }
  return 1;
 }

 function zone_watermark_ok_safe($0, $1, $2, $3) {
  var $4 = 0, $5 = 0;
  $4 = $0;
  $5 = $1;
  $1 = HEAP32[$0 + 468 >> 2];
  if ($1 >>> 0 < HEAPU32[$0 + 460 >> 2]) {
   $1 = HEAP32[$0 + 468 >> 2]
  }
  return __zone_watermark_ok($4, $5, $2, $3, 0, $1);
 }

 function warn_alloc($0, $1, $2) {
  var $3 = 0, $4 = 0;
  $3 = global$0 - 48 | 0;
  global$0 = $3;
  HEAP32[$3 + 44 >> 2] = $0;
  label$1 : {
   if ($0 & 512) {
    break label$1
   }
   if (!___ratelimit(16972, 26544)) {
    break label$1
   }
   $4 = HEAP32[2];
   HEAP32[$3 + 20 >> 2] = $1;
   HEAP32[$3 + 16 >> 2] = ($1 | 0) != 0;
   HEAP32[$3 + 28 >> 2] = $2;
   HEAP32[$3 + 32 >> 2] = 28051;
   HEAP32[$3 + 8 >> 2] = $0;
   HEAP32[$3 >> 2] = $4 + 700;
   HEAP32[$3 + 36 >> 2] = $3 + 28;
   HEAP32[$3 + 12 >> 2] = $3 + 44;
   HEAP32[$3 + 4 >> 2] = $3 + 32;
   printk(26555, $3);
   dump_stack();
   $0 = HEAP32[$3 + 44 >> 2];
   if (!___ratelimit(16996, 27982)) {
    break label$1
   }
   $2 = 1;
   label$2 : {
    if ($0 & 65536) {
     break label$2
    }
    $4 = HEAP32[2];
    if (HEAPU16[$4 + 12 >> 1] & 2052 ? 0 : !HEAP32[HEAP32[$4 + 732 >> 2] + 368 >> 2]) {
     break label$2
    }
    $2 = 0;
   }
   show_mem($0 >>> 21 & (HEAP32[1] & 2096896 ? 0 : $2), $1);
  }
  global$0 = $3 + 48 | 0;
 }

 function gfp_pfmemalloc_allowed($0) {
  label$1 : {
   if ($0 & 65536) {
    break label$1
   }
   label$2 : {
    if ($0 & 8192 | (HEAPU8[HEAP32[2] + 13 | 0] & 8 ? HEAP32[1] & 256 : 0)) {
     break label$2
    }
    if (HEAP32[1] & 2096896) {
     break label$1
    }
    $0 = HEAP32[2];
    if (HEAPU8[$0 + 13 | 0] & 8) {
     break label$2
    }
    if (!HEAP32[HEAP32[$0 + 732 >> 2] + 368 >> 2]) {
     break label$1
    }
   }
  }
 }

 function __alloc_pages_nodemask($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0, $15 = 0, $16 = 0, $17 = 0, $18 = 0, $19 = 0, $20 = 0, $21 = 0, $22 = 0, $23 = 0, $24 = 0, $25 = 0;
  $2 = global$0 + -64 | 0;
  global$0 = $2;
  $3 = $2 + 24 | 0;
  HEAP32[$3 >> 2] = 0;
  HEAP32[$3 + 4 >> 2] = 0;
  $3 = $2 + 16 | 0;
  HEAP32[$3 >> 2] = 0;
  HEAP32[$3 + 4 >> 2] = 0;
  HEAP32[$2 + 8 >> 2] = 0;
  HEAP32[$2 + 12 >> 2] = 0;
  label$1 : {
   if ($1 >>> 0 <= 10) {
    HEAP32[$2 + 12 >> 2] = 0;
    HEAP32[$2 + 8 >> 2] = 142208;
    $0 = HEAP32[4221] & $0;
    HEAP8[$2 + 28 | 0] = $0 >>> 8 & 1;
    $3 = 1024 >>> ($0 & 15) & 1;
    HEAP32[$2 + 24 >> 2] = $3;
    HEAP32[$2 + 20 >> 2] = HEAP32[20707] ? 0 : $0 >>> 3 & 3;
    $6 = $2;
    if (HEAPU32[35553] <= $3 >>> 0 ? 1 : 0) {
     $3 = 142208
    } else {
     $3 = __next_zones_zonelist(142208, $3, 0)
    }
    HEAP32[$6 + 16 >> 2] = $3;
    $4 = get_page_from_freelist($0, $1, 1, $2 + 8 | 0);
    if ($4) {
     break label$1
    }
    $6 = HEAP32[2];
    $3 = HEAP32[$6 + 12 >> 2];
    label$5 : {
     if (!($3 & 524288)) {
      $0 = $3 & 262144 ? $0 & -129 : $0;
      break label$5;
     }
     $0 = $0 & -193;
    }
    HEAP8[$2 + 28 | 0] = 0;
    if (HEAP32[$2 + 12 >> 2]) {
     HEAP32[$2 + 12 >> 2] = 0
    }
    $5 = ($0 & 2621440) == 2621440 ? $0 & -524289 : $0;
    $3 = $5 & 32;
    label$8 : {
     if (!($5 & 524288)) {
      $7 = $3 | 64;
      $4 = $7;
      if (HEAP32[$6 + 24 >> 2] > 99) {
       break label$8
      }
      $4 = HEAP32[1] & 2096896 ? $7 : $3 | 80;
      break label$8;
     }
     $4 = ($3 | $5 >>> 12 & 16) ^ 16;
    }
    $7 = $4;
    $12 = $0 & 2097152;
    $4 = HEAP32[$2 + 8 >> 2];
    $3 = HEAP32[$2 + 24 >> 2];
    if (!(HEAPU32[$4 + 4 >> 2] <= $3 >>> 0 ? 1 : 0)) {
     $4 = __next_zones_zonelist($4, $3, 0)
    }
    HEAP32[$2 + 16 >> 2] = $4;
    label$12 : {
     label$13 : {
      label$14 : {
       label$15 : {
        label$16 : {
         label$17 : {
          label$18 : {
           if (HEAP32[$4 >> 2]) {
            $10 = $5 & 4194304;
            if ($10) {
             wake_all_kswapds($1, $2 + 8 | 0)
            }
            $4 = get_page_from_freelist($5, $1, $7, $2 + 8 | 0);
            if ($4) {
             break label$1
            }
            $3 = 0;
            if (!$12) {
             break label$17
            }
            if ($1 >>> 0 <= 3) {
             if (!$1) {
              break label$16
             }
             if (HEAP32[$2 + 20 >> 2] == 1) {
              break label$15
             }
            }
            gfp_pfmemalloc_allowed($5);
            break label$18;
           }
           $3 = 0;
           if ($5 & 2048) {
            break label$14
           }
           break label$12;
          }
          $0 = 0;
          break label$13;
         }
         $0 = 0;
         break label$13;
        }
        $0 = 0;
        break label$13;
       }
       $0 = 0;
       break label$13;
      }
      $0 = 1;
     }
     while (1) {
      if (!$0) {
       $13 = $1 >>> 0 > 3;
       $17 = $13 & !($5 & 1024) | ($5 & 4096) >>> 12;
       $18 = $5 & 263168;
       $19 = $5 & 8192;
       $15 = $5 & 65536;
       $20 = $15 >>> 16 | 0;
       $14 = $5 & 2048;
       $21 = $14 >>> 11 | 0;
       $22 = $5 & -2228225 | 131072;
       $23 = $1 + -1 >>> 0 > 2;
       $24 = $2 + 60 | 0;
       $16 = $2 + 52 | 0;
       label$25 : {
        label$26 : while (1) {
         $0 = $10 ? 0 : 1;
         label$29 : {
          while (1) {
           if (!$0) {
            wake_all_kswapds($1, $2 + 8 | 0);
            $0 = 1;
            continue;
           }
           label$33 : {
            label$34 : {
             label$35 : {
              if ($15) {
               break label$35
              }
              $0 = 4;
              if ((HEAPU8[HEAP32[2] + 13 | 0] & 8 ? HEAP32[1] & 256 : 0) | $19) {
               break label$34
              }
              if (HEAP32[1] & 2096896) {
               break label$35
              }
              $6 = HEAP32[2];
              if (HEAPU8[$6 + 13 | 0] & 8) {
               break label$34
              }
              $0 = 8;
              if (HEAP32[HEAP32[$6 + 732 >> 2] + 368 >> 2]) {
               break label$34
              }
             }
             $0 = $7;
             if ($0 & 64) {
              break label$33
             }
            }
            HEAP32[$2 + 12 >> 2] = 0;
            $4 = $2 + 16 | 0;
            $6 = HEAP32[$2 + 8 >> 2];
            $7 = HEAP32[$2 + 24 >> 2];
            if (HEAPU32[$6 + 4 >> 2] > $7 >>> 0) {
             $6 = __next_zones_zonelist($6, $7, 0)
            }
            HEAP32[$4 >> 2] = $6;
            $7 = $0;
           }
           $4 = get_page_from_freelist($5, $1, $7, $2 + 8 | 0);
           if ($4) {
            break label$1
           }
           if (!$12 | HEAPU8[HEAP32[2] + 13 | 0] & 8) {
            break label$25
           }
           _cond_resched();
           $0 = HEAP32[2];
           $6 = HEAP32[$0 + 12 >> 2];
           HEAP32[$0 + 12 >> 2] = $6 | 2048;
           HEAP32[$2 + 32 >> 2] = 0;
           HEAP32[$0 + 804 >> 2] = $2 + 32;
           $8 = try_to_free_pages(HEAP32[$2 + 8 >> 2], $1, $5, HEAP32[$2 + 12 >> 2]);
           $0 = HEAP32[2];
           HEAP32[$0 + 804 >> 2] = 0;
           HEAP32[$0 + 12 >> 2] = HEAP32[$0 + 12 >> 2] & -2049 | $6 & 2048;
           _cond_resched();
           if ($8) {
            $0 = 0;
            while (1) {
             $4 = get_page_from_freelist($5, $1, $7, $2 + 8 | 0);
             if (!($4 | $0 & 1)) {
              unreserve_highatomic_pageblock($2 + 8 | 0, 0);
              drain_all_pages();
              $0 = 1;
              continue;
             }
             break;
            };
            if ($4) {
             break label$1
            }
           }
           if ($17) {
            break label$25
           }
           label$41 : {
            label$42 : {
             label$43 : {
              label$44 : {
               label$45 : {
                label$46 : {
                 label$47 : {
                  if (!$13) {
                   $6 = 0;
                   if ($8) {
                    break label$47
                   }
                  }
                  $6 = $3 + 1 | 0;
                  if (($3 | 0) < 16) {
                   break label$47
                  }
                  $3 = $6;
                  if (unreserve_highatomic_pageblock($2 + 8 | 0, 1)) {
                   continue label$26
                  }
                  break label$46;
                 }
                 $0 = HEAP32[$2 + 12 >> 2];
                 $3 = HEAP32[$2 + 8 >> 2];
                 $9 = $2 + 24 | 0;
                 $4 = HEAP32[$9 >> 2];
                 if (!(HEAPU32[$3 + 4 >> 2] <= $4 >>> 0 ? !$0 : 0)) {
                  $3 = __next_zones_zonelist($3, $4, $0)
                 }
                 label$51 : {
                  label$52 : {
                   while (1) {
                    $0 = HEAP32[$3 >> 2];
                    if (!$0) {
                     break label$52
                    }
                    $4 = HEAP32[$0 + 480 >> 2] + HEAP32[$0 + 484 >> 2] | 0;
                    if (!__zone_watermark_ok($0, $1, HEAP32[$0 >> 2], HEAP32[HEAP32[$2 + 16 >> 2] + 4 >> 2], $7, $4 + HEAP32[$0 + 468 >> 2] | 0)) {
                     $0 = $3 + 8 | 0;
                     $4 = HEAP32[$9 >> 2];
                     $11 = HEAP32[$2 + 12 >> 2];
                     if (!$11) {
                      $25 = $3 + 12 | 0;
                      $3 = $0;
                      if (HEAPU32[$25 >> 2] <= $4 >>> 0) {
                       continue
                      }
                     }
                     $3 = __next_zones_zonelist($0, $4, $11);
                     continue;
                    }
                    break;
                   };
                   $3 = 1;
                   if ($8) {
                    break label$51
                   }
                   $3 = 1;
                   if (HEAP32[$0 + 492 >> 2] << 1 >>> 0 <= $4 >>> 0) {
                    break label$51
                   }
                   congestion_wait();
                   break label$45;
                  }
                  $3 = 0;
                 }
                 $0 = $3;
                 label$56 : {
                  if (!(HEAPU8[HEAP32[2] + 12 | 0] & 32)) {
                   _cond_resched();
                   break label$56;
                  }
                  schedule_timeout_uninterruptible(1);
                 }
                 $3 = $6;
                 if ($0) {
                  continue label$26
                 }
                }
                if (!$8 | $23) {
                 break label$44
                }
                $3 = HEAP32[$2 + 12 >> 2];
                $0 = HEAP32[$2 + 8 >> 2];
                $8 = $2 + 24 | 0;
                $4 = HEAP32[$8 >> 2];
                if (!(HEAPU32[$0 + 4 >> 2] <= $4 >>> 0 ? !$3 : 0)) {
                 $0 = __next_zones_zonelist($0, $4, $3)
                }
                while (1) {
                 $3 = HEAP32[$0 >> 2];
                 if (!$3) {
                  break label$44
                 }
                 if (__zone_watermark_ok($3, 0, HEAP32[$3 >> 2], HEAP32[HEAP32[$2 + 16 >> 2] + 4 >> 2], $7, HEAP32[$3 + 468 >> 2])) {
                  break label$45
                 }
                 $3 = $0 + 8 | 0;
                 $4 = HEAP32[$8 >> 2];
                 $9 = HEAP32[$2 + 12 >> 2];
                 if (!$9) {
                  $11 = $0 + 12 | 0;
                  $0 = $3;
                  if (HEAPU32[$11 >> 2] <= $4 >>> 0) {
                   continue
                  }
                 }
                 $0 = __next_zones_zonelist($3, $4, $9);
                 continue;
                };
               }
               $3 = $6;
               if ($10) {
                break label$42
               }
               break label$43;
              }
              HEAP32[$24 >> 2] = 0;
              HEAP32[$16 >> 2] = 0;
              HEAP32[$16 + 4 >> 2] = 0;
              HEAP32[$2 + 48 >> 2] = $1;
              HEAP32[$2 + 44 >> 2] = $5;
              HEAP32[$2 + 40 >> 2] = 0;
              $0 = HEAP32[$2 + 12 >> 2];
              HEAP32[$2 + 32 >> 2] = HEAP32[$2 + 8 >> 2];
              HEAP32[$2 + 36 >> 2] = $0;
              label$62 : {
               if (mutex_trylock(17024)) {
                $0 = 0;
                $4 = get_page_from_freelist($22, $1, 66, $2 + 8 | 0);
                if ($4) {
                 break label$41
                }
                if (!$13) {
                 $4 = 0;
                 if (HEAP32[HEAP32[2] + 12 >> 2] & 512 | $18) {
                  break label$41
                 }
                 $0 = out_of_memory($2 + 32 | 0);
                 if ($14) {
                  break label$62
                 }
                 $0 = $0 | $21;
                }
                $4 = 0;
                break label$41;
               }
               $0 = 1;
               schedule_timeout_uninterruptible(1);
               break label$29;
              }
              $0 = 1;
              $4 = get_page_from_freelist($5, $1, 68, $2 + 8 | 0);
              if ($4) {
               break label$41
              }
              $4 = get_page_from_freelist($5, $1, 4, $2 + 8 | 0);
              break label$41;
             }
             $0 = 1;
             continue;
            }
            $0 = 0;
            continue;
           }
           break;
          };
          mutex_unlock(17024);
          if ($4) {
           break label$1
          }
         }
         if (!(($7 | 0) == 8 | $20 ? !!HEAP32[HEAP32[HEAP32[2] + 732 >> 2] + 368 >> 2] : 0)) {
          $3 = 0;
          if ($0) {
           continue
          }
         }
         break;
        };
        $3 = $6;
       }
       if (!$14) {
        break label$12
       }
       $0 = 1;
       continue;
      }
      if (!$12) {
       break label$12
      }
      $4 = get_page_from_freelist($5, $1, 80, $2 + 8 | 0);
      if ($4) {
       break label$1
      }
      $4 = get_page_from_freelist($5, $1, 16, $2 + 8 | 0);
      if ($4) {
       break label$1
      }
      $10 = $5 & 4194304;
      _cond_resched();
      $0 = 0;
      continue;
     };
    }
    HEAP32[$2 >> 2] = $1;
    warn_alloc($5, HEAP32[$2 + 12 >> 2], $2);
   }
   $4 = 0;
  }
  global$0 = $2 - -64 | 0;
  return $4;
 }

 function get_page_from_freelist($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0, $15 = 0, $16 = 0, $17 = 0, $18 = 0, $19 = 0, $20 = 0, $21 = 0, $22 = 0, $23 = 0, $24 = 0, $25 = 0, $26 = 0, $27 = 0, $28 = 0, $29 = 0, $30 = 0, $31 = 0, $32 = 0, $33 = 0, $34 = 0, $35 = 0, $36 = 0, $37 = 0, $38 = 0, $39 = 0, $40 = 0, $41 = 0, $42 = 0, $43 = 0, $44 = 0, $45 = 0;
  $13 = global$0 - 16 | 0;
  global$0 = $13;
  $28 = $1 + -1 | 0;
  $24 = 1 << $1;
  $25 = $2 & 16;
  $29 = $2 & 4;
  $18 = HEAP32[$3 + 8 >> 2];
  $30 = $3 + 20 | 0;
  $31 = $3 + 8 | 0;
  $32 = ($2 & 3) << 2;
  $5 = Math_imul($1, 9);
  $33 = $5 + 15 << 2;
  $34 = $5 + 12 << 2;
  $35 = $5 + 23 << 2;
  label$1 : {
   while (1) {
    label$2 : {
     label$4 : {
      label$5 : {
       label$6 : {
        $9 = HEAP32[$18 >> 2];
        if ($9) {
         label$8 : {
          label$9 : {
           if (HEAPU8[$30 | 0]) {
            $5 = HEAP32[$9 + 24 >> 2];
            if (($5 | 0) == ($36 | 0)) {
             break label$4
            }
            if (!node_dirty_ok($5)) {
             break label$9
            }
           }
           $4 = HEAP32[$9 + 468 >> 2];
           $6 = HEAP32[$9 + $32 >> 2];
           $5 = HEAP32[HEAP32[$31 >> 2] + 4 >> 2];
           label$11 : {
            if (!($4 >>> 0 <= $6 + HEAP32[($9 + ($5 << 2) | 0) + 16 >> 2] >>> 0 | $1)) {
             $12 = HEAP32[$3 + 12 >> 2];
             break label$11;
            }
            $5 = __zone_watermark_ok($9, $1, $6, $5, $2, $4);
            if ($5 ? 0 : !$29) {
             break label$4
            }
            $12 = HEAP32[$3 + 12 >> 2];
            if ($1) {
             break label$8
            }
           }
           $17 = HEAP32[$9 + 28 >> 2];
           $21 = $12 << 3;
           $5 = $17 + $21 | 0;
           $19 = $5 + 12 | 0;
           $4 = HEAP32[$19 >> 2];
           if (($4 | 0) != ($19 | 0)) {
            break label$5
           }
           $37 = $9 + 60 | 0;
           $38 = $9 + 420 | 0;
           $39 = $21 + 24 | 0;
           $26 = $5 + 16 | 0;
           $40 = HEAP32[$17 + 8 >> 2];
           $22 = 0;
           $20 = 0;
           $4 = 0;
           break label$6;
          }
          $36 = HEAP32[$9 + 24 >> 2];
          break label$4;
         }
         $41 = $9 + 420 | 0;
         $23 = $12 << 3;
         $42 = $23 + 24 | 0;
         $43 = $9 + $33 | 0;
         $44 = $9 + $34 | 0;
         $45 = $9 + $35 | 0;
         $4 = 1;
         break label$6;
        }
        $8 = 0;
        break label$1;
       }
       label$15 : while (1) {
        label$14 : {
         label$16 : {
          label$17 : {
           if (!$4) {
            if ($20 >>> 0 >= $40 >>> 0) {
             break label$14
            }
            $4 = 0;
            break label$17;
           }
           $15 = $1;
           label$20 : {
            if ($25) {
             $5 = $28;
             $4 = $44;
             $6 = $45;
             $7 = $1;
             while (1) {
              if ($7 >>> 0 >= 11) {
               break label$20
              }
              label$23 : {
               $8 = $6 + -8 | 0;
               $10 = HEAP32[$8 >> 2];
               if (($10 | 0) != ($8 | 0)) {
                $8 = $10 + -4 | 0;
                if ($8) {
                 break label$23
                }
               }
               $5 = $5 + 1 | 0;
               $4 = $4 + 36 | 0;
               $6 = $6 + 36 | 0;
               $7 = $7 + 1 | 0;
               continue;
              }
              break;
             };
             $11 = HEAP32[$8 + 8 >> 2];
             $14 = HEAP32[$8 + 4 >> 2];
             HEAP32[$11 >> 2] = $14;
             HEAP32[$14 + 4 >> 2] = $11;
             HEAP32[$8 + 20 >> 2] = 0;
             HEAP32[$8 + 24 >> 2] = HEAP32[$8 + 24 >> 2] | 128;
             HEAP32[$8 + 4 >> 2] = 256;
             HEAP32[$8 + 8 >> 2] = 512;
             HEAP32[$6 >> 2] = HEAP32[$6 >> 2] + -1;
             $6 = 1 << $7;
             while (1) {
              if (!(($5 + 1 | 0) <= ($1 | 0))) {
               $11 = HEAP32[$4 >> 2];
               $6 = $6 >>> 1 | 0;
               $7 = Math_imul($6, 36) + $8 | 0;
               $14 = $7 + 4 | 0;
               HEAP32[$11 + 4 >> 2] = $14;
               $16 = $4 + 8 | 0;
               HEAP32[$16 >> 2] = HEAP32[$16 >> 2] + 1;
               HEAP32[$4 >> 2] = $14;
               HEAP32[$7 + 4 >> 2] = $11;
               HEAP32[$7 + 8 >> 2] = $4;
               HEAP32[$7 + 20 >> 2] = $5;
               HEAP32[$7 + 24 >> 2] = HEAP32[$7 + 24 >> 2] & -129;
               $5 = $5 + -1 | 0;
               $4 = $4 + -36 | 0;
               continue;
              }
              break;
             };
             $4 = 3;
             break label$16;
            }
            $4 = 1;
            break label$17;
           }
           $4 = 2;
          }
          while (1) {
           label$28 : {
            label$29 : {
             label$30 : {
              label$31 : {
               label$32 : {
                label$33 : {
                 label$34 : {
                  label$36 : {
                   switch ($4 | 0) {
                   case 0:
                    $4 = 0;
                    label$39 : {
                     while (1) {
                      if ($4 >>> 0 <= 10) {
                       $7 = $9 + Math_imul($4, 36) | 0;
                       $6 = ($7 + $21 | 0) + 60 | 0;
                       $5 = HEAP32[$6 >> 2];
                       if (($5 | 0) != ($6 | 0)) {
                        $5 = $5 + -4 | 0;
                        if ($5) {
                         break label$39
                        }
                       }
                       $4 = $4 + 1 | 0;
                       continue;
                      }
                      break;
                     };
                     $4 = 10;
                     $5 = $38;
                     while (1) {
                      if (($4 | 0) <= -1) {
                       break label$14
                      }
                      $7 = find_suitable_fallback($5, $4, $12, $13 + 3 | 0);
                      if (($7 | 0) == -1) {
                       $5 = $5 + -36 | 0;
                       $4 = $4 + -1 | 0;
                       continue;
                      }
                      break;
                     };
                     $8 = HEAPU8[$13 + 3 | 0];
                     if (!($8 & 255 | (($12 | 0) != 1 | ($4 | 0) < 1))) {
                      $4 = 0;
                      $6 = $37;
                      label$46 : {
                       while (1) {
                        if ($4 >>> 0 > 10) {
                         break label$46
                        }
                        $8 = find_suitable_fallback($6, $4, 1, $13 + 3 | 0);
                        $7 = -1;
                        $4 = $4 + 1 | 0;
                        $5 = $6;
                        $10 = $5 + 36 | 0;
                        $6 = $10;
                        if (($8 | 0) == -1) {
                         continue
                        }
                        break;
                       };
                       $5 = $10 + -36 | 0;
                       $7 = $8;
                      }
                      $8 = HEAPU8[$13 + 3 | 0];
                     }
                     $7 = HEAP32[($7 << 3) + $5 >> 2];
                     $10 = HEAP32[$7 + 16 >> 2];
                     label$48 : {
                      $4 = $7 + -4 | 0;
                      $11 = get_pfnblock_flags_mask($4, ($4 - HEAP32[20650] | 0) / 36 | 0);
                      if (($11 | 0) == 3) {
                       break label$48
                      }
                      if ($10 >>> 0 >= 10) {
                       $5 = 1 << $10 + -10;
                       while (1) {
                        if (!$5) {
                         break label$48
                        }
                        set_pageblock_migratetype($4, $12);
                        $4 = $4 + 36864 | 0;
                        $5 = $5 + -1 | 0;
                        continue;
                       };
                      }
                      if (!($8 & 255)) {
                       break label$48
                      }
                      $5 = move_freepages_block($9, $4, $12, $13 + 4 | 0);
                      label$51 : {
                       if (($12 | 0) == 1) {
                        $6 = HEAP32[$13 + 4 >> 2];
                        if ($5) {
                         break label$51
                        }
                        break label$48;
                       }
                       $6 = ($11 | 0) == 1 ? (1024 - $5 | 0) - HEAP32[$13 + 4 >> 2] | 0 : 0;
                       if (!$5) {
                        break label$48
                       }
                      }
                      if (HEAP32[20707] ? 0 : ($5 + $6 | 0) <= 511) {
                       break label$33
                      }
                      set_pageblock_migratetype($4, $12);
                      break label$32;
                     }
                     $5 = HEAP32[$7 >> 2];
                     $6 = HEAP32[$7 + 4 >> 2];
                     HEAP32[$5 + 4 >> 2] = $6;
                     HEAP32[$6 >> 2] = $5;
                     $5 = (($9 + Math_imul($10, 36) | 0) + $21 | 0) + 60 | 0;
                     $6 = HEAP32[$5 >> 2];
                     HEAP32[$6 + 4 >> 2] = $7;
                     HEAP32[$5 >> 2] = $7;
                     HEAP32[$7 >> 2] = $6;
                     HEAP32[$7 + 4 >> 2] = $5;
                     break label$31;
                    }
                    $6 = HEAP32[$5 + 8 >> 2];
                    $8 = HEAP32[$5 + 4 >> 2];
                    HEAP32[$6 >> 2] = $8;
                    HEAP32[$8 + 4 >> 2] = $6;
                    HEAP32[$5 + 20 >> 2] = 0;
                    HEAP32[$5 + 24 >> 2] = HEAP32[$5 + 24 >> 2] | 128;
                    HEAP32[$5 + 4 >> 2] = 256;
                    HEAP32[$5 + 8 >> 2] = 512;
                    $6 = $7 + 92 | 0;
                    HEAP32[$6 >> 2] = HEAP32[$6 >> 2] + -1;
                    $8 = 1 << $4;
                    $10 = $5 + 4 | 0;
                    while (1) {
                     if (!(($4 | 0) < 1)) {
                      $11 = $7 + $39 | 0;
                      $14 = HEAP32[$11 >> 2];
                      $8 = $8 >>> 1 | 0;
                      $6 = $5 + Math_imul($8, 36) | 0;
                      $16 = $6 + 4 | 0;
                      HEAP32[$14 + 4 >> 2] = $16;
                      $27 = $7 + 56 | 0;
                      HEAP32[$27 >> 2] = HEAP32[$27 >> 2] + 1;
                      HEAP32[$11 >> 2] = $16;
                      HEAP32[$6 + 4 >> 2] = $14;
                      HEAP32[$6 + 8 >> 2] = $11;
                      $4 = $4 + -1 | 0;
                      HEAP32[$6 + 20 >> 2] = $4;
                      HEAP32[$6 + 24 >> 2] = HEAP32[$6 + 24 >> 2] & -129;
                      $7 = $7 + -36 | 0;
                      continue;
                     }
                     break;
                    };
                    HEAP32[$5 + 16 >> 2] = $12;
                    $6 = $5 + 24 | 0;
                    label$57 : {
                     label$58 : {
                      if (HEAP32[$6 >> 2] == -1) {
                       $4 = HEAP32[$5 >> 2] & 4194303;
                       $7 = HEAP32[$5 + 12 >> 2];
                       if ($4 | ($7 | HEAP32[$5 + 28 >> 2])) {
                        break label$58
                       }
                       $6 = HEAP32[$26 >> 2];
                       HEAP32[$26 >> 2] = $10;
                       HEAP32[$10 >> 2] = $19;
                       HEAP32[$6 >> 2] = $10;
                       HEAP32[$5 + 8 >> 2] = $6;
                       $22 = $22 + 1 | 0;
                       break label$57;
                      }
                      $4 = HEAP32[$5 >> 2] & 4194303;
                      $7 = HEAP32[$5 + 12 >> 2];
                     }
                     bad_page($5, $4 ? 28017 : HEAP32[$5 + 28 >> 2] ? 28002 : $7 ? 27778 : HEAP32[$6 >> 2] == -1 ? 0 : 27761, $4 ? 4194303 : 0);
                    }
                    $20 = $20 + 1 | 0;
                    break label$34;
                   case 1:
                    label$60 : {
                     label$61 : {
                      label$62 : {
                       if ($15 >>> 0 <= 10) {
                        label$64 : {
                         $5 = $9 + Math_imul($15, 36) | 0;
                         $6 = ($23 + $5 | 0) + 60 | 0;
                         $10 = HEAP32[$6 >> 2];
                         if (($10 | 0) != ($6 | 0)) {
                          $8 = $10 + -4 | 0;
                          if ($8) {
                           break label$64
                          }
                         }
                         $15 = $15 + 1 | 0;
                         $4 = 1;
                         continue;
                        }
                        $6 = HEAP32[$8 + 8 >> 2];
                        $4 = HEAP32[$8 + 4 >> 2];
                        HEAP32[$6 >> 2] = $4;
                        HEAP32[$4 + 4 >> 2] = $6;
                        HEAP32[$8 + 20 >> 2] = 0;
                        HEAP32[$8 + 24 >> 2] = HEAP32[$8 + 24 >> 2] | 128;
                        HEAP32[$8 + 4 >> 2] = 256;
                        HEAP32[$8 + 8 >> 2] = 512;
                        $6 = $5 + 92 | 0;
                        HEAP32[$6 >> 2] = HEAP32[$6 >> 2] + -1;
                        $6 = 1 << $15;
                        break label$62;
                       }
                       $4 = 10;
                       $5 = $41;
                       while (1) {
                        if (($4 | 0) < ($1 | 0)) {
                         break label$4
                        }
                        $7 = find_suitable_fallback($5, $4, $12, $13 + 11 | 0);
                        if (($7 | 0) == -1) {
                         $5 = $5 + -36 | 0;
                         $4 = $4 + -1 | 0;
                         continue;
                        }
                        break;
                       };
                       $8 = HEAPU8[$13 + 11 | 0];
                       if (!($8 & 255 | (($12 | 0) != 1 | ($4 | 0) <= ($1 | 0)))) {
                        $6 = $43;
                        $4 = $1;
                        label$69 : {
                         while (1) {
                          if (($4 | 0) > 10) {
                           break label$69
                          }
                          $8 = find_suitable_fallback($6, $4, 1, $13 + 11 | 0);
                          $7 = -1;
                          $4 = $4 + 1 | 0;
                          $5 = $6;
                          $10 = $5 + 36 | 0;
                          $6 = $10;
                          if (($8 | 0) == -1) {
                           continue
                          }
                          break;
                         };
                         $5 = $10 + -36 | 0;
                         $7 = $8;
                        }
                        $8 = HEAPU8[$13 + 11 | 0];
                       }
                       $7 = HEAP32[($7 << 3) + $5 >> 2];
                       $10 = HEAP32[$7 + 16 >> 2];
                       $4 = $7 + -4 | 0;
                       $11 = get_pfnblock_flags_mask($4, ($4 - HEAP32[20650] | 0) / 36 | 0);
                       if (($11 | 0) == 3) {
                        break label$60
                       }
                       if ($10 >>> 0 < 10) {
                        break label$61
                       }
                       $5 = 1 << $10 + -10;
                       while (1) {
                        if (!$5) {
                         break label$60
                        }
                        set_pageblock_migratetype($4, $12);
                        $4 = $4 + 36864 | 0;
                        $5 = $5 + -1 | 0;
                        continue;
                       };
                      }
                      while (1) {
                       if (!(($15 | 0) <= ($1 | 0))) {
                        $7 = $5 + $42 | 0;
                        $11 = HEAP32[$7 >> 2];
                        $6 = $6 >>> 1 | 0;
                        $4 = Math_imul($6, 36) + $8 | 0;
                        $14 = $4 + 4 | 0;
                        HEAP32[$11 + 4 >> 2] = $14;
                        $16 = $5 + 56 | 0;
                        HEAP32[$16 >> 2] = HEAP32[$16 >> 2] + 1;
                        HEAP32[$7 >> 2] = $14;
                        HEAP32[$4 + 4 >> 2] = $11;
                        HEAP32[$4 + 8 >> 2] = $7;
                        $15 = $15 + -1 | 0;
                        HEAP32[$4 + 20 >> 2] = $15;
                        HEAP32[$4 + 24 >> 2] = HEAP32[$4 + 24 >> 2] & -129;
                        $5 = $5 + -36 | 0;
                        continue;
                       }
                       break;
                      };
                      $4 = $12;
                      break label$16;
                     }
                     if (!($8 & 255)) {
                      break label$60
                     }
                     $5 = move_freepages_block($9, $4, $12, $13 + 12 | 0);
                     label$74 : {
                      if (($12 | 0) == 1) {
                       $6 = HEAP32[$13 + 12 >> 2];
                       if ($5) {
                        break label$74
                       }
                       break label$60;
                      }
                      $6 = ($11 | 0) == 1 ? (1024 - $5 | 0) - HEAP32[$13 + 12 >> 2] | 0 : 0;
                      if (!$5) {
                       break label$60
                      }
                     }
                     if (HEAP32[20707] ? 0 : ($5 + $6 | 0) <= 511) {
                      break label$29
                     }
                     set_pageblock_migratetype($4, $12);
                     break label$28;
                    }
                    $5 = HEAP32[$7 >> 2];
                    $6 = HEAP32[$7 + 4 >> 2];
                    HEAP32[$5 + 4 >> 2] = $6;
                    HEAP32[$6 >> 2] = $5;
                    $5 = (($9 + Math_imul($10, 36) | 0) + $23 | 0) + 60 | 0;
                    $6 = HEAP32[$5 >> 2];
                    HEAP32[$6 + 4 >> 2] = $7;
                    HEAP32[$5 >> 2] = $7;
                    HEAP32[$7 >> 2] = $6;
                    HEAP32[$7 + 4 >> 2] = $5;
                    $4 = 2;
                    continue;
                   default:
                    break label$36;
                   };
                  }
                  $15 = $1;
                  break label$30;
                 }
                 $4 = 0;
                 continue label$15;
                }
                $4 = 0;
                continue;
               }
               $4 = 0;
               continue;
              }
              $4 = 0;
              continue;
             }
             $4 = 1;
             continue;
            }
            $4 = 2;
            continue;
           }
           $4 = 2;
           continue;
          };
         }
         HEAP32[$10 + 12 >> 2] = $4;
         $5 = 0;
         $4 = $8;
         label$78 : {
          label$79 : {
           label$80 : {
            while (1) {
             if (($5 | 0) >= ($24 | 0)) {
              break label$79
             }
             $10 = $4 + 24 | 0;
             if (HEAP32[$10 >> 2] == -1) {
              $7 = HEAP32[$4 >> 2] & 4194303;
              $6 = HEAP32[$4 + 12 >> 2];
              if ($7 | ($6 | HEAP32[$4 + 28 >> 2])) {
               break label$80
              }
              $4 = $4 + 36 | 0;
              $5 = $5 + 1 | 0;
              continue;
             }
             break;
            };
            $7 = HEAP32[$4 >> 2] & 4194303;
            $6 = HEAP32[$4 + 12 >> 2];
           }
           bad_page($4, $7 ? 28017 : HEAP32[$4 + 28 >> 2] ? 28002 : $6 ? 27778 : HEAP32[$10 >> 2] == -1 ? 0 : 27761, $7 ? 4194303 : 0);
           break label$78;
          }
          $3 = $9 + 468 | 0;
          $6 = $3;
          $5 = HEAP32[$3 >> 2];
          $3 = -1 << $1;
          HEAP32[$6 >> 2] = $5 + $3;
          HEAP32[20660] = $3 + HEAP32[20660];
          break label$2;
         }
         $4 = 1;
         continue;
        }
        break;
       };
       $5 = $9 + 468 | 0;
       HEAP32[$5 >> 2] = HEAP32[$5 >> 2] - $20;
       HEAP32[20660] = HEAP32[20660] - $20;
       HEAP32[$17 >> 2] = HEAP32[$17 >> 2] + $22;
       $4 = HEAP32[$19 >> 2];
       if (($19 | 0) == ($4 | 0)) {
        break label$4
       }
      }
      $5 = HEAP32[$4 >> 2];
      $6 = HEAP32[$4 + 4 >> 2];
      HEAP32[$5 + 4 >> 2] = $6;
      HEAP32[$6 >> 2] = $5;
      HEAP32[$4 >> 2] = 256;
      HEAP32[$4 + 4 >> 2] = 512;
      HEAP32[$17 >> 2] = HEAP32[$17 >> 2] + -1;
      $8 = $4 + -4 | 0;
      if ($8) {
       break label$2
      }
     }
     $5 = $18 + 8 | 0;
     $6 = HEAP32[$3 + 16 >> 2];
     $4 = HEAP32[$3 + 4 >> 2];
     if (!$4) {
      $7 = $18 + 12 | 0;
      $18 = $5;
      if (HEAPU32[$7 >> 2] <= $6 >>> 0) {
       continue
      }
     }
     $18 = __next_zones_zonelist($5, $6, $4);
     continue;
    }
    break;
   };
   HEAP32[$8 + 28 >> 2] = 1;
   HEAP32[$8 + 20 >> 2] = 0;
   label$84 : {
    if (!($0 & 32768)) {
     break label$84
    }
    $5 = $8 + 32 | 0;
    $4 = 0;
    while (1) {
     if (($4 | 0) >= ($24 | 0)) {
      break label$84
     }
     $3 = HEAP32[2];
     HEAP32[$3 + 880 >> 2] = HEAP32[$3 + 880 >> 2] + 1;
     memset(HEAP32[$5 >> 2], 0, 65536);
     $3 = HEAP32[2];
     HEAP32[$3 + 880 >> 2] = HEAP32[$3 + 880 >> 2] + -1;
     $5 = $5 + 36 | 0;
     $4 = $4 + 1 | 0;
     continue;
    };
   }
   if (!(!$1 | !($0 & 16384))) {
    prep_compound_page($8, $1)
   }
   HEAP32[$8 + 16 >> 2] = $2 << 29 >> 31;
   if (!$25 | !$1) {
    break label$1
   }
   $0 = (HEAPU32[$9 + 40 >> 2] / 100 | 0) + 1024 | 0;
   if (HEAPU32[$9 + 12 >> 2] >= $0 >>> 0) {
    break label$1
   }
   $1 = HEAP32[$9 + 12 >> 2];
   label$87 : {
    if ($1 >>> 0 >= $0 >>> 0) {
     break label$87
    }
    if ((get_pfnblock_flags_mask($8, ($8 - HEAP32[20650] | 0) / 36 | 0) | 0) == 3) {
     break label$87
    }
    HEAP32[$9 + 12 >> 2] = $1 + 1024;
    set_pageblock_migratetype($8, 3);
    move_freepages_block($9, $8, 3, 0);
   }
  }
  global$0 = $13 + 16 | 0;
  return $8;
 }

 function wake_all_kswapds($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  $3 = HEAP32[$1 + 4 >> 2];
  $2 = HEAP32[$1 >> 2];
  $4 = HEAP32[$1 + 16 >> 2];
  if (!(HEAPU32[$2 + 4 >> 2] <= $4 >>> 0 ? !$3 : 0)) {
   $2 = __next_zones_zonelist($2, $4, $3)
  }
  $3 = 0;
  $6 = $1 + 4 | 0;
  while (1) {
   $1 = HEAP32[$2 >> 2];
   if ($1) {
    if (($3 | 0) != HEAP32[$1 + 24 >> 2]) {
     wakeup_kswapd($1, $0, $4);
     $3 = HEAP32[$1 + 24 >> 2];
    }
    $1 = $2 + 8 | 0;
    $5 = HEAP32[$6 >> 2];
    if (!$5) {
     $7 = $2 + 12 | 0;
     $2 = $1;
     if (HEAPU32[$7 >> 2] <= $4 >>> 0) {
      continue
     }
    }
    $2 = __next_zones_zonelist($1, $4, $5);
    continue;
   }
   break;
  };
 }

 function unreserve_highatomic_pageblock($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0;
  $3 = HEAP32[$0 + 16 >> 2];
  $4 = HEAP32[$0 >> 2];
  $2 = HEAP32[$0 + 4 >> 2];
  if (!(HEAPU32[$4 + 4 >> 2] <= $3 >>> 0 ? !$2 : 0)) {
   $4 = __next_zones_zonelist($4, $3, $2)
  }
  $9 = $0 + 4 | 0;
  $10 = $0 + 16 | 0;
  label$3 : {
   while (1) {
    $7 = HEAP32[$4 >> 2];
    if ($7) {
     if (!(HEAPU32[$7 + 12 >> 2] < 1025 ? !$1 : 0)) {
      $8 = $7 + 84 | 0;
      $6 = 0;
      while (1) {
       if ($6 >>> 0 <= 10) {
        $2 = HEAP32[$8 >> 2];
        label$10 : {
         if (($2 | 0) == ($8 | 0)) {
          break label$10
         }
         $5 = $2 + -4 | 0;
         if (!$5) {
          break label$10
         }
         if ((get_pfnblock_flags_mask($5, ($5 - HEAP32[20650] | 0) / 36 | 0) | 0) == 3) {
          $2 = $7 + 12 | 0;
          $3 = HEAP32[$2 >> 2];
          HEAP32[$2 >> 2] = $3 - ($3 >>> 0 < 1024 ? $3 : 1024);
         }
         $2 = $0 + 12 | 0;
         set_pageblock_migratetype($5, HEAP32[$2 >> 2]);
         if (move_freepages_block($7, $5, HEAP32[$2 >> 2], 0)) {
          break label$3
         }
        }
        $8 = $8 + 36 | 0;
        $6 = $6 + 1 | 0;
        continue;
       }
       break;
      };
     }
     $2 = $4 + 8 | 0;
     $5 = HEAP32[$10 >> 2];
     $6 = HEAP32[$9 >> 2];
     if (!$6) {
      $3 = $4 + 12 | 0;
      $4 = $2;
      if (HEAPU32[$3 >> 2] <= $5 >>> 0) {
       continue
      }
     }
     $4 = __next_zones_zonelist($2, $5, $6);
     continue;
    }
    break;
   };
   return 0;
  }
  return 1;
 }

 function free_pages($0, $1) {
  if ($0) {
   __free_pages(HEAP32[20650] + Math_imul($0 >>> 16 | 0, 36) | 0, $1)
  }
 }

 function nr_free_zone_pages() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0;
  $1 = 142208;
  if (HEAPU32[35553] > 1) {
   $1 = __next_zones_zonelist(142208, 1, 0)
  }
  while (1) {
   $0 = HEAP32[$1 >> 2];
   if ($0) {
    $3 = $2;
    $2 = HEAP32[$0 + 8 >> 2];
    $0 = HEAP32[$0 + 40 >> 2];
    $2 = ($3 - $2 | 0) + ($0 >>> 0 > $2 >>> 0 ? $0 : $2) | 0;
    $0 = $1 + 12 | 0;
    $3 = $1 + 8 | 0;
    $1 = $3;
    if (HEAPU32[$0 >> 2] <= 1) {
     continue
    }
    $1 = __next_zones_zonelist($3, 1, 0);
    continue;
   }
   break;
  };
  return $2;
 }

 function show_free_areas($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0, $15 = 0, $16 = 0, $17 = 0, $18 = 0, $19 = 0, $20 = 0, $21 = 0, $22 = 0, $23 = 0, $24 = 0, $25 = 0, $26 = 0, $27 = 0, $28 = 0, $29 = 0, $30 = 0, $31 = 0, $32 = 0, $33 = 0, $34 = 0, $35 = 0, $36 = 0, $37 = 0, $38 = 0, $39 = 0, $40 = 0, $41 = 0, $42 = 0, $43 = 0, $44 = 0, $45 = 0, $46 = 0, $47 = 0, $48 = 0, $49 = 0, $50 = 0, $51 = 0, $52 = 0, $53 = 0, $54 = 0, $55 = 0, $56 = 0, $57 = 0, $58 = 0, $59 = 0, $60 = 0, $61 = 0, $62 = 0, $63 = 0, $64 = 0, $65 = 0, $66 = 0, $67 = 0, $68 = 0, $69 = 0, $70 = 0, $71 = 0, $72 = 0, $73 = 0, $74 = 0, $75 = 0, $76 = 0;
  $2 = global$0 - 400 | 0;
  global$0 = $2;
  $14 = $1 ? $1 : 16876;
  $15 = $0 & 1;
  $0 = 0;
  $12 = 141176;
  $1 = 0;
  while (1) {
   label$1 : {
    label$3 : {
     switch ($1 | 0) {
     case 0:
      if ($12) {
       label$7 : {
        if (!HEAP32[$12 + 48 >> 2] | (HEAP32[$14 >> 2] & 1 ? 0 : $15)) {
         break label$7
        }
        $1 = 1;
        while (1) {
         if (!($1 & 1)) {
          break label$7
         }
         $0 = HEAP32[HEAP32[$12 + 28 >> 2] >> 2] + $0 | 0;
         $1 = 0;
         continue;
        };
       }
       $12 = next_zone($12);
       $1 = 0;
       continue;
      }
      HEAP32[$2 + 308 >> 2] = $0;
      $1 = HEAP32[20673];
      $5 = HEAP32[20672];
      $3 = HEAP32[20679];
      $4 = HEAP32[20675];
      HEAP32[$2 + 256 >> 2] = HEAP32[20674];
      HEAP32[$2 + 260 >> 2] = HEAP32[20680];
      HEAP32[$2 + 264 >> 2] = HEAP32[20676];
      HEAP32[$2 + 268 >> 2] = HEAP32[20689];
      HEAP32[$2 + 272 >> 2] = HEAP32[20690];
      HEAP32[$2 + 276 >> 2] = HEAP32[20696];
      HEAP32[$2 + 280 >> 2] = HEAP32[20677];
      HEAP32[$2 + 284 >> 2] = HEAP32[20678];
      HEAP32[$2 + 288 >> 2] = HEAP32[20687];
      HEAP32[$2 + 292 >> 2] = HEAP32[20692];
      HEAP32[$2 + 296 >> 2] = HEAP32[20668];
      HEAP32[$2 + 300 >> 2] = HEAP32[20670];
      HEAP32[$2 + 304 >> 2] = HEAP32[20660];
      HEAP32[$2 + 312 >> 2] = HEAP32[20671];
      HEAP32[$2 + 240 >> 2] = $1;
      HEAP32[$2 + 244 >> 2] = $5;
      HEAP32[$2 + 248 >> 2] = $3;
      HEAP32[$2 + 252 >> 2] = $4;
      printk(26598, $2 + 240 | 0);
      $1 = 141176;
      if ($1) {
       while (1) {
        $5 = HEAP32[$1 + 1072 >> 2];
        if (!(HEAP32[(($5 | 0) / 32 << 2) + $14 >> 2] & 1 << ($5 & 31) ? 0 : !!$15)) {
         HEAP32[$2 + 232 >> 2] = HEAP32[$1 + 1104 >> 2] > 15 ? 27142 : 27146;
         $1 = HEAP32[20673];
         $3 = HEAP32[20672];
         $4 = HEAP32[20675];
         HEAP32[$2 + 192 >> 2] = HEAP32[20674] << 6;
         HEAP32[$2 + 196 >> 2] = HEAP32[20676] << 6;
         HEAP32[$2 + 200 >> 2] = HEAP32[20679] << 6;
         HEAP32[$2 + 204 >> 2] = HEAP32[20680] << 6;
         HEAP32[$2 + 208 >> 2] = HEAP32[20687] << 6;
         HEAP32[$2 + 212 >> 2] = HEAP32[20689] << 6;
         HEAP32[$2 + 216 >> 2] = HEAP32[20690] << 6;
         HEAP32[$2 + 220 >> 2] = HEAP32[20692] << 6;
         HEAP32[$2 + 224 >> 2] = HEAP32[20691] << 6;
         HEAP32[$2 + 228 >> 2] = HEAP32[20696] << 6;
         HEAP32[$2 + 176 >> 2] = $5;
         HEAP32[$2 + 180 >> 2] = $1 << 6;
         HEAP32[$2 + 184 >> 2] = $3 << 6;
         HEAP32[$2 + 188 >> 2] = $4 << 6;
         printk(26887, $2 + 176 | 0);
        }
        $1 = 0;
        if ($1) {
         continue
        }
        break;
       }
      }
      $3 = 141176;
      $19 = 1;
      $17 = 28;
      $25 = 476;
      $26 = 472;
      $27 = 484;
      $28 = 480;
      $29 = 488;
      $30 = 492;
      $31 = 496;
      $32 = 504;
      $33 = 500;
      $34 = 508;
      $35 = 512;
      $4 = 6;
      $36 = $2 + 168 | 0;
      $37 = $2 + 164 | 0;
      $38 = $2 + 160 | 0;
      $39 = $2 + 156 | 0;
      $40 = $2 + 152 | 0;
      $41 = $2 + 148 | 0;
      $42 = $2 + 144 | 0;
      $43 = $2 + 140 | 0;
      $44 = $2 + 136 | 0;
      $45 = $2 + 132 | 0;
      $46 = $2 + 128 | 0;
      $47 = $2 + 120 | 0;
      $48 = $2 + 116 | 0;
      $20 = 16;
      $49 = $2 + 172 | 0;
      $50 = 27149;
      $51 = 27446;
      $52 = 8;
      $53 = 27471;
      $54 = 27464;
      $55 = 4;
      $1 = 1;
      continue;
     default:
      label$14 : {
       if (!HEAP32[$8 + 48 >> 2] | (HEAP32[$14 >> 2] & $9 ? 0 : $15)) {
        break label$14
       }
       HEAP32[$2 + 64 >> 2] = HEAP32[$8 + 52 >> 2];
       printk($56, $2 - -64 | 0);
       $5 = $8 + $57 | 0;
       $7 = 0;
       $13 = 0;
       $1 = 0;
       while (1) {
        label$17 : {
         if (!$1) {
          if (($7 | 0) != ($21 | 0)) {
           $10 = 0;
           $16 = ($2 + 325 | 0) + $7 | 0;
           HEAP8[$16 | 0] = 0;
           $1 = HEAP32[(Math_imul($7, $22) + $8 | 0) + $58 >> 2];
           HEAP32[($2 + 336 | 0) + ($7 << $23) >> 2] = $1;
           $18 = $1 << $7;
           $1 = $5;
           $6 = 0;
           while (1) {
            if (($6 | 0) != ($24 | 0)) {
             if (($1 | 0) != HEAP32[$1 >> 2]) {
              $10 = $9 << $6 | $10;
              HEAP8[$16 | 0] = $10;
             }
             $1 = $1 + $59 | 0;
             $6 = $6 + $9 | 0;
             continue;
            }
            break;
           };
           $5 = $5 + $22 | 0;
           $7 = $7 + $9 | 0;
           $13 = $13 + $18 | 0;
           $1 = 0;
           continue;
          }
          $11 = 0;
          break label$17;
         }
         if (($11 | 0) != ($21 | 0)) {
          HEAP32[$2 + 52 >> 2] = $60 << $11;
          $1 = HEAP32[($2 + 336 | 0) + ($11 << $23) >> 2];
          HEAP32[$2 + 48 >> 2] = $1;
          printk($61, $2 + 48 | 0);
          if ($1) {
           $10 = HEAPU8[($2 + 325 | 0) + $11 | 0];
           $1 = 0;
           $6 = $2 + 395 | 0;
           while (1) {
            if (($1 | 0) != ($24 | 0)) {
             if ($10 & $9 << $1) {
              HEAP8[$6 | 0] = HEAPU8[$1 + $62 | 0];
              $6 = $6 + $9 | 0;
             }
             $1 = $1 + $9 | 0;
             continue;
            }
            break;
           };
           HEAP8[$6 | 0] = 0;
           HEAP32[$2 + 32 >> 2] = $2 + 395;
           printk($63, $2 + 32 | 0);
          }
          $11 = $9 + $11 | 0;
          $1 = 1;
          continue;
         }
         HEAP32[$2 + 16 >> 2] = $13 << $64;
         printk($65, $2 + 16 | 0);
         break label$14;
        }
        $1 = 1;
        continue;
       };
      }
      $8 = next_zone($8);
      if (!$8) {
       break label$1
      }
      $1 = 2;
      continue;
     case 1:
      break label$3;
     };
    }
    if ($3) {
     $5 = HEAP32[$3 + 48 >> 2];
     if (!(!$5 | (HEAP32[$14 >> 2] & $19 ? 0 : !!$15))) {
      $6 = 0;
      $1 = 1;
      while (1) {
       if ($1 & $19) {
        $6 = HEAP32[HEAP32[$3 + $17 >> 2] >> 2] + $6 | 0;
        $1 = 0;
        continue;
       }
       break;
      };
      $1 = HEAP32[$3 + 468 >> 2];
      $7 = HEAP32[$3 + $25 >> 2];
      $13 = HEAP32[$3 + $26 >> 2];
      $10 = HEAP32[$3 + $27 >> 2];
      $16 = HEAP32[$3 + $28 >> 2];
      $18 = HEAP32[$3 + $29 >> 2];
      $66 = HEAP32[$3 + $30 >> 2];
      $67 = HEAP32[$3 + $31 >> 2];
      $68 = HEAP32[$3 + $32 >> 2];
      $69 = HEAP32[$3 + $33 >> 2];
      $70 = HEAP32[$3 + $34 >> 2];
      $71 = HEAP32[$3 + 52 >> 2];
      $72 = HEAP32[$3 >> 2];
      $73 = HEAP32[$3 + 4 >> 2];
      $74 = HEAP32[$3 + 8 >> 2];
      $75 = HEAP32[$3 + 40 >> 2];
      $76 = HEAP32[$3 + $35 >> 2];
      HEAP32[$36 >> 2] = HEAP32[HEAP32[$3 + $17 >> 2] >> 2] << $4;
      HEAP32[$37 >> 2] = $6 << $4;
      HEAP32[$38 >> 2] = $70 << $4;
      HEAP32[$39 >> 2] = $69 << $4;
      HEAP32[$40 >> 2] = $68;
      HEAP32[$41 >> 2] = $67 << $4;
      HEAP32[$42 >> 2] = $75 << $4;
      HEAP32[$43 >> 2] = $5 << $4;
      HEAP32[$44 >> 2] = $66 << $4;
      HEAP32[$45 >> 2] = $18 << $4;
      HEAP32[$46 >> 2] = $16 << $4;
      HEAP32[($2 + 96 | 0) + $17 >> 2] = $10 << $4;
      HEAP32[$47 >> 2] = $13 << $4;
      HEAP32[$48 >> 2] = $7 << $4;
      HEAP32[($2 + 96 | 0) + $20 >> 2] = $74 << $4;
      HEAP32[$49 >> 2] = $76 << $4;
      HEAP32[$2 + 108 >> 2] = $73 << $4;
      HEAP32[$2 + 104 >> 2] = $72 << $4;
      HEAP32[$2 + 100 >> 2] = $1 << $4;
      HEAP32[$2 + 96 >> 2] = $71;
      printk($50, $2 + 96 | 0);
      $1 = 0;
      printk($51, 0);
      $5 = $3 + $20 | 0;
      while (1) {
       if (($1 | 0) != ($52 | 0)) {
        HEAP32[$2 + 80 >> 2] = HEAP32[$1 + $5 >> 2];
        printk($54, $2 + 80 | 0);
        $1 = $1 + $55 | 0;
        continue;
       }
       break;
      };
      printk($53, 0);
     }
     $3 = next_zone($3);
     $1 = 1;
     continue;
    }
    $56 = 27475;
    $57 = 60;
    $21 = 11;
    $64 = 6;
    $65 = 27495;
    $60 = 64;
    $23 = 2;
    $61 = 27482;
    $9 = 1;
    $24 = 4;
    $63 = 28089;
    $62 = 28085;
    $22 = 36;
    $58 = 92;
    $59 = 8;
    $8 = 141176;
    if (!$8) {
     break label$1
    }
    $1 = 2;
    continue;
   }
   break;
  };
  HEAP32[$2 >> 2] = HEAP32[20688];
  printk(27506, $2);
  global$0 = $2 + 400 | 0;
 }

 function build_all_zonelists() {
  var $0 = 0, $1 = 0, $2 = 0;
  $0 = global$0 - 16 | 0;
  global$0 = $0;
  label$1 : {
   if (HEAP32[16384]) {
    __build_all_zonelists();
    break label$1;
   }
   __build_all_zonelists();
   pageset_init();
   HEAP32[4228] = 1;
   HEAP32[4227] = 0;
   HEAP32[4228] = 1;
  }
  $1 = nr_free_zone_pages();
  HEAP32[20702] = $1;
  $2 = $1 >>> 0 < 4096;
  HEAP32[20707] = $2;
  HEAP32[$0 + 8 >> 2] = $1;
  HEAP32[$0 >> 2] = 1;
  HEAP32[$0 + 4 >> 2] = $2 ? 27596 : 27600;
  printk(27533, $0);
  global$0 = $0 + 16 | 0;
 }

 function __build_all_zonelists() {
  label$1 : {
   if (!(!HEAP32[268] | 1)) {
    build_zonelists(0);
    break label$1;
   }
   build_zonelists(141176);
  }
 }

 function pageset_init() {
  var $0 = 0, $1 = 0, $2 = 0;
  memset(16904, 0, 36);
  HEAP32[4226] = 0;
  while (1) {
   if (($0 | 0) != 24) {
    $2 = $0 + 16904 | 0;
    $1 = $2 + 12 | 0;
    HEAP32[$2 + 16 >> 2] = $1;
    HEAP32[$1 >> 2] = $1;
    $0 = $0 + 8 | 0;
    continue;
   }
   break;
  };
 }

 function build_zonelists($0) {
  var $1 = 0, $2 = 0;
  $2 = HEAP32[$0 + 1072 >> 2];
  $1 = $0;
  $0 = $0 + 1032 | 0;
  $1 = (build_zonerefs_node($1, $0) << 3) + $0 | 0;
  $0 = $2;
  while (1) {
   if (($0 | 0) < 0) {
    $0 = $0 + 1 | 0;
    if ($0) {
     continue
    }
    $1 = (build_zonerefs_node(141176, $1) << 3) + $1 | 0;
    continue;
   }
   break;
  };
  $0 = 0;
  while (1) {
   if (!(($0 | 0) >= ($2 | 0))) {
    if (!$0) {
     $1 = (build_zonerefs_node(141176, $1) << 3) + $1 | 0
    }
    $0 = $0 + 1 | 0;
    continue;
   }
   break;
  };
  HEAP32[$1 >> 2] = 0;
  HEAP32[$1 + 4 >> 2] = 0;
 }

 function memmap_init_zone($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  $5 = $0 + $2 | 0;
  $0 = $5 + -1 | 0;
  if (HEAPU32[20649] < $0 >>> 0) {
   HEAP32[20649] = $0
  }
  $0 = $2 << 16;
  $6 = $1 << 31;
  $4 = Math_imul($2, 36) + 32 | 0;
  while (1) {
   if ($2 >>> 0 < $5 >>> 0) {
    $1 = HEAP32[20650] + $4 | 0;
    $3 = $1 + -32 | 0;
    memset($3, 0, 36);
    HEAP32[$1 + -4 >> 2] = 1;
    HEAP32[$1 + -8 >> 2] = -1;
    HEAP32[$1 >> 2] = $0;
    $7 = $1 + -24 | 0;
    $1 = $1 + -28 | 0;
    HEAP32[$7 >> 2] = $1;
    HEAP32[$3 >> 2] = HEAP32[$3 >> 2] & 2147483647 | $6;
    HEAP32[$1 >> 2] = $1;
    if (!($2 & 1023)) {
     set_pageblock_migratetype($3, 1);
     _cond_resched();
    }
    $0 = $0 + 65536 | 0;
    $4 = $4 + 36 | 0;
    $2 = $2 + 1 | 0;
    continue;
   }
   break;
  };
 }

 function init_currently_empty_zone($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0;
  HEAP32[$0 + 36 >> 2] = $1;
  $1 = HEAP32[$0 + 24 >> 2];
  HEAP32[$1 + 1056 >> 2] = (($0 - $1 | 0) / 516 | 0) + 1;
  $2 = $0;
  while (1) {
   if (($3 | 0) != 11) {
    $1 = 0;
    HEAP32[(Math_imul($3, 36) + $0 | 0) + 92 >> 2] = 0;
    while (1) {
     if (($1 | 0) != 32) {
      $5 = $1 + $2 | 0;
      $4 = $5 + 60 | 0;
      HEAP32[$5 - -64 >> 2] = $4;
      HEAP32[$4 >> 2] = $4;
      $1 = $1 + 8 | 0;
      continue;
     }
     break;
    };
    $2 = $2 + 36 | 0;
    $3 = $3 + 1 | 0;
    continue;
   }
   break;
  };
  HEAP32[$0 + 56 >> 2] = 1;
 }

 function free_area_init_node($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, wasm2js_i32$0 = 0, wasm2js_i32$1 = 0;
  $5 = global$0 - 80 | 0;
  global$0 = $5;
  HEAP32[35559] = $1;
  HEAP32[35562] = 0;
  HEAP32[35589] = 0;
  while (1) {
   if (($6 | 0) != 2) {
    $4 = 0;
    $3 = $0;
    $7 = $1;
    while (1) {
     if (($4 | 0) != ($6 | 0)) {
      $4 = $4 + 1 | 0;
      $7 = HEAP32[$3 >> 2] + $7 | 0;
      $3 = $3 + 4 | 0;
      continue;
     }
     break;
    };
    $4 = Math_imul($6, 516);
    $10 = $6 << 2;
    $3 = HEAP32[$10 + $0 >> 2];
    $10 = $3 - ($2 ? HEAP32[$2 + $10 >> 2] : 0) | 0;
    HEAP32[$4 + 141224 >> 2] = $10;
    HEAP32[$4 + 141220 >> 2] = $3;
    HEAP32[$4 + 141212 >> 2] = $3 ? $7 : 0;
    $6 = $6 + 1 | 0;
    $8 = $3 + $8 | 0;
    $9 = $9 + $10 | 0;
    continue;
   }
   break;
  };
  HEAP32[35560] = $9;
  HEAP32[35561] = $8;
  HEAP32[$5 + 68 >> 2] = $9;
  HEAP32[$5 + 64 >> 2] = 0;
  printk(28097, $5 - -64 | 0);
  __init_waitqueue_head(142252);
  __init_waitqueue_head(142260);
  lruvec_init();
  HEAP32[35589] = 16940;
  $7 = 28168;
  $4 = 0;
  $8 = 0;
  while (1) {
   label$9 : {
    if (($4 | 0) != 1032) {
     $2 = HEAP32[$4 + 141212 >> 2];
     label$11 : {
      $9 = $4 + 141224 | 0;
      $3 = HEAP32[$9 >> 2];
      $0 = HEAP32[$4 + 141220 >> 2];
      $1 = Math_imul($0, 36) + 65535 >>> 16 | 0;
      if ($3 >>> 0 >= $1 >>> 0) {
       $3 = $3 - $1 | 0;
       if ($1) {
        break label$11
       }
       break label$9;
      }
      $6 = HEAP32[$7 >> 2];
      HEAP32[$5 + 40 >> 2] = $3;
      HEAP32[$5 + 36 >> 2] = $1;
      HEAP32[$5 + 32 >> 2] = $6;
      printk(28176, $5 + 32 | 0);
      break label$9;
     }
     $6 = HEAP32[$7 >> 2];
     HEAP32[$5 + 52 >> 2] = $1;
     HEAP32[$5 + 48 >> 2] = $6;
     printk(28127, $5 + 48 | 0);
     break label$9;
    }
    global$0 = $5 + 80 | 0;
    return;
   }
   label$8 : {
    if ($4) {
     break label$8
    }
    $1 = HEAP32[35620];
    if ($3 >>> 0 <= $1 >>> 0) {
     break label$8
    }
    HEAP32[$5 + 16 >> 2] = 28298;
    HEAP32[$5 + 20 >> 2] = $1;
    printk(28221, $5 + 16 | 0);
    $3 = $3 - $1 | 0;
   }
   $1 = $4 + 141176 | 0;
   HEAP32[$4 + 141216 >> 2] = $3;
   $6 = HEAP32[$7 >> 2];
   HEAP32[$4 + 141204 >> 2] = 16904;
   HEAP32[$4 + 141200 >> 2] = 141176;
   HEAP32[$4 + 141228 >> 2] = $6;
   HEAP32[35621] = HEAP32[35621] + $3;
   HEAP32[35622] = HEAP32[35622] + $3;
   $3 = HEAP32[$9 >> 2];
   label$13 : {
    label$14 : {
     if (!$3) {
      if ($0) {
       break label$14
      }
      break label$13;
     }
     (wasm2js_i32$0 = $5, wasm2js_i32$1 = zone_batchsize($1)), HEAP32[wasm2js_i32$0 + 8 >> 2] = wasm2js_i32$1;
     HEAP32[$5 + 4 >> 2] = $3;
     HEAP32[$5 >> 2] = $6;
     printk(28305, $5);
     if (!$0) {
      break label$13
     }
    }
    setup_usemap($1, $2, $0);
    init_currently_empty_zone($1, $2);
    memmap_init_zone($0, $8, $2);
   }
   $4 = $4 + 516 | 0;
   $7 = $7 + 4 | 0;
   $8 = $8 + 1 | 0;
   continue;
  };
 }

 function zone_batchsize($0) {
  var $1 = 0, $2 = 0;
  $0 = HEAP32[$0 + 40 >> 2];
  $0 = ($0 << 6 & -65536) >>> 0 > 1048576 ? 4 : $0 >>> 12 | 0;
  $0 = $0 ? $0 : 1;
  $0 = ($0 >>> 1 | 0) + $0 | 0;
  $1 = $0 >>> 0 > 65535;
  $2 = $1 ? 32 : 16;
  $0 = $1 ? $0 : $0 << 16;
  $1 = $0 >>> 0 > 16777215;
  $2 = $1 ? $2 : $2 + -8 | 0;
  $0 = $1 ? $0 : $0 << 8;
  $1 = $0 >>> 0 > 268435455;
  $2 = $1 ? $2 : $2 + -4 | 0;
  $0 = $1 ? $0 : $0 << 4;
  $1 = $0 >>> 0 > 1073741823;
  return -1 << (($1 ? $2 : $2 + -2 | 0) + (($1 ? $0 : $0 << 2) >> 31 ^ -1) | 0) + -1 ^ -1;
 }

 function setup_usemap($0, $1, $2) {
  var wasm2js_i32$0 = 0, wasm2js_i32$1 = 0;
  HEAP32[$0 + 32 >> 2] = 0;
  $1 = ((($1 & 1023) + $2 | 0) + 1023 >>> 8 & 16777212) + 31 >>> 3 & 4194300;
  if ($1) {
   (wasm2js_i32$0 = $0 + 32 | 0, wasm2js_i32$1 = memblock_alloc_try_nid_nopanic($1, 128, HEAP32[35562])), HEAP32[wasm2js_i32$0 >> 2] = wasm2js_i32$1
  }
 }

 function mem_init_print_info() {
  var $0 = 0, $1 = 0, $2 = 0;
  $0 = global$0 - 48 | 0;
  global$0 = $0;
  HEAP32[$0 + 40 >> 2] = 27741;
  HEAP32[$0 + 36 >> 2] = 27741;
  $1 = HEAP32[20710];
  HEAP32[$0 + 32 >> 2] = $1 << 6;
  HEAP32[$0 + 24 >> 2] = 0;
  HEAP32[$0 + 16 >> 2] = 0;
  $2 = HEAP32[35560];
  HEAP32[$0 + 28 >> 2] = ($2 - HEAP32[20709] | 0) - $1 << 6;
  HEAP32[$0 + 20 >> 2] = 0;
  HEAP32[$0 + 4 >> 2] = $2 << 6;
  HEAP32[$0 >> 2] = HEAP32[20660] << 6;
  HEAP32[$0 + 8 >> 2] = 4194241;
  HEAP32[$0 + 12 >> 2] = 0;
  printk(27603, $0);
  global$0 = $0 + 48 | 0;
 }

 function page_alloc_cpu_dead($0) {
  $0 = $0 | 0;
  lru_add_drain_cpu();
  drain_pages();
  return 0;
 }

 function build_zonerefs_node($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $2 = 1032;
  while (1) {
   $3 = $0 + $2 | 0;
   if (HEAP32[$3 + -476 >> 2]) {
    $5 = ($4 << 3) + $1 | 0;
    $6 = $3 + -516 | 0;
    HEAP32[$5 >> 2] = $6;
    HEAP32[$5 + 4 >> 2] = ($6 - HEAP32[$3 + -492 >> 2] | 0) / 516;
    $4 = $4 + 1 | 0;
   }
   $2 = $2 + -516 | 0;
   if ($2) {
    continue
   }
   break;
  };
  return $4;
 }

 function __probe_kernel_read($0, $1, $2) {
  var $3 = 0, $4 = 0;
  $3 = HEAP32[2];
  HEAP32[$3 + 880 >> 2] = HEAP32[$3 + 880 >> 2] + 1;
  $3 = HEAP32[3];
  HEAP32[3] = 0;
  $4 = HEAP32[2];
  HEAP32[$4 + 444 >> 2] = HEAP32[$4 + 444 >> 2] + 1;
  umem(1, $0 | 0, $1 | 0, $2 | 0) | 0;
  $0 = HEAP32[2];
  HEAP32[$0 + 444 >> 2] = HEAP32[$0 + 444 >> 2] + -1;
  HEAP32[3] = $3;
  $0 = HEAP32[2];
  HEAP32[$0 + 880 >> 2] = HEAP32[$0 + 880 >> 2] + -1;
 }

 function find_lock_task_mm($0) {
  var $1 = 0, $2 = 0;
  $2 = HEAP32[$0 + 732 >> 2];
  $1 = $2 + 12 | 0;
  $0 = $0 + 732 | 0;
  label$1 : {
   while (1) {
    $1 = HEAP32[$1 >> 2];
    if (($1 | 0) == ($2 + 12 | 0)) {
     break label$1
    }
    if (!HEAP32[$1 + -236 >> 2]) {
     $2 = HEAP32[$0 >> 2];
     continue;
    }
    break;
   };
   return $1 + -592 | 0;
  }
  return 0;
 }

 function oom_badness($0, $1) {
  var $2 = 0, $3 = 0;
  label$1 : {
   label$2 : {
    if (HEAPU8[$0 + 14 | 0] & 32 | HEAP32[$0 + 500 >> 2] == 1) {
     break label$2
    }
    $2 = find_lock_task_mm($0);
    if (!$2) {
     break label$2
    }
    $3 = HEAP16[HEAP32[$2 + 732 >> 2] + 362 >> 1];
    if (($3 | 0) == -1e3) {
     break label$1
    }
    $0 = HEAP32[$2 + 356 >> 2];
    if (HEAP32[$0 + 364 >> 2] & 2097152 | (($0 | 0) == HEAP32[HEAP32[$2 + 504 >> 2] + 356 >> 2] ? HEAP32[$2 + 600 >> 2] : 0)) {
     break label$1
    }
    $2 = Math_imul(($1 >>> 0) / 1e3 | 0, $3);
    $1 = HEAP32[$0 + 340 >> 2];
    $2 = $2 + (($1 | 0) > 0 ? $1 : 0) | 0;
    $1 = HEAP32[$0 + 344 >> 2];
    $2 = $2 + (($1 | 0) > 0 ? $1 : 0) | 0;
    $1 = HEAP32[$0 + 352 >> 2];
    $2 = $2 + (($1 | 0) > 0 ? $1 : 0) | 0;
    $1 = HEAP32[$0 + 348 >> 2];
    $0 = $2 + (($1 | 0) > 0 ? $1 : 0) + (HEAP32[$0 + 48 >> 2] >>> 16) | 0;
    $3 = ($0 | 0) > 1 ? $0 : 1;
   }
   return $3;
  }
  return 0;
 }

 function process_shares_mm($0, $1) {
  var $2 = 0, $3 = 0;
  $2 = HEAP32[$0 + 732 >> 2] + 12 | 0;
  $0 = $2;
  label$1 : {
   while (1) {
    $0 = HEAP32[$0 >> 2];
    if (($2 | 0) == ($0 | 0)) {
     break label$1
    }
    $3 = HEAP32[$0 + -236 >> 2];
    if (!$3) {
     continue
    }
    break;
   };
   return ($1 | 0) == ($3 | 0);
  }
  return 0;
 }

 function out_of_memory($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0;
  $5 = global$0 - 16 | 0;
  global$0 = $5;
  HEAP32[$5 + 12 >> 2] = 0;
  $2 = 0;
  label$1 : {
   if (HEAPU8[82864]) {
    break label$1
   }
   if (!HEAP32[$0 + 8 >> 2]) {
    $1 = $5 + 12 | 0;
    if (HEAP32[4262]) {
     __down_read_common(17036);
     notifier_call_chain(17048, 0, $1);
     __up_read(17036);
    }
    $2 = 1;
    if (HEAP32[$5 + 12 >> 2]) {
     break label$1
    }
   }
   if (task_will_free_mem(HEAP32[2])) {
    mark_oom_victim(HEAP32[2]);
    wake_oom_reaper(HEAP32[2]);
    $2 = 1;
    break label$1;
   }
   $1 = HEAP32[$0 + 12 >> 2];
   if ($1) {
    $2 = 1;
    if (!($1 & 128)) {
     break label$1
    }
   }
   HEAP32[$0 + 4 >> 2] = 0;
   $2 = HEAP32[$0 + 8 >> 2];
   HEAP32[$0 + 20 >> 2] = $2 ? 1 : HEAP32[20709];
   $1 = HEAP32[20718];
   if (!(!$1 | ($2 ? ($1 | 0) != 2 : 0) | HEAP32[$0 + 16 >> 2] == -1)) {
    dump_header($0);
    HEAP32[$5 >> 2] = HEAP32[20718] == 2 ? 28548 : 28559;
    panic(28505, $5);
    abort();
   }
   label$7 : {
    label$8 : {
     label$9 : {
      label$10 : {
       if (!HEAP32[20717] | $2) {
        break label$10
       }
       $1 = HEAP32[2];
       if (!HEAP32[$1 + 356 >> 2] | HEAP32[$1 + 500 >> 2] == 1 | HEAPU8[$1 + 14 | 0] & 32) {
        break label$10
       }
       if (HEAPU16[HEAP32[$1 + 732 >> 2] + 362 >> 1] != 64536) {
        break label$9
       }
      }
      if ($2) {
       break label$7
      }
      $9 = $0 + 16 | 0;
      $10 = $0 + 20 | 0;
      $7 = $0 + 28 | 0;
      $6 = $0 + 24 | 0;
      $2 = 1024;
      while (1) {
       $3 = HEAP32[$2 + 348 >> 2];
       $2 = $3 + -348 | 0;
       if (($2 | 0) == 1024) {
        break label$7
       }
       if (HEAPU8[$3 + -334 | 0] & 32 | HEAP32[$3 + 152 >> 2] == 1) {
        continue
       }
       $1 = HEAP32[$3 + 384 >> 2];
       label$12 : {
        if (HEAP32[$9 >> 2] == -1) {
         break label$12
        }
        $4 = HEAP32[$1 + 368 >> 2];
        if (!$4) {
         break label$12
        }
        if (HEAP32[$4 + 364 >> 2] & 2097152) {
         continue
        }
        break label$8;
       }
       $4 = -1;
       label$13 : {
        label$14 : {
         if (!HEAPU8[$1 + 360 | 0]) {
          $4 = oom_badness($2, HEAP32[$10 >> 2]);
          if (!$4) {
           continue
          }
          $1 = HEAP32[$7 >> 2];
          if ($4 >>> 0 < $1 >>> 0) {
           continue
          }
          if (($1 | 0) == ($4 | 0)) {
           break label$14
          }
         }
         $1 = HEAP32[$6 >> 2];
         break label$13;
        }
        $1 = HEAP32[$6 >> 2];
        if (HEAP32[$1 + 420 >> 2] > -1) {
         continue
        }
       }
       label$16 : {
        if (!$1) {
         break label$16
        }
        $8 = HEAP32[$1 + 8 >> 2] + -1 | 0;
        HEAP32[$1 + 8 >> 2] = $8;
        if ($8) {
         break label$16
        }
        __put_task_struct($1);
       }
       HEAP32[$7 >> 2] = $4;
       HEAP32[$6 >> 2] = $2;
       $1 = $3 + -340 | 0;
       HEAP32[$1 >> 2] = HEAP32[$1 >> 2] + 1;
       continue;
      };
     }
     HEAP32[$0 + 24 >> 2] = HEAP32[2];
     HEAP32[$1 + 8 >> 2] = HEAP32[$1 + 8 >> 2] + 1;
     oom_kill_process($0, 28344);
     $2 = 1;
     break label$1;
    }
    $2 = $0 + 24 | 0;
    $1 = HEAP32[$2 >> 2];
    label$17 : {
     if (!$1) {
      break label$17
     }
     $3 = HEAP32[$1 + 8 >> 2] + -1 | 0;
     HEAP32[$1 + 8 >> 2] = $3;
     if ($3) {
      break label$17
     }
     __put_task_struct($1);
    }
    HEAP32[$2 >> 2] = -1;
   }
   HEAP32[$0 + 28 >> 2] = (Math_imul(HEAP32[$0 + 28 >> 2], 1e3) >>> 0) / HEAPU32[$0 + 20 >> 2];
   label$18 : {
    if (HEAP32[$0 + 24 >> 2]) {
     break label$18
    }
    dump_header($0);
    printk(28385, 0);
    if (HEAP32[$0 + 8 >> 2] | HEAP32[$0 + 16 >> 2] == -1) {
     break label$18
    }
    panic(28431, 0);
    abort();
   }
   $1 = $0 + 24 | 0;
   $2 = HEAP32[$1 >> 2];
   if ($2 + 1 >>> 0 >= 2) {
    oom_kill_process($0, HEAP32[$0 + 8 >> 2] ? 28477 : 28463);
    $2 = HEAP32[$1 >> 2];
   }
   $2 = ($2 | 0) != 0;
  }
  $0 = $2;
  global$0 = $5 + 16 | 0;
  return $0;
 }

 function task_will_free_mem($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0;
  label$1 : {
   $3 = HEAP32[$0 + 356 >> 2];
   label$2 : {
    if (!$3) {
     break label$2
    }
    $1 = HEAP32[HEAP32[$0 + 732 >> 2] + 64 >> 2];
    if ($1 & 8 | (!(HEAPU8[$0 + 12 | 0] & 4) | HEAP32[$0 + 584 >> 2] != ($0 + 584 | 0) ? !($1 & 4) : 0)) {
     break label$2
    }
    if (HEAP32[$3 + 364 >> 2] & 2097152) {
     break label$2
    }
    if (HEAP32[$3 + 40 >> 2] < 2) {
     break label$1
    }
    $4 = $0 + 732 | 0;
    $0 = 1024;
    while (1) {
     $1 = HEAP32[$0 + 348 >> 2];
     $0 = $1 + -348 | 0;
     if (($0 | 0) == 1024) {
      break label$1
     }
     if (!process_shares_mm($0, $3)) {
      continue
     }
     $2 = HEAP32[$1 + 384 >> 2];
     if (($2 | 0) == HEAP32[$4 >> 2]) {
      continue
     }
     $2 = HEAP32[$2 + 64 >> 2];
     if ($2 & 8) {
      break label$2
     }
     if ($2 & 4) {
      continue
     }
     if (HEAP32[$1 + 236 >> 2] != ($1 + 236 | 0)) {
      break label$2
     }
     if (HEAPU8[$1 + -336 | 0] & 4) {
      continue
     }
     break;
    };
   }
   return 0;
  }
  return 1;
 }

 function mark_oom_victim($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0;
  $1 = HEAP32[$0 + 356 >> 2];
  $3 = global$0 - 16 | 0;
  $4 = HEAP32[$0 + 4 >> 2];
  $2 = HEAP32[$4 >> 2];
  HEAP32[$3 + 12 >> 2] = $2;
  label$1 : {
   if (HEAP32[$3 + 12 >> 2] & 65536) {
    break label$1
   }
   HEAP32[$4 >> 2] = $2 | 65536;
   if ($2 & 65536) {
    break label$1
   }
   $0 = HEAP32[$0 + 732 >> 2];
   if (!HEAP32[$0 + 368 >> 2]) {
    HEAP32[$0 + 368 >> 2] = $1;
    HEAP32[$1 + 44 >> 2] = HEAP32[$1 + 44 >> 2] + 1;
    HEAP32[$1 + 364 >> 2] = HEAP32[$1 + 364 >> 2] | 33554432;
   }
   HEAP32[20715] = HEAP32[20715] + 1;
  }
 }

 function wake_oom_reaper($0) {
  if (!(HEAP32[$0 + 884 >> 2] ? 0 : ($0 | 0) != HEAP32[20719])) {
   return
  }
  HEAP32[$0 + 8 >> 2] = HEAP32[$0 + 8 >> 2] + 1;
  HEAP32[$0 + 884 >> 2] = HEAP32[20719];
  HEAP32[20719] = $0;
  __wake_up(17052, 3, 0);
 }

 function dump_header($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0, $15 = 0;
  $1 = global$0 - 80 | 0;
  global$0 = $1;
  $3 = HEAP32[$0 + 12 >> 2];
  $2 = HEAP32[$0 + 4 >> 2];
  $5 = HEAP32[$0 + 16 >> 2];
  $4 = HEAP32[2];
  HEAP32[$1 + 72 >> 2] = HEAP16[HEAP32[$4 + 732 >> 2] + 362 >> 1];
  HEAP32[$1 + 68 >> 2] = $5;
  HEAP32[$1 - -64 >> 2] = $2;
  HEAP32[$1 + 60 >> 2] = ($2 | 0) != 0;
  HEAP32[$1 + 56 >> 2] = $0 + 12;
  HEAP32[$1 + 52 >> 2] = $3;
  HEAP32[$1 + 48 >> 2] = $4 + 700;
  printk(28781, $1 + 48 | 0);
  if (HEAP32[$0 + 16 >> 2]) {
   printk(28871, 0)
  }
  dump_stack();
  if (!HEAP32[$0 + 8 >> 2]) {
   show_mem(1, HEAP32[$0 + 4 >> 2])
  }
  label$3 : {
   if (!HEAP32[4255]) {
    break label$3
   }
   printk(28900, 0);
   printk(28941, 0);
   $8 = $1 + 28 | 0;
   $9 = $1 + 20 | 0;
   $10 = $1 + 24 | 0;
   $11 = $1 + 16 | 0;
   $3 = 1024;
   while (1) {
    $0 = HEAP32[$3 + 348 >> 2];
    $3 = $0 + -348 | 0;
    if (($3 | 0) == 1024) {
     break label$3
    }
    if (HEAPU8[$0 + -334 | 0] & 32 | HEAP32[$0 + 152 >> 2] == 1) {
     continue
    }
    $0 = find_lock_task_mm($3);
    if (!$0) {
     continue
    }
    $12 = HEAP32[$0 + 496 >> 2];
    $13 = HEAP32[$0 + 500 >> 2];
    $2 = HEAP32[$0 + 356 >> 2];
    $5 = HEAP32[$2 + 340 >> 2];
    $4 = HEAP32[$2 + 344 >> 2];
    $6 = HEAP32[$2 + 352 >> 2];
    $14 = HEAP32[$2 + 48 >> 2];
    $7 = HEAP32[$2 + 348 >> 2];
    $2 = HEAP32[$2 + 84 >> 2];
    $15 = HEAP16[HEAP32[$0 + 732 >> 2] + 362 >> 1];
    HEAP32[$1 + 32 >> 2] = $0 + 700;
    HEAP32[$8 >> 2] = $15;
    HEAP32[$9 >> 2] = $14;
    HEAP32[$1 + 4 >> 2] = 0;
    HEAP32[$10 >> 2] = ($7 | 0) > 0 ? $7 : 0;
    HEAP32[$11 >> 2] = ((($4 | 0) > 0 ? $4 : 0) + (($5 | 0) > 0 ? $5 : 0) | 0) + (($6 | 0) > 0 ? $6 : 0);
    HEAP32[$1 + 12 >> 2] = $2;
    HEAP32[$1 + 8 >> 2] = $13;
    HEAP32[$1 >> 2] = $12;
    printk(29027, $1);
    continue;
   };
  }
  global$0 = $1 + 80 | 0;
 }

 function oom_kill_process($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0;
  $4 = global$0 + -64 | 0;
  global$0 = $4;
  $3 = HEAP32[$0 + 28 >> 2];
  label$1 : {
   label$2 : {
    $2 = HEAP32[$0 + 24 >> 2];
    if (task_will_free_mem($2)) {
     mark_oom_victim($2);
     wake_oom_reaper($2);
     break label$2;
    }
    if (___ratelimit(17060, 28571)) {
     dump_header($0)
    }
    $6 = HEAP32[$2 + 496 >> 2];
    HEAP32[$4 + 60 >> 2] = $3;
    HEAP32[$4 + 56 >> 2] = $2 + 700;
    HEAP32[$4 + 52 >> 2] = $6;
    HEAP32[$4 + 48 >> 2] = $1;
    printk(28588, $4 + 48 | 0);
    $1 = HEAP32[$2 + 732 >> 2];
    $5 = $1 + 12 | 0;
    $3 = 0;
    $7 = $2 + 732 | 0;
    $9 = $2 + 356 | 0;
    $10 = $0 + 20 | 0;
    while (1) {
     $5 = HEAP32[$5 >> 2];
     if (!(($5 | 0) == ($1 + 12 | 0))) {
      $8 = $5 + -80 | 0;
      $1 = $8;
      while (1) {
       $1 = HEAP32[$1 >> 2];
       if (($1 | 0) != ($8 | 0)) {
        $0 = $1 + -520 | 0;
        if (process_shares_mm($0, HEAP32[$9 >> 2])) {
         continue
        }
        $6 = oom_badness($0, HEAP32[$10 >> 2]);
        if ($6 >>> 0 <= $3 >>> 0) {
         continue
        }
        $3 = HEAP32[$2 + 8 >> 2] + -1 | 0;
        HEAP32[$2 + 8 >> 2] = $3;
        if (!$3) {
         __put_task_struct($2)
        }
        $2 = $1 + -512 | 0;
        HEAP32[$2 >> 2] = HEAP32[$2 >> 2] + 1;
        $3 = $6;
        $2 = $0;
        continue;
       }
       break;
      };
      $1 = HEAP32[$7 >> 2];
      continue;
     }
     break;
    };
    $0 = find_lock_task_mm($2);
    if (!$0) {
     break label$2
    }
    label$11 : {
     if (($0 | 0) == ($2 | 0)) {
      $0 = $2;
      break label$11;
     }
     HEAP32[$0 + 8 >> 2] = HEAP32[$0 + 8 >> 2] + 1;
     $1 = HEAP32[$2 + 8 >> 2] + -1 | 0;
     HEAP32[$2 + 8 >> 2] = $1;
     if ($1) {
      break label$11
     }
     __put_task_struct($2);
    }
    $2 = HEAP32[$0 + 356 >> 2];
    HEAP32[$2 + 44 >> 2] = HEAP32[$2 + 44 >> 2] + 1;
    do_send_sig_info($0);
    mark_oom_victim($0);
    $5 = HEAP32[$0 + 496 >> 2];
    $1 = HEAP32[$0 + 356 >> 2];
    $3 = HEAP32[$1 + 344 >> 2];
    $6 = HEAP32[$1 + 352 >> 2];
    $7 = HEAP32[$1 + 84 >> 2];
    $1 = HEAP32[$1 + 340 >> 2];
    HEAP32[$4 + 32 >> 2] = (($1 | 0) > 0 ? $1 : 0) << 6;
    HEAP32[$4 + 36 >> 2] = (($6 | 0) > 0 ? $6 : 0) << 6;
    HEAP32[$4 + 24 >> 2] = $7 << 6;
    $7 = $0 + 700 | 0;
    HEAP32[$4 + 20 >> 2] = $7;
    HEAP32[$4 + 16 >> 2] = $5;
    HEAP32[$4 + 28 >> 2] = (($3 | 0) > 0 ? $3 : 0) << 6;
    printk(28644, $4 + 16 | 0);
    $9 = $0 + 732 | 0;
    $6 = $2 + 364 | 0;
    $10 = $0 + 496 | 0;
    $5 = 1;
    $1 = 1024;
    while (1) {
     $3 = HEAP32[$1 + 348 >> 2];
     $1 = $3 + -348 | 0;
     if (($1 | 0) != 1024) {
      if (!process_shares_mm($1, $2) | HEAP32[$3 + 384 >> 2] == HEAP32[$9 >> 2]) {
       continue
      }
      if (HEAP32[$3 + 152 >> 2] != 1) {
       if (HEAPU8[$3 + -334 | 0] & 32) {
        continue
       }
       do_send_sig_info($1);
       continue;
      } else {
       HEAP32[$6 >> 2] = HEAP32[$6 >> 2] | 2097152;
       $5 = HEAP32[$10 >> 2];
       $8 = HEAP32[$3 + 148 >> 2];
       HEAP32[$4 + 12 >> 2] = $3 + 352;
       HEAP32[$4 + 8 >> 2] = $8;
       HEAP32[$4 + 4 >> 2] = $7;
       HEAP32[$4 >> 2] = $5;
       printk(28734, $4);
       $5 = 0;
       continue;
      }
     }
     break;
    };
    if ($5) {
     wake_oom_reaper($0)
    }
    $3 = $2 + 44 | 0;
    $1 = HEAP32[$3 >> 2] + -1 | 0;
    HEAP32[$3 >> 2] = $1;
    if (!$1) {
     __mmdrop($2)
    }
    $1 = HEAP32[$0 + 8 >> 2] + -1 | 0;
    HEAP32[$0 + 8 >> 2] = $1;
    if ($1) {
     break label$1
    }
    __put_task_struct($0);
    break label$1;
   }
   $0 = HEAP32[$2 + 8 >> 2] + -1 | 0;
   HEAP32[$2 + 8 >> 2] = $0;
   if ($0) {
    break label$1
   }
   __put_task_struct($2);
  }
  global$0 = $4 - -64 | 0;
 }

 function __delete_from_page_cache($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0;
  $2 = global$0 - 48 | 0;
  global$0 = $2;
  $3 = HEAP32[$0 + 12 >> 2];
  unaccount_page_cache_page($3, $0);
  HEAP32[$2 + 24 >> 2] = $3 + 4;
  HEAP32[$2 + 44 >> 2] = 95;
  HEAP32[$2 + 36 >> 2] = 3;
  HEAP32[$2 + 40 >> 2] = 0;
  HEAP32[$2 + 32 >> 2] = 0;
  $4 = HEAP32[$0 + 16 >> 2];
  HEAP32[$2 + 28 >> 2] = $4;
  if (!(HEAPU8[$0 + 45 | 0] ? !!(HEAP32[$0 >> 2] & 65536) : 0)) {
   HEAP32[$2 + 36 >> 2] = 3;
   HEAP32[$2 + 28 >> 2] = $4;
   $4 = HEAP32[$0 >> 2] & 65536 ? HEAPU8[$0 + 45 | 0] : 0;
   xas_store($2 + 24 | 0, $1);
   xas_init_marks($2 + 24 | 0);
   HEAP32[$0 + 12 >> 2] = 0;
   $0 = 1 << $4;
   if ($1) {
    HEAP32[$3 + 44 >> 2] = $0 + HEAP32[$3 + 44 >> 2]
   }
   HEAP32[$3 + 40 >> 2] = HEAP32[$3 + 40 >> 2] - $0;
   global$0 = $2 + 48 | 0;
   return;
  }
  HEAP32[$2 + 8 >> 2] = 29271;
  HEAP32[$2 + 4 >> 2] = 1230;
  HEAP32[$2 >> 2] = 29215;
  printk(29080, $2);
  abort();
 }

 function unaccount_page_cache_page($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  $2 = HEAP32[$1 + 4 >> 2];
  if (HEAP32[($2 & 1 ? $2 + -1 | 0 : $1) >> 2] & 4) {
   $2 = HEAP32[$1 + 4 >> 2];
   $2 & 1 ? $2 + -1 | 0 : $1;
  }
  label$2 : {
   if (!page_mapped($1)) {
    break label$2
   }
   HEAP32[$3 >> 2] = HEAP32[2] + 700;
   HEAP32[$3 + 4 >> 2] = ($1 - HEAP32[20650] | 0) / 36;
   printk(29141, $3);
   __dump_page($1, 29189);
   dump_stack();
   add_taint(5, 1);
   if (HEAP32[$1 >> 2] & 65536 | HEAP32[$1 + 4 >> 2] & 1) {
    $2 = __page_mapcount($1)
   } else {
    $2 = HEAP32[$1 + 24 >> 2] + 1 | 0
   }
   if (!(HEAP32[$0 + 56 >> 2] & 16)) {
    break label$2
   }
   $4 = HEAP32[$1 + 4 >> 2];
   if (HEAP32[($4 & 1 ? $4 + -1 | 0 : $1) + 28 >> 2] < ($2 + 2 | 0)) {
    break label$2
   }
   HEAP32[$1 + 24 >> 2] = -1;
   HEAP32[$1 + 28 >> 2] = HEAP32[$1 + 28 >> 2] - $2;
  }
  HEAP32[35606] = HEAP32[35606] + -1;
  HEAP32[20688] = HEAP32[20688] + -1;
  $2 = $1 + 4 | 0;
  $4 = HEAP32[$2 >> 2];
  if (HEAP32[($4 & 1 ? $4 + -1 | 0 : $1) >> 2] & 524288) {
   HEAP32[35610] = HEAP32[35610] + -1;
   HEAP32[20692] = HEAP32[20692] + -1;
  }
  $2 = HEAP32[$2 >> 2];
  if (HEAP32[($2 & 1 ? $2 + -1 | 0 : $1) >> 2] & 8) {
   $2 = $0;
   $0 = HEAP32[$0 >> 2];
   label$7 : {
    if ($0) {
     $0 = HEAP32[HEAP32[$0 + 20 >> 2] + 108 >> 2];
     break label$7;
    }
    $0 = 16192;
   }
   account_page_cleaned($1, $2, $0 + 56 | 0);
  }
  global$0 = $3 + 16 | 0;
 }

 function wake_page_function($0, $1, $2, $3) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  $3 = $3 | 0;
  var $4 = 0, $5 = 0, $6 = 0;
  label$1 : {
   $5 = HEAP32[$0 + -8 >> 2];
   label$2 : {
    if (($5 | 0) != HEAP32[$3 >> 2]) {
     break label$2
    }
    HEAP32[$3 + 8 >> 2] = 1;
    $4 = HEAP32[$0 + -4 >> 2];
    if (($4 | 0) != HEAP32[$3 + 4 >> 2]) {
     break label$2
    }
    $6 = -1;
    if (!(HEAP32[(($4 | 0) / 32 << 2) + $5 >> 2] & 1 << ($4 & 31))) {
     break label$1
    }
   }
   return $6 | 0;
  }
  return autoremove_wake_function($0, $1, $2, $3) | 0;
 }

 function unlock_page($0) {
  var $1 = 0;
  $1 = HEAP32[$0 + 4 >> 2];
  $0 = $1 & 1 ? $1 + -1 | 0 : $0;
  $1 = HEAP32[$0 >> 2];
  HEAP32[$0 >> 2] = $1 & -2;
  if ($1 & 128) {
   wake_up_page_bit($0)
  }
 }

 function wake_up_page_bit($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0;
  $1 = global$0 - 48 | 0;
  global$0 = $1;
  $2 = $1 + 20 | 0;
  HEAP32[$1 + 24 >> 2] = $2;
  HEAP32[$1 + 40 >> 2] = 0;
  HEAP32[$1 + 36 >> 2] = 0;
  HEAP32[$1 + 32 >> 2] = $0;
  HEAP32[$1 + 20 >> 2] = $2;
  HEAP32[$1 + 16 >> 2] = 0;
  HEAP32[$1 + 8 >> 2] = 0;
  HEAP32[$1 + 12 >> 2] = 0;
  $2 = HEAP32[20720];
  HEAP32[20720] = 0;
  $3 = Math_imul($0, 1640531527) >>> 24 | 0;
  $4 = ($3 << 3) + 17152 | 0;
  __wake_up_locked_key_bookmark($4, $1 + 32 | 0, $1 + 8 | 0);
  while (1) {
   if (HEAPU8[$1 + 8 | 0] & 4) {
    HEAP32[20720] = $2;
    $2 = HEAP32[20720];
    HEAP32[20720] = 0;
    __wake_up_locked_key_bookmark($4, $1 + 32 | 0, $1 + 8 | 0);
    continue;
   }
   break;
  };
  $3 = ($3 << 3) + 17152 | 0;
  if (!(HEAP32[$1 + 40 >> 2] ? HEAP32[$3 >> 2] != ($3 | 0) : 0)) {
   HEAP32[$0 >> 2] = HEAP32[$0 >> 2] & -129
  }
  HEAP32[20720] = $2;
  global$0 = $1 + 48 | 0;
 }

 function __lock_page($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0;
  $2 = global$0 - 32 | 0;
  global$0 = $2;
  $1 = HEAP32[$0 + 4 >> 2];
  $0 = $1 & 1 ? $1 + -1 | 0 : $0;
  $4 = Math_imul($0, 1640531527) >>> 24 | 0;
  $1 = HEAP32[$0 + 4 >> 2];
  label$1 : {
   if (!(HEAP32[($1 & 1 ? $1 + -1 | 0 : $0) >> 2] & 4)) {
    $1 = HEAP32[$0 + 4 >> 2];
    $5 = 0;
    if (!(HEAP32[($1 & 1 ? $1 + -1 | 0 : $0) >> 2] & 64)) {
     break label$1
    }
    $1 = HEAP32[$0 + 4 >> 2];
    $1 & 1 ? $1 + -1 | 0 : $0;
    $5 = 1;
    break label$1;
   }
   $5 = 0;
  }
  $7 = $2 + 8 | 0;
  HEAP32[$2 + 12 >> 2] = HEAP32[2];
  $6 = $2 + 24 | 0;
  $1 = $2 + 20 | 0;
  HEAP32[$6 >> 2] = $1;
  HEAP32[$2 + 16 >> 2] = 96;
  HEAP32[$2 + 4 >> 2] = 0;
  HEAP32[$2 + 8 >> 2] = 1;
  HEAP32[$2 >> 2] = $0;
  HEAP32[$1 >> 2] = $1;
  $3 = $4 << 3;
  $4 = $3 + 17156 | 0;
  $8 = $3 + 17152 | 0;
  while (1) {
   HEAP32[20720] = 0;
   if (HEAP32[$1 >> 2] == ($1 | 0)) {
    $3 = HEAP32[$4 >> 2];
    HEAP32[$3 >> 2] = $1;
    HEAP32[$6 >> 2] = $3;
    HEAP32[$1 >> 2] = $8;
    HEAP32[$4 >> 2] = $1;
    HEAP32[$0 >> 2] = HEAP32[$0 >> 2] | 128;
   }
   HEAP32[$2 + 28 >> 2] = 2;
   HEAP32[HEAP32[2] >> 2] = 2;
   HEAP32[20720] = 1;
   if (HEAP32[$0 >> 2] & 1) {
    $3 = io_schedule_prepare();
    schedule();
    io_schedule_finish($3);
   }
   $3 = HEAP32[$0 >> 2];
   HEAP32[$2 + 28 >> 2] = $3;
   if (HEAP32[$2 + 28 >> 2] & 1) {
    continue
   }
   HEAP32[$0 >> 2] = $3 | 1;
   if ($3 & 1) {
    continue
   }
   break;
  };
  finish_wait($7);
  if ($5) {
   $1 = HEAP32[$0 + 4 >> 2];
   $1 & 1 ? $1 + -1 | 0 : $0;
  }
  global$0 = $2 + 32 | 0;
 }

 function try_to_release_page($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0;
  $2 = global$0 - 16 | 0;
  global$0 = $2;
  $4 = HEAP32[$0 + 12 >> 2];
  $3 = HEAP32[$0 + 4 >> 2];
  if (HEAP32[($3 & 1 ? $3 + -1 | 0 : $0) >> 2] & 1) {
   $3 = 0;
   $5 = HEAP32[$0 + 4 >> 2];
   label$2 : {
    if (HEAP32[($5 & 1 ? $5 + -1 | 0 : $0) >> 2] & 32768) {
     break label$2
    }
    $3 = 1;
    if (!$4) {
     break label$2
    }
    $4 = HEAP32[HEAP32[$4 + 52 >> 2] + 36 >> 2];
    if (!$4) {
     break label$2
    }
    $3 = FUNCTION_TABLE[$4]($0, $1) | 0;
   }
   global$0 = $2 + 16 | 0;
   return $3;
  }
  HEAP32[$2 + 8 >> 2] = 29121;
  HEAP32[$2 + 4 >> 2] = 3323;
  HEAP32[$2 >> 2] = 29111;
  printk(29080, $2);
  abort();
 }

 function wb_wakeup($0) {
  var $1 = 0;
  $1 = global$0 - 16 | 0;
  global$0 = $1;
  if (HEAP32[$0 + 4 >> 2] & 1) {
   mod_delayed_work_on(HEAP32[20655], $0 + 144 | 0)
  }
  printk(29285, 0);
  HEAP32[$1 + 8 >> 2] = 29422;
  HEAP32[$1 + 4 >> 2] = 382;
  HEAP32[$1 >> 2] = 29364;
  printk(29333, $1);
  abort();
 }

 function __wakeup_flusher_threads_bdi($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0;
  $1 = global$0 - 16 | 0;
  global$0 = $1;
  label$1 : {
   if (!HEAP32[$0 + 48 >> 2]) {
    break label$1
   }
   $4 = $0 + 256 | 0;
   $0 = $4;
   while (1) {
    $0 = HEAP32[$0 >> 2];
    if (($4 | 0) == ($0 | 0)) {
     break label$1
    }
    $2 = $0 + -188 | 0;
    if (!(HEAP32[$2 >> 2] & 4) | HEAP32[$2 >> 2] & 8) {
     continue
    }
    $3 = HEAP32[$2 >> 2];
    HEAP32[$1 + 12 >> 2] = $3;
    if (HEAP32[$1 + 12 >> 2] & 8) {
     continue
    }
    HEAP32[$2 >> 2] = $3 | 8;
    if ($3 & 8) {
     continue
    }
    break;
   };
   HEAP32[$0 + -60 >> 2] = 1;
   wb_wakeup($0 + -192 | 0);
   abort();
  }
  global$0 = $1 + 16 | 0;
 }

 function sys_m_read($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  return sys_read_3($0, $1, $2) | 0;
 }

 function sys_read_3($0, $1, $2) {
  var $3 = 0, $4 = 0;
  $3 = global$0;
  $2 = $3 - ($2 + 15 & -16) | 0;
  global$0 = $2;
  $4 = $2;
  if ($0) {
   $0 = -9
  } else {
   $0 = read0_evt($2)
  }
  kmem(1, $1 | 0, $4 | 0, $0 | 0) | 0;
  global$0 = $3;
  return $0;
 }

 function sys_m_writev($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  return sys_writev_3($0, $1, $2) | 0;
 }

 function sys_writev_3($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  $4 = global$0 - 256 | 0;
  global$0 = $4;
  $3 = $2 << 3;
  $5 = $4 - ($3 + 15 & -16) | 0;
  global$0 = $5;
  umem(1, $5 | 0, $1 | 0, $3 | 0) | 0;
  $1 = $4;
  $3 = $5;
  $6 = $2;
  while (1) {
   if ($6) {
    $7 = HEAP32[$3 + 4 >> 2];
    umem(1, $1 | 0, HEAP32[$3 >> 2], $7 | 0) | 0;
    HEAP32[$3 >> 2] = $1;
    $3 = $3 + 8 | 0;
    $6 = $6 + -1 | 0;
    $1 = $1 + $7 | 0;
    continue;
   }
   break;
  };
  $0 = writev($0, $5, $2);
  global$0 = $4 + 256 | 0;
  return $0;
 }

 function read0_evt($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  $2 = HEAP32[7796];
  $1 = HEAP32[$2 + 128 >> 2];
  while (1) {
   $3 = HEAP32[$1 >> 2];
   if (!($3 | HEAP32[$1 + 4 >> 2])) {
    do_events();
    continue;
   }
   break;
  };
  memcpy($0, (HEAP32[$2 + 56 >> 2] + $1 | 0) + 8 | 0, $3);
  HEAP32[$1 >> 2] = 0;
  HEAP32[$1 + 4 >> 2] = 0;
  $0 = HEAP32[$2 + 60 >> 2] + ($3 >> 31) | 0;
  $1 = HEAP32[$2 + 56 >> 2] + $3 | 0;
  HEAP32[$2 + 56 >> 2] = $1;
  HEAP32[$2 + 60 >> 2] = $1 >>> 0 < $3 >>> 0 ? $0 + 1 | 0 : $0;
  return $3;
 }

 function write($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0;
  label$1 : {
   label$2 : {
    if (($0 | 0) != 1) {
     $3 = -9;
     if ($0) {
      break label$1
     }
     $3 = HEAP32[7796];
     $0 = HEAP32[$3 + 128 >> 2];
     memcpy(($0 + HEAP32[$3 + 56 >> 2] | 0) + 8 | 0, $1, $2);
     $3 = HEAP32[$0 + 4 >> 2];
     $1 = $2 + HEAP32[$0 >> 2] | 0;
     if ($1 >>> 0 < $2 >>> 0) {
      $3 = $3 + 1 | 0
     }
     HEAP32[$0 >> 2] = $1;
     HEAP32[$0 + 4 >> 2] = $3;
     break label$2;
    }
    $3 = HEAP32[7797];
    $5 = HEAP32[$3 + 128 >> 2];
    memcpy($5 + HEAP32[$3 + 56 >> 2] | 0, $1, $2);
    $0 = HEAP32[$3 + 60 >> 2];
    $4 = $2 + HEAP32[$3 + 56 >> 2] | 0;
    if ($4 >>> 0 < $2 >>> 0) {
     $0 = $0 + 1 | 0
    }
    HEAP32[$3 + 56 >> 2] = $4;
    HEAP32[$3 + 60 >> 2] = $0;
    if (HEAPU8[($1 + $2 | 0) + -1 | 0] != 10) {
     break label$2
    }
    flush($5 | 0, $4 | 0);
    $0 = $3 + 56 | 0;
    HEAP32[$0 >> 2] = 0;
    HEAP32[$0 + 4 >> 2] = 0;
   }
   $3 = $2;
  }
  return $3;
 }

 function writev($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0;
  $5 = ($2 << 3) + $1 | 0;
  $2 = 0;
  label$1 : {
   label$2 : {
    while (1) {
     if ($1 >>> 0 >= $5 >>> 0) {
      break label$1
     }
     $4 = HEAP32[$1 + 4 >> 2];
     $3 = write($0, HEAP32[$1 >> 2], $4);
     if (($3 | 0) >= 0) {
      if ($3 >>> 0 < $4 >>> 0) {
       break label$2
      }
      $1 = $1 + 8 | 0;
      $2 = $2 + $4 | 0;
      continue;
     }
     break;
    };
    return $3;
   }
   $2 = $2 + $3 | 0;
  }
  return $2;
 }

 function do_shutdown() {
  var $0 = 0;
  $0 = global$0 - 16 | 0;
  global$0 = $0;
  emem($0 + 15 | 0, 1);
  js_shutdown(HEAPU8[$0 + 15 | 0]);
  global$0 = $0 + 16 | 0;
 }

 function emem($0, $1) {
  var wasm2js_i32$0 = 0, wasm2js_i32$1 = 0;
  (wasm2js_i32$0 = 19424, wasm2js_i32$1 = (js_emem(HEAP32[4856], $0 | 0, $1 | 0) | 0) + HEAP32[4856] | 0), HEAP32[wasm2js_i32$0 >> 2] = wasm2js_i32$1;
 }

 function do_events() {
  var $0 = 0, $1 = 0, $2 = 0;
  $0 = global$0 - 16 | 0;
  global$0 = $0;
  $1 = evt_count(100) | 0;
  while (1) {
   if (!(($2 | 0) >= ($1 | 0))) {
    emem($0 + 15 | 0, 1);
    FUNCTION_TABLE[HEAP32[(HEAPU8[$0 + 15 | 0] << 2) + 29440 >> 2]]();
    $2 = $2 + 1 | 0;
    continue;
   }
   break;
  };
  global$0 = $0 + 16 | 0;
  return $1;
 }

 function evt_loop() {
  while (1) {
   if (!do_events()) {
    continue
   }
   break;
  };
 }

 function do_write() {
  var $0 = 0, $1 = 0;
  $0 = global$0 - 256 | 0;
  global$0 = $0;
  $1 = tty_read($0 | 0, 256) | 0;
  if (($1 | 0) >= 1) {
   write(0, $0, $1)
  }
  global$0 = $0 + 256 | 0;
 }

 function do_run() {
  var $0 = 0;
  $0 = global$0 - 272 | 0;
  global$0 = $0;
  emem($0 + 271 | 0, 1);
  emem($0, HEAPU8[$0 + 271 | 0]);
  js_run($0 | 0, (HEAPU8[$0 + 271 | 0] + 1 & 255) + -1 | 0);
  global$0 = $0 + 272 | 0;
 }

 function sys_m_ioctl($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  sys_ioctl_3($0, $1, $2);
  return 0;
 }

 function sys_ioctl_3($0, $1, $2) {
  var $3 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  HEAP32[$3 + 12 >> 2] = $2;
  HEAP32[$3 + 8 >> 2] = $1;
  HEAP32[$3 + 4 >> 2] = $0;
  HEAP32[$3 >> 2] = 3;
  printk(29468, $3);
  global$0 = $3 + 16 | 0;
 }

 function __syscall0($0) {
  $0 = $0 | 0;
  var $1 = 0, $2 = 0;
  $1 = global$0 - 16 | 0;
  global$0 = $1;
  $2 = HEAP32[($0 << 2) + 29504 >> 2];
  label$1 : {
   if (($2 | 0) != 100) {
    $0 = FUNCTION_TABLE[$2]() | 0;
    break label$1;
   }
   HEAP32[$1 + 4 >> 2] = $0;
   HEAP32[$1 >> 2] = 0;
   printk(30684, $1);
   $0 = -38;
  }
  global$0 = $1 + 16 | 0;
  return $0 | 0;
 }

 function __syscall1($0, $1) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  var $2 = 0, $3 = 0;
  $2 = global$0 - 16 | 0;
  global$0 = $2;
  $3 = HEAP32[($0 << 2) + 29504 >> 2];
  label$1 : {
   if (($3 | 0) != 100) {
    $0 = FUNCTION_TABLE[$3]($1) | 0;
    break label$1;
   }
   HEAP32[$2 + 8 >> 2] = $1;
   HEAP32[$2 + 4 >> 2] = $0;
   HEAP32[$2 >> 2] = 1;
   printk(30710, $2);
   $0 = -38;
  }
  global$0 = $2 + 16 | 0;
  return $0 | 0;
 }

 function __syscall2($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0, $4 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  $4 = HEAP32[($0 << 2) + 29504 >> 2];
  label$1 : {
   if (($4 | 0) != 100) {
    $0 = FUNCTION_TABLE[$4]($1, $2) | 0;
    break label$1;
   }
   HEAP32[$3 + 12 >> 2] = $2;
   HEAP32[$3 + 8 >> 2] = $1;
   HEAP32[$3 + 4 >> 2] = $0;
   HEAP32[$3 >> 2] = 2;
   printk(30739, $3);
   $0 = -38;
  }
  global$0 = $3 + 16 | 0;
  return $0 | 0;
 }

 function __syscall3($0, $1, $2, $3) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  $3 = $3 | 0;
  var $4 = 0, $5 = 0;
  $4 = global$0 - 32 | 0;
  global$0 = $4;
  $5 = HEAP32[($0 << 2) + 29504 >> 2];
  label$1 : {
   if (($5 | 0) != 100) {
    $0 = FUNCTION_TABLE[$5]($1, $2, $3) | 0;
    break label$1;
   }
   HEAP32[$4 + 16 >> 2] = $3;
   HEAP32[$4 + 12 >> 2] = $2;
   HEAP32[$4 + 8 >> 2] = $1;
   HEAP32[$4 + 4 >> 2] = $0;
   HEAP32[$4 >> 2] = 3;
   printk(30772, $4);
   $0 = -38;
  }
  global$0 = $4 + 32 | 0;
  return $0 | 0;
 }

 function __syscall4($0, $1, $2, $3, $4) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  $3 = $3 | 0;
  $4 = $4 | 0;
  var $5 = 0, $6 = 0;
  $5 = global$0 - 32 | 0;
  global$0 = $5;
  $6 = HEAP32[($0 << 2) + 29504 >> 2];
  label$1 : {
   if (($6 | 0) != 100) {
    $0 = FUNCTION_TABLE[$6]($1, $2, $3, $4) | 0;
    break label$1;
   }
   HEAP32[$5 + 20 >> 2] = $4;
   HEAP32[$5 + 16 >> 2] = $3;
   HEAP32[$5 + 12 >> 2] = $2;
   HEAP32[$5 + 8 >> 2] = $1;
   HEAP32[$5 + 4 >> 2] = $0;
   HEAP32[$5 >> 2] = 4;
   printk(30809, $5);
   $0 = -38;
  }
  global$0 = $5 + 32 | 0;
  return $0 | 0;
 }

 function __syscall5($0, $1, $2, $3, $4, $5) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  $3 = $3 | 0;
  $4 = $4 | 0;
  $5 = $5 | 0;
  var $6 = 0, $7 = 0;
  $6 = global$0 - 32 | 0;
  global$0 = $6;
  $7 = HEAP32[($0 << 2) + 29504 >> 2];
  label$1 : {
   if (($7 | 0) != 100) {
    $0 = FUNCTION_TABLE[$7]($1, $2, $3, $4, $5) | 0;
    break label$1;
   }
   HEAP32[$6 + 24 >> 2] = $5;
   HEAP32[$6 + 20 >> 2] = $4;
   HEAP32[$6 + 16 >> 2] = $3;
   HEAP32[$6 + 12 >> 2] = $2;
   HEAP32[$6 + 8 >> 2] = $1;
   HEAP32[$6 + 4 >> 2] = $0;
   HEAP32[$6 >> 2] = 5;
   printk(30850, $6);
   $0 = -38;
  }
  global$0 = $6 + 32 | 0;
  return $0 | 0;
 }

 function __syscall6($0, $1, $2, $3, $4, $5, $6) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  $3 = $3 | 0;
  $4 = $4 | 0;
  $5 = $5 | 0;
  $6 = $6 | 0;
  var $7 = 0, $8 = 0;
  $7 = global$0 - 32 | 0;
  global$0 = $7;
  $8 = HEAP32[($0 << 2) + 29504 >> 2];
  label$1 : {
   if (($8 | 0) != 100) {
    $0 = FUNCTION_TABLE[$8]($1, $2, $3, $4, $5, $6) | 0;
    break label$1;
   }
   HEAP32[$7 + 28 >> 2] = $6;
   HEAP32[$7 + 24 >> 2] = $5;
   HEAP32[$7 + 20 >> 2] = $4;
   HEAP32[$7 + 16 >> 2] = $3;
   HEAP32[$7 + 12 >> 2] = $2;
   HEAP32[$7 + 8 >> 2] = $1;
   HEAP32[$7 + 4 >> 2] = $0;
   HEAP32[$7 >> 2] = 6;
   printk(30895, $7);
   $0 = -38;
  }
  global$0 = $7 + 32 | 0;
  return $0 | 0;
 }

 function setup_processor() {
  var $0 = 0;
  $0 = global$0 - 16 | 0;
  global$0 = $0;
  HEAP32[$0 >> 2] = 31036;
  printk(31006, $0);
  arc_init_IRQ();
  arc_mmu_init();
  arc_cache_init();
  global$0 = $0 + 16 | 0;
 }

 function machine_halt() {
  var $0 = 0;
  $0 = global$0 - 16 | 0;
  global$0 = $0;
  HEAP32[$0 >> 2] = 31073;
  printk(31052, $0);
  global$0 = $0 + 16 | 0;
 }

 function machine_restart() {
  var $0 = 0;
  $0 = global$0 - 16 | 0;
  global$0 = $0;
  HEAP32[$0 >> 2] = 31116;
  printk(31086, $0);
  machine_halt();
  global$0 = $0 + 16 | 0;
 }

 function arc_init_IRQ() {
  var $0 = 0;
  $0 = global$0 - 16 | 0;
  global$0 = $0;
  HEAP32[$0 >> 2] = 31153;
  printk(31132, $0);
  global$0 = $0 + 16 | 0;
 }

 function setup_arch_memory() {
  var $0 = 0, $1 = 0, $2 = 0;
  $0 = global$0 - 48 | 0;
  global$0 = $0;
  HEAP32[3967] = 19448;
  HEAP32[3965] = 19436;
  HEAP32[3963] = 19428;
  HEAP32[3962] = 82980;
  HEAP32[$0 + 16 >> 2] = 19448;
  HEAP32[$0 + 12 >> 2] = 19436;
  HEAP32[$0 + 8 >> 2] = 19428;
  HEAP32[$0 + 4 >> 2] = 82980;
  HEAP32[$0 >> 2] = 31294;
  printk(31192, $0);
  $2 = HEAP32[21272];
  $1 = $2 + 65535 >>> 16 | 0;
  HEAP32[20637] = $1;
  HEAP32[20635] = $1;
  HEAP32[20648] = $1;
  HEAP32[20636] = 0;
  memblock_add_range(15692, 65535, $2);
  memblock_reserve(65535, -46087);
  if (HEAP32[20633]) {
   __memblock_dump_all()
  }
  memset($0 + 40 | 0, 0, 8);
  memset($0 + 32 | 0, 0, 8);
  HEAP32[$0 + 32 >> 2] = 0;
  $1 = HEAP32[20636];
  HEAP32[$0 + 40 >> 2] = HEAP32[20635] - $1;
  free_area_init_node($0 + 40 | 0, $1, $0 + 32 | 0);
  global$0 = $0 + 48 | 0;
 }

 function mem_init() {
  var $0 = 0;
  $0 = global$0 - 16 | 0;
  global$0 = $0;
  HEAP32[$0 >> 2] = 31328;
  printk(31312, $0);
  memblock_free_all();
  mem_init_print_info();
  global$0 = $0 + 16 | 0;
 }

 function arc_cache_mumbojumbo($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $1 = global$0 - 96 | 0;
  global$0 = $1;
  $2 = HEAP32[20724];
  $3 = $2 >>> 14 & 255;
  label$1 : {
   if ($3) {
    HEAP32[$1 + 84 >> 2] = 31419;
    HEAP32[$1 + 80 >> 2] = $2 & 67108864 ? 31408 : 31418;
    HEAP32[$1 + 72 >> 2] = $3;
    HEAP32[$1 + 64 >> 2] = $2 & 16383;
    HEAP32[$1 + 76 >> 2] = $2 & 134217728 ? 31398 : 31403;
    HEAP32[$1 + 68 >> 2] = $2 >>> 22 & 15;
    $3 = scnprintf($0, 256, 31353, $1 - -64 | 0);
    break label$1;
   }
   $3 = scnprintf($0, 256, 31337, 0);
  }
  $4 = 256 - $3 | 0;
  $5 = $0 + $3 | 0;
  $2 = HEAP32[20725];
  $6 = $2 >>> 14 & 255;
  label$3 : {
   if ($6) {
    HEAP32[$1 + 52 >> 2] = 31419;
    HEAP32[$1 + 48 >> 2] = $2 & 67108864 ? 31408 : 31418;
    HEAP32[$1 + 40 >> 2] = $6;
    HEAP32[$1 + 32 >> 2] = $2 & 16383;
    HEAP32[$1 + 44 >> 2] = $2 & 134217728 ? 31398 : 31403;
    HEAP32[$1 + 36 >> 2] = $2 >>> 22 & 15;
    $2 = scnprintf($5, $4, 31447, $1 + 32 | 0);
    break label$3;
   }
   $2 = scnprintf($5, $4, 31431, 0);
  }
  $2 = $2 + $3 | 0;
  $3 = HEAP32[20726];
  $4 = $3 >>> 14 & 255;
  if ($4) {
   HEAP32[$1 + 20 >> 2] = $4;
   HEAP32[$1 + 16 >> 2] = $3 & 16383;
   HEAP32[$1 + 24 >> 2] = HEAP32[4940] ? 31418 : 31419;
   $2 = scnprintf($0 + $2 | 0, 256 - $2 | 0, 31492, $1 + 16 | 0) + $2 | 0;
  }
  HEAP32[$1 + 8 >> 2] = 31418;
  HEAP32[$1 + 4 >> 2] = 31418;
  HEAP32[$1 >> 2] = HEAP32[4941];
  scnprintf($0 + $2 | 0, 256 - $2 | 0, 31516, $1);
  global$0 = $1 + 96 | 0;
  return $0;
 }

 function arc_cache_init() {
  var $0 = 0, wasm2js_i32$0 = 0, wasm2js_i32$1 = 0;
  $0 = global$0 - 272 | 0;
  global$0 = $0;
  (wasm2js_i32$0 = $0, wasm2js_i32$1 = arc_cache_mumbojumbo($0 + 16 | 0)), HEAP32[wasm2js_i32$0 >> 2] = wasm2js_i32$1;
  printk(31540, $0);
  HEAP32[34817] = 104;
  HEAP32[34816] = 105;
  HEAP32[34818] = 106;
  global$0 = $0 + 272 | 0;
 }

 function local_flush_tlb_all() {
  utlb_invalidate();
  abort();
 }

 function utlb_invalidate() {
  var $0 = 0;
  $0 = global$0 - 16 | 0;
  global$0 = $0;
  HEAP32[$0 >> 2] = 31600;
  panic(31578, $0);
  abort();
 }

 function local_flush_tlb_kernel_range($0, $1) {
  if ($1 - $0 >>> 0 < 2097152) {
   $0 = ($0 & -65536) + -65536 | 0;
   while (1) {
    $0 = $0 + 65536 | 0;
    if ($0 >>> 0 < $1 >>> 0) {
     continue
    }
    break;
   };
   utlb_invalidate();
   abort();
  }
  local_flush_tlb_all();
  abort();
 }

 function local_flush_tlb_page($0) {
  if (!HEAP32[HEAP32[$0 + 32 >> 2] + 360 >> 2]) {
   return
  }
  utlb_invalidate();
  abort();
 }

 function arc_mmu_init() {
  var $0 = 0;
  $0 = global$0 - 16 | 0;
  global$0 = $0;
  HEAP32[$0 >> 2] = 31565;
  printk(31545, $0);
  global$0 = $0 + 16 | 0;
 }

 function hex_dump_to_buffer($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0;
  $5 = global$0 - 48 | 0;
  global$0 = $5;
  $8 = 32 < $1 >>> 0 ? 32 : $1;
  $1 = $8 & 3 ? 1 : 4;
  $7 = ($8 >>> 0) / ($1 >>> 0) | 0;
  label$2 : {
   label$4 : {
    label$5 : {
     if (!$8) {
      break label$5
     }
     label$7 : {
      label$9 : {
       if (($1 | 0) != 2) {
        if (($1 | 0) == 4) {
         break label$9
        }
        if (($1 | 0) != 8) {
         break label$7
        }
        $1 = $0;
        while (1) {
         if (($4 | 0) >= ($7 | 0)) {
          break label$5
         }
         $0 = HEAPU8[$1 + 4 | 0] | HEAPU8[$1 + 5 | 0] << 8 | (HEAPU8[$1 + 6 | 0] << 16 | HEAPU8[$1 + 7 | 0] << 24);
         HEAP32[$5 + 8 >> 2] = HEAPU8[$1 | 0] | HEAPU8[$1 + 1 | 0] << 8 | (HEAPU8[$1 + 2 | 0] << 16 | HEAPU8[$1 + 3 | 0] << 24);
         HEAP32[$5 + 12 >> 2] = $0;
         HEAP32[$5 >> 2] = $4 ? 31677 : 31679;
         $0 = 131 - $3 | 0;
         $6 = snprintf($2 + $3 | 0, $0, 31665, $5);
         if ($6 >>> 0 >= $0 >>> 0) {
          break label$2
         }
         $1 = $1 + 8 | 0;
         $4 = $4 + 1 | 0;
         $3 = $3 + $6 | 0;
         continue;
        };
       }
       $1 = $0;
       while (1) {
        if (($4 | 0) >= ($7 | 0)) {
         break label$5
        }
        HEAP32[$5 + 36 >> 2] = HEAPU8[$1 | 0] | HEAPU8[$1 + 1 | 0] << 8;
        HEAP32[$5 + 32 >> 2] = $4 ? 31677 : 31679;
        $0 = 131 - $3 | 0;
        $6 = snprintf($2 + $3 | 0, $0, 31688, $5 + 32 | 0);
        if ($6 >>> 0 >= $0 >>> 0) {
         break label$2
        }
        $1 = $1 + 2 | 0;
        $4 = $4 + 1 | 0;
        $3 = $3 + $6 | 0;
        continue;
       };
      }
      $1 = $0;
      while (1) {
       if (($4 | 0) >= ($7 | 0)) {
        break label$5
       }
       HEAP32[$5 + 20 >> 2] = HEAPU8[$1 | 0] | HEAPU8[$1 + 1 | 0] << 8 | (HEAPU8[$1 + 2 | 0] << 16 | HEAPU8[$1 + 3 | 0] << 24);
       HEAP32[$5 + 16 >> 2] = $4 ? 31677 : 31679;
       $0 = 131 - $3 | 0;
       $6 = snprintf($2 + $3 | 0, $0, 31680, $5 + 16 | 0);
       if ($6 >>> 0 >= $0 >>> 0) {
        break label$2
       }
       $1 = $1 + 4 | 0;
       $4 = $4 + 1 | 0;
       $3 = $3 + $6 | 0;
       continue;
      };
     }
     label$14 : {
      label$15 : {
       while (1) {
        if ($4 >>> 0 < $8 >>> 0) {
         $1 = $3 + 2 | 0;
         if ($1 >>> 0 > 131) {
          break label$15
         }
         $7 = $2 + $3 | 0;
         $9 = HEAPU8[$0 + $4 | 0];
         HEAP8[$7 | 0] = HEAPU8[($9 >>> 4 | 0) + 31616 | 0];
         $6 = $3 + 3 | 0;
         if ($6 >>> 0 > 131) {
          break label$14
         }
         HEAP8[$7 + 1 | 0] = HEAPU8[($9 & 15) + 31616 | 0];
         if ($3 + 4 >>> 0 > 131) {
          break label$4
         }
         HEAP8[$7 + 2 | 0] = 32;
         $4 = $4 + 1 | 0;
         $3 = $6;
         continue;
        }
        break;
       };
       $3 = $3 - (($3 | 0) != 0) | 0;
       break label$5;
      }
      $1 = $3;
      break label$4;
     }
     $1 = $3 + 1 | 0;
     break label$4;
    }
    HEAP8[$2 + $3 | 0] = 0;
    break label$2;
   }
   HEAP8[$1 + $2 | 0] = 0;
  }
  global$0 = $5 + 48 | 0;
 }

 function print_hex_dump($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  $1 = global$0 - 192 | 0;
  global$0 = $1;
  $2 = 36;
  while (1) {
   if ($3 >>> 0 < 36) {
    hex_dump_to_buffer($0 + $3 | 0, ($2 | 0) < 32 ? $2 : 32, $1 + 48 | 0);
    HEAP32[$1 + 4 >> 2] = 26109;
    HEAP32[$1 >> 2] = 26106;
    HEAP32[$1 + 8 >> 2] = $1 + 48;
    printk(31722, $1);
    $2 = $2 - 32 | 0;
    $3 = $3 + 32 | 0;
    continue;
   }
   break;
  };
  global$0 = $1 + 192 | 0;
 }

 function string_escape_mem($0, $1, $2, $3, $4) {
  var $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0;
  $6 = $2 + $3 | 0;
  $7 = $4 & 32;
  $8 = $4 & 8;
  $9 = $4 & 4;
  $10 = $4 & 2;
  $11 = $4 & 1;
  $12 = $4 & 16;
  $4 = $2;
  while (1) {
   if ($1) {
    label$5 : {
     label$6 : {
      label$7 : {
       label$8 : {
        label$9 : {
         label$10 : {
          label$11 : {
           label$12 : {
            $3 = HEAPU8[$0 | 0];
            if (!(HEAPU8[$3 + 31824 | 0] & 151 ? $12 : 0)) {
             label$16 : {
              if (!$11) {
               break label$16
              }
              $5 = $3 + -9 | 0;
              if (($5 & 255) >>> 0 > 4) {
               break label$16
              }
              if ($6 >>> 0 > $4 >>> 0) {
               HEAP8[$4 | 0] = 92
              }
              $3 = $4 + 1 | 0;
              if ($3 >>> 0 >= $6 >>> 0) {
               break label$6
              }
              $13 = $3;
              $5 = ($5 & 255) << 3;
              $3 = $5 & 31;
              HEAP8[$13 | 0] = 32 <= ($5 & 63) >>> 0 ? 114 >>> $3 | 0 : ((1 << $3) - 1 & 114) << 32 - $3 | 1719037556 >>> $3;
              break label$6;
             }
             label$18 : {
              if (!$10) {
               break label$18
              }
              if (($3 | 0) == 92) {
               break label$8
              }
              if (($3 | 0) == 27) {
               break label$9
              }
              if (($3 | 0) != 7) {
               break label$18
              }
              $3 = 97;
              break label$8;
             }
             if ($3 ? 0 : $9) {
              break label$7
             }
             if ($8) {
              break label$12
             }
             if ($7) {
              break label$11
             }
            }
            if ($6 >>> 0 > $4 >>> 0) {
             HEAP8[$4 | 0] = $3
            }
            $4 = $4 + 1 | 0;
            break label$5;
           }
           if ($6 >>> 0 > $4 >>> 0) {
            HEAP8[$4 | 0] = 92
           }
           $5 = $4 + 1 | 0;
           if ($5 >>> 0 < $6 >>> 0) {
            HEAP8[$5 | 0] = $3 >>> 6 | 48
           }
           $5 = $4 + 2 | 0;
           if ($5 >>> 0 < $6 >>> 0) {
            HEAP8[$5 | 0] = $3 >>> 3 & 7 | 48
           }
           $5 = $4 + 3 | 0;
           if ($5 >>> 0 >= $6 >>> 0) {
            break label$10
           }
           HEAP8[$5 | 0] = $3 & 7 | 48;
           break label$10;
          }
          if ($6 >>> 0 > $4 >>> 0) {
           HEAP8[$4 | 0] = 92
          }
          $5 = $4 + 1 | 0;
          if ($5 >>> 0 < $6 >>> 0) {
           HEAP8[$5 | 0] = 120
          }
          $5 = $4 + 2 | 0;
          if ($5 >>> 0 < $6 >>> 0) {
           HEAP8[$5 | 0] = HEAPU8[($3 >>> 4 | 0) + 31616 | 0]
          }
          $5 = $4 + 3 | 0;
          if ($5 >>> 0 >= $6 >>> 0) {
           break label$10
          }
          HEAP8[$5 | 0] = HEAPU8[($3 & 15) + 31616 | 0];
         }
         $4 = $4 + 4 | 0;
         break label$5;
        }
        $3 = 101;
       }
       if ($6 >>> 0 > $4 >>> 0) {
        HEAP8[$4 | 0] = 92
       }
       $5 = $4 + 1 | 0;
       if ($5 >>> 0 >= $6 >>> 0) {
        break label$6
       }
       HEAP8[$5 | 0] = $3;
       break label$6;
      }
      if ($6 >>> 0 > $4 >>> 0) {
       HEAP8[$4 | 0] = 92
      }
      $3 = $4 + 1 | 0;
      if ($3 >>> 0 >= $6 >>> 0) {
       break label$6
      }
      HEAP8[$3 | 0] = 48;
     }
     $4 = $4 + 2 | 0;
    }
    $1 = $1 + -1 | 0;
    $0 = $0 + 1 | 0;
    continue;
   }
   break;
  };
  return $4 - $2 | 0;
 }

 function errseq_set($0, $1) {
  var $2 = 0;
  $2 = HEAP32[$0 >> 2];
  label$1 : {
   if (!$1) {
    break label$1
   }
   $1 = 0 - $1 | 0;
   if ($1 >>> 0 > 4095) {
    break label$1
   }
   $1 = $1 | $2 & -8192;
   $1 = $2 & 4096 ? $1 - -8192 | 0 : $1;
   if (($1 | 0) == ($2 | 0)) {
    break label$1
   }
   HEAP32[$0 >> 2] = $1;
  }
 }

 function refcount_dec_not_one($0) {
  var $1 = 0, $2 = 0;
  $1 = HEAP32[$0 >> 2];
  $2 = $1 + 1 | 0;
  if ($2 >>> 0 < 3) {
   return 3 >>> ($2 & 7) & 1
  }
  HEAP32[$0 >> 2] = $1 + -1;
  return 1;
 }

 function refcount_dec_and_lock_irqsave($0, $1) {
  var $2 = 0;
  label$1 : {
   if (!refcount_dec_not_one($0)) {
    $2 = HEAP32[34819];
    HEAP32[34819] = 0;
    HEAP32[$1 >> 2] = $2;
    $2 = $0;
    $0 = HEAP32[$0 >> 2] + -1 | 0;
    HEAP32[$2 >> 2] = $0;
    if (!$0) {
     break label$1
    }
    HEAP32[34819] = HEAP32[$1 >> 2];
   }
   return 0;
  }
  return 1;
 }

 function llist_add_batch($0, $1, $2) {
  var $3 = 0;
  $3 = $1;
  $1 = HEAP32[$2 >> 2];
  HEAP32[$3 >> 2] = $1;
  HEAP32[$2 >> 2] = $0;
  return !$1;
 }

 function find_next_bit($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  label$1 : {
   if ($2 >>> 0 >= $1 >>> 0) {
    break label$1
   }
   $3 = HEAP32[($2 >>> 3 & 536870908) + $0 >> 2] & -1 << ($2 & 31);
   $2 = $2 & -32;
   while (1) {
    if (!$3) {
     $2 = $2 + 32 | 0;
     if ($2 >>> 0 >= $1 >>> 0) {
      break label$1
     }
     $3 = HEAP32[($2 >>> 3 & 536870908) + $0 >> 2];
     continue;
    }
    break;
   };
   $4 = $2;
   $0 = $3 & 65535;
   $2 = !$0 << 4;
   $5 = $2;
   $6 = $2 | 8;
   $0 = $0 ? $3 : $3 >>> 16 | 0;
   $2 = $0 & 255;
   $3 = $2 ? $5 : $6;
   $0 = $2 ? $0 : $0 >>> 8 | 0;
   $2 = $0 & 15;
   $3 = $2 ? $3 : $3 | 4;
   $0 = $2 ? $0 : $0 >>> 4 | 0;
   $2 = $0 & 3;
   $0 = $4 + (($2 ? $3 : $3 | 2) + ((($2 ? $0 : $0 >>> 2 | 0) ^ -1) & 1) | 0) | 0;
   $1 = $0 >>> 0 < $1 >>> 0 ? $0 : $1;
  }
  return $1;
 }

 function __bitmap_clear($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $3 = $1 & 31;
  $4 = -1 << $3;
  $5 = 32 - $3 | 0;
  $0 = ($1 >>> 3 & 536870908) + $0 | 0;
  $3 = $2;
  while (1) {
   $6 = $3 - $5 | 0;
   if (!(($6 | 0) < 0)) {
    HEAP32[$0 >> 2] = HEAP32[$0 >> 2] & ($4 ^ -1);
    $0 = $0 + 4 | 0;
    $5 = 32;
    $3 = $6;
    $4 = -1;
    continue;
   }
   break;
  };
  if ($3) {
   HEAP32[$0 >> 2] = HEAP32[$0 >> 2] & (-1 >>> (0 - ($1 + $2 | 0) & 31) & $4 ^ -1)
  }
 }

 function bust_spinlocks($0) {
  if ($0) {
   HEAP32[19560] = HEAP32[19560] + 1;
   return;
  }
  console_unblank();
  $0 = HEAP32[19560] + -1 | 0;
  HEAP32[19560] = $0;
  if ($0) {
   return
  }
  wake_up_klogd();
 }

 function debug_locks_off() {
  var $0 = 0;
  label$1 : {
   if (!HEAP32[4943]) {
    break label$1
   }
   $0 = HEAP32[4943];
   HEAP32[4943] = 0;
   if (!HEAP32[2968] | (HEAP32[34820] | !$0)) {
    break label$1
   }
   HEAP32[2968] = 15;
  }
 }

 function u32_swap($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  $2 = HEAP32[$0 >> 2];
  HEAP32[$0 >> 2] = HEAP32[$1 >> 2];
  HEAP32[$1 >> 2] = $2;
 }

 function generic_swap($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0;
  while (1) {
   $3 = HEAPU8[$0 | 0];
   HEAP8[$0 | 0] = HEAPU8[$1 | 0];
   HEAP8[$1 | 0] = $3;
   $1 = $1 + 1 | 0;
   $0 = $0 + 1 | 0;
   $2 = $2 + -1 | 0;
   if (($2 | 0) > 0) {
    continue
   }
   break;
  };
 }

 function u64_swap($0, $1, $2) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $2 = $2 | 0;
  var $3 = 0, $4 = 0;
  $2 = HEAP32[$0 >> 2];
  $3 = HEAP32[$0 + 4 >> 2];
  $4 = HEAP32[$1 + 4 >> 2];
  HEAP32[$0 >> 2] = HEAP32[$1 >> 2];
  HEAP32[$0 + 4 >> 2] = $4;
  HEAP32[$1 >> 2] = $2;
  HEAP32[$1 + 4 >> 2] = $3;
 }

 function __div64_32($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0;
  $2 = HEAP32[$0 + 4 >> 2];
  $5 = $2;
  $6 = HEAP32[$0 >> 2];
  $7 = 0;
  label$1 : {
   if ($2 >>> 0 < $1 >>> 0) {
    break label$1
   }
   $2 = ($2 >>> 0) / ($1 >>> 0) | 0;
   $8 = $2;
   $3 = $6;
   $6 = $3 - 0 | 0;
   $5 = $5 - (Math_imul($1, $2) + ($3 >>> 0 < 0) | 0) | 0;
   $7 = 0;
  }
  $4 = $1;
  $1 = 0;
  $9 = 1;
  $2 = 0;
  while (1) {
   if (!(($1 | 0) == ($5 | 0) & $4 >>> 0 >= $6 >>> 0 | $1 >>> 0 > $5 >>> 0 | (($1 | 0) < 0 ? 1 : ($1 | 0) <= 0 ? ($4 >>> 0 >= 1 ? 0 : 1) : 0))) {
    $3 = $9;
    $2 = $2 << 1 | $3 >>> 31;
    $9 = $3 << 1;
    $3 = $1 << 1 | $4 >>> 31;
    $4 = $4 << 1;
    $1 = $3;
    continue;
   }
   break;
  };
  while (1) {
   $11 = ($1 | 0) == ($5 | 0) & $6 >>> 0 < $4 >>> 0 | $5 >>> 0 < $1 >>> 0;
   $10 = $11;
   $3 = $7 + ($10 ? 0 : $9) | 0;
   $8 = $8 + ($10 ? 0 : $2) | 0;
   $8 = $3 >>> 0 < $7 >>> 0 ? $8 + 1 | 0 : $8;
   $7 = $3;
   $3 = $6;
   $10 = $10 ? 0 : $4;
   $6 = $3 - $10 | 0;
   $5 = $5 - (($3 >>> 0 < $10 >>> 0) + ($11 ? 0 : $1) | 0) | 0;
   $4 = ($1 & 1) << 31 | $4 >>> 1;
   $1 = $1 >>> 1 | 0;
   $9 = ($2 & 1) << 31 | $9 >>> 1;
   $2 = $2 >>> 1 | 0;
   if ($9 | $2) {
    continue
   }
   break;
  };
  HEAP32[$0 >> 2] = $7;
  HEAP32[$0 + 4 >> 2] = $8;
  return $6;
 }

 function div_s64_rem($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0;
  $4 = global$0 - 16 | 0;
  global$0 = $4;
  label$1 : {
   label$2 : {
    label$3 : {
     label$4 : {
      if (!(($1 | 0) < -1 ? 1 : ($1 | 0) <= -1 ? ($0 >>> 0 > 4294967295 ? 0 : 1) : 0)) {
       $5 = $2 >> 31;
       $6 = $5 + $2 ^ $5;
       HEAP32[$4 + 8 >> 2] = $0;
       HEAP32[$4 + 12 >> 2] = $1;
       if (!$1 & $0 >>> 0 > 4294967295 | $1 >>> 0 > 0) {
        break label$4
       }
       $1 = 0;
       $5 = $0;
       $0 = ($0 >>> 0) / ($6 >>> 0) | 0;
       HEAP32[$4 + 8 >> 2] = $0;
       HEAP32[$4 + 12 >> 2] = 0;
       $5 = $5 - Math_imul($6, $0) | 0;
       break label$1;
      }
      $5 = 0 - $0 | 0;
      HEAP32[$4 + 8 >> 2] = $5;
      $1 = 0 - ((0 < $0 >>> 0) + $1 | 0) | 0;
      HEAP32[$4 + 12 >> 2] = $1;
      $0 = $2 >> 31;
      $6 = $0 + $2 ^ $0;
      if (!$1 & $5 >>> 0 > 4294967295 | $1 >>> 0 > 0) {
       break label$3
      }
      $0 = ($5 >>> 0) / ($6 >>> 0) | 0;
      HEAP32[$4 + 8 >> 2] = $0;
      HEAP32[$4 + 12 >> 2] = 0;
      $5 = $5 - Math_imul($6, $0) | 0;
      $1 = 0;
      break label$2;
     }
     $5 = __div64_32($4 + 8 | 0, $6);
     $0 = HEAP32[$4 + 8 >> 2];
     $1 = HEAP32[$4 + 12 >> 2];
     break label$1;
    }
    $5 = __div64_32($4 + 8 | 0, $6);
    $0 = HEAP32[$4 + 8 >> 2];
    $1 = HEAP32[$4 + 12 >> 2];
   }
   HEAP32[$3 >> 2] = 0 - $5;
   global$0 = $4 + 16 | 0;
   $3 = ($2 | 0) > 0;
   $2 = $3 ? 0 - $0 | 0 : $0;
   i64toi32_i32$HIGH_BITS = $3 ? 0 - ((0 < $0 >>> 0) + $1 | 0) | 0 : $1;
   return $2;
  }
  HEAP32[$3 >> 2] = $5;
  global$0 = $4 + 16 | 0;
  $3 = ($2 | 0) < 0;
  $2 = $3 ? 0 - $0 | 0 : $0;
  i64toi32_i32$HIGH_BITS = $3 ? 0 - ((0 < $0 >>> 0) + $1 | 0) | 0 : $1;
  return $2;
 }

 function div64_u64($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0;
  $7 = global$0 - 16 | 0;
  global$0 = $7;
  label$1 : {
   label$2 : {
    label$3 : {
     label$4 : {
      $4 = $3;
      if ($4) {
       $8 = $0;
       $5 = $4 >>> 0 > 65535;
       $6 = $5 ? 32 : 16;
       $4 = $5 ? $4 : $4 << 16;
       $5 = $4 >>> 0 > 16777215;
       $6 = $5 ? $6 : $6 + -8 | 0;
       $4 = $5 ? $4 : $4 << 8;
       $5 = $4 >>> 0 > 268435455;
       $6 = $5 ? $6 : $6 + -4 | 0;
       $4 = $5 ? $4 : $4 << 4;
       $5 = $4 >>> 0 > 1073741823;
       $6 = ($5 ? $6 : $6 + -2 | 0) - (($5 ? $4 : $4 << 2) >> 31) | 0;
       $4 = $6;
       $5 = $4 & 31;
       $9 = $7;
       if (32 <= ($4 & 63) >>> 0) {
        $4 = 0;
        $8 = $1 >>> $5 | 0;
       } else {
        $4 = $1 >>> $5 | 0;
        $8 = ((1 << $5) - 1 & $1) << 32 - $5 | $8 >>> $5;
       }
       HEAP32[$9 + 8 >> 2] = $8;
       HEAP32[$7 + 12 >> 2] = $4;
       $5 = $3;
       $3 = $6 & 31;
       $6 = 32 <= ($6 & 63) >>> 0 ? $5 >>> $3 | 0 : ((1 << $3) - 1 & $5) << 32 - $3 | $2 >>> $3;
       if (!$4 & $8 >>> 0 > 4294967295 | $4 >>> 0 > 0) {
        break label$4
       }
       $3 = 0;
       $4 = ($8 >>> 0) / ($6 >>> 0) | 0;
       HEAP32[$7 + 8 >> 2] = $4;
       HEAP32[$7 + 12 >> 2] = 0;
       break label$2;
      }
      HEAP32[$7 + 8 >> 2] = $0;
      HEAP32[$7 + 12 >> 2] = $1;
      if (!$1 & $0 >>> 0 > 4294967295 | $1 >>> 0 > 0) {
       break label$3
      }
      $3 = 0;
      $2 = ($0 >>> 0) / ($2 >>> 0) | 0;
      HEAP32[$7 + 8 >> 2] = $2;
      HEAP32[$7 + 12 >> 2] = 0;
      break label$1;
     }
     __div64_32($7 + 8 | 0, $6);
     $4 = HEAP32[$7 + 8 >> 2];
     $3 = HEAP32[$7 + 12 >> 2];
     break label$2;
    }
    __div64_32($7 + 8 | 0, $2);
    $2 = HEAP32[$7 + 8 >> 2];
    $3 = HEAP32[$7 + 12 >> 2];
    break label$1;
   }
   $9 = $0;
   $6 = $3 + -1 | 0;
   $8 = $4 + -1 | 0;
   if ($8 >>> 0 < 4294967295) {
    $6 = $6 + 1 | 0
   }
   $3 = !($3 | $4);
   $4 = $3 ? 0 : $8;
   $3 = $3 ? 0 : $6;
   $6 = __wasm_i64_mul($4, $3, $2, $5);
   $8 = $9 - $6 | 0;
   $0 = $1 - (i64toi32_i32$HIGH_BITS + ($0 >>> 0 < $6 >>> 0) | 0) | 0;
   $0 = ($5 | 0) == ($0 | 0) & $8 >>> 0 >= $2 >>> 0 | $0 >>> 0 > $5 >>> 0;
   $1 = $0 + $4 | 0;
   if ($1 >>> 0 < $0 >>> 0) {
    $3 = $3 + 1 | 0
   }
   $2 = $1;
  }
  global$0 = $7 + 16 | 0;
  i64toi32_i32$HIGH_BITS = $3;
  return $2;
 }

 function add_device_randomness($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  HEAP32[$3 + 12 >> 2] = HEAP32[20749];
  if (!(!!HEAP32[34838] | (!$1 | HEAP32[34838] > 1))) {
   $7 = $1 >>> 0 > 32 ? $1 : 32;
   while (1) {
    if (!($4 >>> 0 >= $7 >>> 0)) {
     $2 = ($4 & 31) + 139300 | 0;
     $5 = HEAPU8[$2 | 0];
     $8 = $2;
     $2 = HEAPU8[19836];
     $6 = $2 >>> 1 | 0;
     $2 = $2 & 1 ? $6 ^ -31 : $6;
     HEAP8[$8 | 0] = HEAPU8[(($4 >>> 0) % ($1 >>> 0) | 0) + $0 | 0] ^ ($5 ^ $2);
     HEAP8[19836] = $2 + ($5 << 3 | $5 >>> 5);
     $4 = $4 + 1 | 0;
     continue;
    }
    break;
   };
  }
  _mix_pool_bytes($0, $1);
  _mix_pool_bytes($3 + 12 | 0, 4);
  global$0 = $3 + 16 | 0;
 }

 function _mix_pool_bytes($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0;
  $2 = HEAP32[4944];
  $4 = HEAP32[$2 + 4 >> 2] + -1 | 0;
  $3 = HEAPU16[9906];
  $5 = HEAPU16[9907];
  $7 = HEAP32[$2 + 36 >> 2];
  $8 = HEAP32[$2 + 32 >> 2];
  $9 = HEAP32[$2 + 28 >> 2];
  $10 = HEAP32[$2 + 24 >> 2];
  $11 = HEAP32[$2 + 20 >> 2];
  while (1) {
   if ($1) {
    $2 = HEAP32[4945];
    $3 = $3 + -1 & $4;
    $6 = $2 + ($3 << 2) | 0;
    $2 = __wasm_rotl_i32(HEAP8[$0 | 0], $5) ^ HEAP32[$6 >> 2] ^ HEAP32[$2 + (($3 + $11 & $4) << 2) >> 2] ^ HEAP32[$2 + (($3 + $10 & $4) << 2) >> 2] ^ HEAP32[$2 + (($3 + $9 & $4) << 2) >> 2] ^ HEAP32[$2 + (($3 + $8 & $4) << 2) >> 2] ^ HEAP32[$2 + (($3 + $7 & $4) << 2) >> 2];
    HEAP32[$6 >> 2] = $2 >>> 3 ^ HEAP32[(($2 & 7) << 2) + 31792 >> 2];
    $0 = $0 + 1 | 0;
    $1 = $1 + -1 | 0;
    $5 = ($3 ? 7 : 14) + $5 & 31;
    continue;
   }
   break;
  };
  HEAP16[9906] = $3;
  HEAP16[9907] = $5;
 }

 function strcpy($0, $1) {
  var $2 = 0, $3 = 0;
  while (1) {
   $3 = HEAPU8[$1 + $2 | 0];
   HEAP8[$0 + $2 | 0] = $3;
   $2 = $2 + 1 | 0;
   if ($3) {
    continue
   }
   break;
  };
 }

 function strlcpy() {
  var $0 = 0, wasm2js_i32$0 = 0, wasm2js_i32$1 = 0;
  $0 = strlen(140560);
  $0 = $0 >>> 0 < 512 ? $0 : 511;
  (wasm2js_i32$0 = memcpy(140048, 140560, $0) + $0 | 0, wasm2js_i32$1 = 0), HEAP8[wasm2js_i32$0 | 0] = wasm2js_i32$1;
 }

 function strlen($0) {
  var $1 = 0;
  $1 = $0 + -1 | 0;
  while (1) {
   $1 = $1 + 1 | 0;
   if (HEAPU8[$1 | 0]) {
    continue
   }
   break;
  };
  return $1 - $0 | 0;
 }

 function memcpy($0, $1, $2) {
  var $3 = 0;
  while (1) {
   if (!(($2 | 0) == ($3 | 0))) {
    HEAP8[$0 + $3 | 0] = HEAPU8[$1 + $3 | 0];
    $3 = $3 + 1 | 0;
    continue;
   }
   break;
  };
  return $0;
 }

 function strcmp($0, $1) {
  var $2 = 0, $3 = 0;
  label$1 : {
   while (1) {
    $2 = HEAPU8[$0 | 0];
    $3 = HEAPU8[$1 | 0];
    if (($2 | 0) != ($3 | 0)) {
     break label$1
    }
    $0 = $0 + 1 | 0;
    $1 = $1 + 1 | 0;
    if ($2) {
     continue
    }
    break;
   };
   return 0;
  }
  return $2 >>> 0 < $3 >>> 0 ? -1 : 1;
 }

 function strncmp($0, $1, $2) {
  var $3 = 0, $4 = 0;
  label$1 : {
   while (1) {
    if ($2) {
     $3 = HEAPU8[$0 | 0];
     $4 = HEAPU8[$1 | 0];
     if (($3 | 0) != ($4 | 0)) {
      break label$1
     }
     $2 = $2 + -1 | 0;
     $0 = $0 + 1 | 0;
     $1 = $1 + 1 | 0;
     if ($3) {
      continue
     }
    }
    break;
   };
   return 0;
  }
  return $3 >>> 0 < $4 >>> 0 ? -1 : 1;
 }

 function strchr($0) {
  var $1 = 0;
  label$1 : {
   while (1) {
    $1 = HEAP8[$0 | 0];
    if (($1 | 0) != 46) {
     if (!$1) {
      break label$1
     }
     $0 = $0 + 1 | 0;
     continue;
    }
    break;
   };
   return $0;
  }
  return 0;
 }

 function skip_spaces($0) {
  $0 = $0 + -1 | 0;
  while (1) {
   $0 = $0 + 1 | 0;
   if (HEAPU8[HEAPU8[$0 | 0] + 31824 | 0] & 32) {
    continue
   }
   break;
  };
  return $0;
 }

 function strcspn() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0, $4 = 0;
  $0 = 3291;
  while (1) {
   label$1 : {
    $2 = HEAPU8[$0 | 0];
    if (!$2) {
     break label$1
    }
    $1 = 32626;
    while (1) {
     $3 = HEAPU8[$1 | 0];
     if ($3) {
      $1 = $1 + 1 | 0;
      if (($2 | 0) != ($3 | 0)) {
       continue
      }
      break label$1;
     }
     break;
    };
    $0 = $0 + 1 | 0;
    $4 = $4 + 1 | 0;
    continue;
   }
   break;
  };
  return $4;
 }

 function memset($0, $1, $2) {
  var $3 = 0;
  while (1) {
   if (($2 | 0) != ($3 | 0)) {
    HEAP8[$0 + $3 | 0] = $1;
    $3 = $3 + 1 | 0;
    continue;
   }
   break;
  };
 }

 function memchr($0, $1) {
  $0 = $0 + -1 | 0;
  label$1 : {
   while (1) {
    if (!$1) {
     break label$1
    }
    $1 = $1 + -1 | 0;
    $0 = $0 + 1 | 0;
    if (HEAPU8[$0 | 0] != 10) {
     continue
    }
    break;
   };
   return $0;
  }
  return 0;
 }

 function put_dec($0, $1, $2) {
  var $3 = 0, $4 = 0;
  if (!(!$2 & $1 >>> 0 > 99999999 | $2 >>> 0 > 0)) {
   return put_dec_trunc8($0, $1)
  }
  $3 = $2 & 65535;
  $2 = $2 >>> 16 | 0;
  $4 = $1 >>> 16 | 0;
  $1 = put_dec_helper4($0 + 8 | 0, (Math_imul($3, 42) + Math_imul($2, 4749) | 0) + put_dec_helper4($0 + 4 | 0, ((Math_imul($4, 6) + Math_imul($2, 7671) | 0) + Math_imul($3, 9496) | 0) + put_dec_helper4($0, ((Math_imul($2, 656) + ($1 & 65535) | 0) + Math_imul($4, 5536) | 0) + Math_imul($3, 7296) | 0) | 0) | 0) + Math_imul($2, 281) | 0;
  if ($1) {
   return put_dec_trunc8($0 + 12 | 0, $1)
  }
  $0 = $0 + 13 | 0;
  while (1) {
   $1 = $0 + -2 | 0;
   $2 = $0 + -1 | 0;
   $0 = $2;
   if (HEAPU8[$1 | 0] == 48) {
    continue
   }
   break;
  };
  return $2;
 }

 function put_dec_trunc8($0, $1) {
  var $2 = 0;
  label$1 : {
   if ($1 >>> 0 < 100) {
    break label$1
   }
   $2 = $1;
   __wasm_i64_mul($1, 0, 42949673, 0);
   $1 = i64toi32_i32$HIGH_BITS;
   HEAP16[$0 >> 1] = HEAPU16[($2 + Math_imul($1, -100) << 1) + 32096 >> 1];
   if ($1 >>> 0 < 100) {
    $0 = $0 + 2 | 0;
    break label$1;
   }
   __wasm_i64_mul($1, 0, 42949673, 0);
   $2 = i64toi32_i32$HIGH_BITS;
   HEAP16[$0 + 2 >> 1] = HEAPU16[(Math_imul($2, -100) + $1 << 1) + 32096 >> 1];
   if ($2 >>> 0 < 100) {
    $0 = $0 + 4 | 0;
    $1 = $2;
    break label$1;
   }
   $1 = Math_imul($2, 5243) >>> 19 | 0;
   HEAP16[$0 + 4 >> 1] = HEAPU16[($2 + Math_imul($1, -100) << 1) + 32096 >> 1];
   $0 = $0 + 6 | 0;
  }
  HEAP16[$0 >> 1] = HEAPU16[($1 << 1) + 32096 >> 1];
  return ($1 >>> 0 < 10 ? 1 : 2) + $0 | 0;
 }

 function put_dec_helper4($0, $1) {
  var $2 = 0, $3 = 0;
  $2 = $1;
  __wasm_i64_mul($1, 0, 879609303, 0);
  $1 = i64toi32_i32$HIGH_BITS >>> 11 | 0;
  $2 = $2 + Math_imul($1, -1e4) | 0;
  $3 = Math_imul($2, 5243) >>> 19 | 0;
  HEAP16[$0 + 2 >> 1] = HEAPU16[($3 << 1) + 32096 >> 1];
  HEAP16[$0 >> 1] = HEAPU16[($2 + Math_imul($3, -100) << 1) + 32096 >> 1];
  return $1;
 }

 function vsnprintf($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0;
  $5 = global$0 - 32 | 0;
  global$0 = $5;
  HEAP32[$5 + 24 >> 2] = 0;
  HEAP32[$5 + 28 >> 2] = 0;
  if (($1 | 0) >= 0) {
   $9 = $0 + $1 | 0;
   $6 = $0;
   label$3 : while (1) {
    label$2 : {
     $8 = $2;
     if (!HEAPU8[$8 | 0]) {
      break label$2
     }
     $10 = format_decode($8, $5 + 24 | 0);
     $2 = $8 + $10 | 0;
     $4 = HEAP32[$5 + 28 >> 2];
     label$4 : {
      label$5 : {
       label$6 : {
        label$7 : {
         label$8 : {
          $7 = HEAP32[$5 + 24 >> 2];
          $11 = $7 & 255;
          if ($11 >>> 0 > 18) {
           break label$8
          }
          label$9 : {
           label$10 : {
            label$11 : {
             label$12 : {
              label$13 : {
               label$14 : {
                label$15 : {
                 label$16 : {
                  label$17 : {
                   label$18 : {
                    label$19 : {
                     label$20 : {
                      switch ($11 - 1 | 0) {
                      default:
                       if ($6 >>> 0 < $9 >>> 0) {
                        $4 = $9 - $6 | 0;
                        memcpy($6, $8, ($10 | 0) > ($4 | 0) ? $4 : $10);
                       }
                       $6 = $6 + $10 | 0;
                       continue;
                      case 0:
                       set_field_width($5 + 24 | 0, HEAP32[$3 >> 2]);
                       break label$19;
                      case 1:
                       set_precision($5 + 24 | 0, HEAP32[$3 >> 2]);
                       break label$19;
                      case 2:
                       label$27 : {
                        if ($4 & 2) {
                         break label$27
                        }
                        while (1) {
                         $10 = $4;
                         $4 = $7;
                         $8 = $4 >> 31;
                         $4 = ($4 >> 8) + -1 | 0;
                         if ($4 >>> 0 < 4294967295) {
                          $8 = $8 + 1 | 0
                         }
                         $11 = $10;
                         $10 = $4;
                         $7 = $4 << 8 & -256 | $7 & 255;
                         HEAP32[$5 + 24 >> 2] = $7;
                         $4 = $11;
                         HEAP32[$5 + 28 >> 2] = $4;
                         if ($10 << 8 >> 8 < 1) {
                          break label$27
                         }
                         if ($6 >>> 0 < $9 >>> 0) {
                          HEAP8[$6 | 0] = 32;
                          $7 = HEAP32[$5 + 24 >> 2];
                          $4 = HEAP32[$5 + 28 >> 2];
                         }
                         $6 = $6 + 1 | 0;
                         continue;
                        };
                       }
                       if ($6 >>> 0 < $9 >>> 0) {
                        HEAP8[$6 | 0] = HEAP32[$3 >> 2]
                       }
                       $3 = $3 + 4 | 0;
                       while (1) {
                        $6 = $6 + 1 | 0;
                        $10 = HEAP32[$5 + 28 >> 2];
                        $11 = HEAP32[$5 + 24 >> 2];
                        $4 = $11;
                        $8 = $4 >> 31;
                        $4 = ($4 >> 8) + -1 | 0;
                        if ($4 >>> 0 < 4294967295) {
                         $8 = $8 + 1 | 0
                        }
                        HEAP32[$5 + 24 >> 2] = $4 << 8 & -256 | $11 & 255;
                        HEAP32[$5 + 28 >> 2] = $10;
                        if ($4 << 8 >> 8 < 1) {
                         continue label$3
                        }
                        if ($6 >>> 0 >= $9 >>> 0) {
                         continue
                        }
                        HEAP8[$6 | 0] = 32;
                        continue;
                       };
                      case 3:
                       $4 = HEAP32[$3 >> 2];
                       $7 = HEAP32[$5 + 28 >> 2];
                       HEAP32[$5 + 8 >> 2] = HEAP32[$5 + 24 >> 2];
                       HEAP32[$5 + 12 >> 2] = $7;
                       $6 = string($6, $9, $4, $5 + 8 | 0);
                       break label$19;
                      case 11:
                       break label$10;
                      case 10:
                       break label$11;
                      case 7:
                       break label$12;
                      case 5:
                       break label$13;
                      case 16:
                       break label$14;
                      case 15:
                       break label$15;
                      case 12:
                       break label$16;
                      case 9:
                       break label$17;
                      case 8:
                       break label$18;
                      case 6:
                       break label$2;
                      case 4:
                       break label$20;
                      case 17:
                       break label$7;
                      case 14:
                       break label$8;
                      case 13:
                       break label$9;
                      };
                     }
                     $4 = HEAP32[$3 >> 2];
                     $7 = HEAP32[$5 + 28 >> 2];
                     HEAP32[$5 + 16 >> 2] = HEAP32[$5 + 24 >> 2];
                     HEAP32[$5 + 20 >> 2] = $7;
                     $6 = pointer($2, $6, $9, $4, $5 + 16 | 0);
                     $2 = $2 + -1 | 0;
                     while (1) {
                      $2 = $2 + 1 | 0;
                      if (HEAPU8[HEAPU8[$2 | 0] + 31824 | 0] & 7) {
                       continue
                      }
                      break;
                     };
                    }
                    $3 = $3 + 4 | 0;
                    continue;
                   }
                   $7 = HEAP32[$3 >> 2];
                   $4 = 0;
                   $3 = $3 + 4 | 0;
                   break label$4;
                  }
                  $4 = HEAP32[$3 >> 2];
                  $7 = $4;
                  $4 = $4 >> 31;
                  $3 = $3 + 4 | 0;
                  break label$4;
                 }
                 $7 = HEAPU16[$3 >> 1];
                 $4 = 0;
                 $3 = $3 + 4 | 0;
                 break label$4;
                }
                $4 = HEAP32[$3 >> 2];
                $7 = $4;
                $4 = $4 >> 31;
                $3 = $3 + 4 | 0;
                break label$4;
               }
               $8 = $3 + 4 | 0;
               $7 = HEAP32[$3 >> 2];
               if ($4 & 1) {
                break label$6
               }
               $4 = 0;
               break label$5;
              }
              if ($6 >>> 0 < $9 >>> 0) {
               HEAP8[$6 | 0] = 37
              }
              $6 = $6 + 1 | 0;
              continue;
             }
             $4 = $3 + 7 & -8;
             $3 = $4 + 8 | 0;
             $7 = HEAP32[$4 >> 2];
             $4 = HEAP32[$4 + 4 >> 2];
             break label$4;
            }
            $7 = HEAPU8[$3 | 0];
            $4 = 0;
            $3 = $3 + 4 | 0;
            break label$4;
           }
           $4 = HEAP8[$3 | 0];
           $7 = $4;
           $4 = $4 >> 31;
           $3 = $3 + 4 | 0;
           break label$4;
          }
          $4 = HEAP16[$3 >> 1];
          $7 = $4;
          $4 = $4 >> 31;
          $3 = $3 + 4 | 0;
          break label$4;
         }
         $7 = HEAP32[$3 >> 2];
         $4 = 0;
         $3 = $3 + 4 | 0;
         break label$4;
        }
        $4 = HEAP32[$3 >> 2];
        $7 = $4;
        $4 = $4 >> 31;
        $3 = $3 + 4 | 0;
        break label$4;
       }
       $4 = $7 >> 31;
      }
      $3 = $8;
     }
     $8 = HEAP32[$5 + 28 >> 2];
     HEAP32[$5 >> 2] = HEAP32[$5 + 24 >> 2];
     HEAP32[$5 + 4 >> 2] = $8;
     $6 = number($6, $9, $7, $4, $5);
     continue;
    }
    break;
   };
   if ($1) {
    HEAP8[($6 >>> 0 < $9 >>> 0 ? $6 : $9 + -1 | 0) | 0] = 0
   }
   $6 = $6 - $0 | 0;
  }
  global$0 = $5 + 32 | 0;
  return $6;
 }

 function format_decode($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0;
  $8 = global$0 - 16 | 0;
  global$0 = $8;
  HEAP32[$8 + 12 >> 2] = $0;
  $11 = $8;
  $2 = HEAPU8[$1 + 4 | 0] | HEAPU8[$1 + 5 | 0] << 8 | (HEAPU8[$1 + 6 | 0] << 16 | HEAPU8[$1 + 7 | 0] << 24);
  label$1 : {
   label$2 : {
    label$3 : {
     label$4 : {
      label$5 : {
       label$6 : {
        $3 = HEAPU8[$1 | 0] | HEAPU8[$1 + 1 | 0] << 8 | (HEAPU8[$1 + 2 | 0] << 16 | HEAPU8[$1 + 3 | 0] << 24);
        $4 = $3 & 255;
        if (($4 | 0) != 2) {
         if (($4 | 0) != 1) {
          break label$6
         }
         $5 = $3 >> 8;
         if (($5 | 0) <= -1) {
          $6 = $2 & -3 | 2;
          $2 = $6;
          $4 = $3 & 255;
          $3 = $5;
          $3 = $4 | 0 - ($3 << 8) & -256;
          HEAP8[$1 | 0] = $3;
          HEAP8[$1 + 1 | 0] = $3 >>> 8;
          HEAP8[$1 + 2 | 0] = $3 >>> 16;
          HEAP8[$1 + 3 | 0] = $3 >>> 24;
          HEAP8[$1 + 4 | 0] = $2;
          HEAP8[$1 + 5 | 0] = $2 >>> 8;
          HEAP8[$1 + 6 | 0] = $2 >>> 16;
          HEAP8[$1 + 7 | 0] = $2 >>> 24;
         }
         $4 = $2;
         $6 = $3 & -256;
         $2 = $6;
         HEAP8[$1 | 0] = $2;
         HEAP8[$1 + 1 | 0] = $2 >>> 8;
         HEAP8[$1 + 2 | 0] = $2 >>> 16;
         HEAP8[$1 + 3 | 0] = $2 >>> 24;
         HEAP8[$1 + 4 | 0] = $4;
         HEAP8[$1 + 5 | 0] = $4 >>> 8;
         HEAP8[$1 + 6 | 0] = $4 >>> 16;
         HEAP8[$1 + 7 | 0] = $4 >>> 24;
         $5 = $0;
         break label$5;
        }
        if ($2 >> 16 <= -1) {
         $4 = $2 & 65535;
         $2 = $4;
         HEAP8[$1 | 0] = $3;
         HEAP8[$1 + 1 | 0] = $3 >>> 8;
         HEAP8[$1 + 2 | 0] = $3 >>> 16;
         HEAP8[$1 + 3 | 0] = $3 >>> 24;
         HEAP8[$1 + 4 | 0] = $2;
         HEAP8[$1 + 5 | 0] = $2 >>> 8;
         HEAP8[$1 + 6 | 0] = $2 >>> 16;
         HEAP8[$1 + 7 | 0] = $2 >>> 24;
        }
        $4 = $2;
        $6 = $3 & -256;
        $2 = $6;
        HEAP8[$1 | 0] = $2;
        HEAP8[$1 + 1 | 0] = $2 >>> 8;
        HEAP8[$1 + 2 | 0] = $2 >>> 16;
        HEAP8[$1 + 3 | 0] = $2 >>> 24;
        HEAP8[$1 + 4 | 0] = $4;
        HEAP8[$1 + 5 | 0] = $4 >>> 8;
        HEAP8[$1 + 6 | 0] = $4 >>> 16;
        HEAP8[$1 + 7 | 0] = $4 >>> 24;
        $2 = $0;
        break label$4;
       }
       $4 = $3 & -256;
       HEAP8[$1 | 0] = $4;
       HEAP8[$1 + 1 | 0] = $4 >>> 8;
       HEAP8[$1 + 2 | 0] = $4 >>> 16;
       HEAP8[$1 + 3 | 0] = $4 >>> 24;
       HEAP8[$1 + 4 | 0] = $2;
       HEAP8[$1 + 5 | 0] = $2 >>> 8;
       HEAP8[$1 + 6 | 0] = $2 >>> 16;
       HEAP8[$1 + 7 | 0] = $2 >>> 24;
       $7 = $0;
       while (1) {
        $6 = $0 + $5 | 0;
        $4 = HEAPU8[$6 | 0];
        if (!(!$4 | ($4 | 0) == 37)) {
         $7 = $6 + 1 | 0;
         HEAP32[$8 + 12 >> 2] = $7;
         $5 = $5 + 1 | 0;
         continue;
        }
        break;
       };
       if (!$4 | $5) {
        break label$1
       }
       $5 = $0 + 1 | 0;
       $3 = $3 & -256;
       $2 = $2 & -256;
       while (1) {
        label$12 : {
         HEAP8[$1 | 0] = $3;
         HEAP8[$1 + 1 | 0] = $3 >>> 8;
         HEAP8[$1 + 2 | 0] = $3 >>> 16;
         HEAP8[$1 + 3 | 0] = $3 >>> 24;
         HEAP8[$1 + 4 | 0] = $2;
         HEAP8[$1 + 5 | 0] = $2 >>> 8;
         HEAP8[$1 + 6 | 0] = $2 >>> 16;
         HEAP8[$1 + 7 | 0] = $2 >>> 24;
         HEAP32[$8 + 12 >> 2] = $5;
         $6 = HEAP8[$5 | 0];
         $4 = 8;
         label$14 : {
          if (($6 | 0) == 32) {
           break label$14
          }
          $4 = 64;
          if (($6 | 0) == 35) {
           break label$14
          }
          $4 = 16;
          if (($6 | 0) == 48) {
           break label$14
          }
          $4 = 2;
          if (($6 | 0) == 45) {
           break label$14
          }
          if (($6 | 0) != 43) {
           break label$12
          }
          $4 = 4;
         }
         $5 = $5 + 1 | 0;
         $2 = $2 | $4;
         continue;
        }
        break;
       };
       $4 = $2;
       $6 = $3 | -256;
       $2 = $6;
       HEAP8[$1 | 0] = $2;
       HEAP8[$1 + 1 | 0] = $2 >>> 8;
       HEAP8[$1 + 2 | 0] = $2 >>> 16;
       HEAP8[$1 + 3 | 0] = $2 >>> 24;
       HEAP8[$1 + 4 | 0] = $4;
       HEAP8[$1 + 5 | 0] = $4 >>> 8;
       HEAP8[$1 + 6 | 0] = $4 >>> 16;
       HEAP8[$1 + 7 | 0] = $4 >>> 24;
       $2 = HEAP8[$5 | 0];
       if ($2 + -48 >>> 0 > 9) {
        if (($2 | 0) != 42) {
         break label$5
        }
        $2 = $3 | -255;
        HEAP8[$1 | 0] = $2;
        HEAP8[$1 + 1 | 0] = $2 >>> 8;
        HEAP8[$1 + 2 | 0] = $2 >>> 16;
        HEAP8[$1 + 3 | 0] = $2 >>> 24;
        HEAP8[$1 + 4 | 0] = $4;
        HEAP8[$1 + 5 | 0] = $4 >>> 8;
        HEAP8[$1 + 6 | 0] = $4 >>> 16;
        HEAP8[$1 + 7 | 0] = $4 >>> 24;
        $7 = $5 + 1 | 0;
        break label$2;
       }
       $3 = skip_atoi($8 + 12 | 0);
       $2 = HEAPU8[$1 + 4 | 0] | HEAPU8[$1 + 5 | 0] << 8 | (HEAPU8[$1 + 6 | 0] << 16 | HEAPU8[$1 + 7 | 0] << 24);
       $4 = $2;
       $6 = (HEAPU8[$1 | 0] | HEAPU8[$1 + 1 | 0] << 8 | (HEAPU8[$1 + 2 | 0] << 16 | HEAPU8[$1 + 3 | 0] << 24)) & 255 | $3 << 8;
       $3 = $6;
       HEAP8[$1 | 0] = $3;
       HEAP8[$1 + 1 | 0] = $3 >>> 8;
       HEAP8[$1 + 2 | 0] = $3 >>> 16;
       HEAP8[$1 + 3 | 0] = $3 >>> 24;
       HEAP8[$1 + 4 | 0] = $2;
       HEAP8[$1 + 5 | 0] = $2 >>> 8;
       HEAP8[$1 + 6 | 0] = $2 >>> 16;
       HEAP8[$1 + 7 | 0] = $2 >>> 24;
       $5 = HEAP32[$8 + 12 >> 2];
      }
      $2 = $4 | -65536;
      $4 = $2;
      $3 = $6;
      HEAP8[$1 | 0] = $3;
      HEAP8[$1 + 1 | 0] = $3 >>> 8;
      HEAP8[$1 + 2 | 0] = $3 >>> 16;
      HEAP8[$1 + 3 | 0] = $3 >>> 24;
      HEAP8[$1 + 4 | 0] = $2;
      HEAP8[$1 + 5 | 0] = $2 >>> 8;
      HEAP8[$1 + 6 | 0] = $2 >>> 16;
      HEAP8[$1 + 7 | 0] = $2 >>> 24;
      label$19 : {
       $3 = HEAPU8[$5 | 0];
       if (($3 | 0) == 46) {
        $2 = $5 + 1 | 0;
        HEAP32[$8 + 12 >> 2] = $2;
        $3 = HEAP8[$5 + 1 | 0];
        if ($3 + -48 >>> 0 <= 9) {
         break label$19
        }
        if (($3 | 0) != 42) {
         break label$4
        }
        $2 = $6 & -256 | 2;
        HEAP8[$1 | 0] = $2;
        HEAP8[$1 + 1 | 0] = $2 >>> 8;
        HEAP8[$1 + 2 | 0] = $2 >>> 16;
        HEAP8[$1 + 3 | 0] = $2 >>> 24;
        HEAP8[$1 + 4 | 0] = $4;
        HEAP8[$1 + 5 | 0] = $4 >>> 8;
        HEAP8[$1 + 6 | 0] = $4 >>> 16;
        HEAP8[$1 + 7 | 0] = $4 >>> 24;
        $7 = $5 + 2 | 0;
        break label$2;
       }
       $2 = $5;
       break label$3;
      }
      $2 = skip_atoi($8 + 12 | 0) << 16;
      $3 = $2 >> 16 < 0;
      $6 = 0 | (HEAPU8[$1 | 0] | HEAPU8[$1 + 1 | 0] << 8 | (HEAPU8[$1 + 2 | 0] << 16 | HEAPU8[$1 + 3 | 0] << 24));
      $3 = (HEAPU8[$1 + 4 | 0] | HEAPU8[$1 + 5 | 0] << 8 | (HEAPU8[$1 + 6 | 0] << 16 | HEAPU8[$1 + 7 | 0] << 24)) & 65535 | ($3 ? 0 : $2);
      $4 = $3;
      HEAP8[$1 | 0] = $6;
      HEAP8[$1 + 1 | 0] = $6 >>> 8;
      HEAP8[$1 + 2 | 0] = $6 >>> 16;
      HEAP8[$1 + 3 | 0] = $6 >>> 24;
      HEAP8[$1 + 4 | 0] = $3;
      HEAP8[$1 + 5 | 0] = $3 >>> 8;
      HEAP8[$1 + 6 | 0] = $3 >>> 16;
      HEAP8[$1 + 7 | 0] = $3 >>> 24;
      $2 = HEAP32[$8 + 12 >> 2];
     }
     $3 = HEAPU8[$2 | 0];
    }
    label$21 : {
     label$22 : {
      label$23 : {
       $5 = $3 + -104 | 0;
       if (!(1 << $5 & 266257 ? $5 >>> 0 <= 18 : 0)) {
        $5 = 0;
        if (($3 | 0) != 76) {
         break label$23
        }
       }
       $7 = $2 + 1 | 0;
       HEAP32[$8 + 12 >> 2] = $7;
       $5 = HEAPU8[$2 | 0];
       if (($5 | 0) == HEAPU8[$2 + 1 | 0]) {
        break label$22
       }
       break label$21;
      }
      $7 = $2;
      break label$21;
     }
     if (($5 | 0) != 104) {
      if (($5 | 0) != 108) {
       break label$21
      }
      $7 = $2 + 2 | 0;
      HEAP32[$8 + 12 >> 2] = $7;
      $5 = 76;
      break label$21;
     }
     $7 = $2 + 2 | 0;
     HEAP32[$8 + 12 >> 2] = $7;
     $5 = 72;
    }
    $2 = $4 & -65281;
    $12 = $2;
    $9 = $2 | 2560;
    $2 = $9;
    $3 = $6;
    HEAP8[$1 | 0] = $3;
    HEAP8[$1 + 1 | 0] = $3 >>> 8;
    HEAP8[$1 + 2 | 0] = $3 >>> 16;
    HEAP8[$1 + 3 | 0] = $3 >>> 24;
    HEAP8[$1 + 4 | 0] = $2;
    HEAP8[$1 + 5 | 0] = $2 >>> 8;
    HEAP8[$1 + 6 | 0] = $2 >>> 16;
    HEAP8[$1 + 7 | 0] = $2 >>> 24;
    label$27 : {
     label$28 : {
      label$29 : {
       label$30 : {
        label$31 : {
         label$32 : {
          label$33 : {
           label$34 : {
            label$35 : {
             label$36 : {
              label$37 : {
               $9 = HEAP8[$7 | 0];
               $10 = $9 + -111 | 0;
               if ($10 >>> 0 > 9) {
                if (($9 | 0) == 37) {
                 break label$29
                }
                if (($9 | 0) == 88) {
                 break label$32
                }
                if (($9 | 0) == 105 | ($9 | 0) == 100) {
                 break label$37
                }
                if (($9 | 0) != 99) {
                 break label$36
                }
                $3 = $3 & -256 | 3;
                HEAP8[$1 | 0] = $3;
                HEAP8[$1 + 1 | 0] = $3 >>> 8;
                HEAP8[$1 + 2 | 0] = $3 >>> 16;
                HEAP8[$1 + 3 | 0] = $3 >>> 24;
                $2 = $2 & -62721;
                HEAP8[$1 + 4 | 0] = $2;
                HEAP8[$1 + 5 | 0] = $2 >>> 8;
                HEAP8[$1 + 6 | 0] = $2 >>> 16;
                HEAP8[$1 + 7 | 0] = $2 >>> 24;
                $7 = $7 + 1 | 0;
                break label$2;
               }
               label$39 : {
                switch ($10 - 1 | 0) {
                case 5:
                 break label$30;
                case 8:
                 break label$33;
                case 3:
                 break label$34;
                case 0:
                 break label$35;
                case 1:
                case 2:
                case 4:
                case 6:
                case 7:
                 break label$36;
                default:
                 break label$39;
                };
               }
               $2 = $12 | 2048;
               break label$31;
              }
              $2 = $4 & 254 | $2 & -62976 | 1;
              break label$31;
             }
             $3 = $3 & -256 | 7;
             HEAP8[$1 | 0] = $3;
             HEAP8[$1 + 1 | 0] = $3 >>> 8;
             HEAP8[$1 + 2 | 0] = $3 >>> 16;
             HEAP8[$1 + 3 | 0] = $3 >>> 24;
             $2 = $2 & -62721;
             HEAP8[$1 + 4 | 0] = $2;
             HEAP8[$1 + 5 | 0] = $2 >>> 8;
             HEAP8[$1 + 6 | 0] = $2 >>> 16;
             HEAP8[$1 + 7 | 0] = $2 >>> 24;
             break label$1;
            }
            $3 = $3 & -256 | 5;
            HEAP8[$1 | 0] = $3;
            HEAP8[$1 + 1 | 0] = $3 >>> 8;
            HEAP8[$1 + 2 | 0] = $3 >>> 16;
            HEAP8[$1 + 3 | 0] = $3 >>> 24;
            $2 = $2 & -62721;
            HEAP8[$1 + 4 | 0] = $2;
            HEAP8[$1 + 5 | 0] = $2 >>> 8;
            HEAP8[$1 + 6 | 0] = $2 >>> 16;
            HEAP8[$1 + 7 | 0] = $2 >>> 24;
            $7 = $7 + 1 | 0;
            break label$2;
           }
           $3 = $3 & -256 | 4;
           HEAP8[$1 | 0] = $3;
           HEAP8[$1 + 1 | 0] = $3 >>> 8;
           HEAP8[$1 + 2 | 0] = $3 >>> 16;
           HEAP8[$1 + 3 | 0] = $3 >>> 24;
           $2 = $2 & -62721;
           HEAP8[$1 + 4 | 0] = $2;
           HEAP8[$1 + 5 | 0] = $2 >>> 8;
           HEAP8[$1 + 6 | 0] = $2 >>> 16;
           HEAP8[$1 + 7 | 0] = $2 >>> 24;
           $7 = $7 + 1 | 0;
           break label$2;
          }
          $4 = $4 & 223 | $2 & -62976 | 32;
          $2 = $4;
          HEAP8[$1 | 0] = $3;
          HEAP8[$1 + 1 | 0] = $6 >>> 8;
          HEAP8[$1 + 2 | 0] = $6 >>> 16;
          HEAP8[$1 + 3 | 0] = $6 >>> 24;
          HEAP8[$1 + 4 | 0] = $2;
          HEAP8[$1 + 5 | 0] = $2 >>> 8;
          HEAP8[$1 + 6 | 0] = $2 >>> 16;
          HEAP8[$1 + 7 | 0] = $2 >>> 24;
         }
         $2 = $2 & -65281 | 4096;
        }
        HEAP8[$1 | 0] = $3;
        HEAP8[$1 + 1 | 0] = $3 >>> 8;
        HEAP8[$1 + 2 | 0] = $3 >>> 16;
        HEAP8[$1 + 3 | 0] = $3 >>> 24;
        HEAP8[$1 + 4 | 0] = $2;
        HEAP8[$1 + 5 | 0] = $2 >>> 8;
        HEAP8[$1 + 6 | 0] = $2 >>> 16;
        HEAP8[$1 + 7 | 0] = $2 >>> 24;
       }
       label$40 : {
        label$41 : {
         label$42 : {
          label$43 : {
           if (($5 | 0) != 72) {
            if (($5 | 0) == 122) {
             break label$43
            }
            if (($5 | 0) == 108) {
             break label$42
            }
            if (($5 | 0) == 116) {
             break label$41
            }
            if (($5 | 0) != 76) {
             break label$40
            }
            $3 = $3 & -256;
            $6 = 8;
            $4 = 0;
            break label$27;
           }
           $6 = $3 & -256;
           $4 = $2;
           $2 = 0;
           $3 = ($4 & 1) + 11 | 0;
           if ($3 >>> 0 < 11) {
            $2 = 1
           }
           break label$27;
          }
          $3 = $3 & -256;
          $6 = 17;
          $4 = 0;
          break label$27;
         }
         $6 = $3 & -256;
         $5 = 0;
         $4 = $2;
         $2 = ($2 & 1) + 9 | 0;
         if ($2 >>> 0 < 9) {
          $5 = 1
         }
         $3 = $2;
         $2 = $5;
         break label$27;
        }
        $3 = $3 & -256;
        $6 = 18;
        $4 = 0;
        break label$27;
       }
       $4 = $2 & 1;
       if (($5 | 0) != 104) {
        break label$28
       }
       $3 = $3 & -256;
       $6 = $4 + 13 | 0;
       $4 = 0;
       break label$27;
      }
      $3 = $3 & -256 | 6;
      HEAP8[$1 | 0] = $3;
      HEAP8[$1 + 1 | 0] = $3 >>> 8;
      HEAP8[$1 + 2 | 0] = $3 >>> 16;
      HEAP8[$1 + 3 | 0] = $3 >>> 24;
      $2 = $2 & -62721;
      HEAP8[$1 + 4 | 0] = $2;
      HEAP8[$1 + 5 | 0] = $2 >>> 8;
      HEAP8[$1 + 6 | 0] = $2 >>> 16;
      HEAP8[$1 + 7 | 0] = $2 >>> 24;
      $7 = $7 + 1 | 0;
      break label$2;
     }
     $3 = $3 & -256;
     $6 = $4 + 15 | 0;
     $4 = 0;
    }
    $3 = $3 | $6;
    HEAP8[$1 | 0] = $3;
    HEAP8[$1 + 1 | 0] = $3 >>> 8;
    HEAP8[$1 + 2 | 0] = $3 >>> 16;
    HEAP8[$1 + 3 | 0] = $3 >>> 24;
    $2 = $2 | $4;
    HEAP8[$1 + 4 | 0] = $2;
    HEAP8[$1 + 5 | 0] = $2 >>> 8;
    HEAP8[$1 + 6 | 0] = $2 >>> 16;
    HEAP8[$1 + 7 | 0] = $2 >>> 24;
    $7 = $7 + 1 | 0;
   }
   HEAP32[$11 + 12 >> 2] = $7;
  }
  global$0 = $8 + 16 | 0;
  return $7 - $0 | 0;
 }

 function set_field_width($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0;
  $3 = (HEAPU8[$0 | 0] | HEAPU8[$0 + 1 | 0] << 8 | (HEAPU8[$0 + 2 | 0] << 16 | HEAPU8[$0 + 3 | 0] << 24)) & 255;
  $2 = HEAPU8[$0 + 4 | 0] | HEAPU8[$0 + 5 | 0] << 8 | (HEAPU8[$0 + 6 | 0] << 16 | HEAPU8[$0 + 7 | 0] << 24);
  $4 = $0;
  if (($1 | 0) == $1 << 8 >> 8) {
   $1 = $1 << 8
  } else {
   $1 = ($1 | 0) > -8388607 ? $1 : -8388607;
   $1 = (($1 | 0) < 8388607 ? $1 : 8388607) << 8;
  }
  $1 = $1 | $3;
  HEAP8[$4 | 0] = $1;
  HEAP8[$0 + 1 | 0] = $1 >>> 8;
  HEAP8[$0 + 2 | 0] = $1 >>> 16;
  HEAP8[$0 + 3 | 0] = $1 >>> 24;
  HEAP8[$0 + 4 | 0] = $2;
  HEAP8[$0 + 5 | 0] = $2 >>> 8;
  HEAP8[$0 + 6 | 0] = $2 >>> 16;
  HEAP8[$0 + 7 | 0] = $2 >>> 24;
 }

 function set_precision($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0;
  $2 = HEAPU8[$0 | 0] | HEAPU8[$0 + 1 | 0] << 8 | (HEAPU8[$0 + 2 | 0] << 16 | HEAPU8[$0 + 3 | 0] << 24);
  $4 = (HEAPU8[$0 + 4 | 0] | HEAPU8[$0 + 5 | 0] << 8 | (HEAPU8[$0 + 6 | 0] << 16 | HEAPU8[$0 + 7 | 0] << 24)) & 65535;
  $3 = $1;
  $1 = $1 << 16;
  if (($3 | 0) != $1 >> 16) {
   $1 = ($3 | 0) > 0 ? $3 : 0;
   $1 = (($1 | 0) < 32767 ? $1 : 32767) << 16;
  }
  HEAP8[$0 | 0] = $2;
  HEAP8[$0 + 1 | 0] = $2 >>> 8;
  HEAP8[$0 + 2 | 0] = $2 >>> 16;
  HEAP8[$0 + 3 | 0] = $2 >>> 24;
  $1 = $1 | $4;
  HEAP8[$0 + 4 | 0] = $1;
  HEAP8[$0 + 5 | 0] = $1 >>> 8;
  HEAP8[$0 + 6 | 0] = $1 >>> 16;
  HEAP8[$0 + 7 | 0] = $1 >>> 24;
 }

 function string($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0;
  $4 = global$0 - 16 | 0;
  global$0 = $4;
  $7 = $2 >>> 0 < 65536 ? 32080 : $2;
  $8 = (HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24)) >> 16;
  $2 = 0;
  while (1) {
   label$1 : {
    $5 = $0 + $2 | 0;
    if (($2 | 0) == ($8 | 0)) {
     break label$1
    }
    $6 = HEAPU8[$2 + $7 | 0];
    if (!$6) {
     break label$1
    }
    if ($5 >>> 0 < $1 >>> 0) {
     HEAP8[$5 | 0] = $6
    }
    $2 = $2 + 1 | 0;
    continue;
   }
   break;
  };
  $0 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
  HEAP32[$4 + 8 >> 2] = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
  HEAP32[$4 + 12 >> 2] = $0;
  $0 = widen_string($5, $2, $1, $4 + 8 | 0);
  global$0 = $4 + 16 | 0;
  return $0;
 }

 function pointer($0, $1, $2, $3, $4) {
  var $5 = 0, $6 = 0, $7 = 0;
  $5 = global$0 - 192 | 0;
  global$0 = $5;
  $6 = HEAP8[$0 | 0];
  label$1 : {
   label$2 : {
    if ($3) {
     break label$2
    }
    $7 = $6 & 255;
    if (($7 | 0) == 75 | ($7 | 0) == 120) {
     break label$2
    }
    $0 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
    $3 = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
    if ($3 >> 8 == -1) {
     $3 = $3 & 255 | 2048;
     HEAP8[$4 | 0] = $3;
     HEAP8[$4 + 1 | 0] = $3 >>> 8;
     HEAP8[$4 + 2 | 0] = $3 >>> 16;
     HEAP8[$4 + 3 | 0] = $3 >>> 24;
     HEAP8[$4 + 4 | 0] = $0;
     HEAP8[$4 + 5 | 0] = $0 >>> 8;
     HEAP8[$4 + 6 | 0] = $0 >>> 16;
     HEAP8[$4 + 7 | 0] = $0 >>> 24;
    }
    $0 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
    HEAP32[$5 + 8 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
    HEAP32[$5 + 12 >> 2] = $0;
    $0 = string($1, $2, 32080, $5 + 8 | 0);
    break label$1;
   }
   label$4 : {
    label$5 : {
     label$6 : {
      label$7 : {
       label$8 : {
        label$9 : {
         label$10 : {
          $6 = $6 + -66 | 0;
          if ($6 >>> 0 > 54) {
           break label$10
          }
          label$11 : {
           switch ($6 - 1 | 0) {
           default:
            $6 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
            HEAP32[$5 + 24 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
            HEAP32[$5 + 28 >> 2] = $6;
            $0 = symbol_string($1, $2, $3, $5 + 24 | 0, $0);
            break label$1;
           case 6:
           case 38:
            $6 = HEAP8[$0 + 1 | 0];
            if (($6 | 0) == 52) {
             break label$8
            }
            if (($6 | 0) == 83) {
             break label$7
            }
            if (($6 | 0) != 54) {
             break label$10
            }
            $6 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
            HEAP32[$5 + 72 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
            HEAP32[$5 + 76 >> 2] = $6;
            $0 = ip6_addr_string($1, $2, $3, $5 + 72 | 0, $0);
            break label$1;
           case 10:
           case 42:
            $6 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
            HEAP32[$5 + 64 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
            HEAP32[$5 + 68 >> 2] = $6;
            $0 = mac_address_string($1, $2, $3, $5 - -64 | 0, $0);
            break label$1;
           case 15:
           case 47:
            $6 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
            HEAP32[$5 + 32 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
            HEAP32[$5 + 36 >> 2] = $6;
            $0 = resource_string($1, $2, $3, $5 + 32 | 0, $0);
            break label$1;
           case 0:
            $0 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
            HEAP32[$5 + 152 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
            HEAP32[$5 + 156 >> 2] = $0;
            $0 = clock($1, $2, $5 + 152 | 0);
            break label$1;
           case 1:
            $3 = HEAP32[$3 + 12 >> 2];
            $6 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
            HEAP32[$5 + 160 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
            HEAP32[$5 + 164 >> 2] = $6;
            $0 = dentry_name($1, $2, $3, $5 + 160 | 0, $0);
            break label$1;
           case 2:
            $6 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
            HEAP32[$5 + 112 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
            HEAP32[$5 + 116 >> 2] = $6;
            $0 = escaped_string($1, $2, $3, $5 + 112 | 0, $0);
            break label$1;
           case 8:
            if (!HEAP32[34968]) {
             break label$10
            }
            $0 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
            HEAP32[$5 + 128 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
            HEAP32[$5 + 132 >> 2] = $0;
            $0 = restricted_pointer($1, $2, $3, $5 + 128 | 0);
            break label$1;
           case 18:
            $6 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
            HEAP32[$5 + 120 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
            HEAP32[$5 + 124 >> 2] = $6;
            $0 = uuid_string($1, $2, $3, $5 + 120 | 0, $0);
            break label$1;
           case 19:
            HEAP32[$5 + 188 >> 2] = HEAP32[HEAP32[$3 + 4 >> 2] >> 2];
            $0 = vsnprintf($1, $2 >>> 0 > $1 >>> 0 ? $2 - $1 | 0 : 0, HEAP32[$3 >> 2], HEAP32[$5 + 188 >> 2]) + $1 | 0;
            break label$1;
           case 31:
            if (HEAPU8[$0 + 1 | 0] != 108) {
             break label$6
            }
            $0 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
            HEAP32[$5 + 48 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
            HEAP32[$5 + 52 >> 2] = $0;
            $0 = bitmap_list_string($1, $2, $3, $5 + 48 | 0);
            break label$1;
           case 33:
            $6 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
            HEAP32[$5 + 144 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
            HEAP32[$5 + 148 >> 2] = $6;
            $0 = dentry_name($1, $2, $3, $5 + 144 | 0, $0);
            break label$1;
           case 37:
            $6 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
            HEAP32[$5 + 40 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
            HEAP32[$5 + 44 >> 2] = $6;
            $0 = hex_string($1, $2, $3, $5 + 40 | 0, $0);
            break label$1;
           case 53:
            $0 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
            HEAP32[$5 + 176 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
            HEAP32[$5 + 180 >> 2] = $0;
            $0 = pointer_string($1, $2, $3, $5 + 176 | 0);
            break label$1;
           case 4:
            $0 = flags_string($1, $2, $3, $0);
            break label$1;
           case 11:
            $6 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
            HEAP32[$5 + 136 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
            HEAP32[$5 + 140 >> 2] = $6;
            $0 = netdev_bits($1, $2, $3, $5 + 136 | 0, $0);
            break label$1;
           case 5:
           case 7:
           case 9:
           case 13:
           case 14:
           case 17:
           case 20:
           case 21:
           case 22:
           case 23:
           case 24:
           case 25:
           case 26:
           case 27:
           case 28:
           case 29:
           case 32:
           case 34:
           case 36:
           case 39:
           case 40:
           case 41:
           case 43:
           case 44:
           case 45:
           case 46:
           case 49:
           case 50:
           case 51:
           case 52:
            break label$10;
           case 12:
            break label$11;
           case 30:
            break label$9;
           };
          }
          if (HEAPU8[$0 + 1 | 0] != 70) {
           break label$10
          }
          $0 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
          HEAP32[$5 + 168 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
          HEAP32[$5 + 172 >> 2] = $0;
          $0 = device_node_string($1, $2, $5 + 168 | 0);
          break label$1;
         }
         $0 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
         HEAP32[$5 + 16 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
         HEAP32[$5 + 20 >> 2] = $0;
         $0 = ptr_to_id($1, $2, $3, $5 + 16 | 0);
         break label$1;
        }
        $0 = special_hex_number($1, $2, HEAP32[$3 >> 2], 0, 4);
        break label$1;
       }
       $6 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
       HEAP32[$5 + 80 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
       HEAP32[$5 + 84 >> 2] = $6;
       $0 = ip4_addr_string($1, $2, $3, $5 + 80 | 0, $0);
       break label$1;
      }
      $6 = HEAPU16[$3 >> 1];
      if (($6 | 0) == 10) {
       break label$5
      }
      if (($6 | 0) != 2) {
       break label$4
      }
      $6 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
      HEAP32[$5 + 96 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
      HEAP32[$5 + 100 >> 2] = $6;
      $0 = ip4_addr_string_sa($1, $2, $3, $5 + 96 | 0, $0);
      break label$1;
     }
     $0 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
     HEAP32[$5 + 56 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
     HEAP32[$5 + 60 >> 2] = $0;
     $0 = bitmap_string($1, $2, $3, $5 + 56 | 0);
     break label$1;
    }
    $6 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
    HEAP32[$5 + 104 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
    HEAP32[$5 + 108 >> 2] = $6;
    $0 = ip6_addr_string_sa($1, $2, $3, $5 + 104 | 0, $0);
    break label$1;
   }
   $0 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
   HEAP32[$5 + 88 >> 2] = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
   HEAP32[$5 + 92 >> 2] = $0;
   $0 = string($1, $2, 32296, $5 + 88 | 0);
  }
  global$0 = $5 + 192 | 0;
  return $0;
 }

 function number($0, $1, $2, $3, $4) {
  var $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0, $15 = 0, $16 = 0, $17 = 0, $18 = 0;
  $12 = global$0 - 32 | 0;
  global$0 = $12;
  $5 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
  $11 = ($5 & 65280) != 2560;
  $13 = ($5 & 64) >>> 6 | 0;
  $10 = HEAPU8[$4 | 0] | HEAPU8[$4 + 1 | 0] << 8 | (HEAPU8[$4 + 2 | 0] << 16 | HEAPU8[$4 + 3 | 0] << 24);
  $9 = $10 >> 8;
  $15 = $5;
  $8 = $5;
  $6 = $5;
  if ($5 & 2) {
   $6 = $5 & -17;
   $15 = $6;
   $7 = $10;
   HEAP8[$4 | 0] = $7;
   HEAP8[$4 + 1 | 0] = $7 >>> 8;
   HEAP8[$4 + 2 | 0] = $7 >>> 16;
   HEAP8[$4 + 3 | 0] = $7 >>> 24;
   HEAP8[$4 + 4 | 0] = $6;
   HEAP8[$4 + 5 | 0] = $6 >>> 8;
   HEAP8[$4 + 6 | 0] = $6 >>> 16;
   HEAP8[$4 + 7 | 0] = $6 >>> 24;
   $7 = 0;
  } else {
   $7 = 0
  }
  $16 = $11 & $13;
  $11 = 0;
  label$2 : {
   label$3 : {
    if (!($6 & 1)) {
     break label$3
    }
    label$4 : {
     if (!(($3 | 0) < -1 ? 1 : ($3 | 0) <= -1 ? ($2 >>> 0 > 4294967295 ? 0 : 1) : 0)) {
      if ($6 & 4) {
       break label$4
      }
      $9 = ($6 << 28 >> 31) + $9 | 0;
      $11 = $6 << 2 & 32;
      break label$3;
     }
     $9 = $9 + -1 | 0;
     $6 = 0 - $2 | 0;
     $11 = 45;
     $7 = 0 - ($3 + (0 < $2 >>> 0) | 0) | 0;
     break label$2;
    }
    $9 = $9 + -1 | 0;
    $11 = 43;
   }
   $6 = $2;
   $7 = $3;
  }
  $10 = $5 >> 16;
  label$6 : {
   if (!$16) {
    break label$6
   }
   if (($15 & 65280) == 4096) {
    $9 = $9 + -2 | 0;
    break label$6;
   }
   $9 = $9 - (($2 | 0) != 0 | ($3 | 0) != 0) | 0;
  }
  $13 = $8 & 32;
  $5 = $15 >>> 8 | 0;
  label$8 : {
   if (!(!$7 & $6 >>> 0 >= ($5 & 255) >>> 0 | $7 >>> 0 > 0)) {
    HEAP8[$12 + 8 | 0] = $13 | HEAPU8[$6 + 31648 | 0];
    $8 = 1;
    break label$8;
   }
   $14 = $5 & 255;
   if (($14 | 0) == 10) {
    $8 = put_dec($12 + 8 | 0, $6, $7) - ($12 + 8 | 0) | 0;
    break label$8;
   }
   $14 = ($14 | 0) == 16 ? 4 : 3;
   $17 = $5 + -1 & 255;
   $8 = 0;
   while (1) {
    HEAP8[($12 + 8 | 0) + $8 | 0] = $13 | HEAPU8[($6 & $17) + 31648 | 0];
    $8 = $8 + 1 | 0;
    $5 = $7;
    $18 = $6;
    $6 = $14 & 31;
    if (32 <= ($14 & 63) >>> 0) {
     $7 = 0;
     $6 = $5 >>> $6 | 0;
    } else {
     $7 = $5 >>> $6 | 0;
     $6 = ((1 << $6) - 1 & $5) << 32 - $6 | $18 >>> $6;
    }
    if ($6 | $7) {
     continue
    }
    break;
   };
  }
  $10 = ($8 | 0) > ($10 | 0) ? $8 : $10;
  $5 = $9 - $10 | 0;
  if (!($15 & 18)) {
   while (1) {
    if (($5 | 0) >= 1) {
     if ($0 >>> 0 < $1 >>> 0) {
      HEAP8[$0 | 0] = 32
     }
     $5 = $5 + -1 | 0;
     $0 = $0 + 1 | 0;
     continue;
    }
    break;
   };
   $5 = $5 + -1 | 0;
  }
  if ($11) {
   if ($0 >>> 0 < $1 >>> 0) {
    HEAP8[$0 | 0] = $11
   }
   $0 = $0 + 1 | 0;
  }
  label$18 : {
   if (!$16) {
    break label$18
   }
   $7 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
   label$19 : {
    if (($7 & 65280) != 4096) {
     if (!($2 | $3)) {
      break label$19
     }
    }
    if ($0 >>> 0 < $1 >>> 0) {
     HEAP8[$0 | 0] = 48;
     $7 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
    }
    $0 = $0 + 1 | 0;
   }
   if (($7 & 65280) != 4096) {
    break label$18
   }
   if ($0 >>> 0 < $1 >>> 0) {
    HEAP8[$0 | 0] = $13 | 88
   }
   $0 = $0 + 1 | 0;
  }
  $2 = HEAPU8[$4 + 4 | 0] | HEAPU8[$4 + 5 | 0] << 8 | (HEAPU8[$4 + 6 | 0] << 16 | HEAPU8[$4 + 7 | 0] << 24);
  if (!($2 & 2)) {
   $2 = $2 & 16 | 32;
   while (1) {
    if (($5 | 0) >= 1) {
     if ($0 >>> 0 < $1 >>> 0) {
      HEAP8[$0 | 0] = $2
     }
     $5 = $5 + -1 | 0;
     $0 = $0 + 1 | 0;
     continue;
    }
    break;
   };
   $5 = $5 + -1 | 0;
  }
  while (1) {
   if (($8 | 0) < ($10 | 0)) {
    if ($0 >>> 0 < $1 >>> 0) {
     HEAP8[$0 | 0] = 48
    }
    $10 = $10 + -1 | 0;
    $0 = $0 + 1 | 0;
    continue;
   }
   break;
  };
  $2 = $12 + 7 | 0;
  while (1) {
   if (($8 | 0) > 0) {
    if ($0 >>> 0 < $1 >>> 0) {
     HEAP8[$0 | 0] = HEAPU8[$2 + $8 | 0]
    }
    $8 = $8 + -1 | 0;
    $0 = $0 + 1 | 0;
    continue;
   }
   break;
  };
  while (1) {
   if (($5 | 0) >= 1) {
    if ($0 >>> 0 < $1 >>> 0) {
     HEAP8[$0 | 0] = 32
    }
    $5 = $5 + -1 | 0;
    $0 = $0 + 1 | 0;
    continue;
   }
   break;
  };
  global$0 = $12 + 32 | 0;
  return $0;
 }

 function skip_atoi($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  $1 = HEAP32[$0 >> 2] + 1 | 0;
  while (1) {
   HEAP32[$0 >> 2] = $1;
   $2 = (HEAP8[$1 + -1 | 0] + Math_imul($2, 10) | 0) + -48 | 0;
   $3 = HEAP8[$1 | 0];
   $1 = $1 + 1 | 0;
   if ($3 + -48 >>> 0 < 10) {
    continue
   }
   break;
  };
  return $2;
 }

 function widen_string($0, $1, $2, $3) {
  var $4 = 0;
  $4 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
  label$1 : {
   $3 = (HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24)) >> 8;
   if (($3 | 0) <= ($1 | 0)) {
    break label$1
   }
   label$2 : {
    label$3 : {
     if (!($4 & 2)) {
      $3 = $3 - $1 | 0;
      $4 = $0 - $1 | 0;
      if ($4 >>> 0 >= $2 >>> 0) {
       break label$2
      }
      $2 = $2 - $4 | 0;
      if ($2 >>> 0 <= $3 >>> 0) {
       break label$3
      }
      if ($1) {
       $2 = $2 - $3 | 0;
       memmove($3 + $4 | 0, $4, $2 >>> 0 < $1 >>> 0 ? $2 : $1);
      }
      memset($4, 32, $3);
      break label$2;
     }
     $1 = $1 - $3 | 0;
     while (1) {
      if (!$1) {
       break label$1
      }
      if ($0 >>> 0 < $2 >>> 0) {
       HEAP8[$0 | 0] = 32
      }
      $1 = $1 + 1 | 0;
      $0 = $0 + 1 | 0;
      continue;
     };
    }
    memset($4, 32, $2);
   }
   return $0 + $3 | 0;
  }
  return $0;
 }

 function symbol_string($0, $1, $2, $3, $4) {
  var $5 = 0;
  $5 = global$0 - 240 | 0;
  global$0 = $5;
  label$1 : {
   label$2 : {
    $4 = HEAPU8[$4 | 0];
    if (!(($4 | 0) == 115 | ($4 | 0) == 102)) {
     if (($4 | 0) != 66) {
      break label$2
     }
     __sprint_symbol($5 + 16 | 0, $2, -1, 1);
     break label$1;
    }
    __sprint_symbol($5 + 16 | 0, $2, 0, 0);
    break label$1;
   }
   __sprint_symbol($5 + 16 | 0, $2, 0, 1);
  }
  $2 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
  HEAP32[$5 + 8 >> 2] = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
  HEAP32[$5 + 12 >> 2] = $2;
  $0 = string($0, $1, $5 + 16 | 0, $5 + 8 | 0);
  global$0 = $5 + 240 | 0;
  return $0;
 }

 function ip6_addr_string($0, $1, $2, $3, $4) {
  var $5 = 0;
  $5 = global$0 + -64 | 0;
  global$0 = $5;
  label$1 : {
   if (!(HEAPU8[$4 | 0] != 73 | HEAPU8[$4 + 2 | 0] != 99)) {
    ip6_compressed_string($5 + 16 | 0, $2);
    break label$1;
   }
   ip6_string($5 + 16 | 0, $2, $4);
  }
  $2 = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
  $3 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
  HEAP32[$5 + 8 >> 2] = $2;
  HEAP32[$5 + 12 >> 2] = $3;
  $0 = string($0, $1, $5 + 16 | 0, $5 + 8 | 0);
  global$0 = $5 - -64 | 0;
  return $0;
 }

 function mac_address_string($0, $1, $2, $3, $4) {
  var $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0;
  $6 = global$0 - 48 | 0;
  global$0 = $6;
  $5 = HEAP8[$4 + 1 | 0];
  label$1 : {
   if (($5 | 0) != 70) {
    $11 = ($5 | 0) == 82 ? 1 : 0;
    $10 = 58;
    break label$1;
   }
   $10 = 45;
  }
  $8 = 5;
  $7 = $6 + 16 | 0;
  while (1) {
   if (!(($9 | 0) == 6)) {
    $5 = HEAPU8[($11 ? $8 : $9) + $2 | 0];
    HEAP8[$7 + 1 | 0] = HEAPU8[($5 & 15) + 31616 | 0];
    HEAP8[$7 | 0] = HEAPU8[($5 >>> 4 | 0) + 31616 | 0];
    $5 = $7 + 2 | 0;
    if (!(!$8 | HEAPU8[$4 | 0] != 77)) {
     HEAP8[$7 + 2 | 0] = $10;
     $5 = $7 + 3 | 0;
    }
    $8 = $8 + -1 | 0;
    $9 = $9 + 1 | 0;
    $7 = $5;
    continue;
   }
   break;
  };
  HEAP8[$7 | 0] = 0;
  $2 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
  HEAP32[$6 + 8 >> 2] = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
  HEAP32[$6 + 12 >> 2] = $2;
  $0 = string($0, $1, $6 + 16 | 0, $6 + 8 | 0);
  global$0 = $6 + 48 | 0;
  return $0;
 }

 function resource_string($0, $1, $2, $3, $4) {
  var $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0;
  $6 = global$0 - 176 | 0;
  global$0 = $6;
  HEAP8[$6 + 112 | 0] = 91;
  $9 = $6 + 112 | 1;
  $10 = HEAPU8[$4 | 0];
  $8 = $6 + 171 | 0;
  label$1 : {
   label$2 : {
    label$3 : {
     label$4 : {
      label$5 : {
       label$6 : {
        label$7 : {
         $7 = HEAP32[$2 + 12 >> 2];
         if (!($7 & 256)) {
          if ($7 & 512) {
           break label$7
          }
          $5 = 32421;
          $4 = 32356;
          if ($7 & 1024) {
           break label$5
          }
          $4 = 32361;
          if ($7 & 2048) {
           break label$5
          }
          if ($7 & 4096) {
           break label$6
          }
          $7 = 0;
          $4 = HEAPU8[32342] | HEAPU8[32343] << 8 | (HEAPU8[32344] << 16 | HEAPU8[32345] << 24);
          HEAP32[$6 + 80 >> 2] = HEAPU8[32338] | HEAPU8[32339] << 8 | (HEAPU8[32340] << 16 | HEAPU8[32341] << 24);
          HEAP32[$6 + 84 >> 2] = $4;
          $4 = string($9, $8, 32371, $6 + 80 | 0);
          $5 = 32322;
          break label$4;
         }
         $5 = 32314;
         $4 = 32346;
         break label$5;
        }
        $5 = 32322;
        $4 = 32351;
        break label$5;
       }
       $5 = 32330;
       $4 = 32366;
      }
      $7 = 0;
      $11 = HEAPU8[32342] | HEAPU8[32343] << 8 | (HEAPU8[32344] << 16 | HEAPU8[32345] << 24);
      HEAP32[$6 + 104 >> 2] = HEAPU8[32338] | HEAPU8[32339] << 8 | (HEAPU8[32340] << 16 | HEAPU8[32341] << 24);
      HEAP32[$6 + 108 >> 2] = $11;
      $4 = string($9, $8, $4, $6 + 104 | 0);
      if (($10 | 0) != 82) {
       break label$4
      }
      $7 = 1;
      if (HEAPU8[$2 + 15 | 0] & 32) {
       break label$3
      }
     }
     $9 = HEAP32[$2 >> 2];
     $10 = HEAPU8[$5 + 4 | 0] | HEAPU8[$5 + 5 | 0] << 8 | (HEAPU8[$5 + 6 | 0] << 16 | HEAPU8[$5 + 7 | 0] << 24);
     HEAP32[$6 + 72 >> 2] = HEAPU8[$5 | 0] | HEAPU8[$5 + 1 | 0] << 8 | (HEAPU8[$5 + 2 | 0] << 16 | HEAPU8[$5 + 3 | 0] << 24);
     HEAP32[$6 + 76 >> 2] = $10;
     $4 = number($4, $8, $9, 0, $6 + 72 | 0);
     if (HEAP32[$2 >> 2] != HEAP32[$2 + 4 >> 2]) {
      HEAP8[$4 | 0] = 45;
      $9 = HEAP32[$2 + 4 >> 2];
      $10 = HEAPU8[$5 + 4 | 0] | HEAPU8[$5 + 5 | 0] << 8 | (HEAPU8[$5 + 6 | 0] << 16 | HEAPU8[$5 + 7 | 0] << 24);
      HEAP32[$6 + 64 >> 2] = HEAPU8[$5 | 0] | HEAPU8[$5 + 1 | 0] << 8 | (HEAPU8[$5 + 2 | 0] << 16 | HEAPU8[$5 + 3 | 0] << 24);
      HEAP32[$6 + 68 >> 2] = $10;
      $4 = number($4 + 1 | 0, $8, $9, 0, $6 - -64 | 0);
     }
     $5 = $4;
     if ($7) {
      break label$2
     }
     $5 = HEAPU8[32342] | HEAPU8[32343] << 8 | (HEAPU8[32344] << 16 | HEAPU8[32345] << 24);
     HEAP32[$6 + 56 >> 2] = HEAPU8[32338] | HEAPU8[32339] << 8 | (HEAPU8[32340] << 16 | HEAPU8[32341] << 24);
     HEAP32[$6 + 60 >> 2] = $5;
     $4 = string($4, $8, 32413, $6 + 56 | 0);
     $2 = HEAP32[$2 + 12 >> 2];
     $5 = HEAPU8[32433] | HEAPU8[32434] << 8 | (HEAPU8[32435] << 16 | HEAPU8[32436] << 24);
     HEAP32[$6 + 48 >> 2] = HEAPU8[32429] | HEAPU8[32430] << 8 | (HEAPU8[32431] << 16 | HEAPU8[32432] << 24);
     HEAP32[$6 + 52 >> 2] = $5;
     $4 = number($4, $8, $2, 0, $6 + 48 | 0);
     break label$1;
    }
    $7 = HEAPU8[32342] | HEAPU8[32343] << 8 | (HEAPU8[32344] << 16 | HEAPU8[32345] << 24);
    HEAP32[$6 + 96 >> 2] = HEAPU8[32338] | HEAPU8[32339] << 8 | (HEAPU8[32340] << 16 | HEAPU8[32341] << 24);
    HEAP32[$6 + 100 >> 2] = $7;
    $4 = string($4, $8, 32376, $6 + 96 | 0);
    $7 = HEAP32[$2 >> 2];
    $9 = HEAP32[$2 + 4 >> 2];
    $10 = HEAPU8[$5 + 4 | 0] | HEAPU8[$5 + 5 | 0] << 8 | (HEAPU8[$5 + 6 | 0] << 16 | HEAPU8[$5 + 7 | 0] << 24);
    HEAP32[$6 + 88 >> 2] = HEAPU8[$5 | 0] | HEAPU8[$5 + 1 | 0] << 8 | (HEAPU8[$5 + 2 | 0] << 16 | HEAPU8[$5 + 3 | 0] << 24);
    HEAP32[$6 + 92 >> 2] = $10;
    $5 = number($4, $8, ($9 + 1 | 0) - $7 | 0, 0, $6 + 88 | 0);
   }
   $4 = $5;
   $7 = $2 + 12 | 0;
   $5 = HEAP32[$7 >> 2];
   if ($5 & 1048576) {
    $5 = HEAPU8[32342] | HEAPU8[32343] << 8 | (HEAPU8[32344] << 16 | HEAPU8[32345] << 24);
    HEAP32[$6 + 40 >> 2] = HEAPU8[32338] | HEAPU8[32339] << 8 | (HEAPU8[32340] << 16 | HEAPU8[32341] << 24);
    HEAP32[$6 + 44 >> 2] = $5;
    $4 = string($4, $8, 32382, $6 + 40 | 0);
    $5 = HEAP32[$7 >> 2];
   }
   if ($5 & 8192) {
    $5 = HEAPU8[32342] | HEAPU8[32343] << 8 | (HEAPU8[32344] << 16 | HEAPU8[32345] << 24);
    HEAP32[$6 + 32 >> 2] = HEAPU8[32338] | HEAPU8[32339] << 8 | (HEAPU8[32340] << 16 | HEAPU8[32341] << 24);
    HEAP32[$6 + 36 >> 2] = $5;
    $4 = string($4, $8, 32389, $6 + 32 | 0);
    $5 = HEAP32[$2 + 12 >> 2];
   }
   if ($5 & 2097152) {
    $5 = HEAPU8[32342] | HEAPU8[32343] << 8 | (HEAPU8[32344] << 16 | HEAPU8[32345] << 24);
    HEAP32[$6 + 24 >> 2] = HEAPU8[32338] | HEAPU8[32339] << 8 | (HEAPU8[32340] << 16 | HEAPU8[32341] << 24);
    HEAP32[$6 + 28 >> 2] = $5;
    $4 = string($4, $8, 32395, $6 + 24 | 0);
    $5 = HEAP32[$2 + 12 >> 2];
   }
   if (!($5 & 268435456)) {
    break label$1
   }
   $2 = HEAPU8[32342] | HEAPU8[32343] << 8 | (HEAPU8[32344] << 16 | HEAPU8[32345] << 24);
   HEAP32[$6 + 16 >> 2] = HEAPU8[32338] | HEAPU8[32339] << 8 | (HEAPU8[32340] << 16 | HEAPU8[32341] << 24);
   HEAP32[$6 + 20 >> 2] = $2;
   $4 = string($4, $8, 32403, $6 + 16 | 0);
  }
  HEAP8[$4 | 0] = 93;
  HEAP8[$4 + 1 | 0] = 0;
  $2 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
  HEAP32[$6 + 8 >> 2] = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
  HEAP32[$6 + 12 >> 2] = $2;
  $0 = string($0, $1, $6 + 112 | 0, $6 + 8 | 0);
  global$0 = $6 + 176 | 0;
  return $0;
 }

 function clock($0, $1, $2) {
  var $3 = 0, $4 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  $4 = HEAPU8[$2 | 0] | HEAPU8[$2 + 1 | 0] << 8 | (HEAPU8[$2 + 2 | 0] << 16 | HEAPU8[$2 + 3 | 0] << 24);
  $2 = HEAPU8[$2 + 4 | 0] | HEAPU8[$2 + 5 | 0] << 8 | (HEAPU8[$2 + 6 | 0] << 16 | HEAPU8[$2 + 7 | 0] << 24);
  HEAP32[$3 + 8 >> 2] = $4;
  HEAP32[$3 + 12 >> 2] = $2;
  $0 = string($0, $1, 0, $3 + 8 | 0);
  global$0 = $3 + 16 | 0;
  return $0;
 }

 function dentry_name($0, $1, $2, $3, $4) {
  var $5 = 0, $6 = 0, $7 = 0, $8 = 0;
  $5 = global$0 - 32 | 0;
  global$0 = $5;
  $4 = HEAP8[$4 + 1 | 0];
  $8 = $4 + -50 >>> 0 < 3 ? $4 + -48 | 0 : 1;
  $4 = 0;
  $6 = $5 + 16 | 0;
  label$1 : {
   while (1) {
    if (($4 | 0) >= ($8 | 0)) {
     break label$1
    }
    $7 = HEAP32[$2 + 16 >> 2];
    HEAP32[$6 >> 2] = HEAP32[$2 + 32 >> 2];
    if (($2 | 0) != ($7 | 0)) {
     $6 = $6 + 4 | 0;
     $4 = $4 + 1 | 0;
     $2 = $7;
     continue;
    }
    break;
   };
   if ($4) {
    HEAP32[$6 >> 2] = 32449
   }
   $4 = $4 + 1 | 0;
  }
  $7 = $4 + -1 | 0;
  $4 = HEAP32[($5 + 16 | 0) + ($7 << 2) >> 2];
  $2 = 0;
  while (1) {
   label$5 : {
    $6 = $0 + $2 | 0;
    if ((HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24)) >> 16 == ($2 | 0)) {
     break label$5
    }
    $8 = HEAPU8[$4 | 0];
    $4 = $4 + 1 | 0;
    label$7 : {
     if ($8) {
      break label$7
     }
     if (!$7) {
      break label$5
     }
     $8 = 47;
     $7 = $7 + -1 | 0;
     $4 = HEAP32[($5 + 16 | 0) + ($7 << 2) >> 2];
    }
    if ($6 >>> 0 < $1 >>> 0) {
     HEAP8[$6 | 0] = $8
    }
    $2 = $2 + 1 | 0;
    continue;
   }
   break;
  };
  $0 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
  HEAP32[$5 + 8 >> 2] = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
  HEAP32[$5 + 12 >> 2] = $0;
  $0 = widen_string($6, $2, $1, $5 + 8 | 0);
  global$0 = $5 + 32 | 0;
  return $0;
 }

 function escaped_string($0, $1, $2, $3, $4) {
  var $5 = 0, $6 = 0, $7 = 0, $8 = 0;
  $5 = global$0 - 16 | 0;
  global$0 = $5;
  $6 = (HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24)) >> 8;
  label$1 : {
   if (!$6) {
    break label$1
   }
   if ($2 >>> 0 < 17) {
    $2 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
    HEAP32[$5 + 8 >> 2] = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
    HEAP32[$5 + 12 >> 2] = $2;
    $0 = string($0, $1, 0, $5 + 8 | 0);
    break label$1;
   }
   $3 = $4 + 1 | 0;
   while (1) {
    label$3 : {
     $7 = HEAP8[$3 | 0];
     $4 = $7 + -104 | 0;
     label$5 : {
      if ($4 >>> 0 <= 11) {
       label$7 : {
        switch ($4 - 1 | 0) {
        case 5:
         $4 = 4;
         break label$5;
        case 6:
         $4 = 8;
         break label$5;
        case 7:
         $4 = 16;
         break label$5;
        case 10:
         $4 = 1;
         break label$5;
        case 0:
        case 1:
        case 2:
        case 3:
        case 4:
        case 8:
        case 9:
         break label$3;
        default:
         break label$7;
        };
       }
       $4 = 32;
       break label$5;
      }
      $4 = 15;
      if (($7 | 0) == 97) {
       break label$5
      }
      if (($7 | 0) != 99) {
       break label$3
      }
      $4 = 2;
     }
     $3 = $3 + 1 | 0;
     $8 = $4 | $8;
     continue;
    }
    break;
   };
   $0 = string_escape_mem($2, ($6 | 0) < 0 ? 1 : $6, $0, $0 >>> 0 < $1 >>> 0 ? $1 - $0 | 0 : 0, $8 ? $8 : 31) + $0 | 0;
  }
  global$0 = $5 + 16 | 0;
  return $0;
 }

 function restricted_pointer($0, $1, $2, $3) {
  var $4 = 0, $5 = 0;
  $5 = global$0 - 16 | 0;
  global$0 = $5;
  $4 = HEAP32[34968];
  label$1 : {
   label$2 : {
    if (!$4) {
     break label$2
    }
    if (($4 | 0) == 1) {
     if (HEAP32[1] & 1048576 ? 0 : !(HEAP32[1] & 983040 | HEAP32[1] & 256)) {
      break label$2
     }
     $2 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
     $4 = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
     if ($4 >> 8 == -1) {
      $4 = $4 & 255 | 2048;
      HEAP8[$3 | 0] = $4;
      HEAP8[$3 + 1 | 0] = $4 >>> 8;
      HEAP8[$3 + 2 | 0] = $4 >>> 16;
      HEAP8[$3 + 3 | 0] = $4 >>> 24;
      HEAP8[$3 + 4 | 0] = $2;
      HEAP8[$3 + 5 | 0] = $2 >>> 8;
      HEAP8[$3 + 6 | 0] = $2 >>> 16;
      HEAP8[$3 + 7 | 0] = $2 >>> 24;
     }
     $2 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
     HEAP32[$5 + 8 >> 2] = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
     HEAP32[$5 + 12 >> 2] = $2;
     $3 = string($0, $1, 32440, $5 + 8 | 0);
     break label$1;
    }
    $2 = 0;
   }
   $4 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
   HEAP32[$5 >> 2] = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
   HEAP32[$5 + 4 >> 2] = $4;
   $3 = pointer_string($0, $1, $2, $5);
  }
  global$0 = $5 + 16 | 0;
  return $3;
 }

 function uuid_string($0, $1, $2, $3, $4) {
  var $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0;
  $6 = global$0 + -64 | 0;
  global$0 = $6;
  $8 = 31760;
  $4 = HEAP8[$4 + 1 | 0];
  label$1 : {
   if (($4 | 0) != 66) {
    if (($4 | 0) != 108) {
     if (($4 | 0) != 76) {
      break label$1
     }
     $5 = 1;
    }
    $8 = 31744;
    break label$1;
   }
   $5 = 1;
  }
  $9 = $5 ? 31648 : 31616;
  $4 = 0;
  $5 = $6 + 16 | 0;
  while (1) {
   if (!(($4 | 0) == 16)) {
    $7 = HEAPU8[HEAPU8[$4 + $8 | 0] + $2 | 0];
    HEAP8[$5 + 1 | 0] = HEAPU8[($7 & 15) + $9 | 0];
    HEAP8[$5 | 0] = HEAPU8[($7 >>> 4 | 0) + $9 | 0];
    $7 = $5 + 2 | 0;
    if (!(!(1 << $4 & 680) | $4 >>> 0 > 9)) {
     HEAP8[$5 + 2 | 0] = 45;
     $7 = $5 + 3 | 0;
    }
    $4 = $4 + 1 | 0;
    $5 = $7;
    continue;
   }
   break;
  };
  HEAP8[$5 | 0] = 0;
  $2 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
  HEAP32[$6 + 8 >> 2] = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
  HEAP32[$6 + 12 >> 2] = $2;
  $0 = string($0, $1, $6 + 16 | 0, $6 + 8 | 0);
  global$0 = $6 - -64 | 0;
  return $0;
 }

 function bitmap_list_string($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0;
  $4 = global$0 - 16 | 0;
  global$0 = $4;
  $3 = (HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24)) >> 8;
  $6 = ($3 | 0) > 0 ? $3 : 0;
  $8 = find_next_bit($2, $6, 0);
  $9 = 1;
  while (1) {
   $3 = $8;
   label$2 : {
    while (1) {
     $7 = $3;
     if (($3 | 0) >= ($6 | 0)) {
      break label$2
     }
     $5 = $7 + 1 | 0;
     $3 = find_next_bit($2, $6, $5);
     if (($3 | 0) <= ($5 | 0) ? ($3 | 0) < ($6 | 0) : 0) {
      continue
     }
     break;
    };
    if (!$9) {
     if ($0 >>> 0 < $1 >>> 0) {
      HEAP8[$0 | 0] = 44
     }
     $0 = $0 + 1 | 0;
    }
    $9 = 0;
    $5 = HEAPU8[32425] | HEAPU8[32426] << 8 | (HEAPU8[32427] << 16 | HEAPU8[32428] << 24);
    HEAP32[$4 + 8 >> 2] = HEAPU8[32421] | HEAPU8[32422] << 8 | (HEAPU8[32423] << 16 | HEAPU8[32424] << 24);
    HEAP32[$4 + 12 >> 2] = $5;
    $5 = $8;
    $0 = number($0, $1, $5, $5 >> 31, $4 + 8 | 0);
    $8 = $3;
    if (($5 | 0) >= ($7 | 0)) {
     continue
    }
    if ($0 >>> 0 < $1 >>> 0) {
     HEAP8[$0 | 0] = 45
    }
    $3 = HEAPU8[32425] | HEAPU8[32426] << 8 | (HEAPU8[32427] << 16 | HEAPU8[32428] << 24);
    HEAP32[$4 >> 2] = HEAPU8[32421] | HEAPU8[32422] << 8 | (HEAPU8[32423] << 16 | HEAPU8[32424] << 24);
    HEAP32[$4 + 4 >> 2] = $3;
    $0 = number($0 + 1 | 0, $1, $7, $7 >> 31, $4);
    continue;
   }
   break;
  };
  global$0 = $4 + 16 | 0;
  return $0;
 }

 function hex_string($0, $1, $2, $3, $4) {
  var $5 = 0, $6 = 0, $7 = 0, $8 = 0;
  $6 = global$0 - 16 | 0;
  global$0 = $6;
  label$1 : {
   $5 = (HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24)) >> 8;
   if (!$5) {
    break label$1
   }
   if ($2 >>> 0 <= 16) {
    $2 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
    HEAP32[$6 + 8 >> 2] = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
    HEAP32[$6 + 12 >> 2] = $2;
    $0 = string($0, $1, 0, $6 + 8 | 0);
    break label$1;
   }
   label$3 : {
    label$4 : {
     label$5 : {
      $3 = HEAP8[$4 + 1 | 0];
      if (($3 | 0) != 67) {
       if (($3 | 0) == 78) {
        break label$5
       }
       if (($3 | 0) != 68) {
        break label$4
       }
       $4 = 45;
       break label$3;
      }
      $4 = 58;
      break label$3;
     }
     $4 = 0;
     break label$3;
    }
    $4 = 32;
   }
   $3 = 0;
   $7 = ($5 | 0) > 0 ? (($5 | 0) < 64 ? $5 : 64) : 1;
   $8 = $7 + -1 | 0;
   while (1) {
    if (($3 | 0) >= ($7 | 0)) {
     break label$1
    }
    if ($0 >>> 0 < $1 >>> 0) {
     HEAP8[$0 | 0] = HEAPU8[(HEAPU8[$2 + $3 | 0] >>> 4 | 0) + 31616 | 0]
    }
    $5 = $0 + 1 | 0;
    if ($5 >>> 0 < $1 >>> 0) {
     HEAP8[$5 | 0] = HEAPU8[(HEAPU8[$2 + $3 | 0] & 15) + 31616 | 0]
    }
    $5 = $0 + 2 | 0;
    label$10 : {
     if (!(!$4 | ($3 | 0) == ($8 | 0))) {
      if ($5 >>> 0 < $1 >>> 0) {
       HEAP8[$5 | 0] = $4
      }
      $0 = $0 + 3 | 0;
      break label$10;
     }
     $0 = $5;
    }
    $3 = $3 + 1 | 0;
    continue;
   };
  }
  global$0 = $6 + 16 | 0;
  return $0;
 }

 function pointer_string($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0;
  $7 = global$0 - 16 | 0;
  global$0 = $7;
  $8 = (HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24)) & -65313 | 4128;
  $6 = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
  $5 = $6;
  $6 = $5 >> 8 == -1;
  $5 = $6 ? $5 & 255 | 2048 : $5;
  $4 = $5;
  HEAP8[$3 | 0] = $4;
  HEAP8[$3 + 1 | 0] = $4 >>> 8;
  HEAP8[$3 + 2 | 0] = $4 >>> 16;
  HEAP8[$3 + 3 | 0] = $4 >>> 24;
  $4 = $6 ? $8 & -61201 | 16 : $8;
  HEAP8[$3 + 4 | 0] = $4;
  HEAP8[$3 + 5 | 0] = $4 >>> 8;
  HEAP8[$3 + 6 | 0] = $4 >>> 16;
  HEAP8[$3 + 7 | 0] = $4 >>> 24;
  $3 = $7;
  HEAP32[$3 + 8 >> 2] = $5;
  HEAP32[$3 + 12 >> 2] = $4;
  $0 = number($0, $1, $2, 0, $3 + 8 | 0);
  global$0 = $3 + 16 | 0;
  return $0;
 }

 function flags_string($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  $4 = global$0 - 16 | 0;
  global$0 = $4;
  label$1 : {
   label$2 : {
    label$3 : {
     $3 = HEAP8[$3 + 1 | 0];
     if (($3 | 0) != 103) {
      if (($3 | 0) == 118) {
       break label$3
      }
      if (($3 | 0) != 112) {
       break label$1
      }
      $3 = 24496;
      $2 = HEAP32[$2 >> 2] & 4194303;
      break label$2;
     }
     $3 = 25168;
     $2 = HEAP32[$2 >> 2];
     break label$2;
    }
    $3 = 25712;
    $2 = HEAP32[$2 >> 2];
   }
   while (1) {
    if (!$2) {
     break label$1
    }
    $6 = HEAP32[$3 + 4 >> 2];
    if ($6) {
     $5 = HEAP32[$3 >> 2];
     label$7 : {
      if (($5 | 0) != ($2 & $5)) {
       break label$7
      }
      $7 = HEAPU8[32454] | HEAPU8[32455] << 8 | (HEAPU8[32456] << 16 | HEAPU8[32457] << 24);
      HEAP32[$4 + 8 >> 2] = HEAPU8[32450] | HEAPU8[32451] << 8 | (HEAPU8[32452] << 16 | HEAPU8[32453] << 24);
      HEAP32[$4 + 12 >> 2] = $7;
      $0 = string($0, $1, $6, $4 + 8 | 0);
      $2 = ($5 ^ -1) & $2;
      if ($2) {
       if ($0 >>> 0 < $1 >>> 0) {
        HEAP8[$0 | 0] = 124
       }
       $0 = $0 + 1 | 0;
       break label$7;
      }
      $2 = 0;
     }
     $3 = $3 + 8 | 0;
     continue;
    }
    break;
   };
   $3 = HEAPU8[32433] | HEAPU8[32434] << 8 | (HEAPU8[32435] << 16 | HEAPU8[32436] << 24);
   HEAP32[$4 >> 2] = HEAPU8[32429] | HEAPU8[32430] << 8 | (HEAPU8[32431] << 16 | HEAPU8[32432] << 24);
   HEAP32[$4 + 4 >> 2] = $3;
   $0 = number($0, $1, $2, 0, $4);
  }
  global$0 = $4 + 16 | 0;
  return $0;
 }

 function netdev_bits($0, $1, $2, $3, $4) {
  var $5 = 0;
  $5 = global$0 - 16 | 0;
  global$0 = $5;
  label$1 : {
   if (HEAPU8[$4 + 1 | 0] == 70) {
    $0 = special_hex_number($0, $1, HEAP32[$2 >> 2], HEAP32[$2 + 4 >> 2], 8);
    break label$1;
   }
   $4 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
   HEAP32[$5 + 8 >> 2] = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
   HEAP32[$5 + 12 >> 2] = $4;
   $0 = ptr_to_id($0, $1, $2, $5 + 8 | 0);
  }
  global$0 = $5 + 16 | 0;
  return $0;
 }

 function device_node_string($0, $1, $2) {
  var $3 = 0, $4 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  $4 = HEAPU8[$2 | 0] | HEAPU8[$2 + 1 | 0] << 8 | (HEAPU8[$2 + 2 | 0] << 16 | HEAPU8[$2 + 3 | 0] << 24);
  $2 = HEAPU8[$2 + 4 | 0] | HEAPU8[$2 + 5 | 0] << 8 | (HEAPU8[$2 + 6 | 0] << 16 | HEAPU8[$2 + 7 | 0] << 24);
  HEAP32[$3 + 8 >> 2] = $4;
  HEAP32[$3 + 12 >> 2] = $2;
  $0 = string($0, $1, 32458, $3 + 8 | 0);
  global$0 = $3 + 16 | 0;
  return $0;
 }

 function ptr_to_id($0, $1, $2, $3) {
  var $4 = 0, $5 = 0;
  $4 = global$0 - 32 | 0;
  global$0 = $4;
  label$1 : {
   label$2 : {
    if (!HEAPU8[19920]) {
     if (HEAP32[4981] >= 1) {
      break label$2
     }
     $2 = siphash_1u32($2);
     $5 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
     HEAP32[$4 + 24 >> 2] = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
     HEAP32[$4 + 28 >> 2] = $5;
     $3 = pointer_string($0, $1, $2, $4 + 24 | 0);
     break label$1;
    }
    $5 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
    HEAP32[$4 + 8 >> 2] = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
    HEAP32[$4 + 12 >> 2] = $5;
    $3 = pointer_string($0, $1, Math_imul($2, 1640531527), $4 + 8 | 0);
    break label$1;
   }
   $5 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
   $2 = (HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24)) & 255 | 2048;
   HEAP8[$3 | 0] = $2;
   HEAP8[$3 + 1 | 0] = $2 >>> 8;
   HEAP8[$3 + 2 | 0] = $2 >>> 16;
   HEAP8[$3 + 3 | 0] = $2 >>> 24;
   HEAP8[$3 + 4 | 0] = $5;
   HEAP8[$3 + 5 | 0] = $5 >>> 8;
   HEAP8[$3 + 6 | 0] = $5 >>> 16;
   HEAP8[$3 + 7 | 0] = $5 >>> 24;
   HEAP32[$4 + 16 >> 2] = $2;
   HEAP32[$4 + 20 >> 2] = $5;
   $3 = string($0, $1, 32464, $4 + 16 | 0);
  }
  global$0 = $4 + 32 | 0;
  return $3;
 }

 function ip4_addr_string($0, $1, $2, $3, $4) {
  var $5 = 0;
  $5 = global$0 - 32 | 0;
  global$0 = $5;
  ip4_string($5 + 16 | 0, $2, $4);
  $2 = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
  $3 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
  HEAP32[$5 + 8 >> 2] = $2;
  HEAP32[$5 + 12 >> 2] = $3;
  $0 = string($0, $1, $5 + 16 | 0, $5 + 8 | 0);
  global$0 = $5 + 32 | 0;
  return $0;
 }

 function ip4_addr_string_sa($0, $1, $2, $3, $4) {
  var $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0;
  $5 = global$0 + -64 | 0;
  global$0 = $5;
  HEAP8[$5 + 30 | 0] = 52;
  HEAP8[$5 + 31 | 0] = 0;
  HEAP8[$5 + 29 | 0] = HEAPU8[$4 | 0];
  $4 = $4 + 1 | 0;
  $9 = $2 + 4 | 0;
  $10 = $5 + 31 | 0;
  while (1) {
   $4 = $4 + 1 | 0;
   $6 = HEAPU8[$4 | 0];
   if (HEAPU8[$6 + 31824 | 0] & 3) {
    $7 = __wasm_rotl_i32(($6 << 24 >> 24) + -98 | 0, 31);
    if ($7 >>> 0 > 7) {
     continue
    }
    if (1 << $7 & 105) {
     HEAP8[$10 | 0] = $6;
     continue;
    }
    if (($7 | 0) != 7) {
     continue
    }
    $8 = 1;
    continue;
   }
   break;
  };
  $4 = ip4_string($5 + 32 | 0, $9, $5 + 29 | 0);
  if ($8) {
   HEAP8[$4 | 0] = 58;
   $2 = HEAPU16[$2 + 2 >> 1];
   $8 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
   HEAP32[$5 + 16 >> 2] = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
   HEAP32[$5 + 20 >> 2] = $8;
   $4 = number($4 + 1 | 0, $5 + 55 | 0, ($2 << 8 & 16711680 | $2 << 24) >>> 16 | 0, 0, $5 + 16 | 0);
  }
  HEAP8[$4 | 0] = 0;
  $2 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
  HEAP32[$5 + 8 >> 2] = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
  HEAP32[$5 + 12 >> 2] = $2;
  $0 = string($0, $1, $5 + 32 | 0, $5 + 8 | 0);
  global$0 = $5 - -64 | 0;
  return $0;
 }

 function bitmap_string($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0;
  $6 = global$0 - 16 | 0;
  global$0 = $6;
  $5 = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
  HEAP8[$3 | 0] = 0;
  HEAP8[$3 + 1 | 0] = 0;
  HEAP8[$3 + 2 | 0] = 0;
  HEAP8[$3 + 3 | 0] = 0;
  HEAP8[$3 + 4 | 0] = 4144;
  HEAP8[$3 + 5 | 0] = 16;
  HEAP8[$3 + 6 | 0] = 0;
  HEAP8[$3 + 7 | 0] = 0;
  $4 = $5 >> 8;
  $5 = ($4 | 0) > 0 ? $4 : 0;
  $4 = $5 & 31;
  $4 = $4 ? $4 : 32;
  $7 = ($5 + 31 & 2147483616) + -32 | 0;
  $5 = 1;
  while (1) {
   if (!(($7 | 0) < 0)) {
    $8 = HEAP32[($7 >>> 3 & 536870908) + $2 >> 2] & ((32 <= ($4 & 63) >>> 0 ? 0 : -1 << ($4 & 31)) ^ -1);
    if (!$5) {
     if ($0 >>> 0 < $1 >>> 0) {
      HEAP8[$0 | 0] = 44
     }
     $0 = $0 + 1 | 0;
    }
    $5 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
    $4 = (HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24)) & 255 | ($4 + 3 | 0) / 4 << 8;
    HEAP8[$3 | 0] = $4;
    HEAP8[$3 + 1 | 0] = $4 >>> 8;
    HEAP8[$3 + 2 | 0] = $4 >>> 16;
    HEAP8[$3 + 3 | 0] = $4 >>> 24;
    HEAP8[$3 + 4 | 0] = $5;
    HEAP8[$3 + 5 | 0] = $5 >>> 8;
    HEAP8[$3 + 6 | 0] = $5 >>> 16;
    HEAP8[$3 + 7 | 0] = $5 >>> 24;
    HEAP32[$6 + 8 >> 2] = $4;
    HEAP32[$6 + 12 >> 2] = $5;
    $0 = number($0, $1, $8, 0, $6 + 8 | 0);
    $7 = $7 + -32 | 0;
    $4 = 32;
    $5 = 0;
    continue;
   }
   break;
  };
  global$0 = $6 + 16 | 0;
  return $0;
 }

 function ip6_addr_string_sa($0, $1, $2, $3, $4) {
  var $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0;
  $5 = global$0 - 128 | 0;
  global$0 = $5;
  HEAP8[$5 + 47 | 0] = 54;
  $11 = HEAPU8[$4 | 0];
  HEAP8[$5 + 46 | 0] = $11;
  $4 = $4 + 1 | 0;
  $8 = $2 + 8 | 0;
  while (1) {
   $6 = HEAPU8[$4 + 1 | 0];
   if (HEAPU8[$6 + 31824 | 0] & 3) {
    $4 = $4 + 1 | 0;
    label$3 : {
     label$4 : {
      $6 = $6 << 24 >> 24;
      if (($6 | 0) != 99) {
       if (($6 | 0) == 102) {
        break label$4
       }
       if (($6 | 0) == 112) {
        break label$3
       }
       if (($6 | 0) != 115) {
        continue
       }
       $9 = 1;
       continue;
      }
      $12 = 1;
      continue;
     }
     $10 = 1;
     continue;
    }
    $7 = 1;
    continue;
   }
   break;
  };
  $6 = $7 | $9 | $10;
  if ($6 & 1) {
   HEAP8[$5 + 48 | 0] = 91;
   $4 = 1;
  } else {
   $4 = 0
  }
  $4 = $4 | $5 + 48;
  label$7 : {
   if (!($12 ^ 1 | ($11 | 0) != 73)) {
    $4 = ip6_compressed_string($4, $8);
    break label$7;
   }
   $4 = ip6_string($4, $8, $5 + 46 | 0);
  }
  if ($6 & 1) {
   HEAP8[$4 | 0] = 93;
   $4 = $4 + 1 | 0;
  }
  $6 = $5 + 126 | 0;
  if ($7) {
   HEAP8[$4 | 0] = 58;
   $7 = HEAPU16[$2 + 2 >> 1];
   $8 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
   HEAP32[$5 + 32 >> 2] = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
   HEAP32[$5 + 36 >> 2] = $8;
   $4 = number($4 + 1 | 0, $6, ($7 << 8 & 16711680 | $7 << 24) >>> 16 | 0, 0, $5 + 32 | 0);
  }
  if ($10) {
   HEAP8[$4 | 0] = 47;
   $10 = HEAP32[$2 + 4 >> 2];
   $7 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
   HEAP32[$5 + 24 >> 2] = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
   HEAP32[$5 + 28 >> 2] = $7;
   $7 = $4 + 1 | 0;
   $4 = $10 & -241;
   $4 = number($7, $6, $4 << 24 | $4 << 8 & 16711680 | ($4 >>> 8 & 65280 | $4 >>> 24), 0, $5 + 24 | 0);
  }
  if ($9) {
   HEAP8[$4 | 0] = 37;
   $2 = HEAP32[$2 + 24 >> 2];
   $9 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
   HEAP32[$5 + 16 >> 2] = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
   HEAP32[$5 + 20 >> 2] = $9;
   $4 = number($4 + 1 | 0, $6, $2, 0, $5 + 16 | 0);
  }
  HEAP8[$4 | 0] = 0;
  $2 = HEAPU8[$3 + 4 | 0] | HEAPU8[$3 + 5 | 0] << 8 | (HEAPU8[$3 + 6 | 0] << 16 | HEAPU8[$3 + 7 | 0] << 24);
  HEAP32[$5 + 8 >> 2] = HEAPU8[$3 | 0] | HEAPU8[$3 + 1 | 0] << 8 | (HEAPU8[$3 + 2 | 0] << 16 | HEAPU8[$3 + 3 | 0] << 24);
  HEAP32[$5 + 12 >> 2] = $2;
  $0 = string($0, $1, $5 + 48 | 0, $5 + 8 | 0);
  global$0 = $5 + 128 | 0;
  return $0;
 }

 function vscnprintf($0, $1, $2, $3) {
  $0 = vsnprintf($0, $1, $2, $3);
  if ($0 >>> 0 < $1 >>> 0) {
   return $0
  }
  return $1 ? $1 + -1 | 0 : 0;
 }

 function snprintf($0, $1, $2, $3) {
  var $4 = 0;
  $4 = global$0 - 16 | 0;
  global$0 = $4;
  HEAP32[$4 + 12 >> 2] = $3;
  $0 = vsnprintf($0, $1, $2, $3);
  global$0 = $4 + 16 | 0;
  return $0;
 }

 function scnprintf($0, $1, $2, $3) {
  var $4 = 0;
  $4 = global$0 - 16 | 0;
  global$0 = $4;
  HEAP32[$4 + 12 >> 2] = $3;
  $0 = vscnprintf($0, $1, $2, $3);
  global$0 = $4 + 16 | 0;
  return $0;
 }

 function sprintf($0, $1, $2) {
  var $3 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  HEAP32[$3 + 12 >> 2] = $2;
  $0 = vsnprintf($0, 2147483647, $1, $2);
  global$0 = $3 + 16 | 0;
  return $0;
 }

 function ip6_compressed_string($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0;
  $4 = global$0 - 32 | 0;
  global$0 = $4;
  memcpy($4 + 8 | 0, $1, 16);
  $1 = HEAP32[$4 + 16 >> 2];
  label$1 : {
   label$2 : {
    if (HEAP32[$4 + 12 >> 2] | HEAP32[$4 + 8 >> 2] | $1 ^ -65536) {
     $8 = 8;
     memset($4 + 24 | 0, 0, 8);
     if (($1 | 2) == -27394046) {
      break label$2
     }
     break label$1;
    }
    memset($4 + 24 | 0, 0, 8);
   }
   $8 = 6;
   $10 = 1;
  }
  $2 = $4 + 8 | 0;
  while (1) {
   if (!(($5 | 0) == ($8 | 0))) {
    $6 = ($4 + 24 | 0) + $5 | 0;
    $3 = $2;
    $1 = $5;
    while (1) {
     if (!(HEAPU16[$3 >> 1] | $1 >>> 0 >= $8 >>> 0)) {
      HEAP8[$6 | 0] = HEAPU8[$6 | 0] + 1;
      $3 = $3 + 2 | 0;
      $1 = $1 + 1 | 0;
      continue;
     }
     break;
    };
    $2 = $2 + 2 | 0;
    $5 = $5 + 1 | 0;
    continue;
   }
   break;
  };
  $1 = 0;
  $5 = -1;
  $3 = 1;
  while (1) {
   if (!(($1 | 0) == ($8 | 0))) {
    $6 = HEAPU8[($4 + 24 | 0) + $1 | 0];
    $2 = $3 >>> 0 < $6 >>> 0;
    $5 = $2 ? $1 : $5;
    $3 = $2 ? $6 : $3;
    $1 = $1 + 1 | 0;
    continue;
   }
   break;
  };
  $9 = ($3 | 0) == 1 ? -1 : $5;
  $6 = ($9 + $3 | 0) + -1 | 0;
  $1 = 0;
  $3 = 0;
  while (1) {
   label$11 : {
    if (($1 | 0) < ($8 | 0)) {
     if (($1 | 0) == ($9 | 0)) {
      if (!(($3 ^ -1) & ($9 | 0) != 0)) {
       HEAP8[$0 | 0] = 58;
       $0 = $0 + 1 | 0;
      }
      HEAP8[$0 | 0] = 58;
      $0 = $0 + 1 | 0;
      $3 = 0;
      $1 = $6;
      break label$11;
     }
     if ($3 & 1) {
      HEAP8[$0 | 0] = 58;
      $0 = $0 + 1 | 0;
     }
     $2 = HEAPU16[($4 + 8 | 0) + ($1 << 1) >> 1];
     $2 = $2 << 24 | $2 << 8 & 16711680 | ($2 >>> 8 & 65280 | $2 >>> 24);
     $7 = $2 >>> 16 | 0;
     label$16 : {
      label$17 : {
       label$18 : {
        label$19 : {
         $2 = $2 >>> 24 | 0;
         if ($2) {
          if ($7 >>> 0 < 4096) {
           break label$19
          }
          HEAP8[$0 | 0] = HEAPU8[($2 >>> 4 | 0) + 31616 | 0];
          $5 = $2 & 15;
          $3 = 2;
          $2 = $0 + 1 | 0;
          break label$18;
         }
         $2 = $7 & 240;
         if (!$2) {
          break label$16
         }
         HEAP8[$0 + 1 | 0] = HEAPU8[($7 & 15) + 31616 | 0];
         HEAP8[$0 | 0] = HEAPU8[($2 >>> 4 | 0) + 31616 | 0];
         $0 = $0 + 2 | 0;
         break label$17;
        }
        $5 = $2 & 15;
        $3 = 1;
        $2 = $0;
       }
       HEAP8[$2 | 0] = HEAPU8[$5 + 31616 | 0];
       $0 = $0 + $3 | 0;
       HEAP8[$0 + 1 | 0] = HEAPU8[($7 & 15) + 31616 | 0];
       HEAP8[$0 | 0] = HEAPU8[(($7 & 240) >>> 4 | 0) + 31616 | 0];
       $0 = $0 + 2 | 0;
      }
      $3 = 1;
      break label$11;
     }
     HEAP8[$0 | 0] = HEAPU8[($7 & 15) + 31616 | 0];
     $3 = 1;
     $0 = $0 + 1 | 0;
     break label$11;
    }
    if ($10) {
     if ($3 & 1) {
      HEAP8[$0 | 0] = 58;
      $0 = $0 + 1 | 0;
     }
     $0 = ip4_string($0, $4 + 20 | 0, 32437);
    }
    HEAP8[$0 | 0] = 0;
    global$0 = $4 + 32 | 0;
    return $0;
   }
   $1 = $1 + 1 | 0;
   continue;
  };
 }

 function ip6_string($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0;
  while (1) {
   if (!(($4 | 0) == 16)) {
    $3 = $1 + $4 | 0;
    $5 = HEAPU8[$3 | 0];
    HEAP8[$0 + 1 | 0] = HEAPU8[($5 & 15) + 31616 | 0];
    HEAP8[$0 | 0] = HEAPU8[($5 >>> 4 | 0) + 31616 | 0];
    $3 = HEAPU8[$3 + 1 | 0];
    HEAP8[$0 + 3 | 0] = HEAPU8[($3 & 15) + 31616 | 0];
    HEAP8[$0 + 2 | 0] = HEAPU8[($3 >>> 4 | 0) + 31616 | 0];
    $3 = $0 + 4 | 0;
    if (!(($4 | 0) == 14 | HEAPU8[$2 | 0] != 73)) {
     HEAP8[$0 + 4 | 0] = 58;
     $3 = $0 + 5 | 0;
    }
    $4 = $4 + 2 | 0;
    $0 = $3;
    continue;
   }
   break;
  };
  HEAP8[$0 | 0] = 0;
  return $0;
 }

 function ip4_string($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  $4 = 3;
  $6 = HEAPU8[$2 | 0];
  $2 = __wasm_rotl_i32(HEAP8[$2 + 2 | 0] + -98 | 0, 31);
  label$1 : {
   if (($2 | 0) != 3) {
    $5 = -1;
    if (($2 | 0) == 5) {
     break label$1
    }
    $4 = 0;
    $5 = 1;
    break label$1;
   }
   $5 = -1;
  }
  $8 = $3 + 11 | 0;
  $6 = ($6 | 0) != 105;
  while (1) {
   if (!(($7 | 0) == 4)) {
    $2 = put_dec_trunc8($3 + 12 | 0, HEAPU8[$1 + $4 | 0]) - ($3 + 12 | 0) | 0;
    label$5 : {
     if (($2 | 0) > 2 | $6) {
      break label$5
     }
     HEAP8[$0 | 0] = 48;
     if (($2 | 0) <= 1) {
      HEAP8[$0 + 1 | 0] = 48;
      $0 = $0 + 2 | 0;
      break label$5;
     }
     $0 = $0 + 1 | 0;
    }
    while (1) {
     if ($2) {
      HEAP8[$0 | 0] = HEAPU8[$2 + $8 | 0];
      $0 = $0 + 1 | 0;
      $2 = $2 + -1 | 0;
      continue;
     }
     break;
    };
    if ($7 >>> 0 <= 2) {
     HEAP8[$0 | 0] = 46;
     $0 = $0 + 1 | 0;
    }
    $7 = $7 + 1 | 0;
    $4 = $4 + $5 | 0;
    continue;
   }
   break;
  };
  HEAP8[$0 | 0] = 0;
  global$0 = $3 + 16 | 0;
  return $0;
 }

 function special_hex_number($0, $1, $2, $3, $4) {
  var $5 = 0;
  $5 = global$0 - 16 | 0;
  global$0 = $5;
  $4 = ($4 << 9) + 512 | 5;
  HEAP32[$5 >> 2] = $4;
  HEAP32[$5 + 4 >> 2] = -61328;
  HEAP32[$5 + 8 >> 2] = $4;
  HEAP32[$5 + 12 >> 2] = -61328;
  $0 = number($0, $1, $2, $3, $5);
  global$0 = $5 + 16 | 0;
  return $0;
 }

 function next_arg($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0;
  $8 = HEAPU8[$0 | 0];
  $5 = ($8 | 0) == 34;
  $6 = $5 ? $0 + 1 | 0 : $0;
  $0 = 0;
  while (1) {
   $4 = $0 + $6 | 0;
   $7 = HEAPU8[$4 | 0];
   if (!(!$7 | (HEAPU8[$7 + 31824 | 0] & 32 ? !$5 : 0))) {
    $5 = ($7 | 0) == 34 ? !$5 : $5;
    $3 = $3 ? $3 : ($7 | 0) == 61 ? $0 : 0;
    $0 = $0 + 1 | 0;
    continue;
   }
   break;
  };
  HEAP32[$1 >> 2] = $6;
  label$4 : {
   if ($3) {
    $1 = $3 + $6 | 0;
    HEAP8[$1 | 0] = 0;
    $3 = $1 + 1 | 0;
    HEAP32[$2 >> 2] = $3;
    if (HEAPU8[$1 + 1 | 0] != 34) {
     break label$4
    }
    HEAP32[$2 >> 2] = $3 + 1;
    $1 = ($0 + $6 | 0) + -1 | 0;
    if (HEAPU8[$1 | 0] != 34) {
     break label$4
    }
    HEAP8[$1 | 0] = 0;
    break label$4;
   }
   HEAP32[$2 >> 2] = 0;
  }
  label$6 : {
   if (($8 | 0) != 34) {
    break label$6
   }
   $0 = ($0 + $6 | 0) + -1 | 0;
   if (HEAPU8[$0 | 0] != 34) {
    break label$6
   }
   HEAP8[$0 | 0] = 0;
  }
  if (HEAPU8[$4 | 0]) {
   HEAP8[$4 | 0] = 0;
   $4 = $4 + 1 | 0;
  }
  return skip_spaces($4);
 }

 function rb_insert_color($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0;
  $2 = HEAP32[$0 >> 2];
  folding_inner0 : {
   label$1 : {
    label$3 : {
     label$4 : {
      label$5 : {
       label$6 : {
        label$7 : {
         label$8 : {
          label$9 : {
           while (1) {
            if (!$2) {
             break label$1
            }
            $4 = HEAP32[$2 >> 2];
            if (!($4 & 1)) {
             $5 = $4;
             $3 = HEAP32[$4 + 4 >> 2];
             label$12 : {
              if (($2 | 0) != ($3 | 0)) {
               if (!$3 | HEAP8[$3 | 0] & 1) {
                break label$9
               }
               $0 = $4 | 1;
               HEAP32[$3 >> 2] = $0;
               HEAP32[$2 >> 2] = $0;
               $2 = HEAP32[$4 >> 2] & -4;
               break label$12;
              }
              $3 = HEAP32[$4 + 8 >> 2];
              if (!$3 | HEAP8[$3 | 0] & 1) {
               break label$8
              }
              $0 = $4 | 1;
              HEAP32[$3 >> 2] = $0;
              HEAP32[$2 >> 2] = $0;
              $2 = HEAP32[$4 >> 2] & -4;
             }
             HEAP32[$5 >> 2] = $2;
             $0 = $4;
             continue;
            }
            break;
           };
           return;
          }
          $3 = HEAP32[$2 + 4 >> 2];
          if (($3 | 0) == ($0 | 0)) {
           break label$7
          }
          $0 = $2;
          break label$6;
         }
         $3 = HEAP32[$2 + 8 >> 2];
         if (($3 | 0) == ($0 | 0)) {
          break label$5
         }
         $0 = $2;
         break label$4;
        }
        $3 = HEAP32[$0 + 8 >> 2];
        HEAP32[$2 + 4 >> 2] = $3;
        HEAP32[$0 + 8 >> 2] = $2;
        if ($3) {
         HEAP32[$3 >> 2] = $2 | 1
        }
        HEAP32[$2 >> 2] = $0;
        $3 = HEAP32[$0 + 4 >> 2];
       }
       HEAP32[$4 + 8 >> 2] = $3;
       HEAP32[$0 + 4 >> 2] = $4;
       if ($3) {
        HEAP32[$3 >> 2] = $4 | 1
       }
       $2 = HEAP32[$4 >> 2];
       HEAP32[$0 >> 2] = $2;
       HEAP32[$4 >> 2] = $0;
       $2 = $2 & -4;
       if (!$2) {
        break label$3
       }
       if (($4 | 0) != HEAP32[$2 + 8 >> 2]) {
        HEAP32[$2 + 4 >> 2] = $0;
        return;
       }
       break folding_inner0;
      }
      $3 = HEAP32[$0 + 4 >> 2];
      HEAP32[$2 + 8 >> 2] = $3;
      HEAP32[$0 + 4 >> 2] = $2;
      if ($3) {
       HEAP32[$3 >> 2] = $2 | 1
      }
      HEAP32[$2 >> 2] = $0;
      $3 = HEAP32[$0 + 8 >> 2];
     }
     HEAP32[$4 + 4 >> 2] = $3;
     HEAP32[$0 + 8 >> 2] = $4;
     if ($3) {
      HEAP32[$3 >> 2] = $4 | 1
     }
     $2 = HEAP32[$4 >> 2];
     HEAP32[$0 >> 2] = $2;
     HEAP32[$4 >> 2] = $0;
     $2 = $2 & -4;
     if (!$2) {
      break label$3
     }
     if (HEAP32[$2 + 8 >> 2] == ($4 | 0)) {
      break folding_inner0
     }
     HEAP32[$2 + 4 >> 2] = $0;
     return;
    }
    HEAP32[$1 >> 2] = $0;
    return;
   }
   HEAP32[$0 >> 2] = 1;
   return;
  }
  HEAP32[$2 + 8 >> 2] = $0;
 }

 function rb_erase($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0;
  $5 = HEAP32[$0 + 4 >> 2];
  folding_inner0 : {
   label$1 : {
    label$2 : {
     label$3 : {
      label$4 : {
       label$5 : {
        label$6 : {
         label$7 : {
          label$8 : {
           label$9 : {
            label$10 : {
             label$11 : {
              label$12 : {
               label$13 : {
                label$14 : {
                 $6 = HEAP32[$0 + 8 >> 2];
                 if ($6) {
                  if (!$5) {
                   break label$14
                  }
                  $2 = HEAP32[$5 + 8 >> 2];
                  if (!$2) {
                   break label$13
                  }
                  $3 = $5;
                  while (1) {
                   $4 = $3;
                   $7 = $2;
                   $3 = $2;
                   $2 = HEAP32[$2 + 8 >> 2];
                   if ($2) {
                    continue
                   }
                   break;
                  };
                  $2 = HEAP32[$7 + 4 >> 2];
                  HEAP32[$4 + 8 >> 2] = $2;
                  HEAP32[$7 + 4 >> 2] = $5;
                  HEAP32[$5 >> 2] = $7 | HEAP32[$5 >> 2] & 1;
                  $5 = $7;
                  break label$12;
                 }
                 $2 = HEAP32[$0 >> 2];
                 $4 = $2 & -4;
                 if (!$4) {
                  break label$11
                 }
                 if (HEAP32[$4 + 8 >> 2] == ($0 | 0)) {
                  break label$8
                 }
                 HEAP32[$4 + 4 >> 2] = $5;
                 if (!$5) {
                  break label$5
                 }
                 break label$1;
                }
                $2 = HEAP32[$0 >> 2];
                HEAP32[$6 >> 2] = $2;
                $2 = $2 & -4;
                if (!$2) {
                 break label$7
                }
                if (HEAP32[$2 + 8 >> 2] == ($0 | 0)) {
                 break label$6
                }
                HEAP32[$2 + 4 >> 2] = $6;
                return;
               }
               $2 = HEAP32[$5 + 4 >> 2];
               $4 = $5;
              }
              HEAP32[$6 >> 2] = HEAP32[$6 >> 2] & 1 | $5;
              HEAP32[$5 + 8 >> 2] = $6;
              $7 = HEAP32[$0 >> 2];
              $3 = $7 & -4;
              if ($3) {
               if (HEAP32[$3 + 8 >> 2] == ($0 | 0)) {
                break label$10
               }
               $0 = $3 + 4 | 0;
               break label$9;
              }
              $0 = $1;
              break label$9;
             }
             HEAP32[$1 >> 2] = $5;
             if ($5) {
              break label$1
             }
             break label$5;
            }
            $0 = $3 + 8 | 0;
           }
           HEAP32[$0 >> 2] = $5;
           if ($2) {
            HEAP32[$5 >> 2] = $7;
            HEAP32[$2 >> 2] = $4 | 1;
            return;
           }
           $0 = HEAP32[$5 >> 2];
           HEAP32[$5 >> 2] = $7;
           if (!($0 & 1)) {
            break label$3
           }
           break label$4;
          }
          HEAP32[$4 + 8 >> 2] = $5;
          if ($5) {
           break label$1
          }
          break label$5;
         }
         HEAP32[$1 >> 2] = $6;
         return;
        }
        HEAP32[$2 + 8 >> 2] = $6;
        return;
       }
       if (!($2 & 1) | !$4) {
        break label$3
       }
      }
      $2 = 0;
      label$19 : {
       label$20 : {
        label$21 : {
         label$22 : {
          label$23 : {
           label$24 : {
            label$26 : {
             label$27 : {
              label$28 : {
               while (1) {
                label$29 : {
                 label$31 : {
                  label$32 : {
                   label$33 : {
                    label$34 : {
                     label$35 : {
                      label$36 : {
                       label$37 : {
                        label$38 : {
                         $0 = HEAP32[$4 + 4 >> 2];
                         if (($2 | 0) != ($0 | 0)) {
                          if (HEAP8[$0 | 0] & 1) {
                           break label$38
                          }
                          $2 = HEAP32[$0 + 8 >> 2];
                          HEAP32[$2 >> 2] = $4 | 1;
                          HEAP32[$4 + 4 >> 2] = $2;
                          $3 = HEAP32[$4 >> 2];
                          HEAP32[$0 >> 2] = $3;
                          HEAP32[$0 + 8 >> 2] = $4;
                          HEAP32[$4 >> 2] = $0;
                          $3 = $3 & -4;
                          if (!$3) {
                           break label$35
                          }
                          if (HEAP32[$3 + 8 >> 2] == ($4 | 0)) {
                           break label$34
                          }
                          $3 = $3 + 4 | 0;
                          break label$33;
                         }
                         $2 = HEAP32[$4 + 8 >> 2];
                         if (HEAP8[$2 | 0] & 1) {
                          break label$37
                         }
                         $0 = HEAP32[$2 + 4 >> 2];
                         HEAP32[$0 >> 2] = $4 | 1;
                         HEAP32[$4 + 8 >> 2] = $0;
                         $3 = HEAP32[$4 >> 2];
                         HEAP32[$2 >> 2] = $3;
                         HEAP32[$2 + 4 >> 2] = $4;
                         HEAP32[$4 >> 2] = $2;
                         $3 = $3 & -4;
                         $5 = $1;
                         label$40 : {
                          if (!$3) {
                           break label$40
                          }
                          $5 = $3 + 8 | 0;
                          if (($4 | 0) == HEAP32[$3 + 8 >> 2]) {
                           break label$40
                          }
                          $5 = $3 + 4 | 0;
                         }
                         HEAP32[$5 >> 2] = $2;
                         break label$36;
                        }
                        $2 = $0;
                        break label$32;
                       }
                       $0 = $2;
                      }
                      $3 = HEAP32[$0 + 8 >> 2];
                      if (HEAP8[$3 | 0] & 1 ? 0 : $3) {
                       break label$23
                      }
                      $2 = HEAP32[$0 + 4 >> 2];
                      if (HEAP8[$2 | 0] & 1 ? 0 : $2) {
                       break label$22
                      }
                      HEAP32[$0 >> 2] = $4;
                      $0 = HEAP32[$4 >> 2];
                      if (!($0 & 1)) {
                       break folding_inner0
                      }
                      break label$31;
                     }
                     $3 = $1;
                     break label$33;
                    }
                    $3 = $3 + 8 | 0;
                   }
                   HEAP32[$3 >> 2] = $0;
                  }
                  $3 = HEAP32[$2 + 4 >> 2];
                  if (HEAP8[$3 | 0] & 1 ? 0 : $3) {
                   break label$28
                  }
                  $0 = HEAP32[$2 + 8 >> 2];
                  if (HEAP8[$0 | 0] & 1 ? 0 : $0) {
                   break label$27
                  }
                  HEAP32[$2 >> 2] = $4;
                  $0 = HEAP32[$4 >> 2];
                  if (!($0 & 1)) {
                   break label$29
                  }
                 }
                 $0 = $0 & -4;
                 if (!$0) {
                  break label$3
                 }
                 $2 = $4;
                 $4 = $0;
                 continue;
                }
                break;
               };
               break folding_inner0;
              }
              $0 = $2;
              $2 = $3;
              break label$26;
             }
             $3 = HEAP32[$0 + 4 >> 2];
             HEAP32[$2 + 8 >> 2] = $3;
             HEAP32[$0 + 4 >> 2] = $2;
             HEAP32[$4 + 4 >> 2] = $0;
             if (!$3) {
              break label$26
             }
             HEAP32[$3 >> 2] = $2 | 1;
            }
            $3 = HEAP32[$0 + 8 >> 2];
            HEAP32[$4 + 4 >> 2] = $3;
            $5 = $2;
            $2 = $0 | 1;
            HEAP32[$5 >> 2] = $2;
            HEAP32[$0 + 8 >> 2] = $4;
            if ($3) {
             HEAP32[$3 >> 2] = HEAP32[$3 >> 2] & 1 | $4
            }
            $3 = HEAP32[$4 >> 2];
            HEAP32[$0 >> 2] = $3;
            HEAP32[$4 >> 2] = $2;
            $2 = $3 & -4;
            if (!$2) {
             break label$24
            }
            if (HEAP32[$2 + 8 >> 2] == ($4 | 0)) {
             break label$20
            }
            HEAP32[$2 + 4 >> 2] = $0;
            return;
           }
           HEAP32[$1 >> 2] = $0;
           return;
          }
          $2 = $0;
          $0 = $3;
          break label$21;
         }
         $3 = HEAP32[$2 + 8 >> 2];
         HEAP32[$0 + 4 >> 2] = $3;
         HEAP32[$2 + 8 >> 2] = $0;
         HEAP32[$4 + 8 >> 2] = $2;
         if (!$3) {
          break label$21
         }
         HEAP32[$3 >> 2] = $0 | 1;
        }
        $3 = HEAP32[$2 + 4 >> 2];
        HEAP32[$4 + 8 >> 2] = $3;
        $5 = $0;
        $0 = $2 | 1;
        HEAP32[$5 >> 2] = $0;
        HEAP32[$2 + 4 >> 2] = $4;
        if ($3) {
         HEAP32[$3 >> 2] = HEAP32[$3 >> 2] & 1 | $4
        }
        $3 = HEAP32[$4 >> 2];
        HEAP32[$2 >> 2] = $3;
        HEAP32[$4 >> 2] = $0;
        $0 = $3 & -4;
        if (!$0) {
         break label$19
        }
        if (HEAP32[$0 + 8 >> 2] == ($4 | 0)) {
         break label$2
        }
        HEAP32[$0 + 4 >> 2] = $2;
        return;
       }
       HEAP32[$2 + 8 >> 2] = $0;
       return;
      }
      HEAP32[$1 >> 2] = $2;
     }
     return;
    }
    HEAP32[$0 + 8 >> 2] = $2;
    return;
   }
   HEAP32[$5 >> 2] = $2;
   return;
  }
  HEAP32[$4 >> 2] = $0 | 1;
 }

 function rb_insert_color_cached($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0;
  $3 = HEAP32[$0 >> 2];
  if ($2) {
   HEAP32[$1 + 4 >> 2] = $0
  }
  folding_inner0 : {
   label$2 : {
    label$4 : {
     label$5 : {
      label$6 : {
       label$7 : {
        label$8 : {
         label$9 : {
          label$10 : {
           while (1) {
            if (!$3) {
             break label$2
            }
            $2 = HEAP32[$3 >> 2];
            if (!($2 & 1)) {
             $5 = $2;
             $4 = HEAP32[$2 + 4 >> 2];
             label$13 : {
              if (($3 | 0) != ($4 | 0)) {
               if (!$4 | HEAP8[$4 | 0] & 1) {
                break label$10
               }
               $0 = $2 | 1;
               HEAP32[$4 >> 2] = $0;
               HEAP32[$3 >> 2] = $0;
               $3 = HEAP32[$2 >> 2] & -4;
               break label$13;
              }
              $4 = HEAP32[$2 + 8 >> 2];
              if (!$4 | HEAP8[$4 | 0] & 1) {
               break label$9
              }
              $0 = $2 | 1;
              HEAP32[$4 >> 2] = $0;
              HEAP32[$3 >> 2] = $0;
              $3 = HEAP32[$2 >> 2] & -4;
             }
             HEAP32[$5 >> 2] = $3;
             $0 = $2;
             continue;
            }
            break;
           };
           return;
          }
          $4 = HEAP32[$3 + 4 >> 2];
          if (($4 | 0) == ($0 | 0)) {
           break label$8
          }
          $0 = $3;
          break label$7;
         }
         $4 = HEAP32[$3 + 8 >> 2];
         if (($4 | 0) == ($0 | 0)) {
          break label$6
         }
         $0 = $3;
         break label$5;
        }
        $4 = HEAP32[$0 + 8 >> 2];
        HEAP32[$3 + 4 >> 2] = $4;
        HEAP32[$0 + 8 >> 2] = $3;
        if ($4) {
         HEAP32[$4 >> 2] = $3 | 1
        }
        HEAP32[$3 >> 2] = $0;
        $4 = HEAP32[$0 + 4 >> 2];
       }
       HEAP32[$2 + 8 >> 2] = $4;
       HEAP32[$0 + 4 >> 2] = $2;
       if ($4) {
        HEAP32[$4 >> 2] = $2 | 1
       }
       $3 = HEAP32[$2 >> 2];
       HEAP32[$0 >> 2] = $3;
       HEAP32[$2 >> 2] = $0;
       $3 = $3 & -4;
       if (!$3) {
        break label$4
       }
       if (HEAP32[$3 + 8 >> 2] != ($2 | 0)) {
        HEAP32[$3 + 4 >> 2] = $0;
        return;
       }
       break folding_inner0;
      }
      $4 = HEAP32[$0 + 4 >> 2];
      HEAP32[$3 + 8 >> 2] = $4;
      HEAP32[$0 + 4 >> 2] = $3;
      if ($4) {
       HEAP32[$4 >> 2] = $3 | 1
      }
      HEAP32[$3 >> 2] = $0;
      $4 = HEAP32[$0 + 8 >> 2];
     }
     HEAP32[$2 + 4 >> 2] = $4;
     HEAP32[$0 + 8 >> 2] = $2;
     if ($4) {
      HEAP32[$4 >> 2] = $2 | 1
     }
     $3 = HEAP32[$2 >> 2];
     HEAP32[$0 >> 2] = $3;
     HEAP32[$2 >> 2] = $0;
     $3 = $3 & -4;
     if (!$3) {
      break label$4
     }
     if (($2 | 0) == HEAP32[$3 + 8 >> 2]) {
      break folding_inner0
     }
     HEAP32[$3 + 4 >> 2] = $0;
     return;
    }
    HEAP32[$1 >> 2] = $0;
    return;
   }
   HEAP32[$0 >> 2] = 1;
   return;
  }
  HEAP32[$3 + 8 >> 2] = $0;
 }

 function rb_erase_cached($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, wasm2js_i32$0 = 0, wasm2js_i32$1 = 0;
  $2 = HEAP32[$0 + 8 >> 2];
  $5 = HEAP32[$0 + 4 >> 2];
  folding_inner0 : {
   label$1 : {
    label$2 : {
     label$3 : {
      label$4 : {
       label$5 : {
        label$6 : {
         label$7 : {
          label$8 : {
           label$10 : {
            label$11 : {
             label$12 : {
              label$13 : {
               label$14 : {
                label$15 : {
                 label$16 : {
                  label$17 : {
                   if (($0 | 0) != HEAP32[$1 + 4 >> 2]) {
                    if (!$2) {
                     break label$17
                    }
                    break label$16;
                   }
                   (wasm2js_i32$0 = $1 + 4 | 0, wasm2js_i32$1 = rb_next($0)), HEAP32[wasm2js_i32$0 >> 2] = wasm2js_i32$1;
                   if ($2) {
                    break label$16
                   }
                  }
                  label$19 : {
                   label$20 : {
                    label$21 : {
                     $2 = HEAP32[$0 >> 2];
                     $4 = $2 & -4;
                     if ($4) {
                      if (HEAP32[$4 + 8 >> 2] == ($0 | 0)) {
                       break label$21
                      }
                      HEAP32[$4 + 4 >> 2] = $5;
                      if (!$5) {
                       break label$20
                      }
                      break label$19;
                     }
                     HEAP32[$1 >> 2] = $5;
                     if ($5) {
                      break label$19
                     }
                     break label$20;
                    }
                    HEAP32[$4 + 8 >> 2] = $5;
                    if ($5) {
                     break label$19
                    }
                   }
                   if (!($2 & 1)) {
                    break label$2
                   }
                   if ($4) {
                    break label$15
                   }
                   break label$2;
                  }
                  HEAP32[$5 >> 2] = $2;
                  return;
                 }
                 label$23 : {
                  label$24 : {
                   if ($5) {
                    $2 = HEAP32[$5 + 8 >> 2];
                    if (!$2) {
                     break label$24
                    }
                    $3 = $5;
                    while (1) {
                     $4 = $3;
                     $6 = $2;
                     $3 = $2;
                     $2 = HEAP32[$2 + 8 >> 2];
                     if ($2) {
                      continue
                     }
                     break;
                    };
                    $2 = HEAP32[$6 + 4 >> 2];
                    HEAP32[$4 + 8 >> 2] = $2;
                    HEAP32[$6 + 4 >> 2] = $5;
                    HEAP32[$5 >> 2] = $6 | HEAP32[$5 >> 2] & 1;
                    $5 = $6;
                    break label$23;
                   }
                   $4 = HEAP32[$0 >> 2];
                   HEAP32[$2 >> 2] = $4;
                   $4 = $4 & -4;
                   if (!$4) {
                    break label$14
                   }
                   if (HEAP32[$4 + 8 >> 2] == ($0 | 0)) {
                    break label$13
                   }
                   HEAP32[$4 + 4 >> 2] = $2;
                   return;
                  }
                  $2 = HEAP32[$5 + 4 >> 2];
                  $4 = $5;
                 }
                 $3 = HEAP32[$0 + 8 >> 2];
                 HEAP32[$3 >> 2] = HEAP32[$3 >> 2] & 1 | $5;
                 HEAP32[$5 + 8 >> 2] = $3;
                 label$27 : {
                  label$28 : {
                   $6 = HEAP32[$0 >> 2];
                   $3 = $6 & -4;
                   if ($3) {
                    if (HEAP32[$3 + 8 >> 2] == ($0 | 0)) {
                     break label$28
                    }
                    $0 = $3 + 4 | 0;
                    break label$27;
                   }
                   $0 = $1;
                   break label$27;
                  }
                  $0 = $3 + 8 | 0;
                 }
                 HEAP32[$0 >> 2] = $5;
                 if ($2) {
                  HEAP32[$5 >> 2] = $6;
                  HEAP32[$2 >> 2] = $4 | 1;
                  return;
                 }
                 $0 = HEAP32[$5 >> 2];
                 HEAP32[$5 >> 2] = $6;
                 if (!($0 & 1)) {
                  break label$2
                 }
                }
                $2 = 0;
                while (1) {
                 label$31 : {
                  label$33 : {
                   label$34 : {
                    label$35 : {
                     label$36 : {
                      label$37 : {
                       label$38 : {
                        label$39 : {
                         label$40 : {
                          $0 = HEAP32[$4 + 4 >> 2];
                          if (($2 | 0) != ($0 | 0)) {
                           if (HEAP8[$0 | 0] & 1) {
                            break label$40
                           }
                           $2 = HEAP32[$0 + 8 >> 2];
                           HEAP32[$2 >> 2] = $4 | 1;
                           HEAP32[$4 + 4 >> 2] = $2;
                           $3 = HEAP32[$4 >> 2];
                           HEAP32[$0 >> 2] = $3;
                           HEAP32[$0 + 8 >> 2] = $4;
                           HEAP32[$4 >> 2] = $0;
                           $3 = $3 & -4;
                           if (!$3) {
                            break label$37
                           }
                           if (HEAP32[$3 + 8 >> 2] == ($4 | 0)) {
                            break label$36
                           }
                           $3 = $3 + 4 | 0;
                           break label$35;
                          }
                          $2 = HEAP32[$4 + 8 >> 2];
                          if (HEAP8[$2 | 0] & 1) {
                           break label$39
                          }
                          $0 = HEAP32[$2 + 4 >> 2];
                          HEAP32[$0 >> 2] = $4 | 1;
                          HEAP32[$4 + 8 >> 2] = $0;
                          $3 = HEAP32[$4 >> 2];
                          HEAP32[$2 >> 2] = $3;
                          HEAP32[$2 + 4 >> 2] = $4;
                          HEAP32[$4 >> 2] = $2;
                          $3 = $3 & -4;
                          $5 = $1;
                          label$42 : {
                           if (!$3) {
                            break label$42
                           }
                           $5 = $3 + 8 | 0;
                           if (($4 | 0) == HEAP32[$3 + 8 >> 2]) {
                            break label$42
                           }
                           $5 = $3 + 4 | 0;
                          }
                          HEAP32[$5 >> 2] = $2;
                          break label$38;
                         }
                         $2 = $0;
                         break label$34;
                        }
                        $0 = $2;
                       }
                       $3 = HEAP32[$0 + 8 >> 2];
                       if (HEAP8[$3 | 0] & 1 ? 0 : $3) {
                        break label$7
                       }
                       $2 = HEAP32[$0 + 4 >> 2];
                       if (HEAP8[$2 | 0] & 1 ? 0 : $2) {
                        break label$6
                       }
                       HEAP32[$0 >> 2] = $4;
                       $0 = HEAP32[$4 >> 2];
                       if (!($0 & 1)) {
                        break folding_inner0
                       }
                       break label$33;
                      }
                      $3 = $1;
                      break label$35;
                     }
                     $3 = $3 + 8 | 0;
                    }
                    HEAP32[$3 >> 2] = $0;
                   }
                   $3 = HEAP32[$2 + 4 >> 2];
                   if (HEAP8[$3 | 0] & 1 ? 0 : $3) {
                    break label$12
                   }
                   $0 = HEAP32[$2 + 8 >> 2];
                   if (HEAP8[$0 | 0] & 1 ? 0 : $0) {
                    break label$11
                   }
                   HEAP32[$2 >> 2] = $4;
                   $0 = HEAP32[$4 >> 2];
                   if (!($0 & 1)) {
                    break label$31
                   }
                  }
                  $0 = $0 & -4;
                  if (!$0) {
                   break label$2
                  }
                  $2 = $4;
                  $4 = $0;
                  continue;
                 }
                 break;
                };
                break folding_inner0;
               }
               HEAP32[$1 >> 2] = $2;
               return;
              }
              HEAP32[$4 + 8 >> 2] = $2;
              return;
             }
             $0 = $2;
             $2 = $3;
             break label$10;
            }
            $3 = HEAP32[$0 + 4 >> 2];
            HEAP32[$2 + 8 >> 2] = $3;
            HEAP32[$0 + 4 >> 2] = $2;
            HEAP32[$4 + 4 >> 2] = $0;
            if (!$3) {
             break label$10
            }
            HEAP32[$3 >> 2] = $2 | 1;
           }
           $3 = HEAP32[$0 + 8 >> 2];
           HEAP32[$4 + 4 >> 2] = $3;
           $5 = $2;
           $2 = $0 | 1;
           HEAP32[$5 >> 2] = $2;
           HEAP32[$0 + 8 >> 2] = $4;
           if ($3) {
            HEAP32[$3 >> 2] = HEAP32[$3 >> 2] & 1 | $4
           }
           $3 = HEAP32[$4 >> 2];
           HEAP32[$0 >> 2] = $3;
           HEAP32[$4 >> 2] = $2;
           $2 = $3 & -4;
           if (!$2) {
            break label$8
           }
           if (HEAP32[$2 + 8 >> 2] == ($4 | 0)) {
            break label$4
           }
           HEAP32[$2 + 4 >> 2] = $0;
           return;
          }
          HEAP32[$1 >> 2] = $0;
          return;
         }
         $2 = $0;
         $0 = $3;
         break label$5;
        }
        $3 = HEAP32[$2 + 8 >> 2];
        HEAP32[$0 + 4 >> 2] = $3;
        HEAP32[$2 + 8 >> 2] = $0;
        HEAP32[$4 + 8 >> 2] = $2;
        if (!$3) {
         break label$5
        }
        HEAP32[$3 >> 2] = $0 | 1;
       }
       $3 = HEAP32[$2 + 4 >> 2];
       HEAP32[$4 + 8 >> 2] = $3;
       $5 = $0;
       $0 = $2 | 1;
       HEAP32[$5 >> 2] = $0;
       HEAP32[$2 + 4 >> 2] = $4;
       if ($3) {
        HEAP32[$3 >> 2] = HEAP32[$3 >> 2] & 1 | $4
       }
       $3 = HEAP32[$4 >> 2];
       HEAP32[$2 >> 2] = $3;
       HEAP32[$4 >> 2] = $0;
       $0 = $3 & -4;
       if (!$0) {
        break label$3
       }
       if (HEAP32[$0 + 8 >> 2] == ($4 | 0)) {
        break label$1
       }
       HEAP32[$0 + 4 >> 2] = $2;
       return;
      }
      HEAP32[$2 + 8 >> 2] = $0;
      return;
     }
     HEAP32[$1 >> 2] = $2;
    }
    return;
   }
   HEAP32[$0 + 8 >> 2] = $2;
   return;
  }
  HEAP32[$4 >> 2] = $0 | 1;
 }

 function rb_next($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  label$1 : {
   $3 = HEAP32[$0 >> 2];
   if (($3 | 0) == ($0 | 0)) {
    break label$1
   }
   $2 = HEAP32[$0 + 4 >> 2];
   if ($2) {
    while (1) {
     $1 = $2;
     $2 = HEAP32[$1 + 8 >> 2];
     if ($2) {
      continue
     }
     break label$1;
    }
   }
   while (1) {
    $1 = $3 & -4;
    if (!$1 | HEAP32[$1 + 4 >> 2] != ($0 | 0)) {
     break label$1
    }
    $3 = HEAP32[$1 >> 2];
    $0 = $1;
    continue;
   };
  }
  return $1;
 }

 function rb_prev($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  label$1 : {
   $3 = HEAP32[$0 >> 2];
   if (($3 | 0) == ($0 | 0)) {
    break label$1
   }
   $2 = HEAP32[$0 + 8 >> 2];
   if ($2) {
    while (1) {
     $1 = $2;
     $2 = HEAP32[$1 + 4 >> 2];
     if ($2) {
      continue
     }
     break label$1;
    }
   }
   while (1) {
    $1 = $3 & -4;
    if (!$1 | HEAP32[$1 + 8 >> 2] != ($0 | 0)) {
     break label$1
    }
    $3 = HEAP32[$1 >> 2];
    $0 = $1;
    continue;
   };
  }
  return $1;
 }

 function radix_tree_node_rcu_free($0) {
  $0 = $0 | 0;
  memset($0 + 8 | 0, 0, 64);
  memset($0 + 72 | 0, 0, 12);
  HEAP32[$0 + 4 >> 2] = $0;
  HEAP32[$0 >> 2] = $0;
  kmem_cache_free(HEAP32[34974], $0 + -12 | 0);
 }

 function __radix_tree_lookup($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  label$1 : {
   label$2 : while (1) {
    $2 = 0;
    $1 = HEAP32[973];
    if (($1 & 3) == 2) {
     $3 = (16 << HEAPU8[$1 & -3]) + -1 | 0
    } else {
     $3 = 0
    }
    if ($3 >>> 0 < $0 >>> 0) {
     break label$1
    }
    while (1) {
     if (($1 & 3) == 2) {
      if (($1 | 0) == 1030) {
       continue label$2
      }
      $2 = $1 & -3;
      $3 = HEAPU8[$2 | 0];
      $1 = HEAP32[((($0 >>> $3 & 15) << 2) + $2 | 0) + 20 >> 2];
      if ($3) {
       continue
      }
     }
     break;
    };
    break;
   };
   $2 = $1;
  }
  return $2;
 }

 function timerqueue_add($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0;
  $2 = $0;
  while (1) {
   $4 = HEAP32[$2 >> 2];
   if ($4) {
    $2 = $1 + 16 | 0;
    $3 = $4 + 16 | 0;
    $5 = HEAPU32[$2 >> 2] >= HEAPU32[$3 >> 2] ? 0 : 1;
    $2 = HEAP32[$2 + 4 >> 2];
    $3 = HEAP32[$3 + 4 >> 2];
    $2 = (($2 | 0) < ($3 | 0) ? 1 : ($2 | 0) <= ($3 | 0) ? $5 : 0) ? $4 + 8 | 0 : $4 + 4 | 0;
    $3 = $4;
    continue;
   }
   break;
  };
  HEAP32[$1 + 4 >> 2] = 0;
  HEAP32[$1 + 8 >> 2] = 0;
  HEAP32[$1 >> 2] = $3;
  HEAP32[$2 >> 2] = $1;
  rb_insert_color($1, $0);
  $2 = HEAP32[$0 + 4 >> 2];
  label$3 : {
   if ($2) {
    $3 = $1 + 16 | 0;
    $5 = HEAPU32[$3 >> 2] < HEAPU32[$2 + 16 >> 2] ? 0 : 1;
    $4 = HEAP32[$3 + 4 >> 2];
    $3 = HEAP32[$2 + 20 >> 2];
    $2 = 0;
    if (($4 | 0) > ($3 | 0) ? 1 : ($4 | 0) >= ($3 | 0) ? $5 : 0) {
     break label$3
    }
   }
   HEAP32[$0 + 4 >> 2] = $1;
   $2 = 1;
  }
  return $2;
 }

 function timerqueue_del($0, $1) {
  var wasm2js_i32$0 = 0, wasm2js_i32$1 = 0;
  if (($1 | 0) == HEAP32[$0 + 4 >> 2]) {
   (wasm2js_i32$0 = $0 + 4 | 0, wasm2js_i32$1 = rb_next($1)), HEAP32[wasm2js_i32$0 >> 2] = wasm2js_i32$1
  }
  rb_erase($1, $0);
  HEAP32[$1 >> 2] = $1;
  return HEAP32[$0 + 4 >> 2] != 0;
 }

 function xas_load($0) {
  var $1 = 0, $2 = 0, $3 = 0;
  $1 = xas_start($0);
  $3 = $0 + 8 | 0;
  while (1) {
   label$1 : {
    if (($1 & 3) != 2 | $1 >>> 0 < 4097) {
     break label$1
    }
    $2 = $1 + -2 | 0;
    if (HEAPU8[$3 | 0] > HEAPU8[$2 | 0]) {
     break label$1
    }
    $1 = xas_descend($0, $2);
    continue;
   }
   break;
  };
  return $1;
 }

 function xas_start($0) {
  var $1 = 0, $2 = 0;
  folding_inner0 : {
   label$1 : {
    label$2 : {
     label$3 : {
      label$4 : {
       $1 = HEAP32[$0 + 12 >> 2];
       $2 = $1 & 3;
       if ($2) {
        if (($2 | 0) != 2 | $1 >>> 0 < 4) {
         break label$4
        }
        return 0;
       }
       if (!$1) {
        break label$3
       }
       $0 = ($1 + (HEAPU8[$0 + 10 | 0] << 2) | 0) + 20 | 0;
       break label$2;
      }
      $2 = HEAP32[$0 + 4 >> 2];
      $1 = HEAP32[HEAP32[$0 >> 2] + 4 >> 2];
      if (!($1 >>> 0 < 4097 | ($1 & 3) != 2)) {
       if ($2 >>> HEAPU8[$1 + -2 | 0] >>> 0 < 16) {
        break label$1
       }
       break folding_inner0;
      }
      if (!$2) {
       break label$1
      }
      break folding_inner0;
     }
     $0 = HEAP32[$0 >> 2] + 4 | 0;
    }
    return HEAP32[$0 >> 2];
   }
   HEAP32[$0 + 12 >> 2] = 0;
   return $1;
  }
  HEAP32[$0 + 12 >> 2] = 1;
  return 0;
 }

 function xas_descend($0, $1) {
  var $2 = 0;
  HEAP32[$0 + 12 >> 2] = $1;
  $2 = $0;
  $0 = HEAP32[$0 + 4 >> 2] >>> HEAPU8[$1 | 0] & 15;
  HEAP8[$2 + 10 | 0] = $0;
  return HEAP32[(($0 << 2) + $1 | 0) + 20 >> 2];
 }

 function xas_create($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0;
  $11 = HEAPU8[$0 + 8 | 0];
  $6 = HEAP32[$0 >> 2];
  label$1 : {
   label$2 : {
    label$3 : {
     label$4 : {
      label$6 : {
       label$7 : {
        label$8 : {
         $1 = HEAP32[$0 + 12 >> 2];
         if ($1 >>> 0 > 3) {
          if ($1 >>> 0 >= 4) {
           if (($1 & 3) == 2) {
            break label$2
           }
          }
          if (!$1) {
           break label$8
          }
          $8 = ($1 + (HEAPU8[$0 + 10 | 0] << 2) | 0) + 20 | 0;
          $1 = HEAPU8[$1 | 0];
          break label$3;
         }
         $1 = 0;
         HEAP32[$0 + 12 >> 2] = 0;
         $8 = $6 + 4 | 0;
         $10 = HEAP32[$0 + 4 >> 2];
         $3 = HEAP32[$6 + 4 >> 2];
         if ($3) {
          if ($3 >>> 0 < 4097) {
           break label$6
          }
          if (($3 & 3) != 2) {
           break label$6
          }
          $4 = $3 + -2 | 0;
          $1 = HEAPU8[$4 | 0] + 4 | 0;
          break label$6;
         }
         if (!$10) {
          break label$7
         }
         while (1) {
          $3 = $10 >>> $2 | 0;
          $1 = $2 + 4 | 0;
          $2 = $1;
          if ($3 >>> 0 > 15) {
           continue
          }
          break;
         };
         break label$4;
        }
        $8 = $6 + 4 | 0;
       }
       $1 = 0;
       break label$3;
      }
      HEAP32[$0 + 12 >> 2] = 0;
      $12 = $0 + 20 | 0;
      while (1) {
       if ($10 >>> 0 > max_index($3) >>> 0) {
        $4 = xas_alloc($0, $1);
        if (!$4) {
         break label$1
        }
        HEAP8[$4 + 2 | 0] = 1;
        if ($3 & 1) {
         HEAP8[$4 + 3 | 0] = 1
        }
        HEAP32[$4 + 20 >> 2] = $3;
        $7 = HEAP32[$6 >> 2];
        $2 = 0;
        $9 = $4 + 84 | 0;
        $5 = $9;
        while (1) {
         label$16 : {
          label$18 : {
           if (!(!($7 & 4) | $2)) {
            memset($9, 255, 4);
            $7 = HEAP32[$6 >> 2];
            if ($7 & 8388608) {
             break label$18
            }
            $7 = $7 | 8388608;
            HEAP32[$6 >> 2] = $7;
            HEAP32[$9 >> 2] = HEAP32[$9 >> 2] & -2;
            break label$18;
           }
           if (8388608 << $2 & $7) {
            HEAP32[$5 >> 2] = HEAP32[$5 >> 2] | 1
           }
           if (($2 | 0) == 2) {
            break label$16
           }
          }
          $5 = $5 + 4 | 0;
          $2 = $2 + 1 | 0;
          continue;
         }
         break;
        };
        if (!(($3 & 3) != 2 | $3 >>> 0 < 4097)) {
         HEAP8[$3 + -1 | 0] = 0;
         HEAP32[$3 + 2 >> 2] = $4;
        }
        $3 = $4 | 2;
        HEAP32[$8 >> 2] = $3;
        $2 = HEAP32[$12 >> 2];
        if ($2) {
         FUNCTION_TABLE[$2]($4)
        }
        $1 = $1 + 4 | 0;
        continue;
       }
       break;
      };
      HEAP32[$0 + 12 >> 2] = $4;
     }
     $2 = 0;
     if (($1 | 0) < 0) {
      break label$2
     }
    }
    $2 = HEAP32[$8 >> 2];
    $3 = $0 + 10 | 0;
    while (1) {
     if ($1 >>> 0 <= $11 >>> 0) {
      break label$2
     }
     $1 = $1 + -4 | 0;
     label$24 : {
      if ($2) {
       if (($2 & 3) != 2 | $2 >>> 0 < 4097) {
        break label$2
       }
       $5 = $2 + -2 | 0;
       break label$24;
      }
      $5 = xas_alloc($0, $1);
      if (!$5) {
       break label$1
      }
      if (HEAPU8[$6 | 0] & 4) {
       memset($5 + 84 | 0, 255, 4)
      }
      HEAP32[$8 >> 2] = $5 | 2;
     }
     $2 = xas_descend($0, $5);
     $8 = ((HEAPU8[$3 | 0] << 2) + $5 | 0) + 20 | 0;
     continue;
    };
   }
   return $2;
  }
  return 0;
 }

 function max_index($0) {
  return ($0 & 3) != 2 | $0 >>> 0 < 4097 ? 0 : (16 << HEAPU8[$0 + -2 | 0]) + -1 | 0;
 }

 function xas_alloc($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0;
  $3 = HEAP32[$0 + 12 >> 2];
  if ($3 & 3) {
   return 0
  }
  label$2 : {
   $2 = HEAP32[$0 + 16 >> 2];
   label$3 : {
    label$4 : {
     if ($2) {
      HEAP32[$0 + 16 >> 2] = 0;
      if ($3) {
       break label$4
      }
      break label$3;
     }
     $2 = kmem_cache_alloc(HEAP32[34974], 4194816);
     if (!$2) {
      break label$2
     }
     if (!$3) {
      break label$3
     }
    }
    HEAP8[$2 + 1 | 0] = HEAPU8[$0 + 10 | 0];
    HEAP8[$3 + 2 | 0] = HEAPU8[$3 + 2 | 0] + 1;
    $4 = HEAP32[$0 + 20 >> 2];
    if (!$4) {
     break label$3
    }
    FUNCTION_TABLE[$4]($3);
   }
   HEAP16[$2 + 2 >> 1] = 0;
   HEAP8[$2 | 0] = $1;
   HEAP32[$2 + 8 >> 2] = HEAP32[$0 >> 2];
   HEAP32[$2 + 4 >> 2] = HEAP32[$0 + 12 >> 2];
   return $2;
  }
  HEAP32[$0 + 12 >> 2] = -46;
  return 0;
 }

 function xas_store($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0, $14 = 0, $15 = 0;
  $6 = HEAP32[$0 >> 2];
  label$1 : {
   if ($1) {
    $7 = xas_create($0);
    break label$1;
   }
   $7 = xas_load($0);
  }
  $4 = HEAP32[$0 + 12 >> 2];
  label$3 : {
   if ($4 & 3) {
    break label$3
   }
   if (!(!$4 | HEAPU8[$0 + 8 | 0] >= HEAPU8[$4 | 0])) {
    HEAP8[$0 + 9 | 0] = 0
   }
   $3 = HEAPU8[$0 + 9 | 0];
   if (!($3 | ($1 | 0) != ($7 | 0))) {
    return
   }
   $5 = HEAPU8[$0 + 10 | 0];
   $10 = $3 + $5 | 0;
   label$6 : {
    if ($4) {
     $8 = ($4 + ($5 << 2) | 0) + 20 | 0;
     if (!$3) {
      break label$6
     }
     $12 = $10 + 1 | 0;
     $2 = 84;
     $14 = $0 + 12 | 0;
     $13 = $0 + 10 | 0;
     $15 = $0 + 9 | 0;
     $3 = $4;
     $6 = $5;
     while (1) {
      $9 = $2 + $3 | 0;
      if ((find_next_bit($9, $12, ($6 & 255) + 1 | 0) | 0) != ($12 | 0)) {
       $11 = HEAPU8[$13 | 0];
       $6 = ($3 + ($11 >>> 3 & 28) | 0) + $2 | 0;
       HEAP32[$6 >> 2] = HEAP32[$6 >> 2] | 1 << ($11 & 31);
       __bitmap_clear($9, $11 + 1 | 0, HEAPU8[$15 | 0]);
      }
      if (($2 | 0) == 92) {
       break label$6
      }
      $2 = $2 + 4 | 0;
      $3 = HEAP32[$14 >> 2];
      $6 = HEAPU8[$13 | 0];
      continue;
     };
    }
    $8 = $6 + 4 | 0;
   }
   if (!$1) {
    xas_init_marks($0)
   }
   $9 = $1 & 1 ^ 1;
   $2 = 0;
   $6 = $0 + 10 | 0;
   $3 = 0;
   while (1) {
    HEAP32[$8 >> 2] = $1;
    if (!(($7 & 3) != 2 | $7 >>> 0 < 4097)) {
     xas_free_nodes($0, $7 + -2 | 0)
    }
    if (!$4) {
     break label$3
    }
    $2 = (!$7 - !$1 | 0) + $2 | 0;
    $3 = ((($7 ^ -1) & 1) - $9 | 0) + $3 | 0;
    label$13 : {
     label$14 : {
      if ($1) {
       if (($5 | 0) == ($10 | 0)) {
        break label$13
       }
       $5 = $5 + 1 | 0;
       $1 = HEAPU8[$6 | 0] << 2 | 2;
       break label$14;
      }
      if (($5 | 0) == 15) {
       break label$13
      }
      $1 = 0;
      $5 = $5 + 1 | 0;
      if ($5 >>> 0 > $10 >>> 0) {
       break label$13
      }
     }
     $8 = $8 + 4 | 0;
     $7 = HEAP32[($4 + ($5 << 2) | 0) + 20 >> 2];
     continue;
    }
    break;
   };
   if (!($2 | $3)) {
    break label$3
   }
   HEAP8[$4 + 2 | 0] = HEAPU8[$4 + 2 | 0] + $2;
   HEAP8[$4 + 3 | 0] = HEAPU8[$4 + 3 | 0] + $3;
   $1 = HEAP32[$0 + 20 >> 2];
   if ($1) {
    FUNCTION_TABLE[$1]($4)
   }
   if (($2 | 0) > -1) {
    break label$3
   }
   $6 = $0 + 12 | 0;
   $2 = HEAP32[$6 >> 2];
   $3 = $0 + 10 | 0;
   label$17 : {
    while (1) {
     label$18 : {
      $1 = HEAP32[$2 + 4 >> 2];
      if (HEAPU8[$2 + 2 | 0]) {
       break label$18
      }
      HEAP32[$6 >> 2] = $1;
      HEAP8[$3 | 0] = HEAPU8[$2 + 1 | 0];
      xa_node_free($2);
      if (!$1) {
       break label$17
      }
      HEAP32[($1 + (HEAPU8[$3 | 0] << 2) | 0) + 20 >> 2] = 0;
      HEAP8[$1 + 2 | 0] = HEAPU8[$1 + 2 | 0] + -1;
      $2 = $1;
      $1 = HEAP32[$0 + 20 >> 2];
      if (!$1) {
       continue
      }
      FUNCTION_TABLE[$1]($2);
      continue;
     }
     break;
    };
    if ($1) {
     break label$3
    }
    $3 = $0 + 12 | 0;
    $1 = HEAP32[$3 >> 2];
    $4 = HEAP32[$0 >> 2];
    $6 = $0 + 20 | 0;
    while (1) {
     if (HEAPU8[$1 + 2 | 0] != 1) {
      break label$3
     }
     $2 = HEAP32[$1 + 20 >> 2];
     if (!$2) {
      break label$3
     }
     $5 = ($2 & 3) == 2 & $2 >>> 0 > 4096;
     if (HEAPU8[$1 | 0] ? !$5 : 0) {
      break label$3
     }
     HEAP32[$4 + 4 >> 2] = $2;
     HEAP32[$3 >> 2] = 1;
     $0 = HEAP32[$4 >> 2];
     if (!(HEAP32[$1 + 84 >> 2] & 1 | (!($0 & 4) | !($0 & 8388608)))) {
      HEAP32[$4 >> 2] = $0 & -8388609
     }
     HEAP16[$1 + 2 >> 1] = 0;
     if (!$5) {
      HEAP32[$1 + 20 >> 2] = 1030
     }
     $0 = HEAP32[$6 >> 2];
     if ($0) {
      FUNCTION_TABLE[$0]($1)
     }
     xa_node_free($1);
     if (!$5) {
      break label$3
     }
     HEAP32[$2 + 2 >> 2] = 0;
     $1 = $2 + -2 | 0;
     continue;
    };
   }
   HEAP32[HEAP32[$0 >> 2] + 4 >> 2] = 0;
   HEAP32[$0 + 12 >> 2] = 1;
  }
 }

 function xas_init_marks($0) {
  var $1 = 0;
  while (1) {
   label$1 : {
    label$3 : {
     if (!(!(HEAP32[HEAP32[$0 >> 2] >> 2] & 4) | $1)) {
      xas_set_mark($0);
      break label$3;
     }
     xas_clear_mark($0, $1);
     if (($1 | 0) == 2) {
      break label$1
     }
    }
    $1 = $1 + 1 | 0;
    continue;
   }
   break;
  };
 }

 function xas_free_nodes($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0;
  $5 = $0 + 20 | 0;
  $0 = $1;
  while (1) {
   if (!$2) {
    $4 = 0;
    $2 = 1;
    continue;
   }
   label$4 : {
    label$5 : {
     label$6 : {
      $3 = (($4 << 2) + $0 | 0) + 20 | 0;
      $2 = HEAP32[$3 >> 2];
      if (!(($2 & 3) == 2 ? $2 >>> 0 >= 4097 : 0)) {
       if ($2) {
        HEAP32[$3 >> 2] = 1030
       }
       while (1) {
        $4 = $4 + 1 | 0;
        if (($4 | 0) != 16) {
         break label$4
        }
        HEAP16[$0 + 2 >> 1] = 0;
        $4 = HEAPU8[$0 + 1 | 0];
        $2 = HEAP32[$0 + 4 >> 2];
        $3 = HEAP32[$5 >> 2];
        if ($3) {
         FUNCTION_TABLE[$3]($0)
        }
        xa_node_free($0);
        $3 = ($0 | 0) != ($1 | 0);
        $0 = $2;
        if ($3) {
         continue
        }
        break;
       };
       break label$6;
      }
      $0 = $2 + -2 | 0;
      break label$5;
     }
     return;
    }
    $2 = 0;
    continue;
   }
   $2 = 1;
   continue;
  };
 }

 function xa_node_free($0) {
  HEAP32[$0 + 8 >> 2] = 1;
  call_rcu($0 + 12 | 0, 110);
 }

 function xas_set_mark($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0;
  label$1 : {
   $1 = HEAP32[$0 + 12 >> 2];
   label$2 : {
    if ($1 & 3) {
     break label$2
    }
    $2 = $0 + 10 | 0;
    while (1) {
     if ($1) {
      $2 = HEAPU8[$2 | 0];
      $3 = ($1 + ($2 >>> 3 & 28) | 0) + 84 | 0;
      $4 = $3;
      $2 = 1 << ($2 & 31);
      $3 = HEAP32[$3 >> 2];
      HEAP32[$4 >> 2] = $2 | $3;
      if ($2 & $3) {
       break label$2
      }
      $2 = $1 + 1 | 0;
      $1 = HEAP32[$1 + 4 >> 2];
      continue;
     }
     break;
    };
    $0 = HEAP32[$0 >> 2];
    $1 = HEAP32[$0 >> 2];
    if (!($1 & 8388608)) {
     break label$1
    }
   }
   return;
  }
  HEAP32[$0 >> 2] = $1 | 8388608;
 }

 function xas_clear_mark($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, wasm2js_i32$0 = 0, wasm2js_i32$1 = 0;
  label$1 : {
   $2 = HEAP32[$0 + 12 >> 2];
   if ($2 & 3) {
    break label$1
   }
   $3 = $0 + 10 | 0;
   $7 = $1 << 2;
   while (1) {
    if ($2) {
     $4 = $2 + $7 | 0;
     $3 = HEAPU8[$3 | 0];
     $5 = ($4 + ($3 >>> 3 & 28) | 0) + 84 | 0;
     $6 = HEAP32[$5 >> 2];
     (wasm2js_i32$0 = $5, wasm2js_i32$1 = __wasm_rotl_i32(-2, $3) & $6), HEAP32[wasm2js_i32$0 >> 2] = wasm2js_i32$1;
     if (HEAPU16[$4 + 84 >> 1] | !($6 & 1 << ($3 & 31))) {
      break label$1
     }
     $3 = $2 + 1 | 0;
     $2 = HEAP32[$2 + 4 >> 2];
     continue;
    }
    break;
   };
   $0 = HEAP32[$0 >> 2];
   $2 = HEAP32[$0 >> 2];
   $1 = 8388608 << $1;
   if (!($2 & $1)) {
    break label$1
   }
   HEAP32[$0 >> 2] = $2 & ($1 ^ -1);
  }
 }

 function int_sqrt($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0;
  if ($0 >>> 0 >= 2) {
   $1 = $0 >>> 0 > 65535;
   $2 = $1 ? 31 : 15;
   $3 = $2;
   $4 = $2 + -8 | 0;
   $1 = $1 ? $0 : $0 << 16;
   $2 = $1 >>> 0 > 16777215;
   $3 = $2 ? $3 : $4;
   $1 = $2 ? $1 : $1 << 8;
   $2 = $1 >>> 0 > 268435455;
   $3 = $2 ? $3 : $3 + -4 | 0;
   $1 = $2 ? $1 : $1 << 4;
   $2 = $1 >>> 0 > 1073741823;
   $2 = 1 << (($2 ? $3 : $3 + -2 | 0) + (($2 ? $1 : $1 << 2) >> 31 ^ -1) & -2);
   $1 = 0;
   while (1) {
    if ($2) {
     $3 = $1 + $2 | 0;
     $4 = $0 >>> 0 < $3 >>> 0;
     $1 = ($1 >>> 1 | 0) + ($4 ? 0 : $2) | 0;
     $0 = $0 - ($4 ? 0 : $3) | 0;
     $2 = $2 >>> 2 | 0;
     continue;
    }
    break;
   };
   $0 = $1;
  }
  return $0;
 }

 function cmp_ex_sort($0, $1) {
  $0 = $0 | 0;
  $1 = $1 | 0;
  $0 = HEAP32[$0 >> 2];
  $1 = HEAP32[$1 >> 2];
  return ($0 >>> 0 > $1 >>> 0 ? 1 : $0 >>> 0 < $1 >>> 0 ? -1 : 0) | 0;
 }

 function ___ratelimit($0, $1) {
  var $2 = 0, $3 = 0;
  $3 = global$0 - 16 | 0;
  global$0 = $3;
  label$1 : {
   label$2 : {
    label$3 : {
     label$4 : {
      if (HEAP32[$0 >> 2]) {
       $2 = HEAP32[$0 + 16 >> 2];
       if (!$2) {
        $2 = HEAP32[20749];
        HEAP32[$0 + 16 >> 2] = $2;
       }
       if (((HEAP32[$0 >> 2] + $2 | 0) - HEAP32[20749] | 0) > -1) {
        break label$2
       }
       $2 = HEAP32[$0 + 12 >> 2];
       if (!$2) {
        break label$3
       }
       if (!(HEAP8[$0 + 20 | 0] & 1)) {
        break label$4
       }
       break label$3;
      }
      $0 = 1;
      break label$1;
     }
     HEAP32[$3 + 4 >> 2] = $2;
     HEAP32[$3 >> 2] = $1;
     printk_deferred(32473, $3);
     HEAP32[$0 + 12 >> 2] = 0;
    }
    HEAP32[$0 + 8 >> 2] = 0;
    HEAP32[$0 + 16 >> 2] = HEAP32[20749];
   }
   label$7 : {
    label$8 : {
     $1 = HEAP32[$0 + 4 >> 2];
     if (!$1) {
      break label$8
     }
     $2 = HEAP32[$0 + 8 >> 2];
     if (($1 | 0) <= ($2 | 0)) {
      break label$8
     }
     $1 = $0 + 8 | 0;
     $0 = 1;
     break label$7;
    }
    $1 = $0 + 12 | 0;
    $2 = HEAP32[$0 + 12 >> 2];
    $0 = 0;
   }
   HEAP32[$1 >> 2] = $2 + 1;
  }
  global$0 = $3 + 16 | 0;
  return $0;
 }

 function show_mem($0, $1) {
  var $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $2 = global$0 - 48 | 0;
  global$0 = $2;
  printk(32504, 0);
  show_free_areas($0, $1);
  $1 = 141176;
  while (1) {
   if ($1) {
    $0 = 0;
    while (1) {
     if (($0 | 0) != 1032) {
      $4 = $0 + $1 | 0;
      $3 = HEAP32[$4 + 48 >> 2];
      if ($3) {
       $5 = $3 + $5 | 0;
       $6 = ($6 + $3 | 0) - HEAP32[$4 + 40 >> 2] | 0;
      }
      $0 = $0 + 516 | 0;
      continue;
     }
     break;
    };
    $1 = 0;
    continue;
   }
   break;
  };
  HEAP32[$2 + 32 >> 2] = $5;
  printk(32515, $2 + 32 | 0);
  HEAP32[$2 + 16 >> 2] = 0;
  printk(32530, $2 + 16 | 0);
  HEAP32[$2 >> 2] = $6;
  printk(32561, $2);
  global$0 = $2 + 48 | 0;
 }

 function siphash_1u32($0) {
  var $1 = 0, $2 = 0, $3 = 0, $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0, $10 = 0, $11 = 0, $12 = 0, $13 = 0;
  $9 = HEAP32[34973];
  $1 = $9 ^ 1685025377;
  $2 = $1;
  $6 = HEAP32[34972];
  $3 = $6 ^ 1852075885;
  $7 = __wasm_rotl_i64($3, $1, 13);
  $4 = i64toi32_i32$HIGH_BITS;
  $1 = HEAP32[34971];
  $8 = $1;
  $1 = $2 + ($1 ^ 1936682341) | 0;
  $5 = HEAP32[34970];
  $2 = $3 + ($5 ^ 1886610805) | 0;
  if ($2 >>> 0 < $3 >>> 0) {
   $1 = $1 + 1 | 0
  }
  $7 = $2 ^ $7;
  $3 = $1;
  $10 = $1 ^ $4;
  $11 = __wasm_rotl_i64($7, $10, 17);
  $12 = $9 ^ 1885693026;
  $1 = $12 + ($8 ^ 1819895653) | 0;
  $9 = $0;
  $8 = $6 ^ $0 ^ 2037671283;
  $0 = $8;
  $4 = $0 + ($5 ^ 1852142177) | 0;
  if ($4 >>> 0 < $0 >>> 0) {
   $1 = $1 + 1 | 0
  }
  $5 = i64toi32_i32$HIGH_BITS;
  $0 = $1 + $10 | 0;
  $6 = $4 + $7 | 0;
  if ($6 >>> 0 < $4 >>> 0) {
   $0 = $0 + 1 | 0
  }
  $10 = $6 ^ $11;
  $7 = $0;
  $5 = $0 ^ $5;
  $11 = __wasm_rotl_i64($10, $5, 13);
  $13 = i64toi32_i32$HIGH_BITS;
  $3 = __wasm_rotl_i64($2, $3, 32);
  $0 = i64toi32_i32$HIGH_BITS;
  $2 = __wasm_rotl_i64($8, $12, 16) ^ $4;
  $8 = $1 ^ i64toi32_i32$HIGH_BITS;
  $0 = $8 + $0 | 0;
  $4 = $2 + $3 | 0;
  if ($4 >>> 0 < $2 >>> 0) {
   $0 = $0 + 1 | 0
  }
  $1 = $0 + $5 | 0;
  $3 = $4 + $10 | 0;
  if ($3 >>> 0 < $4 >>> 0) {
   $1 = $1 + 1 | 0
  }
  $5 = $3 ^ $11;
  $10 = $1 ^ $13;
  $11 = __wasm_rotl_i64($5, $10, 17);
  $12 = i64toi32_i32$HIGH_BITS;
  $4 = __wasm_rotl_i64($2, $8, 21) ^ $4;
  $8 = $0 ^ i64toi32_i32$HIGH_BITS;
  $0 = __wasm_rotl_i64($6, $7, 32);
  $7 = $0 + $4 | 0;
  $6 = $10;
  $2 = i64toi32_i32$HIGH_BITS + $8 | 0;
  $10 = $7 >>> 0 < $0 >>> 0 ? $2 + 1 | 0 : $2;
  $0 = $6 + $10 | 0;
  $2 = $7 + $5 | 0;
  if ($2 >>> 0 < $7 >>> 0) {
   $0 = $0 + 1 | 0
  }
  $12 = $0 ^ $12;
  $13 = $12;
  $6 = $2;
  $5 = $2 ^ $11;
  $11 = __wasm_rotl_i64($5, $12, 13);
  $12 = i64toi32_i32$HIGH_BITS;
  $7 = __wasm_rotl_i64($4, $8, 16) ^ $7;
  $4 = $10 ^ i64toi32_i32$HIGH_BITS;
  $1 = __wasm_rotl_i64($3, $1, 32);
  $2 = $1 + $7 | 0;
  $3 = i64toi32_i32$HIGH_BITS + $4 | 0;
  $8 = $2 >>> 0 < $1 >>> 0 ? $3 + 1 | 0 : $3;
  $1 = $13 + ($8 ^ 67108864) | 0;
  $3 = $5 + ($2 ^ $9) | 0;
  if ($3 >>> 0 < $5 >>> 0) {
   $1 = $1 + 1 | 0
  }
  $5 = $3 ^ $11;
  $9 = $1;
  $1 = $1 ^ $12;
  $10 = __wasm_rotl_i64($5, $1, 17);
  $11 = i64toi32_i32$HIGH_BITS;
  $6 = __wasm_rotl_i64($6, $0, 32) ^ 255;
  $0 = i64toi32_i32$HIGH_BITS;
  $2 = __wasm_rotl_i64($7, $4, 21) ^ $2;
  $4 = $8 ^ i64toi32_i32$HIGH_BITS;
  $0 = $4 + $0 | 0;
  $7 = $2 + $6 | 0;
  if ($7 >>> 0 < $2 >>> 0) {
   $0 = $0 + 1 | 0
  }
  $1 = $0 + $1 | 0;
  $6 = $7 + $5 | 0;
  if ($6 >>> 0 < $7 >>> 0) {
   $1 = $1 + 1 | 0
  }
  $8 = $6 ^ $10;
  $5 = $1 ^ $11;
  $10 = __wasm_rotl_i64($8, $5, 13);
  $11 = i64toi32_i32$HIGH_BITS;
  $7 = __wasm_rotl_i64($2, $4, 16) ^ $7;
  $4 = $0 ^ i64toi32_i32$HIGH_BITS;
  $0 = __wasm_rotl_i64($3, $9, 32);
  $3 = $0 + $7 | 0;
  $2 = i64toi32_i32$HIGH_BITS + $4 | 0;
  $9 = $3 >>> 0 < $0 >>> 0 ? $2 + 1 | 0 : $2;
  $0 = $9 + $5 | 0;
  $2 = $3 + $8 | 0;
  if ($2 >>> 0 < $3 >>> 0) {
   $0 = $0 + 1 | 0
  }
  $8 = $2 ^ $10;
  $5 = $0 ^ $11;
  $10 = __wasm_rotl_i64($8, $5, 17);
  $11 = i64toi32_i32$HIGH_BITS;
  $7 = __wasm_rotl_i64($7, $4, 21) ^ $3;
  $4 = $9 ^ i64toi32_i32$HIGH_BITS;
  $1 = __wasm_rotl_i64($6, $1, 32);
  $9 = $1 + $7 | 0;
  $3 = i64toi32_i32$HIGH_BITS + $4 | 0;
  $6 = $9 >>> 0 < $1 >>> 0 ? $3 + 1 | 0 : $3;
  $1 = $6 + $5 | 0;
  $3 = $8 + $9 | 0;
  if ($3 >>> 0 < $9 >>> 0) {
   $1 = $1 + 1 | 0
  }
  $8 = $3 ^ $10;
  $5 = $1 ^ $11;
  $10 = __wasm_rotl_i64($8, $5, 13);
  $11 = i64toi32_i32$HIGH_BITS;
  $7 = __wasm_rotl_i64($7, $4, 16) ^ $9;
  $4 = $6 ^ i64toi32_i32$HIGH_BITS;
  $0 = __wasm_rotl_i64($2, $0, 32);
  $6 = $0 + $7 | 0;
  $9 = $5;
  $2 = i64toi32_i32$HIGH_BITS + $4 | 0;
  $5 = $6 >>> 0 < $0 >>> 0 ? $2 + 1 | 0 : $2;
  $0 = $9 + $5 | 0;
  $2 = $6 + $8 | 0;
  if ($2 >>> 0 < $6 >>> 0) {
   $0 = $0 + 1 | 0
  }
  $8 = $2 ^ $10;
  $9 = $0;
  $0 = $0 ^ $11;
  $10 = __wasm_rotl_i64($8, $0, 17);
  $11 = i64toi32_i32$HIGH_BITS;
  $7 = __wasm_rotl_i64($7, $4, 21) ^ $6;
  $4 = $5 ^ i64toi32_i32$HIGH_BITS;
  $1 = __wasm_rotl_i64($3, $1, 32);
  $6 = $1 + $7 | 0;
  $3 = $0;
  $0 = i64toi32_i32$HIGH_BITS + $4 | 0;
  $5 = $6 >>> 0 < $1 >>> 0 ? $0 + 1 | 0 : $0;
  $0 = $3 + $5 | 0;
  $1 = $6 + $8 | 0;
  if ($1 >>> 0 < $6 >>> 0) {
   $0 = $0 + 1 | 0
  }
  $3 = $1;
  $8 = $1 ^ $10;
  $1 = $0 ^ $11;
  $10 = __wasm_rotl_i64($8, $1, 13);
  $11 = i64toi32_i32$HIGH_BITS;
  $6 = __wasm_rotl_i64($7, $4, 16) ^ $6;
  $7 = $5 ^ i64toi32_i32$HIGH_BITS;
  $9 = __wasm_rotl_i64($2, $9, 32);
  $2 = $9 + $6 | 0;
  $5 = $1;
  $1 = i64toi32_i32$HIGH_BITS + $7 | 0;
  $9 = $2 >>> 0 < $9 >>> 0 ? $1 + 1 | 0 : $1;
  $1 = $5 + $9 | 0;
  $4 = $2 + $8 | 0;
  if ($4 >>> 0 < $2 >>> 0) {
   $1 = $1 + 1 | 0
  }
  $4 = $4 ^ $10;
  $8 = $1 ^ $11;
  $5 = __wasm_rotl_i64($4, $8, 17);
  $10 = i64toi32_i32$HIGH_BITS;
  $2 = __wasm_rotl_i64($6, $7, 21) ^ $2;
  $9 = $9 ^ i64toi32_i32$HIGH_BITS;
  $0 = __wasm_rotl_i64($3, $0, 32);
  $1 = $0 + $2 | 0;
  $3 = i64toi32_i32$HIGH_BITS + $9 | 0;
  $6 = $1 >>> 0 < $0 >>> 0 ? $3 + 1 | 0 : $3;
  $0 = $8 + $6 | 0;
  $3 = $1 + $4 | 0;
  if ($3 >>> 0 < $1 >>> 0) {
   $0 = $0 + 1 | 0
  }
  $1 = __wasm_rotl_i64(__wasm_rotl_i64($2, $9, 16) ^ $1, $6 ^ i64toi32_i32$HIGH_BITS, 21) ^ ($3 ^ $5);
  $2 = i64toi32_i32$HIGH_BITS ^ ($0 ^ $10);
  $0 = __wasm_rotl_i64($3, $0, 32) ^ $1;
  i64toi32_i32$HIGH_BITS = i64toi32_i32$HIGH_BITS ^ $2;
  return $0;
 }

 function dump_stack_print_info() {
  var $0 = 0, $1 = 0, $2 = 0, $3 = 0, $4 = 0;
  $0 = global$0 + -64 | 0;
  global$0 = $0;
  $1 = HEAP32[2];
  $2 = HEAP32[$1 + 496 >> 2];
  $3 = print_tainted();
  $4 = strcspn();
  HEAP32[$0 + 48 >> 2] = 3291;
  HEAP32[$0 + 44 >> 2] = $4;
  HEAP32[$0 + 40 >> 2] = 3226;
  HEAP32[$0 + 36 >> 2] = $3;
  HEAP32[$0 + 32 >> 2] = 32625;
  HEAP32[$0 + 28 >> 2] = $1 + 700;
  HEAP32[$0 + 24 >> 2] = $2;
  HEAP32[$0 + 20 >> 2] = 0;
  HEAP32[$0 + 16 >> 2] = 32649;
  printk(32581, $0 + 16 | 0);
  if (HEAPU8[139904]) {
   HEAP32[$0 + 4 >> 2] = 139904;
   HEAP32[$0 >> 2] = 32649;
   printk(32628, $0);
  }
  print_worker_info(HEAP32[2]);
  global$0 = $0 - -64 | 0;
 }

 function dump_stack() {
  dump_stack_print_info();
  printk(30989, 0);
  if (!HEAPU8[82884]) {
   HEAP8[82884] = 1;
   printk(30944, 0);
  }
 }

 function memmove($0, $1, $2) {
  label$1 : {
   label$2 : {
    if (!$2) {
     break label$2
    }
    if ($0 >>> 0 <= $1 >>> 0) {
     break label$1
    }
    $1 = $1 + -1 | 0;
    while (1) {
     if (!$2) {
      break label$2
     }
     HEAP8[($0 + $2 | 0) + -1 | 0] = HEAPU8[$1 + $2 | 0];
     $2 = $2 + -1 | 0;
     continue;
    };
   }
   return;
  }
  memcpy($0, $1, $2);
 }

 function _ZN17compiler_builtins3int3mul3Mul3mul17h070e9a1c69faec5bE($0, $1, $2, $3) {
  var $4 = 0, $5 = 0, $6 = 0, $7 = 0, $8 = 0, $9 = 0;
  $4 = $2 >>> 16 | 0;
  $5 = $0 >>> 16 | 0;
  $9 = Math_imul($4, $5);
  $6 = $2 & 65535;
  $7 = $0 & 65535;
  $8 = Math_imul($6, $7);
  $5 = ($8 >>> 16 | 0) + Math_imul($5, $6) | 0;
  $4 = ($5 & 65535) + Math_imul($4, $7) | 0;
  $0 = (Math_imul($1, $2) + $9 | 0) + Math_imul($0, $3) + ($5 >>> 16) + ($4 >>> 16) | 0;
  $1 = $8 & 65535 | $4 << 16;
  i64toi32_i32$HIGH_BITS = $0;
  return $1;
 }

 function __wasm_i64_mul($0, $1, $2, $3) {
  $0 = _ZN17compiler_builtins3int3mul3Mul3mul17h070e9a1c69faec5bE($0, $1, $2, $3);
  return $0;
 }

 function __wasm_rotl_i32($0, $1) {
  var $2 = 0, $3 = 0;
  $2 = $1 & 31;
  $3 = (-1 >>> $2 & $0) << $2;
  $2 = $0;
  $0 = 0 - $1 & 31;
  return $3 | ($2 & -1 << $0) >>> $0;
 }

 function __wasm_rotl_i64($0, $1, $2) {
  var $3 = 0, $4 = 0, $5 = 0, $6 = 0;
  $6 = $2 & 63;
  $5 = $6;
  $3 = $5 & 31;
  if (32 <= $5 >>> 0) {
   $3 = -1 >>> $3 | 0
  } else {
   $4 = -1 >>> $3 | 0;
   $3 = (1 << $3) - 1 << 32 - $3 | -1 >>> $3;
  }
  $5 = $3 & $0;
  $3 = $1 & $4;
  $4 = $6 & 31;
  if (32 <= $6 >>> 0) {
   $3 = $5 << $4;
   $6 = 0;
  } else {
   $3 = (1 << $4) - 1 & $5 >>> 32 - $4 | $3 << $4;
   $6 = $5 << $4;
  }
  $5 = $3;
  $4 = 0 - $2 & 63;
  $3 = $4;
  $2 = $3 & 31;
  if (32 <= $3 >>> 0) {
   $3 = -1 << $2;
   $2 = 0;
  } else {
   $3 = (1 << $2) - 1 & -1 >>> 32 - $2 | -1 << $2;
   $2 = -1 << $2;
  }
  $0 = $2 & $0;
  $3 = $1 & $3;
  $1 = $4 & 31;
  if (32 <= $4 >>> 0) {
   $2 = 0;
   $0 = $3 >>> $1 | 0;
  } else {
   $2 = $3 >>> $1 | 0;
   $0 = ((1 << $1) - 1 & $3) << 32 - $1 | $0 >>> $1;
  }
  $0 = $0 | $6;
  i64toi32_i32$HIGH_BITS = $2 | $5;
  return $0;
 }

 var FUNCTION_TABLE = [null, do_no_restart_syscall, do_early_param, unknown_bootoption, set_init_arg, put_cred_rcu, wq_barrier_func, tasklet_action, tasklet_hi_action, no_blink, mmdrop_async_fn, process_timeout, run_timer_softirq, hrtimer_run_softirq, ktime_get, ktime_get_real, ktime_get_boottime, ktime_get_clocktai, dummy_clock_read, jiffies_read, rcu_process_callbacks, wake_up_klogd_work_func, __printk_safe_flush, dequeue_task_idle, check_preempt_curr_idle, pick_next_task_idle, put_prev_task_idle, arch_release_task_struct, task_tick_idle, switched_to_idle, prio_changed_idle, get_rr_interval_idle, arch_release_task_struct, enqueue_task_fair, dequeue_task_fair, yield_task_fair, yield_to_task_fair, check_preempt_wakeup, pick_next_task_fair, put_prev_task_fair, set_curr_task_fair, task_tick_fair, task_fork_fair, switched_from_fair, switched_to_fair, prio_changed_fair, get_rr_interval_fair, update_curr_fair, sched_rt_period_timer, enqueue_task_rt, dequeue_task_rt, yield_task_rt, check_preempt_curr_rt, pick_next_task_rt, put_prev_task_rt, set_curr_task_rt, task_tick_rt, switched_to_rt, prio_changed_rt, get_rr_interval_rt, update_curr_rt, dl_task_timer, inactive_task_timer, enqueue_task_dl, dequeue_task_dl, yield_task_dl, check_preempt_curr_dl, pick_next_task_dl, put_prev_task_dl, set_curr_task_rt, task_tick_dl, arch_release_task_struct, switched_from_dl, switched_to_dl, prio_changed_dl, update_curr_dl, autoremove_wake_function, default_wake_function, kmem_rcu_free, free_work, page_lock_anon_vma_read, page_referenced_one, get_rr_interval_idle, invalid_mkclean_vma, page_mkclean_one, page_mapcount_is_zero, try_to_unmap_one, invalid_migration_vma, pagevec_move_tail_fn, __pagevec_lru_add_fn, lru_deactivate_file_fn, lru_lazyfree_fn, drain_local_pages_wq, page_alloc_cpu_dead, free_compound_page, workingset_update_node, wake_page_function, do_write, do_run, do_shutdown, sys_ni_syscall, sys_m_read, sys_m_ioctl, sys_m_writev, put_prev_task_idle, put_prev_task_idle, put_prev_task_idle, u32_swap, generic_swap, u64_swap, radix_tree_node_rcu_free, cmp_ex_sort];
 function __wasm_memory_size() {
  return buffer.byteLength / 65536 | 0;
 }

 function __wasm_memory_grow(pagesToAdd) {
  pagesToAdd = pagesToAdd | 0;
  var oldPages = __wasm_memory_size() | 0;
  var newPages = oldPages + pagesToAdd | 0;
  if ((oldPages < newPages) && (newPages < 65536)) {
   var newBuffer = new ArrayBuffer(Math_imul(newPages, 65536));
   var newHEAP8 = new global.Int8Array(newBuffer);
   newHEAP8.set(HEAP8);
   HEAP8 = newHEAP8;
   HEAP8 = new global.Int8Array(newBuffer);
   HEAP16 = new global.Int16Array(newBuffer);
   HEAP32 = new global.Int32Array(newBuffer);
   HEAPU8 = new global.Uint8Array(newBuffer);
   HEAPU16 = new global.Uint16Array(newBuffer);
   HEAPU32 = new global.Uint32Array(newBuffer);
   HEAPF32 = new global.Float32Array(newBuffer);
   HEAPF64 = new global.Float64Array(newBuffer);
   buffer = newBuffer;
  }
  return oldPages;
 }

 return {
  "memory": Object.create(Object.prototype, {
   "grow": {
    "value": __wasm_memory_grow
   },
   "buffer": {
    "get": function () {
     return buffer;
    }

   }
  }),
  "start_kernel": start_kernel,
  "evt_loop": evt_loop,
  "__syscall0": __syscall0,
  "__syscall1": __syscall1,
  "__syscall2": __syscall2,
  "__syscall3": __syscall3,
  "__syscall4": __syscall4,
  "__syscall5": __syscall5,
  "__syscall6": __syscall6
 };
}

var memasmFunc = new ArrayBuffer(262144);
for (var base64ReverseLookup = new Uint8Array(123 ), i = 25; i >= 0; --i) {
    base64ReverseLookup[48+i] = 52+i;
    base64ReverseLookup[65+i] = i;
    base64ReverseLookup[97+i] = 26+i;
  }
  base64ReverseLookup[43] = 62;
  base64ReverseLookup[47] = 63;

  function base64DecodeToExistingUint8Array(uint8Array, offset, b64) {
    var b1, b2, i = 0, j = offset, bLength = b64.length, end = offset + (bLength*3>>2);
    if (b64[bLength-2] == '=') --end;
    if (b64[bLength-1] == '=') --end;
    for (; i < bLength; i += 4, j += 3) {
      b1 = base64ReverseLookup[b64.charCodeAt(i+1)];
      b2 = base64ReverseLookup[b64.charCodeAt(i+2)];
      uint8Array[j] = base64ReverseLookup[b64.charCodeAt(i)] << 2 | b1 >> 4;
      if (j+1 < end) uint8Array[j+1] = b1 << 4 | b2 >> 2;
      if (j+2 < end) uint8Array[j+2] = b2 << 6 | base64ReverseLookup[b64.charCodeAt(i+3)];
    }
  }
var bufferView = new Uint8Array(memasmFunc);
base64DecodeToExistingUint8Array(bufferView, 1028, "OEQBAAIAAAAAACA=");
base64DecodeToExistingUint8Array(bufferView, 1048, "eAAAAHgAAAB4");
base64DecodeToExistingUint8Array(bufferView, 1096, "SAQAAEgE");
base64DecodeToExistingUint8Array(bufferView, 1152, "gAQAAIAE");
base64DecodeToExistingUint8Array(bufferView, 1168, "GQ==");
base64DecodeToExistingUint8Array(bufferView, 1364, "AQAAAAEAAABcBQAAXAUAAAAAAAB4PQ==");
base64DecodeToExistingUint8Array(bufferView, 1480, "AQ==");
base64DecodeToExistingUint8Array(bufferView, 1529, "BAAAAAQAAAAGAAAABgAACAYAAAgGAAAABAAAFAYAABQGAAAcBgAAHAYAAAgP");
base64DecodeToExistingUint8Array(bufferView, 1608, "SAYAAEgGAACUBwAAlAc=");
base64DecodeToExistingUint8Array(bufferView, 1716, "KA4AACgOAABzd2FwcGVy");
base64DecodeToExistingUint8Array(bufferView, 1745, "SwAAIEsAAIwOAACIBwAACAk=");
base64DecodeToExistingUint8Array(bufferView, 1776, "8AYAAPAG");
base64DecodeToExistingUint8Array(bufferView, 1888, "UMM=");
base64DecodeToExistingUint8Array(bufferView, 1912, "OEQC");
base64DecodeToExistingUint8Array(bufferView, 1936, "AQAAAFAGAABQBgAAnAcAAJwHAAAAAAAAqAcAAKgH");
base64DecodeToExistingUint8Array(bufferView, 2000, "CA8AAAgPAAAIDwAACA8=");
base64DecodeToExistingUint8Array(bufferView, 2160, "////////////////////////////////AACAAP////8AAAAA////////////////");
base64DecodeToExistingUint8Array(bufferView, 2217, "BAAAABAAAAAAAQAAAAEA/////////////////////w==");
base64DecodeToExistingUint8Array(bufferView, 2257, "gAwAAIAM");
base64DecodeToExistingUint8Array(bufferView, 2280, "//////////8=");
base64DecodeToExistingUint8Array(bufferView, 2305, "CQAAAAkAAAE=");
base64DecodeToExistingUint8Array(bufferView, 3084, "DAwAAAwMAAACAAAATGludXg=");
base64DecodeToExistingUint8Array(bufferView, 3161, "bWV0YWw=");
base64DecodeToExistingUint8Array(bufferView, 3226, "dXRzX3JlbGVhc2U=");
base64DecodeToExistingUint8Array(bufferView, 3291, "dXRzX3ZlcnNpb24=");
base64DecodeToExistingUint8Array(bufferView, 3356, "dXRzX21hY2hpbmU=");
base64DecodeToExistingUint8Array(bufferView, 3421, "KG5vbmUp");
base64DecodeToExistingUint8Array(bufferView, 3488, "WA8=");
base64DecodeToExistingUint8Array(bufferView, 3504, "/v//7w==");
base64DecodeToExistingUint8Array(bufferView, 3520, "G04AACJO");
base64DecodeToExistingUint8Array(bufferView, 3568, "504=");
base64DecodeToExistingUint8Array(bufferView, 3616, "AgAAAAAAAAAE");
base64DecodeToExistingUint8Array(bufferView, 3672, "/////z8AAAD/////PwAAAP////8/");
base64DecodeToExistingUint8Array(bufferView, 3704, "bBAAAFgPAAAgDg==");
base64DecodeToExistingUint8Array(bufferView, 3724, "AQAAABQM");
base64DecodeToExistingUint8Array(bufferView, 3740, "qA4=");
base64DecodeToExistingUint8Array(bufferView, 3752, "AgAAAAQAgA==");
base64DecodeToExistingUint8Array(bufferView, 3783, "gAAE");
base64DecodeToExistingUint8Array(bufferView, 3800, "WA8=");
base64DecodeToExistingUint8Array(bufferView, 3844, "/P//7wE=");
base64DecodeToExistingUint8Array(bufferView, 3884, "qA4AAAQAgA==");
base64DecodeToExistingUint8Array(bufferView, 3904, "4gQAAAo=");
base64DecodeToExistingUint8Array(bufferView, 3928, "AQ==");
base64DecodeToExistingUint8Array(bufferView, 3940, "/////w==");
base64DecodeToExistingUint8Array(bufferView, 3992, "AQ==");
base64DecodeToExistingUint8Array(bufferView, 4004, "/////w==");
base64DecodeToExistingUint8Array(bufferView, 4056, "AQ==");
base64DecodeToExistingUint8Array(bufferView, 4068, "/////w==");
base64DecodeToExistingUint8Array(bufferView, 4120, "Aw==");
base64DecodeToExistingUint8Array(bufferView, 4148, "/f//7wE=");
base64DecodeToExistingUint8Array(bufferView, 4204, "AQAAAAE=");
base64DecodeToExistingUint8Array(bufferView, 4504, "mBEAAJgRAACYUg==");
base64DecodeToExistingUint8Array(bufferView, 8472, "oFI=");
base64DecodeToExistingUint8Array(bufferView, 8496, "ECcAAP////8=");
base64DecodeToExistingUint8Array(bufferView, 11064, "AQ==");
base64DecodeToExistingUint8Array(bufferView, 11084, "Dg==");
base64DecodeToExistingUint8Array(bufferView, 11100, "AQ==");
base64DecodeToExistingUint8Array(bufferView, 11124, "Dw==");
base64DecodeToExistingUint8Array(bufferView, 11140, "AgAAAAc=");
base64DecodeToExistingUint8Array(bufferView, 11164, "EA==");
base64DecodeToExistingUint8Array(bufferView, 11180, "AwAAAAs=");
base64DecodeToExistingUint8Array(bufferView, 11204, "EQ==");
base64DecodeToExistingUint8Array(bufferView, 11220, "BAAAAAE=");
base64DecodeToExistingUint8Array(bufferView, 11244, "Dg==");
base64DecodeToExistingUint8Array(bufferView, 11260, "BQ==");
base64DecodeToExistingUint8Array(bufferView, 11284, "Dw==");
base64DecodeToExistingUint8Array(bufferView, 11300, "BgAAAAc=");
base64DecodeToExistingUint8Array(bufferView, 11324, "EA==");
base64DecodeToExistingUint8Array(bufferView, 11340, "BwAAAAs=");
base64DecodeToExistingUint8Array(bufferView, 11364, "EQ==");
base64DecodeToExistingUint8Array(bufferView, 11400, "eC0=");
base64DecodeToExistingUint8Array(bufferView, 11456, "eC0=");
base64DecodeToExistingUint8Array(bufferView, 11528, "eC0=");
base64DecodeToExistingUint8Array(bufferView, 11584, "eC0=");
base64DecodeToExistingUint8Array(bufferView, 11640, "Eg==");
base64DecodeToExistingUint8Array(bufferView, 11736, "0QMAAEAAAAAAJPQAACT0AP////////9/EwAAAAAAAAD/////AAAAAAAACT0I");
base64DecodeToExistingUint8Array(bufferView, 11800, "CgAAAAAAAAA2VQ==");
base64DecodeToExistingUint8Array(bufferView, 11820, "AQ==");
base64DecodeToExistingUint8Array(bufferView, 11860, "UC4AAFAuAAAAAAAAAQAAAAEAAAABAAAAAQAAAHAuAABwLgAAaAcBAAACAAABAAAAhC4AAIQuAAAAAAAABAAAAAAAAAAVAAAAnC4AAJwu");
base64DecodeToExistingUint8Array(bufferView, 12200, "QEIPAPB+Dg==");
base64DecodeToExistingUint8Array(bufferView, 13432, "gI1bALBxCwBAQg8AGQ==");
base64DecodeToExistingUint8Array(bufferView, 15620, "LAAAAIAAAAAAAAQ=");
base64DecodeToExistingUint8Array(bufferView, 15640, "Hls=");
base64DecodeToExistingUint8Array(bufferView, 15660, "LD0AACw9AAA0PQAAND0AADw9AAA8PQAAAAAAAP////8BAAAAgAAAAAAAAABgNgEAPlsAAAEAAACAAAAAAAAAAGA8AQBFWw==");
base64DecodeToExistingUint8Array(bufferView, 15774, "AgACAAAAAQ==");
base64DecodeToExistingUint8Array(bufferView, 15796, "tD0AALQ9AAC8PQAAvD0=");
base64DecodeToExistingUint8Array(bufferView, 16108, "WA8=");
base64DecodeToExistingUint8Array(bufferView, 16144, "ED8AABA/");
base64DecodeToExistingUint8Array(bufferView, 16184, "OD8AADg/");
base64DecodeToExistingUint8Array(bufferView, 16216, "HmYAAAAAAAAH");
base64DecodeToExistingUint8Array(bufferView, 16496, "cEAAAHBA");
base64DecodeToExistingUint8Array(bufferView, 16512, "gEAAAIBAAACIQAAAiEAAAAAAAACUQAAAlEAAAJxAAACcQAAA4gQAAAo=");
base64DecodeToExistingUint8Array(bufferView, 16844, "FAAAAAAAAADUQQAA1EEAAAAAAAABAAAAAQAAAAEAAAABAAAAAQAAAD//Hw==");
base64DecodeToExistingUint8Array(bufferView, 16972, "4gQAAAo=");
base64DecodeToExistingUint8Array(bufferView, 16996, "+gAAAAE=");
base64DecodeToExistingUint8Array(bufferView, 17020, "AQAAAAAAAACEQgAAhEIAAAAAAACQQgAAkEIAAAAAAACcQgAAnEIAAOIEAAAK");
base64DecodeToExistingUint8Array(bufferView, 19200, "AQAAAAAAAAAS");
base64DecodeToExistingUint8Array(bufferView, 19232, "AQ==");
base64DecodeToExistingUint8Array(bufferView, 19248, "NEsAACAAAABgSwAAVEsAAFhLAABcSw==");
base64DecodeToExistingUint8Array(bufferView, 19424, "BAAAAEAAAABAAAAAACAAAEEAAACkQAAAAIAAAAAgAAAwdQAA0A8AAKAf");
base64DecodeToExistingUint8Array(bufferView, 19600, "WEQB");
base64DecodeToExistingUint8Array(bufferView, 19744, "YEgB");
base64DecodeToExistingUint8Array(bufferView, 19760, "AQAAAAAAAMAAAQAAAQAAAIBNAABgIAIAIHw=");
base64DecodeToExistingUint8Array(bufferView, 19836, "AQAAAAwAAACAAAAAAAIAAAAQAAAAgAAAaAAAAEwAAAAzAAAAGQAAAAEAAAAKAAAAIAAAAIAAAAAABAAAACAAABoAAAATAAAADgAAAAcAAAABAAAAAAAAAAE=");
base64DecodeToExistingUint8Array(bufferView, 19936, "TGludXggdmVyc2lvbiB1dHNfcmVsZWFzZSAocUBPcGVuQlNEKSAoQ0xhbmcpIHV0c192ZXJzaW9uCgBIT01FPS8AVEVSTT1saW51eABlYXJseSBvcHRpb25zAAE1JXMAATNTa2lwcGluZyBzZXR1cF9jb21tYW5kX2xpbmUgYW5kIG90aGVyIGZ1bmN0aW9ucyB0aGF0IGRlcGVuZCBvbiB3b3JraW5nIG1tCgABNUtlcm5lbCBjb21tYW5kIGxpbmU6ICVzCgBCb290aW5nIGtlcm5lbABTZXR0aW5nIGluaXQgYXJncwBUb28gbWFueSBib290ICVzIHZhcnMgYXQgYCVzJwBpbml0AGNvbnNvbGUAZWFybHljb24AATRNYWxmb3JtZWQgZWFybHkgb3B0aW9uICclcycKAGVudgABNEJVRzogZmFpbHVyZSBhdCAlczolZC8lcygpIQoAbWFpbi5jAHJlcGFpcl9lbnZfc3RyaW5nAAE0UGFyYW1ldGVyICVzIGlzIG9ic29sZXRlLCBpZ25vcmVkCgBwdXJlAGNvcmUAcG9zdGNvcmUAYXJjaABzdWJzeXMAZnMAZGV2aWNlAGxhdGUAATRCVUc6IGZhaWx1cmUgYXQgJXM6JWQvJXMoKSEKAGthbGxzeW1zLmMAZ2V0X3N5bWJvbF9wb3MAMHglbHgAKyUjbHgvJSNseAAgWyVzXQABNEJVRzogZmFpbHVyZSBhdCAlczolZC8lcygpIQoAY3JlZC5jAF9fcHV0X2NyZWQAQ1JFRDogcHV0X2NyZWRfcmN1KCkgc2VlcyAlcCB3aXRoIHVzYWdlICVkCgAtLQABMyVzOiBVbmtub3duIHBhcmFtZXRlciBgJXMnCgABMyVzOiBgJXMnIHRvbyBsYXJnZSBmb3IgcGFyYW1ldGVyIGAlcycKAAABMyVzOiBgJXMnIGludmFsaWQgZm9yIHBhcmFtZXRlciBgJXMnCgABNVNldHRpbmcgZGFuZ2Vyb3VzIG9wdGlvbiAlcyAtIHRhaW50aW5nIGtlcm5lbAoAATVTb3J0aW5nIF9fZXhfdGFibGUuLi4KACVzV29ya3F1ZXVlOiAlcyAlcGYAAWMgKCVzKQABYwoAATR3b3JrcXVldWU6IHJvdW5kLXJvYmluIENQVSBzZWxlY3Rpb24gZm9yY2VkLCBleHBlY3QgcGVyZm9ybWFuY2UgaW1wYWN0CgAmeC0+d2FpdAABNEJVRzogZmFpbHVyZSBhdCAlczolZC8lcygpIQoAc2lnbmFsLmMAdGFza19zZXRfam9iY3RsX3BlbmRpbmcAdGFza19jbGVhcl9qb2JjdGxfcGVuZGluZwBwcmludF9kcm9wcGVkX3NpZ25hbAABNiVzLyVkOiByZWFjaGVkIFJMSU1JVF9TSUdQRU5ESU5HLCBkcm9wcGVkIHNpZ25hbCAlZAoAATRNZXRhbDogQlVHOiBmYWlsdXJlIGF0ICVzOiVkLyVzKCkhCgBzb2Z0aXJxLmMAdGFza2xldF9hY3Rpb25fY29tbW9uAAE0QlVHOiBmYWlsdXJlIGF0ICVzOiVkLyVzKCkhCgBjcHUuYwBvZmZsaW5lAG9ubGluZQBjcHVocF9pc3N1ZV9jYWxsAAEwS2VybmVsIHBhbmljIC0gbm90IHN5bmNpbmc6ICVzCgABMFJlYm9vdGluZyBpbiAlZCBzZWNvbmRzLi4KAAEwLS0tWyBlbmQgS2VybmVsIHBhbmljIC0gbm90IHN5bmNpbmc6ICVzIF0tLS0K");
base64DecodeToExistingUint8Array(bufferView, 21296, "UEcBRiABUyAAUiAATSAAQiAAVSAARCAAQSAAVyAAQyABSSAATyABRSABTCAASyABWCABVCABVGFpbnRlZDogAE5vdCB0YWludGVkAAE0RGlzYWJsaW5nIGxvY2sgZGVidWdnaW5nIGR1ZSB0byBrZXJuZWwgdGFpbnQKAAE0QlVHOiBmYWlsdXJlIGF0ICVzOiVkLyVzKCkhCgBmb3JrLmMAX19tbWRyb3AAATFCVUc6IEJhZCByc3MtY291bnRlciBzdGF0ZSBtbTolcCBpZHg6JWQgdmFsOiVsZAoAATFCVUc6IG5vbi16ZXJvIHBndGFibGVzX2J5dGVzIG9uIGZyZWVpbmcgbW06ICVsZAoAATRCVUc6IGZhaWx1cmUgYXQgJXM6JWQvJXMoKSEKAHRpbWVyLmMAYWRkX3RpbWVyAGFkZF90aW1lcl9vbgABM3NjaGVkdWxlX3RpbWVvdXQ6IHdyb25nIHRpbWVvdXQgdmFsdWUgJWx4CgBfX21vZF90aW1lcg==");
base64DecodeToExistingUint8Array(bufferView, 21696, "AQAAAAAAAAAIAAAACAAAAAgAAAAIAAAACAAAAAIAAAAIAAAACAAAAAgAAAADAAAACAAAAAgAAAAIAAAACAAAAJgFAQCgBQEAqAUBAAE0UGVyc2lzdGVudCBjbG9jayByZXR1cm5lZCBpbnZhbGlkIHZhbHVlAGppZmZpZXMAATNNZXRhbDogbG9nX2J1Zl9sZW46ICVsdSBieXRlcyBub3QgYXZhaWxhYmxlCgABNk1ldGFsOiBsb2dfYnVmX2xlbjogJXUgYnl0ZXMKAAE2TWV0YWw6IGVhcmx5IGxvZyBidWYgZnJlZTogJXUoJXUlJSkKACoqICVsbHUgcHJpbnRrIG1lc3NhZ2VzIGRyb3BwZWQgKioKADwldT4AWyU1bHUuMDAwMDAwXSAAWyU1bHUuJTA2bHVdIAA8dHJ1bmNhdGVkPgAKACV1LCVsbHUsJWxsdSwlYzsAXHglMDJ4AHByaW50a19zYWZlX2ZsdXNoOiBpbnRlcm5hbCBlcnJvcgoAJS4qcwABYwoATG9zdCAlZCBtZXNzYWdlKHMpIQoAATRCVUc6IGZhaWx1cmUgYXQgJXM6JWQvJXMoKSEKAGNvcmUuYwB3YWtlX3VwX3E=");
base64DecodeToExistingUint8Array(bufferView, 22176, "uVoBAEsYAQCj3AAAwbQAAMONAADicQAA1loAABFJAABlOgAAjC4AAEwlAADEHQAA1BcAACgTAABCDwAAMQwAAMUJAADHBwAAMgYAAP0EAAAABAAANAMAAI8CAAAOAgAApwEAAE8BAAAQAQAA1wAAAKwAAACJAAAAbgAAAFcAAABGAAAAOAAAAC0AAAAkAAAAHQAAABcAAAASAAAADwAAAAS9AADQ6QAACCkBAJJqAQBMzgEAeD8CAHrRAgDwgAMATGIEAPV/BQAl3QYAvJkIAF2+CgAhXQ0APscQAJf/FAA0NBoAh+ogAFJSKQD+UTMAAABAAAXsTwASDmQA2Zd8AHPumgA+ocMA8fDwAJDRMAH0BX0Bbl3eASXIUwKQSfEChDqoAyRJkgQFW7AFx3EcB7Dc0wgsZCELjuM4DhEREREBM0JVRzogc2NoZWR1bGluZyB3aGlsZSBhdG9taWM6ICVzLyVkLzB4JTA4eAoAc2NoZWR1bGluZyB3aGlsZSBhdG9taWMKAHBpY2tfbmV4dF90YXNr");
base64DecodeToExistingUint8Array(bufferView, 22592, "Fw==");
base64DecodeToExistingUint8Array(bufferView, 22604, "GAAAABkAAAAaAAAAGwAAABw=");
base64DecodeToExistingUint8Array(bufferView, 22636, "HQAAAB4AAAAfAAAAIAAAAAEzYmFkOiBzY2hlZHVsaW5nIGZyb20gdGhlIGlkbGUgdGhyZWFkIQoAATRCVUc6IGZhaWx1cmUgYXQgJXM6JWQvJXMoKSEKAGlkbGUuYwBzd2l0Y2hlZF90b19pZGxlAHByaW9fY2hhbmdlZF9pZGxlAAAAOFgAACEAAAAiAAAAIwAAACQAAAAlAAAAJgAAACcAAAAoAAAAKQAAACoAAAAAAAAAKwAAACwAAAAtAAAALgAAAC8AAADwWAAAMQAAADIAAAAzAAAAAAAAADQAAAA1AAAANgAAADcAAAA4");
base64DecodeToExistingUint8Array(bufferView, 22888, "OQAAADoAAAA7AAAAPAAAAAE0QlVHOiBmYWlsdXJlIGF0ICVzOiVkLyVzKCkhCgBydC5jAGRlcXVldWVfdG9wX3J0X3JxAF9waWNrX25leHRfdGFza19ydABwaWNrX25leHRfcnRfZW50aXR5AHNjaGVkOiBSVCB0aHJvdHRsaW5nIGFjdGl2YXRlZAoAATRCVUc6IGZhaWx1cmUgYXQgJXM6JWQvJXMoKSEKAGRlYWRsaW5lLmMAADRZAAA/AAAAQAAAAEEAAAAAAAAAQgAAAEMAAABEAAAARQAAAEYAAABHAAAAAAAAAEgAAABJAAAASgAAAAAAAABLAAAAcmVwbGVuaXNoX2RsX2VudGl0eQBzY2hlZDogREwgcmVwbGVuaXNoIGxhZ2dlZCB0b28gbXVjaAoAZW5xdWV1ZV90YXNrX2RsAGVucXVldWVfZGxfZW50aXR5AF9fZW5xdWV1ZV9kbF9lbnRpdHkAcGlja19uZXh0X3Rhc2tfZGwAYml0X3dhaXRfdGFibGUgKyBpAAE0QlVHOiBmYWlsdXJlIGF0ICVzOiVkLyVzKCkhCgBzbG9iLmMAa21lbV9jYWNoZQBzbG9iX2FsbG9jAHNsb2JfZnJlZQBtZW1vcnkAcmVzZXJ2ZWQAATRDb3VsZCBub3QgYWxsb2NhdGUgJXBhcCBieXRlcyBvZiBtaXJyb3JlZCBtZW1vcnkKAAE2ICAgbWVtYmxvY2tfZnJlZTogWyVwYS0lcGFdICVwRgoAATZtZW1ibG9ja19yZXNlcnZlOiBbJXBhLSVwYV0gJXBGCgABNiVzOiAlbGx1IGJ5dGVzIGFsaWduPTB4JWxseCBuaWQ9JWQgZnJvbT0lcGEgbWF4X2FkZHI9JXBhICVwRgoAbWVtYmxvY2tfYWxsb2NfdHJ5X25pZF9ub3BhbmljAG1lbWJsb2NrX2FsbG9jX3RyeV9uaWQAJXM6IEZhaWxlZCB0byBhbGxvY2F0ZSAlbGx1IGJ5dGVzIGFsaWduPTB4JWxseCBuaWQ9JWQgZnJvbT0lcGEgbWF4X2FkZHI9JXBhCgABNk1FTUJMT0NLIGNvbmZpZ3VyYXRpb246CgABNiBtZW1vcnkgc2l6ZSA9ICVwYSByZXNlcnZlZCBzaXplID0gJXBhCgABNEJVRzogZmFpbHVyZSBhdCAlczolZC8lcygpIQoAbWVtYmxvY2suYwBtZW1ibG9ja19pbnNlcnRfcmVnaW9uAAEzbWVtYmxvY2s6IEZhaWxlZCB0byBkb3VibGUgJXMgYXJyYXkgZnJvbSAlbGQgdG8gJWxkIGVudHJpZXMgIQoAATZtZW1ibG9jazogJXMgaXMgZG91YmxlZCB0byAlbGQgYXQgWyVwYS0lcGFdAG1lbWJsb2NrX2RvdWJsZV9hcnJheQBtZW1ibG9ja19tZXJnZV9yZWdpb25zAAEzJXMgaXMgYnJlYWtpbmcKAG1lbWJsb2NrX2FsbG9jX2ludGVybmFsAAE2ICVzLmNudCAgPSAweCVseAoAATYgJXNbJSN4XQlbJXBhLSVwYV0sICVwYSBieXRlcyVzIGZsYWdzOiAlI3gKAAE0QlVHOiBmYWlsdXJlIGF0ICVzOiVkLyVzKCkhCgB2bWFsbG9jLmMAdmZyZWUAX19mcmVlX3ZtYXBfYXJlYQBfX2luc2VydF92bWFwX2FyZWEAdnVubWFwX3BhZ2VfcmFuZ2UAX192dW5tYXAAATRCVUc6IGZhaWx1cmUgYXQgJXM6JWQvJXMoKSEKAHJtYXAuYwBwYWdlX21rY2xlYW4AATRCVUc6IGZhaWx1cmUgYXQgJXM6JWQvJXMoKSEKAG1sb2NrLmMAbWxvY2tfdm1hX3BhZ2UAbG9ja2VkAHdhaXRlcnMAZXJyb3IAcmVmZXJlbmNlZAB1cHRvZGF0ZQBkaXJ0eQBscnUAYWN0aXZlAHdvcmtpbmdzZXQAc2xhYgBvd25lcl9wcml2XzEAYXJjaF8xAHJlc2VydmVkAHByaXZhdGUAcHJpdmF0ZV8yAHdyaXRlYmFjawBoZWFkAG1hcHBlZHRvZGlzawByZWNsYWltAHN3YXBiYWNrZWQAdW5ldmljdGFibGUAbWxvY2tlZAAAAAAAAQAAAPBeAACAAAAA914AAAABAAD/XgAAAgAAAAVfAAAEAAAAEF8AAAgAAAAZXwAAEAAAAB9fAAAgAAAAI18AAEAAAAAqXwAAAAIAADVfAAAABAAAOl8AAAAIAABHXwAAABAAAE5fAAAAIAAAV18AAABAAABfXwAAAIAAAGlfAAAAAAEAc18AAAAAAgB4XwAAAAAEAIVfAAAAAAgAjV8AAAAAEACYXwAAAAAgAKRf");
base64DecodeToExistingUint8Array(bufferView, 24680, "R0ZQX1RSQU5TSFVHRQBHRlBfVFJBTlNIVUdFX0xJR0hUAEdGUF9ISUdIVVNFUl9NT1ZBQkxFAEdGUF9ISUdIVVNFUgBHRlBfVVNFUgBHRlBfS0VSTkVMX0FDQ09VTlQAR0ZQX0tFUk5FTABHRlBfTk9GUwBHRlBfQVRPTUlDAEdGUF9OT0lPAEdGUF9OT1dBSVQAR0ZQX0RNQQBfX0dGUF9ISUdITUVNAEdGUF9ETUEzMgBfX0dGUF9ISUdIAF9fR0ZQX0FUT01JQwBfX0dGUF9JTwBfX0dGUF9GUwBfX0dGUF9OT1dBUk4AX19HRlBfUkVUUllfTUFZRkFJTABfX0dGUF9OT0ZBSUwAX19HRlBfTk9SRVRSWQBfX0dGUF9DT01QAF9fR0ZQX1pFUk8AX19HRlBfTk9NRU1BTExPQwBfX0dGUF9NRU1BTExPQwBfX0dGUF9IQVJEV0FMTABfX0dGUF9USElTTk9ERQBfX0dGUF9SRUNMQUlNQUJMRQBfX0dGUF9NT1ZBQkxFAF9fR0ZQX0FDQ09VTlQAX19HRlBfV1JJVEUAX19HRlBfUkVDTEFJTQBfX0dGUF9ESVJFQ1RfUkVDTEFJTQBfX0dGUF9LU1dBUERfUkVDTEFJTQ==");
base64DecodeToExistingUint8Array(bufferView, 25168, "ykIjAGhgAADKQgMAdmAAAMoAYgCKYAAAwgBiAJ9gAADAAGIArGAAAMAAcAC1YAAAwABgAMhgAABAAGAA02AAACAASADcYAAAAABgAOdgAAAAAEAA8GAAAAEAAAD7YAAAAgAAAANhAAAEAAAAEWEAACAAAAAbYQAAAAAIACZhAABAAAAAM2EAAIAAAAA8YQAAAAIAAEVhAAAABAAAUmEAAAAIAABmYQAAABAAAHNhAAAAQAAAgWEAAACAAACMYQAAAAABAJdhAAAAIAAAqGEAAAAAAgC3YQAAAAAEAMZhAAAQAAAA1WEAAAgAAADnYQAAAAAQAPVhAAAAAQAAA2IAAAAAYAAPYgAAAAAgAB1iAAAAAEAAMmI=");
base64DecodeToExistingUint8Array(bufferView, 25456, "cmVhZAB3cml0ZQBleGVjAHNoYXJlZABtYXlyZWFkAG1heXdyaXRlAG1heWV4ZWMAbWF5c2hhcmUAZ3Jvd3Nkb3duAHVmZmRfbWlzc2luZwBwZm5tYXAAZGVueXdyaXRlAHVmZmRfd3AAaW8Ac2VxcmVhZAByYW5kcmVhZABkb250Y29weQBkb250ZXhwYW5kAGxvY2tvbmZhdWx0AGFjY291bnQAbm9yZXNlcnZlAGh1Z2V0bGIAd2lwZW9uZm9yawBkb250ZHVtcABtaXhlZG1hcABodWdlcGFnZQBub2h1Z2VwYWdlAG1lcmdlYWJsZQ==");
base64DecodeToExistingUint8Array(bufferView, 25712, "AQAAAHBjAAACAAAAdWMAAAQAAAB7YwAACAAAAIBjAAAQAAAAh2MAACAAAACPYwAAQAAAAJhjAACAAAAAoGMAAAABAACpYwAAAAIAALNjAAAABAAAwGMAAAAIAADHYwAAABAAANFjAAAAIAAA8F4AAABAAADZYwAAAIAAANxjAAAAAAEA5GMAAAAAAgDtYwAAAAAEAPZjAAAAAAgAAWQAAAAAEAANZAAAAAAgABVkAAAAAEAAH2QAAAAAAAFHXwAAAAAAAidkAAAAAAAEMmQAAAAAABA7ZAAAAAAAIERkAAAAAABATWQAAAAAAIBYZA==");
base64DecodeToExistingUint8Array(bufferView, 25960, "ATBwYWdlOiVweCBpcyB1bmluaXRpYWxpemVkIGFuZCBwb2lzb25lZAABMHBhZ2U6JXB4IGNvdW50OiVkIG1hcGNvdW50OiVkIG1hcHBpbmc6JXB4IGluZGV4OiUjbHgAAWMgY29tcG91bmRfbWFwY291bnQ6ICVkAAFjCgABMGZsYWdzOiAlI2x4KCVwR3ApCgABMQByYXc6IAABMXBhZ2UgZHVtcGVkIGJlY2F1c2U6ICVzCgBub29wAGlzb2xhdGVfbHJ1X3BhZ2UAATRNZXRhbDogQlVHOiBmYWlsdXJlIGF0ICVzOiVkLyVzKCkhCgB2bXNjYW4uYwABM01ldGFsOiBzaHJpbmtfc2xhYjogJXBGIG5lZ2F0aXZlIG9iamVjdHMgdG8gZGVsZXRlIG5yPSVsZAoAX19yZW1vdmVfbWFwcGluZwABNk1ldGFsOiAlczogb3JwaGFuZWQgcGFnZQoAcGFnZW91dAAAAAAg");
base64DecodeToExistingUint8Array(bufferView, 26344, "/////////38AAAAACAAAAGlzb2xhdGVfbHJ1X3BhZ2VzAAE0QlVHOiBmYWlsdXJlIGF0ICVzOiVkLyVzKCkhCgBwYWdlLXdyaXRlYmFjay5jAGNsZWFyX3BhZ2VfZGlydHlfZm9yX2lvAE1vdmFibGUAAAAAAAAAXg==");
base64DecodeToExistingUint8Array(bufferView, 26480, "AgAAAAEAAAAEAAAAAAAAAAIAAAAAAAAABA==");
base64DecodeToExistingUint8Array(bufferView, 26516, "AQAAAAQ=");
base64DecodeToExistingUint8Array(bufferView, 26544, "d2Fybl9hbGxvYwABNCVzOiAlcFYsIG1vZGU6JSN4KCVwR2cpLCBub2RlbWFzaz0lKnBibAoAYWN0aXZlX2Fub246JWx1IGluYWN0aXZlX2Fub246JWx1IGlzb2xhdGVkX2Fub246JWx1CiBhY3RpdmVfZmlsZTolbHUgaW5hY3RpdmVfZmlsZTolbHUgaXNvbGF0ZWRfZmlsZTolbHUKIHVuZXZpY3RhYmxlOiVsdSBkaXJ0eTolbHUgd3JpdGViYWNrOiVsdSB1bnN0YWJsZTolbHUKIHNsYWJfcmVjbGFpbWFibGU6JWx1IHNsYWJfdW5yZWNsYWltYWJsZTolbHUKIG1hcHBlZDolbHUgc2htZW06JWx1IHBhZ2V0YWJsZXM6JWx1IGJvdW5jZTolbHUKIGZyZWU6JWx1IGZyZWVfcGNwOiVsdSBmcmVlX2NtYTolbHUKAE5vZGUgJWQgYWN0aXZlX2Fub246JWx1a0IgaW5hY3RpdmVfYW5vbjolbHVrQiBhY3RpdmVfZmlsZTolbHVrQiBpbmFjdGl2ZV9maWxlOiVsdWtCIHVuZXZpY3RhYmxlOiVsdWtCIGlzb2xhdGVkKGFub24pOiVsdWtCIGlzb2xhdGVkKGZpbGUpOiVsdWtCIG1hcHBlZDolbHVrQiBkaXJ0eTolbHVrQiB3cml0ZWJhY2s6JWx1a0Igc2htZW06JWx1a0Igd3JpdGViYWNrX3RtcDolbHVrQiB1bnN0YWJsZTolbHVrQiBhbGxfdW5yZWNsYWltYWJsZT8gJXMKAHllcwBubwABYyVzIGZyZWU6JWx1a0IgbWluOiVsdWtCIGxvdzolbHVrQiBoaWdoOiVsdWtCIGFjdGl2ZV9hbm9uOiVsdWtCIGluYWN0aXZlX2Fub246JWx1a0IgYWN0aXZlX2ZpbGU6JWx1a0IgaW5hY3RpdmVfZmlsZTolbHVrQiB1bmV2aWN0YWJsZTolbHVrQiB3cml0ZXBlbmRpbmc6JWx1a0IgcHJlc2VudDolbHVrQiBtYW5hZ2VkOiVsdWtCIG1sb2NrZWQ6JWx1a0Iga2VybmVsX3N0YWNrOiVsdWtCIHBhZ2V0YWJsZXM6JWx1a0IgYm91bmNlOiVsdWtCIGZyZWVfcGNwOiVsdWtCIGxvY2FsX3BjcDoldWtCIGZyZWVfY21hOiVsdWtCCgBsb3dtZW1fcmVzZXJ2ZVtdOgABYyAlbGQAAWMKAAFjJXM6IAABYyVsdSolbHVrQiAAAWM9ICVsdWtCCgAlbGQgdG90YWwgcGFnZWNhY2hlIHBhZ2VzCgABNkJ1aWx0ICVpIHpvbmVsaXN0cywgbW9iaWxpdHkgZ3JvdXBpbmcgJXMuICBUb3RhbCBwYWdlczogJWxkCgBvZmYAb24AATZNZW1vcnk6ICVsdUsvJWx1SyBhdmFpbGFibGUgKCVsdUsga2VybmVsIGNvZGUsICVsdUsgcndkYXRhLCAlbHVLIHJvZGF0YSwgJWx1SyBpbml0LCAlbHVLIGJzcywgJWx1SyByZXNlcnZlZCwgJWx1SyBjbWEtcmVzZXJ2ZWQlcyVzKQoALCAAAG1tL3BhZ2VfYWxsb2M6ZGVhZABub256ZXJvIG1hcGNvdW50AG5vbi1OVUxMIG1hcHBpbmcAbm9uemVybyBfcmVmY291bnQAUEFHRV9GTEFHU19DSEVDS19BVF9GUkVFIGZsYWcocykgc2V0AAExQlVHOiBCYWQgcGFnZSBzdGF0ZTogJWx1IG1lc3NhZ2VzIHN1cHByZXNzZWQKAAExQlVHOiBCYWQgcGFnZSBzdGF0ZSBpbiBwcm9jZXNzICVzICBwZm46JTA1bHgKAAExYmFkIGJlY2F1c2Ugb2YgZmxhZ3M6ICUjbHgoJXBHcCkKAHdhcm5fYWxsb2Nfc2hvd19tZW0Abm9uemVybyBfY291bnQAUEFHRV9GTEFHU19DSEVDS19BVF9QUkVQIGZsYWcgc2V0AHBhZ2UgYWxsb2NhdGlvbiBmYWlsdXJlOiBvcmRlcjoldQBVTUVIAWMoJXMpIAABN09uIG5vZGUgJWQgdG90YWxwYWdlczogJWx1CgABNyAgJXMgem9uZTogJWx1IHBhZ2VzIHVzZWQgZm9yIG1lbW1hcAoAAIpuAABSZwAAATQgICVzIHpvbmU6ICVsdSBwYWdlcyBleGNlZWRzIGZyZWVzaXplICVsdQoAATcgICVzIHpvbmU6ICVsdSBwYWdlcyByZXNlcnZlZAoAJnBnZGF0LT5rc3dhcGRfd2FpdAAmcGdkYXQtPnBmbWVtYWxsb2Nfd2FpdABOb3JtYWwAATcgICVzIHpvbmU6ICVsdSBwYWdlcywgTElGTyBiYXRjaDoldQoAT3V0IG9mIG1lbW9yeSAob29tX2tpbGxfYWxsb2NhdGluZ190YXNrKQABNE91dCBvZiBtZW1vcnkgYW5kIG5vIGtpbGxhYmxlIHByb2Nlc3Nlcy4uLgoAU3lzdGVtIGlzIGRlYWRsb2NrZWQgb24gbWVtb3J5CgBPdXQgb2YgbWVtb3J5AE1lbW9yeSBjZ3JvdXAgb3V0IG9mIG1lbW9yeQBPdXQgb2YgbWVtb3J5OiAlcyBwYW5pY19vbl9vb20gaXMgZW5hYmxlZAoAY29tcHVsc29yeQBzeXN0ZW0td2lkZQBvb21fa2lsbF9wcm9jZXNzAAEzJXM6IEtpbGwgcHJvY2VzcyAlZCAoJXMpIHNjb3JlICV1IG9yIHNhY3JpZmljZSBjaGlsZAoAATNLaWxsZWQgcHJvY2VzcyAlZCAoJXMpIHRvdGFsLXZtOiVsdWtCLCBhbm9uLXJzczolbHVrQiwgZmlsZS1yc3M6JWx1a0IsIHNobWVtLXJzczolbHVrQgoAATZvb20ga2lsbGVyICVkICglcykgaGFzIG1tIHBpbm5lZCBieSAlZCAoJXMpCgABNCVzIGludm9rZWQgb29tLWtpbGxlcjogZ2ZwX21hc2s9JSN4KCVwR2cpLCBub2RlbWFzaz0lKnBibCwgb3JkZXI9JWQsIG9vbV9zY29yZV9hZGo9JWhkCgABNENPTVBBQ1RJT04gaXMgZGlzYWJsZWQhISEKAAE2VGFza3Mgc3RhdGUgKG1lbW9yeSB2YWx1ZXMgaW4gcGFnZXMpOgoAATZbICBwaWQgIF0gICB1aWQgIHRnaWQgdG90YWxfdm0gICAgICByc3MgcGd0YWJsZXNfYnl0ZXMgc3dhcGVudHMgb29tX3Njb3JlX2FkaiBuYW1lCgABNlslN2RdICU1ZCAlNWQgJThsdSAlOGx1ICU4bGQgJThsdSAgICAgICAgICU1aGQgJXMKAAE0QlVHOiBmYWlsdXJlIGF0ICVzOiVkLyVzKCkhCgBmaWxlbWFwLmMAdHJ5X3RvX3JlbGVhc2VfcGFnZQABMUJVRzogQmFkIHBhZ2UgY2FjaGUgaW4gcHJvY2VzcyAlcyAgcGZuOiUwNWx4CgBzdGlsbCBtYXBwZWQgd2hlbiBkZWxldGVkAC9ob21lL3F1aXJpbnBhL21ldGFsL21ldGFsLWxpbnV4L2luY2x1ZGUvbGludXgveGFycmF5LmgAeGFzX3NldF9vcmRlcgABMFdlYmFzc2VtYmx5IGNhbid0IGp1bXAgaW50byBjb21wdXRlZCBhZGRyZXNzCgABNEJVRzogZmFpbHVyZSBhdCAlczolZC8lcygpIQoAL2hvbWUvcXVpcmlucGEvbWV0YWwvbWV0YWwtbGludXgvaW5jbHVkZS9saW51eC9zcGlubG9jay5oAHNwaW5fdW5sb2NrX2JoAAAAAAAAAABh");
base64DecodeToExistingUint8Array(bufferView, 29456, "YgAAAAAAAABjAAAAATNpb2N0bChkKVslZF0gKCVsdSwlbHUsJWx1KQoAAAAAAAAAZAAAAGQAAABkAAAAZQAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZgAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABnAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAGQAAABkAAAAZAAAAAEzbmlfc3lzY2FsbFslZF1bJWxkXSAoKQoAATNuaV9zeXNjYWxsWyVkXVslbGRdICglbHUpCgABM25pX3N5c2NhbGxbJWRdWyVsZF0gKCVsdSwlbHUpCgABM25pX3N5c2NhbGxbJWRdWyVsZF0gKCVsdSwlbHUsJWx1KQoAATNuaV9zeXNjYWxsWyVkXVslbGRdICglbHUsJWx1LCVsdSwlbHUpCgABM25pX3N5c2NhbGxbJWRdWyVsZF0gKCVsdSwlbHUsJWx1LCVsdSwlbHUpCgABM25pX3N5c2NhbGxbJWRdWyVsZF0gKCVsdSwlbHUsJWx1LCVsdSwlbHUsJWx1KQoAATRDT05GSUdfQVJDX0RXMl9VTldJTkQgbmVlZHMgdG8gYmUgZW5hYmxlZAoAATYKU3RhY2sgVHJhY2U6CgABMyVzOiBJbXBsZW1lbnQgbWUgcHJvcGVybHkuCgBzZXR1cF9wcm9jZXNzb3IAATMlczogSW1wbGVtZW50IG1lLgoAbWFjaGluZV9oYWx0AAEzJXM6IEltcGxlbWVudCBtZSBwcm9wZXJseS4KAG1hY2hpbmVfcmVzdGFydAABMyVzOiBJbXBsZW1lbnQgbWUuCgBhcmNfaW5pdF9JUlEAATZfX3N3aXRjaF90bwoAAAAAEEwAAKBMAAABMydzZXR1cF9hcmNoX21lbW9yeScgJXM6IEltcGxlbWVudCBtZSBwcm9wZXJseQpzdGFydF9jb2RlOiAlbHUKZW5kX2NvZGU6ICVsdQplbmRfZGF0YTogJWx1CmJyazogJWx1CgBzZXR1cF9hcmNoX21lbW9yeQABM21lbV9pbml0ICVzLgoAbWVtX2luaXQASS1DYWNoZQkJOiBOL0EKAEktQ2FjaGUJCTogJXVLLCAlZHdheS9zZXQsICV1QiBMaW5lLCAlcyVzJXMKAFZJUFQAUElQVAAgYWxpYXNpbmcAAChub3QgdXNlZCkgAEQtQ2FjaGUJCTogTi9BCgBELUNhY2hlCQk6ICV1SywgJWR3YXkvc2V0LCAldUIgTGluZSwgJXMlcyVzCgBTTEMJCTogJXVLLCAldUIgTGluZSVzCgBQZXJpcGhlcmFscwk6ICUjbHglcyVzCgABNiVzAAEzJXM6IEltcGxlbWVudCBtZS4AYXJjX21tdV9pbml0ACVzOiBub3QgaW1wbGVtZW50ZWQuCgB1dGxiX2ludmFsaWRhdGUAMDEyMzQ1Njc4OWFiY2RlZg==");
base64DecodeToExistingUint8Array(bufferView, 31648, "MDEyMzQ1Njc4OUFCQ0RFRgAlcyUxNi4xNmxseAAgAAAlcyU4Ljh4ACVzJTQuNHgAJXMlcyVwOiAlcwoAJXMlcyUuOHg6ICVzCgAlcyVzJXMK");
base64DecodeToExistingUint8Array(bufferView, 31744, "AwIBAAUEBwYICQoLDA0ODwABAgMEBQYHCAkKCwwNDg9pbnB1dA==");
base64DecodeToExistingUint8Array(bufferView, 31796, "yCBuO5BB3HZYYbJNIIO47eij1tawwmSbeOIKoAgICAgICAgICCgoKCgoCAgICAgICAgICAgICAgICAgIoBAQEBAQEBAQEBAQEBAQEAQEBAQEBAQEBAQQEBAQEBAQQUFBQUFBAQEBAQEBAQEBAQEBAQEBAQEBAQEQEBAQEBBCQkJCQkICAgICAgICAgICAgICAgICAgICAhAQEBAI");
base64DecodeToExistingUint8Array(bufferView, 31984, "oBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBABAQEBAQEBAQEBAQEBAQEBAQEBAQEBARABAQEBAQEBAgICAgICAgICAgICAgICAgICAgICAgICEAICAgICAgICKG51bGwp");
base64DecodeToExistingUint8Array(bufferView, 32096, "MDAxMDIwMzA0MDUwNjA3MDgwOTAwMTExMjEzMTQxNTE2MTcxODE5MTAyMTIyMjMyNDI1MjYyNzI4MjkyMDMxMzIzMzM0MzUzNjM3MzgzOTMwNDE0MjQzNDQ0NTQ2NDc0ODQ5NDA1MTUyNTM1NDU1NTY1NzU4NTk1MDYxNjI2MzY0NjU2NjY3Njg2OTYwNzE3MjczNzQ3NTc2Nzc3ODc5NzA4MTgyODM4NDg1ODY4Nzg4ODk4MDkxOTI5Mzk0OTU5Njk3OTg5OTkoaW52YWxpZCBhZGRyZXNzKQAABgAAcBD//wAKAABwEP//AAIAADAQ//8A////AgAKAGlvICAAbWVtIABpcnEgAGRtYSAAYnVzIAA/Pz8gAHNpemUgACA2NGJpdAAgcHJlZgAgd2luZG93ACBkaXNhYmxlZAAgZmxhZ3MgAAAAAAAACv//AAAAAGAQ//9JNABwSy1lcnJvcgAAAP///wAA//8oIU9GKQAocHRydmFsKQABNCVzOiAlZCBjYWxsYmFja3Mgc3VwcHJlc3NlZAoATWVtLUluZm86CgAlbHUgcGFnZXMgUkFNCgAlbHUgcGFnZXMgSGlnaE1lbS9Nb3ZhYmxlT25seQoAJWx1IHBhZ2VzIHJlc2VydmVkCgAlc0NQVTogJWQgUElEOiAlZCBDb21tOiAlLjIwcyAlcyVzICVzICUuKnMKAAAgACVzSGFyZHdhcmUgbmFtZTogJXMKAAFk");
base64DecodeToExistingUint8Array(bufferView, 140036, "BCMCAAQjAg==");
base64DecodeToExistingUint8Array(bufferView, 141076, "FCcCABQnAgAAAAAAfU8AAIJPAACHTwAAkE8AAJVPAACcTwAAn08AAKZPAABURAEAVEQBAFREAQBURAEAVEQBAFREAQBURAEAVEQBAFREAQAB");
var retasmFunc = asmFunc({Math: Math,Int8Array: Int8Array,Uint8Array: Uint8Array,Int16Array: Int16Array,Uint16Array: Uint16Array,Int32Array: Int32Array,Uint32Array: Uint32Array,Float32Array: Float32Array,Float64Array: Float64Array,NaN: NaN,Infinity: Infinity}, {abort:function() { throw new Error('abort'); },kmem: kmem,umem: umem,flush: flush,js_shutdown: js_shutdown,js_emem: js_emem,evt_count: evt_count,tty_read: tty_read,js_run: js_run},memasmFunc);
window["metal"] = {};
window["metal"].memory = retasmFunc.memory;
window["metal"].start_kernel = retasmFunc.start_kernel;
window["metal"].evt_loop = retasmFunc.evt_loop;
window["metal"].__syscall0 = retasmFunc.__syscall0;
window["metal"].__syscall1 = retasmFunc.__syscall1;
window["metal"].__syscall2 = retasmFunc.__syscall2;
window["metal"].__syscall3 = retasmFunc.__syscall3;
window["metal"].__syscall4 = retasmFunc.__syscall4;
window["metal"].__syscall5 = retasmFunc.__syscall5;
window["metal"].__syscall6 = retasmFunc.__syscall6;
})();
